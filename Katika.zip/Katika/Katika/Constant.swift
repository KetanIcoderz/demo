//
//  Constant.swift
//  Katika
//
//  Created by ketan_icoderz on 17/05/17.
//  Copyright © 2017 icoderz123. All rights reserved.
//

// Avenir for the app font: with its alternatives (i.e. thin, medium, heavy)
///*pod 'BraintreeDropIn'

import UIKit


class Constant: NSObject {
    static let developerTest : Bool = false
    static let appLive : Bool = true
    
    //Implementation View height
    static let screenHeightDeveloper : Double = 667
    static let screenWidthDeveloper : Double = 375
    
    //Base URL
    static let BaseURL = "http://13.59.254.172/katika/api/v1/"
    
    //Name And Appdelegate Object
    static let appName: String = "Katika"
    static let appDelegate = (UIApplication.shared.delegate as? AppDelegate)
    
    //System width height
    static let windowWidth: Double = Double(UIScreen.main.bounds.size.width)
    static let windowHeight: Double = Double(UIScreen.main.bounds.size.height)
    
    //Font
    static let kFontLight = "Avenir-Light"
    static let kFontRegular = "Avenir-Book"
    static let kFontSemiBold = "Avenir-Medium"
    static let kFontBold = "Avenir-Heavy"    
    
    //Google Api forKey
    static let apiKeyGoogle = "AIzaSyDQy9sCLvDj2anzl8152anNw-nXC3rBpik" //AIzaSyDuRbLYlvSvQWK_Kwp7pe93yOQ7KbM-Hkc
    
    //Google AnalityKey
    static let apiKeyGoogleAnality = "UA-105722820-1"
    
    //Device Token
    static let DeviceToken = UserDefaults.standard.object(forKey: "DeviceToken")
    
    //Place holder
    static let placeHolder_User = "icon_Demo_Person"
    static let placeHolder_Comman = "Img_SignInView"
    
    //Loading data pagination
    static let int_LoadMax = 10
    
    static let int_Minimumvalue_Use_RewardPoint : Int = 250
    static let int_ReasionofRewardPointAndDollar : Int = 10
    
    //Quick Box Setup
    static let kQBAuthKey = "Hwbq4MHumkR99Qj" //MbyaeEc-BP3Jfj7
    static let kQBAuthSecret = "NwKOVeA9L75SDmC" //kyQzt-4r-OJAt-w
    static let kQBAccountKey = "vWVR7UHdygNsnwbV3NcK" //z98SEjY2jLkDM5DzhEZa
    static let kQBApplicationID:UInt = 64028 //61395
    
    //Search listing hide or not
    static let SearchlistingresultKatikaDirectory : Bool = false
    static let KatikaDirectoryMapShow : Bool = false
    static let KatikaDirectoryClustoringShow : Bool = false
    
//    //Manage Font
//    func manageFont(font: Double) -> Double
//    {
//        return (font * Constant.windowHeight) / Constant.screenHeightDeveloper
//        // println("Hello \(name).... All your base belong to us!")
//    }
    
    // Using a property
    var firstName: String!
    func printSomething(name: String)
    {
        // println("Hello \(name).... All your base belong to us!")
    }
}



//MARK: - Manage function for value save -
extension NSDictionary {
    func getStringForID(key: String) -> String! {
        
        var strKeyValue : String = ""
        if self[key] != nil {
            if (self[key] as? Int) != nil {
                strKeyValue = String(self[key] as? Int ?? 0)
            } else if (self[key] as? String) != nil {
                strKeyValue = self[key] as? String ?? ""
            }else if (self[key] as? Double) != nil {
                strKeyValue = String(self[key] as? Double ?? 0)
            }else if (self[key] as? Float) != nil {
                strKeyValue = String(self[key] as? Float ?? 0)
            }else if (self[key] as? Bool) != nil {
                let bool_Get = self[key] as? Bool ?? false
                if bool_Get == true{
                    strKeyValue = "1"
                }else{
                    strKeyValue = "0"
                }
            }
        }
        return strKeyValue
    }
    
    func getArrayVarification(key: String) -> NSArray {
        
        var strKeyValue : NSArray = []
        if self[key] != nil {
            if (self[key] as? NSArray) != nil {
                strKeyValue = self[key] as? NSArray ?? []
            }
        }
        return strKeyValue
    }
}


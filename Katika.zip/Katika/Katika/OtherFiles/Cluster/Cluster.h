//
//  Cluster.h
//  Cluster
//
//  Created by Lasha Efremidze on 4/13/17.
//  Copyright © 2017 efremidze. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Cluster.
FOUNDATION_EXPORT double ClusterVersionNumber;

//! Project version string for Cluster.
FOUNDATION_EXPORT const unsigned char ClusterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Cluster/PublicHeader.h>



//
//  QBAuthHeader.h
//  Quickblox
//
//  Created by QuickBlox team on 6/13/14.
//  Copyright (c) 2016 QuickBlox. All rights reserved.
//

#ifndef Quickblox_QBAuthHeader_h
#define Quickblox_QBAuthHeader_h

#import <Quickblox/QBRequest+QBAuth.h>

#endif

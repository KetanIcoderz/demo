//
//  Classes.h
//  Chat
//
//  Created by QuickBlox team on 9/12/12.
//  Copyright (c) 2016 QuickBlox. All rights reserved.
//

#import <Quickblox/QBChatDefinitions.h>
#import <Quickblox/QBChatBusiness.h>

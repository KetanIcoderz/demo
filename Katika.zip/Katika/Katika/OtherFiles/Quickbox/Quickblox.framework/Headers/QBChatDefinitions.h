//
//  Definitions.h
//  Chat
//
//  Created by QuickBlox team on 9/12/12.
//  Copyright (c) 2016 QuickBlox. All rights reserved.
//

#import <Quickblox/QBChatTypes.h>
#import <Quickblox/ChatDelegates.h>

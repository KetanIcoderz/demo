//
//  QBChatHeader.h
//  Quickblox
//
//  Created by QuickBlox team on 9/1/14.
//  Copyright (c) 2016 QuickBlox. All rights reserved.
//

#import <Quickblox/QBChat.h>
#import <Quickblox/QBRequest+QBChat.h>
#import <Quickblox/QBCompletionTypes.h>

//
//  BusinessDetailMoreViewController.swift
//  Katika
//
//  Created by Apple on 17/05/18.
//  Copyright © 2018 icoderz123. All rights reserved.
//

import UIKit
import MessageUI
import SwiftMessages

class BusinessDetailMoreViewController: UIViewController,MFMailComposeViewControllerDelegate {

    //Product Data
    var obj_Get = ProductObject ()

    //Label Declaration
    @IBOutlet var lbl_ExploreTheMenu: UILabel!
    @IBOutlet var lbl_Hours: UILabel!
    @IBOutlet var lbl_PhoneNumber: UILabel!
    @IBOutlet var lbl_Website: UILabel!
    @IBOutlet var lbl_CompanuDecription: UILabel!
    @IBOutlet var lbl_EmailAddress: UILabel!
    
    //Button Declaration
    @IBOutlet var btn_ExploreTheMenu: UIButton!
    @IBOutlet var btn_PhoneNumber: UIButton!
    @IBOutlet var btn_WebSite: UIButton!
    @IBOutlet var btn_EmailAddress: UIButton!
    
    @IBOutlet var con_ExploreMenu: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
//        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - MessageView controller -
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    //MARK: - Comman Method -
    func commanMethod(){
        self.navigationItem.title = obj_Get.str_Business_title as String
        
        lbl_ExploreTheMenu.text = obj_Get.str_Explore_menu as String
        lbl_Hours.text = obj_Get.str_Open_hr_json as String
        var arr = Array(obj_Get.str_Open_hr_json as String)
        lbl_PhoneNumber.text = obj_Get.str_Phone_number as String
        lbl_Website.text = obj_Get.str_Website as String
        lbl_CompanuDecription.text = obj_Get.str_Business_description as String
        lbl_EmailAddress.text = obj_Get.str_Business_email as String
        
       var arr2 = convertString(toDictionary: obj_Get.str_Open_hr_json as String)
        
        var arr_Mutable : NSArray = arr2 as! NSArray
        var str_Time : String = ""
        for i in 0..<arr_Mutable.count{
            let dic = arr_Mutable[i] as! NSDictionary
            if str_Time == ""{
                str_Time = "\(dic["day"] as! String) \(dic["start_time"] as! String) - \(dic["end_time"] as! String)"
            }else{
                str_Time = str_Time + "\n" + "\(dic["day"] as! String) \(dic["start_time"] as! String) - \(dic["end_time"] as! String)"
            }
        }
        lbl_Hours.text = str_Time
        
        //Explore menu hide show
        if obj_Get.str_ExporeMenuShow == "0"{
            con_ExploreMenu.constant = 0
        }
    }
    
    func convertString(toDictionary str: String?) -> [Any]? {
        var jsonError: Error?
        let objectData: Data? = str?.data(using: .utf8)
        var json: [Any]? = nil
        if let aData = objectData {
            json = try! JSONSerialization.jsonObject(with: aData, options: .mutableContainers) as? [Any]
        }
        return json
    }
    func shareMail(receiverMain : String,Body : String){
        if MFMailComposeViewController.canSendMail() {
            let emailDialog = MFMailComposeViewController()
            emailDialog.mailComposeDelegate = self
            let htmlMsg: String = "<html><body><p>\(Body)</p></body></html>"
            emailDialog.setToRecipients([receiverMain])
            
            emailDialog.setSubject("email subject")
            emailDialog.setMessageBody(htmlMsg, isHTML: true)
            present(emailDialog, animated: true, completion: { _ in })
        }else{
            messageBar.MessageShow(title: NSLocalizedString("Mail account not comfortable in your device.", comment: "") as NSString, alertType: MessageView.Layout.CardView, alertTheme: .success, TopBottom: true)
        }
    }
    
    
    //MARK: - Button Event -
    @IBAction func btn_Back(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    @IBAction func btn_ExploreTheMenu(_ sender: Any) {
        if let url = URL(string: obj_Get.str_Explore_menu as! String) {
            if UIApplication.shared.canOpenURL(url) {
                openURLToWeb(url : url)
            }
        }
    }
    @IBAction func btn_PhoneNumber(_ sender: Any) {
        if let url = URL(string: "tel://\(obj_Get.str_Phone_number)"), UIApplication.shared.canOpenURL(url) {
            if #available(iOS 10, *) {
                UIApplication.shared.open(url)
            }else{
                UIApplication.shared.openURL(url)
            }
        }
    }
    @IBAction func btn_WebSite(_ sender: Any) {
        if obj_Get.str_Website as String != ""{
            let url = URL(string:obj_Get.str_Website as String)!
            openURLToWeb(url : url)
        }
    }
    @IBAction func btn_EmailAddress(_ sender: Any) {
        let str_Value : String = "Business Name : \(obj_Get.str_Business_title)"
        self.shareMail(receiverMain:obj_Get.str_Business_email as String,Body : str_Value)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

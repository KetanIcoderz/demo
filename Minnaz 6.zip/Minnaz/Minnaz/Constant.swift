//
//  Constant.swift
//  SportLite
//
//  Created by iCoderz_07 on 11/09/17.
//  Copyright © 2017 iCoderz. All rights reserved.
//

import Foundation
import UIKit

struct GlobalConstants
{
    // Constant define here.
    
    static let developerTest : Bool = false
  
    //Implementation View height
    static let screenHeightDeveloper : Double = 667
    static let screenWidthDeveloper : Double = 375
    
    //Base URL
//    static let BaseURL = "http://www.icoderzsolutions.com/client_a/minazz/api/v1/"
//    static let BaseURL = "http://www.icoderzsolutions.com/client_a/minazz/api/v2/"
//    static let BaseURL = "http://www.icoderzsolutions.com/client_a/minazz/api/v3/"
    static let BaseURL = "http://www.minnaz.com/admin/api/v3/"
    
    
    //Name And Appdelegate Object
    static let appName: String = "Minnaz"
    static let appDelegate = (UIApplication.shared.delegate as? AppDelegate)
    static let kFontRatio =  (UIScreen.main.bounds.size.width/375)
  
    //System width height
    static let windowWidth: Double = Double(UIScreen.main.bounds.size.width)
    static let windowHeight: Double = Double(UIScreen.main.bounds.size.height)
    
    //Font
    static let kFontLight = "Roboto-Light"
    static let kFontRegular = "Roboto-Regular"
    static let kFontMedium = "Roboto-Medium"
    static let kFontSemiBold = "Avenir-Medium"
    static let kFontBold = "Avenir-Heavy"
    
    //Google Api forKey
    static let apiKeyGoogle = "AIzaSyCuuATFaZqxiN-7tvSkEvEN41G1GP_M3uE"
    
    //Loading data pagination
    static let int_LoadMax = 12
    static let int_LoadMaxCollection = 12
    
    //Google AnalityKey
    static let apiKeyGoogleAnality = "UA-105722820-1"
    
    //Device Token
    static let DeviceToken = UserDefaults.standard.object(forKey: "DeviceToken")
    
    //Place holder
    static let placeHolder_User = "icon_PlaceHolderUser"
    static let placeHolder_Comman = "icon_PlaceHolderSquare"
    
    //App Color
    static let appColor = UIColor(red: 44/255, green: 62/255, blue: 84/255, alpha: 1.0)
    static let appGreenColor = UIColor(red: 0/255, green: 207/255, blue: 255/255, alpha: 1.0)
    static let appPopupBackgroundColor = UIColor(red: 232/255, green: 232/255, blue: 232/255, alpha: 1.0)
    
    //Google Search
    static let googleImageSearch = "AIzaSyBd0vpZ05n2frDI2dUoTA_HSiFB4xa8Euw"
    
    //tempIMage232
    static let img_Temp = "https://hellodotcom.hello.com/img_/hello_logo_hero.png"
    
    //Added Time Limitation in second
    static let int_AddedUsingReviewTime = 30
}

//Comman Function
//func removeSpecialCharsFromString(text: String) -> String {
//    let okayChars : Set<Character> =
//        Set("abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLKMNOPQRSTUVWXYZ1234567890".characters)
//    return String(text.characters.filter {okayChars.contains($0) })
//}

func removeSpecialCharsFromString(text: String) -> String {

    let charsToRemove: Set<Character> = Set("[{}\\[\\]+:?,\"\'".characters)
    let newNumberCharacters = String(text.characters.filter { !charsToRemove.contains($0) })
    print(newNumberCharacters) //prints 1 832 8316486
     return newNumberCharacters
}


// MARK: - Object Class -
class GlobalObjectCard : NSObject {
    var str_category_id: String = ""
    var str_subcategory_id: String = ""
    var str_category_name: String = ""
    var str_user_id: String = ""
    var str_parent_id: String = ""
    var str_sub_cat_count: String = ""
    var str_total_card: String = ""
    var str_percentage: String = ""
    
    var arr_FlatCard: NSMutableArray = []
    var str_FlatCard_id: String = ""
    var str_FlatCard_keyword: String = ""
    var str_FlatCard_card_image: String = ""
    var str_FlatCard_card_type: String = ""
    var str_FlatCard_store_type: String = ""
    var str_FlatCard_dictionary_id: String = ""
    var str_FlatCard_from_language: String = ""
    var str_FlatCard_to_language: String = ""
    var isCardFront: Bool = true
    var str_FlatCard_traslation_Play: String = ""
    var str_FlatCard_abbrivation: String = ""
    var str_FlatCard_abbrivation_Lexin_From: String = ""
    var str_FlatCard_abbrivation_Lexin_To: String = ""
    var data_ImageData: NSData? = nil
    var str_FlatCard_category_id: String = ""
    var str_FlatCard_sub_category_id: String = ""
    var str_FlatCard_color_code: String = ""
    var str_FlatCard_card_thumb: String = ""
    var str_FlatCard_box: String = ""
    
    
    var arr_FlatCardInfo: NSMutableArray = []
    var str_FlatCardInfo_id: String = ""
    var str_FlatCardInfo_card_id: String = ""
    var str_FlatCardInfo_meanings: String = ""
    var str_FlatCardInfo_translate: String = ""
    var str_FlatCardInfo_example: String = ""
    var str_FlatCardInfo_inflection: String = ""
    var str_FlatCardInfo_synonym: String = ""
    var str_FlatCardInfo_another_word: String = ""
    var str_FlatCardInfo_another_created_at: String = ""
 
    var str_Quiz_Id: String = ""
    var str_Quiz_Title: String = ""
    var str_Quiz_SubTitle: String = ""
    var str_Quiz_Count: String = ""
    var str_Quiz_Term: String = ""
    var str_Quiz_Defination: String = ""
    var str_Quiz_Rank: String = ""
    var str_Quiz_Image: String = ""
    var str_CardSaveFlag: String = "-1"
    var str_CardID: String = ""
    var str_CatSave: String = ""
    var str_Level: String = ""
    
    var str_Statisic_category_id: String = ""
    var str_Statisic_category_name: String = ""
    var str_Statisic_parcentage: String = ""
    var arr_Statisic_chart_data_Sub: NSMutableArray = []
    
    var str_Statisic_total_card_readed: String = ""
    var str_Statisic_total_last_week_cards: String = ""
    var str_Statisic_total_last_month_cards: String = ""
    var arr_Statisic_day_wise_count: NSMutableArray = []
    var arr_Statisic_month_wise_count: NSMutableArray = []
    
    var str_Statisic_total_minute_spend: String = ""
    var str_Statisic_total_last_week_minute: String = ""
    var str_Statisic_total_last_month_sums: String = ""
    var str_Statisic_day_wise_sum: String = ""
    var str_Statisic_month_wise_sum: String = ""
    
    var str_Statisic_counts: String = ""
    var str_Statisic_card_id: String = ""
    var str_Statisic_creator_id: String = ""
    var str_Statisic_keyword: String = ""
    var str_Statisic_sub_category_id: String = ""
    var str_Statisic_from_language: String = ""
    var str_Statisic_to_language: String = ""
    var str_Statisic_dictionary_id: String = ""
    var str_Statisic_card_image: String = ""
    var str_Statisic_audio_file: String = ""
    var str_Statisic_color_code: String = ""
    var str_Statisic_card_type: String = ""
    var str_Statisic_store_type: String = ""
}


//MARK: - Manage function for value save -
extension NSDictionary {
    func getStringForID(key: String) -> String! {
        
        var strKeyValue : String = ""
        if self[key] != nil {
            if (self[key] as? Int) != nil {
                strKeyValue = String(self[key] as? Int ?? 0)
            } else if (self[key] as? String) != nil {
                strKeyValue = self[key] as? String ?? ""
            }else if (self[key] as? Double) != nil {
                strKeyValue = String(self[key] as? Double ?? 0)
            }else if (self[key] as? Float) != nil {
                strKeyValue = String(self[key] as? Float ?? 0)
            }else if (self[key] as? Bool) != nil {
                let bool_Get = self[key] as? Bool ?? false
                if bool_Get == true{
                    strKeyValue = "1"
                }else{
                    strKeyValue = "0"
                }
            }
        }
        return strKeyValue
    }
    
    func getArrayVarification(key: String) -> NSArray {
        
        var strKeyValue : NSArray = []
        if self[key] != nil {
            if (self[key] as? NSArray) != nil {
                strKeyValue = self[key] as? NSArray ?? []
            }
        }
        return strKeyValue
    }
}





//
//  Use this file to import your target's public headers that you would like to expose to Swift.
//

#ifndef Minnaz_Bridging_Header_h
#define Minnaz_Bridging_Header_h


@import UIKit;
@import Foundation;
@import SystemConfiguration;
@import MobileCoreServices;

//com.app.katika.payments
//com.app.katika
//com.testkatika

// Quick box declaration
#import <GoogleSignIn/GoogleSignIn.h>


#endif /* Katika_Bridging_Header_h */


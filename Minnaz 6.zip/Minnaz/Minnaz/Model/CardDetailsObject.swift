//
//  CardDetailsObject.swift
//  Minnaz
//
//  Created by Apple on 01/01/18.
//  Copyright © 2018 iCoderz. All rights reserved.
//

import Foundation
class CardDetailsObject {
      var nCardId: Int = 0
      var strCardName: String = ""
    
      var strCardNameTo: String = ""
      var strCardNameFrom: String = ""
    
      var strCardImageUrl: String = ""
      var strCardGoogleMeaning: String = ""
      var strCardOtherMeaning: String = ""
      var isCardFront: Bool = true
  
    var str_CardSaveFlag: String = "-1"
    var str_CardID: String = ""
    
    var arr_ConvertString : NSMutableArray = []
    
    var data_Image : NSData? = nil
}

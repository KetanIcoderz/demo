//
//  setsListObject.swift
//  QuizletSwift
//
//  Created by iCoderz_02 on 29/12/17.
//  Copyright © 2017 QuizletSwift. All rights reserved.
//

import UIKit

class setsListObject: NSObject {

    var strid: Any = 0
    var strtitle: String = ""
    var strCreateBy: String = ""
    var strTotalCard : Any = 0
    var strSearch: String = ""
  
}

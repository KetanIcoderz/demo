//
//  RenameCategoryViewController.swift
//  Minnaz
//
//  Created by iCoderz_07 on 13/02/18.
//  Copyright © 2018 iCoderz. All rights reserved.
//

import UIKit
import SwiftMessages

protocol DismissRenameCategoryDelegate: class {
    func ClickOptionRenameCategory(info: NSInteger)
}

class RenameCategoryViewController: UIViewController {

     weak var delegate :DismissRenameCategoryDelegate? = nil
    
    //Declaration TextFiled
    @IBOutlet weak var tf_CategoryName: UITextField!
    
    //Declaration Button
    @IBOutlet weak var btn_Accept: UIButton!
    
    var str_Cat_Id : String = ""
    var str_SubCat_Id : String = ""
    var str_Title : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tf_CategoryName.text = str_Title
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    // MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any){
        dismiss(animated:true, completion: nil)
    }
    @IBAction func btn_Accept(_ sender:Any){
        if tf_CategoryName.text != ""{
            
            self.Post_CategoryRename()
            
//            //Alert show for Header
//            messageBar.MessageShow(title: "Rename Category Successfully" as NSString, alertType: MessageView.Layout.cardView, alertTheme: .success, TopBottom: true)
//
//            dismiss(animated:true, completion: nil)
        }
    }
    
    
    func Post_CategoryRename(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)vocab_category_rename"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "user_id" : objUser?.user_UserID,
            "category_id" : str_Cat_Id,
            "parent_id" : str_SubCat_Id,
            "category_name" : tf_CategoryName.text,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "vocab_category_rename"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = true
        webHelper.startDownload()

    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}



extension RenameCategoryViewController : WebServiceHelperDelegate{
    //MARK: - Webservice Helper -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        
        if strRequest == "vocab_category_rename" {
            
            self.dismiss(animated: true) {
                self.delegate?.ClickOptionRenameCategory(info: 1)
            }
            
            userObjectUpdate(dict_Get : response)

        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
    }
}




//
//  StatisticsViewController.swift
//  Minnaz
//
//  Created by iCoderz_07 on 16/11/17.
//  Copyright © 2017 iCoderz. All rights reserved.
//

import UIKit
import Charts
import SwiftyJSON

class StatisticsViewController: UIViewController,ChartViewDelegate {
    
    //mark - PieChart
    @IBOutlet var PieChatView: PieChartView!
    @IBOutlet var sliderX: UISlider!
    @IBOutlet var sliderY: UISlider!
    @IBOutlet var sliderTextX: UITextField!
    @IBOutlet var sliderTextY: UITextField!
    
    @IBOutlet var btn_Word: UIButton!
    @IBOutlet var btn_Minute: UIButton!
    @IBOutlet var btnLastWeekPress: UIButton!
    @IBOutlet var btnLastMonthPress: UIButton!
    
    @IBOutlet var lbl_Week: UILabel!
    @IBOutlet var lbl_Month: UILabel!
    @IBOutlet var lbl_Total: UILabel!
    
    @IBOutlet var viewLastWeek: UIView!
    @IBOutlet var viewLastMonth: UIView!
    
    @IBOutlet var btn_Class : UIButton!
    
    var CategoryName : NSMutableArray = []
    var CategoryPer : NSMutableArray = []
    
    var arr_Main_Chart : NSMutableArray = []
    var obj_Words = GlobalObjectCard ()
    var obj_Minutes = GlobalObjectCard ()
    var obj_Main_Selected = GlobalObjectCard ()
    var arr_Problemetic : NSMutableArray = []
    
    @IBOutlet var tblViewProblematic: UITableView!
    var tbl_reload_Number : Int = 0
    var isHighLighted:Bool = false
    
    var arr_Months : NSMutableArray = []
    
//    var itemData = [5, 15, 20, 30, 15, 25, 5]
    var arr_Data : NSMutableArray = []
    
    var isSubCategory : Bool = false
    
    //CombineChart
    @IBOutlet var CombinChart: CombinedChartView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Minnaz"
        
        viewLastWeek.backgroundColor = UIColor(red: 0/255, green: 174/255, blue: 239/255, alpha: 1)
        
    }
    override func viewWillAppear(_ animated: Bool) {
        if objUser?.user_Type == "0"{
            btn_Class.isHidden = true
        }else{
            btn_Class.isHidden = false
        }
        
        self.Get_Statistics()
    }
    
    func CreateCombineChart()
    {
        //        CombinChart.delegate = self
        CombinChart.chartDescription?.enabled = false
        CombinChart.drawBarShadowEnabled = false
        CombinChart.highlightFullBarEnabled = false
        
        CombinChart.backgroundColor = UIColor.black
        
        CombinChart.drawOrder = [DrawOrder.bar.rawValue,
                                 DrawOrder.line.rawValue]
        
        let l = CombinChart.legend
        l.form = .none
        l.textColor = .clear
        //        l.wordWrapEnabled = true
        //        l.horizontalAlignment = .center
        //        l.verticalAlignment = .bottom
        //        l.orientation = .horizontal
        //        l.drawInside = false
        
        let rightAxis = CombinChart.rightAxis
        rightAxis.axisMinimum = 0
        
        rightAxis.labelTextColor = UIColor.black
        
        let leftAxis = CombinChart.leftAxis
        leftAxis.axisMinimum = 0
        
        leftAxis.labelTextColor = UIColor.white
        
        let xAxis = CombinChart.xAxis
        xAxis.labelPosition = .bottom
        xAxis.axisMinimum = 0
        xAxis.granularity = 1
        xAxis.valueFormatter = self
        
        xAxis.labelTextColor = UIColor.white
        
        self.setChartData()
        
        
    }
    //Pie Chart
    func updateChartData() {
        
        PieChatView.animate(xAxisDuration: 1.4, easingOption: .easeOutBack)
        
        self.setDataCount(CategoryName.count, range: 100)
    }
    
    func setDataCount(_ count: Int, range: UInt32)
    {
        let entries = (0..<count).map { (i) -> PieChartDataEntry in
            // IMPORTANT: In a PieChart, no values (Entry) should have the same xIndex (even if from different DataSets), since no values can be drawn above each other.
            
            return PieChartDataEntry(value: Double(CategoryPer[i] as! String)!,
                                     label: CategoryName[i % CategoryName.count] as? String)
        }
        
        let set = PieChartDataSet(values: entries, label: "")
        set.drawIconsEnabled = false
        //        set.sliceSpace = 2
        
        //RJ Change
        set.colors =
            [UIColor(red: 239/255, green: 213/255, blue: 88/255, alpha: 1)]
            + [UIColor(red: 245/255, green: 88/255, blue: 67/255, alpha: 1)]
            + [UIColor(red: 21/255, green: 197/255, blue: 236/255, alpha: 1)]
        
        let data = PieChartData(dataSet: set)
        
        let pFormatter = NumberFormatter()
        pFormatter.numberStyle = .percent
        pFormatter.maximumFractionDigits = 1
        pFormatter.multiplier = 1
        pFormatter.percentSymbol = " %"
        
        data.setValueFormatter(DefaultValueFormatter(formatter: pFormatter))
        
        data.setValueFont(.systemFont(ofSize: 11, weight: .bold))
        data.setValueTextColor(.white)
        
        PieChatView.data = data
        PieChatView.highlightValues(nil)
    }
    
    
    // TODO: Cannot override from extensions
    //extension DemoBaseViewController: ChartViewDelegate {
    func chartValueSelected(_ chartView: ChartViewBase, entry: ChartDataEntry, highlight: Highlight){
        
        NSLog("chartValueSelected");
        if chartView == PieChatView && isSubCategory == false
        {
            CategoryName = []
            CategoryPer = []
            for i in 0..<arr_Main_Chart.count{
                if i == Int(highlight.x){
                    let obj : GlobalObjectCard = arr_Main_Chart[i] as! GlobalObjectCard
                    
                    for j in 0..<obj.arr_Statisic_chart_data_Sub.count{
                        let obj2 : GlobalObjectCard = obj.arr_Statisic_chart_data_Sub[j] as! GlobalObjectCard
                        
                        CategoryName.add(obj2.str_Statisic_category_name)
                        CategoryPer.add(obj2.str_Statisic_parcentage)
                    }
                    break
                }
            }
            isSubCategory = true;
            self.updateChartData()
        }
        else{
            isSubCategory = false;
            
            CategoryName = []
            CategoryPer = []
            for i in 0..<arr_Main_Chart.count{
                let obj : GlobalObjectCard = arr_Main_Chart[i] as! GlobalObjectCard
                CategoryName.add(obj.str_Statisic_category_name)
                CategoryPer.add(obj.str_Statisic_parcentage)
            }
            
            self.updateChartData()
        }
    }
    
    func chartValueNothingSelected(_ chartView: ChartViewBase) {
        NSLog("chartValueNothingSelected");
    }
    
    func chartScaled(_ chartView: ChartViewBase, scaleX: CGFloat, scaleY: CGFloat) {
        
    }
    
    func chartTranslated(_ chartView: ChartViewBase, dX: CGFloat, dY: CGFloat) {
        
    }
    
    
    //Combine chart
    func setChartData() {
        let data = CombinedChartData()
        data.lineData = generateLineData()
        data.barData = generateBarData()
        
        CombinChart.xAxis.axisMaximum = data.xMax + 0.25
        
        
        CombinChart.data = data
    }
    
    func generateLineData() -> LineChartData {
        
        let entries = (0..<arr_Data.count).map {
            (i) -> ChartDataEntry in
            return ChartDataEntry(x: Double(i) + 0.3, y: Double(arr_Data[i] as! String)!)
        }
        
        let set = LineChartDataSet(values: entries, label: "Line DataSet")
        set.setColor(UIColor(red: 0/255, green: 174/255, blue: 239/255, alpha: 1))
        set.lineWidth = 2.0
        set.setCircleColor(UIColor(red: 0/255, green: 174/255, blue: 239/255, alpha: 1))
        set.circleRadius = 5
        set.circleHoleRadius = 2.5
        set.fillColor = UIColor(red: 255/255, green: 255/255, blue: 31/255, alpha: 1)
        set.mode = .linear
        set.drawValuesEnabled = true
        set.valueFont = .systemFont(ofSize: 10)
        set.valueTextColor = UIColor.clear
        set.axisDependency = .left
        
        return LineChartData(dataSet: set)
    }
    
    func generateBarData() -> BarChartData
    {
        
        let entries1 = (0..<arr_Data.count).map { (i) -> BarChartDataEntry in
            return BarChartDataEntry(x: 0, y: Double(arr_Data[i] as! String)!)
        }
        let entries2 = (0..<arr_Data.count).map { _ -> BarChartDataEntry in
            return BarChartDataEntry(x: 0, y: Double( 0))
        }
        
        let set1 = BarChartDataSet(values: entries1, label: "Bar 1")
        set1.setColor(UIColor(red: 0/255, green: 174/255, blue: 239/255, alpha: 0.3))
        set1.valueTextColor = .clear
        set1.valueFont = .systemFont(ofSize: 10)
        set1.axisDependency = .left
        
        let set2 = BarChartDataSet(values: entries2, label: "")
        set2.stackLabels = ["Stack 1", "Stack 2"]
        set2.colors = [UIColor(red: 61/255, green: 165/255, blue: 255/255, alpha: 0)]
        set2.valueTextColor = UIColor(red: 61/255, green: 165/255, blue: 255/255, alpha: 0)
        set2.valueFont = .systemFont(ofSize: 10)
        set2.axisDependency = .left
        
        let groupSpace = 0.06
        let barSpace = 0.02 // x2 dataset
        let barWidth = 0.45 // x2 dataset
        // (0.45 + 0.02) * 2 + 0.06 = 1.00 -> interval per "group"
        
        let data = BarChartData(dataSets: [set1, set2])
        data.barWidth = barWidth
        
        // make this BarData object grouped
        data.groupBars(fromX: 0, groupSpace: groupSpace, barSpace: barSpace)
        
        return data
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Other Event -
    func selectedButton(){
        
    }
    func reloadData(){
        //Reload data chart
        let l1 = PieChatView.legend
        l1.form = .none
        l1.textColor = .clear
        
        CategoryName = []
        CategoryPer = []
        for i in 0..<arr_Main_Chart.count{
            let obj : GlobalObjectCard = arr_Main_Chart[i] as! GlobalObjectCard
            CategoryName.add(obj.str_Statisic_category_name)
            CategoryPer.add(obj.str_Statisic_parcentage)
        }
        
        PieChatView.noDataTextColor = UIColor.white
        PieChatView.noDataFont = UIFont(name: GlobalConstants.kFontRegular, size: manageFont(font: 17))
        PieChatView.clear()
        if CategoryName.count != 0{
            self.updateChartData()
            PieChatView.delegate = self
            PieChatView.animate(xAxisDuration: 1.4, easingOption: .easeOutBack)
        }
     
        //Data Graph
        self.reloadDataGraph()
        
        //Probalmatic word
        tblViewProblematic.reloadData()
    }
    
    func reloadDataGraph(){
        if btn_Word.isSelected == true{
            obj_Main_Selected = obj_Words
        }else{
            obj_Main_Selected = obj_Minutes
        }
        
        lbl_Total.text = obj_Main_Selected.str_Statisic_total_card_readed
        lbl_Week.text = obj_Main_Selected.str_Statisic_total_last_week_cards
        lbl_Month.text = obj_Main_Selected.str_Statisic_total_last_month_cards
        
        
        if btnLastWeekPress.isSelected == true{
            arr_Months = ["Mon", "Tue", "Wed",
                      "Thu", "Fri", "Sat",
                      "Sun"]
            
            arr_Data = []
            for i in 0..<obj_Main_Selected.arr_Statisic_day_wise_count.count{
                if obj_Main_Selected.arr_Statisic_day_wise_count[i] as! String == ""{
                    arr_Data.add("0")
                }else{
                    arr_Data.add(obj_Main_Selected.arr_Statisic_day_wise_count[i] as! String)
                }
            }
        }else{
            let arr_MonthTemp : NSMutableArray = []
            for i in 0..<obj_Main_Selected.arr_Statisic_month_wise_count.count{
                arr_MonthTemp.add(String(i))
            }
            arr_Months = arr_MonthTemp
            
            arr_Data = []
            for i in 0..<obj_Main_Selected.arr_Statisic_month_wise_count.count{
                if obj_Main_Selected.arr_Statisic_month_wise_count[i] as! String == ""{
                    arr_Data.add("0")
                }else{
                    arr_Data.add(obj_Main_Selected.arr_Statisic_month_wise_count[i] as! String)
                }
            }
        }
        
        self.CreateCombineChart()
    }
    
    
    // MARK: - Button Event -
    @IBAction func wordClick(_ sender: UIButton) {
        btn_Word.isSelected = true
        btn_Minute.isSelected = false
        
        btn_Word.backgroundColor = UIColor.black
        btn_Minute.backgroundColor = UIColor(red: 19/256.0, green: 18/256.0, blue: 40/256.0, alpha: 1.0)
        
        self.reloadDataGraph()
    }
    @IBAction func minutesClick(_ sender: UIButton) {
        btn_Minute.isSelected = true
        btn_Word.isSelected = false
        
        btn_Minute.backgroundColor = UIColor.black
        btn_Word.backgroundColor = UIColor(red: 19/256.0, green: 18/256.0, blue: 40/256.0, alpha: 1.0)
        
        self.reloadDataGraph()
    }
    
    @IBAction func btnLastWeekPress(_ sender: Any) {
        btnLastWeekPress.isSelected = true
        btnLastMonthPress.isSelected = false
        
        self.reloadDataGraph()
        viewLastWeek.backgroundColor = UIColor(red: 0/255, green: 174/255, blue: 239/255, alpha: 1)
        viewLastMonth.backgroundColor = UIColor.white
        
    }
    
    @IBAction func btnLastMonthPress(_ sender: Any) {
        btnLastWeekPress.isSelected = false
        btnLastMonthPress.isSelected = true
        
        self.reloadDataGraph()
        viewLastMonth.backgroundColor = UIColor(red: 0/255, green: 174/255, blue: 239/255, alpha: 1)
        viewLastWeek.backgroundColor = UIColor.white
    }
    
    
    @IBAction func btn_Share (_ sender : Any){
        
        shareFunction(textData : "Statistics From Minnaz \n\n|Word|\nLast Week : \(obj_Words.str_Statisic_total_last_week_cards)\nLast Month : \(obj_Words.str_Statisic_total_last_month_cards)\nTotal : \(obj_Words.str_Statisic_total_card_readed)\n\n|Minutes|\nLast Week : \(obj_Minutes.str_Statisic_total_last_week_cards)\nLast Month : \(obj_Minutes.str_Statisic_total_last_month_cards)\nTotal : \(obj_Minutes.str_Statisic_total_card_readed)",viewPresent: self)
    }
    
    @IBAction func btn_ClearHistory (_ sender : Any){
        let alert = UIAlertController(title: GlobalConstants.appName, message: "Are you sure want clear history?", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Yes", style: UIAlertActionStyle.default, handler: { (action) in
            self.Post_ClearHistory()
        }))
        alert.addAction(UIAlertAction(title: "No", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    
    //MARK: - Service Method -
    func Get_Statistics(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)get_today_category_statistics"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "user_id" : objUser?.user_UserID,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "get_today_category_statistics"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.startDownload()
        
    }
    func Post_ClearHistory(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)reset_statistics"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "user_id" : objUser?.user_UserID,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "reset_statistics"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.startDownload()
        
    }
}

// MARK: - Extension IAxidValue -

extension StatisticsViewController: IAxisValueFormatter {
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        return arr_Months[Int(value) % arr_Months.count] as! String
    }
}


// MARK: - Cell -

class HeaderCell: UITableViewCell {
    
    @IBOutlet var btn_Click: UIButton!
    @IBOutlet var btnUpDown: UIButton!
    
    
    @IBOutlet var lbl_Title: UILabel!
}

class StatisticeCell: UITableViewCell {
    
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var lblCount: UILabel!
    @IBOutlet var viewCount: UIView!
    
    @IBOutlet var lbl_WordCount: UILabel!
    @IBOutlet var lbl_MinuteCount: UILabel!
}

// MARK: - TableView Delegate -

extension StatisticsViewController : UITableViewDataSource,UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int{
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat{
        return 50
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellHeader") as! HeaderCell
        
        if arr_Problemetic.count != 0{
            cell.btnUpDown.isHidden = false
            
            if isHighLighted == true
            {
                cell.btnUpDown.isSelected = true
            }
            else
            {
                cell.btnUpDown.isSelected = false
            }
        }else{
            cell.btnUpDown.isHidden = true
        }
        
        if arr_Problemetic.count != 0{
            cell.btn_Click.tag = section;
            cell.btn_Click.addTarget(self, action:#selector(btn_Section(_:)), for: .touchUpInside)
        }
        
        return cell
    }
    
    @IBAction func btn_Section(_ sender: UIButton) {
        
        if  isHighLighted == true {
            tbl_reload_Number = 0
            isHighLighted = false
            tblViewProblematic.reloadData()
        }
        else{
            tbl_reload_Number = arr_Problemetic.count
            isHighLighted = true
            tblViewProblematic.reloadData()
            tblViewProblematic.scrollToRow(at: IndexPath(item:arr_Problemetic.count - 1, section: 0), at: .bottom, animated: true)
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return tbl_reload_Number
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellStatistic", for:indexPath as IndexPath) as! StatisticeCell
        
        let obj = arr_Problemetic[indexPath.row] as! GlobalObjectCard
        
        cell.lblTitle.text = obj.str_Statisic_keyword
        cell.lblCount.text = obj.str_Statisic_counts
        
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

    }
}



//MARK: - Webservice Helper -
extension StatisticsViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        //        self.completedServiceCalling()
        
        let response = data as! NSDictionary
        let json2 = try JSON(jsonObject : response)
        
        if strRequest == "get_today_category_statistics" {
            
            //Chart manage
            arr_Main_Chart = []
            for i in (0..<json2["chart_data"].array!.count) {
                let dict_Data = json2["chart_data"][i].dictionaryObject! as NSDictionary
                
                //Other Tab Demo data
                let obj = GlobalObjectCard ()
                
                obj.str_Statisic_category_id = dict_Data.getStringForID(key:"category_id")
                obj.str_Statisic_category_name = dict_Data.getStringForID(key: "category_name")
                obj.str_Statisic_parcentage = dict_Data.getStringForID(key: "percentage")
                
                obj.arr_Statisic_chart_data_Sub = []
                for j in (0..<json2["chart_data"][i]["sub_category"].array!.count) {
                    let dict_SubData = json2["chart_data"][i]["sub_category"][j].dictionaryObject! as NSDictionary
                    
                    let obj2 = GlobalObjectCard ()
                    
                    obj2.str_Statisic_category_id = dict_SubData.getStringForID(key:"category_id")
                    obj2.str_Statisic_category_name = dict_SubData.getStringForID(key: "category_name")
                    obj2.str_Statisic_parcentage = dict_SubData.getStringForID(key: "percentage")
                    
                    obj.arr_Statisic_chart_data_Sub.add(obj2)
                }
                
                arr_Main_Chart.add(obj)
            }
            
            //Words
            let dict_Word = json2["words"].dictionaryObject! as NSDictionary
            obj_Words = GlobalObjectCard ()
            if dict_Word != nil{
                obj_Words.str_Statisic_total_card_readed = dict_Word.getStringForID(key: "total_card_readed")
                obj_Words.str_Statisic_total_last_week_cards = dict_Word.getStringForID(key: "total_last_week_cards")
                obj_Words.str_Statisic_total_last_month_cards = dict_Word.getStringForID(key: "total_last_month_cards")
                
                obj_Words.arr_Statisic_day_wise_count = []
                obj_Words.arr_Statisic_month_wise_count = []
                
                let dict_Word_Day = dict_Word["day_wise_count"] as! NSDictionary
                let dict_Word_Month = dict_Word["month_wise_count"] as! NSDictionary
                var arr_Word = ["Monday", "Thursday", "Wednesday",
                              "Tuesday", "Friday", "Saturday",
                              "Sunday"]
                for i in 0..<arr_Word.count{
                    obj_Words.arr_Statisic_day_wise_count.add(dict_Word_Day.getStringForID(key: arr_Word[i]))
                }
                let arr_MonthData : NSMutableArray = []
                for i in 0..<40{
                    arr_MonthData.add(String(i))
                }
                for i in 0..<dict_Word_Month.count{
                    obj_Words.arr_Statisic_month_wise_count.add(dict_Word_Month.getStringForID(key: arr_MonthData[i] as! String))
                }
            }
            
            //minutes
            let dict_Minute = json2["minutes"].dictionaryObject! as NSDictionary
            obj_Minutes = GlobalObjectCard ()
            if dict_Minute != nil{
                obj_Minutes.str_Statisic_total_card_readed = dict_Minute.getStringForID(key: "total_minute_spend")
                obj_Minutes.str_Statisic_total_last_week_cards = dict_Minute.getStringForID(key: "total_last_week_minute")
                obj_Minutes.str_Statisic_total_last_month_cards = dict_Minute.getStringForID(key: "total_last_month_sums")
                
                obj_Minutes.arr_Statisic_day_wise_count = []
                obj_Minutes.arr_Statisic_month_wise_count = []
                
                let dict_Minute_Day = dict_Minute["day_wise_sum"] as! NSDictionary
                let dict_Minute_Month = dict_Minute["month_wise_sum"] as! NSDictionary
                var arr_Word = ["Monday", "Thursday", "Wednesday",
                                "Tuesday", "Friday", "Saturday",
                                "Sunday"]
                for i in 0..<arr_Word.count{
                    obj_Minutes.arr_Statisic_day_wise_count.add(dict_Minute_Day.getStringForID(key: arr_Word[i]))
                }
                let arr_MonthData : NSMutableArray = []
                for i in 0..<40{
                    arr_MonthData.add(String(i))
                }
                for i in 0..<dict_Minute_Month.count{
                    obj_Minutes.arr_Statisic_month_wise_count.add(dict_Minute_Month.getStringForID(key: arr_MonthData[i] as! String))
                }
            }
            
            //Problemetic word
            arr_Problemetic = []
            for i in (0..<json2["top_problemetic_words"].array!.count) {
                let dict_Data = json2["top_problemetic_words"][i].dictionaryObject! as NSDictionary
                let dict_FlashCard = json2["top_problemetic_words"][i]["flashcard"].dictionaryObject! as NSDictionary
                
                //Other Tab Demo data
                let obj = GlobalObjectCard ()
                
                obj.str_Statisic_counts = dict_Data.getStringForID(key:"counts")
                obj.str_Statisic_card_id = dict_Data.getStringForID(key: "card_id")
                
                obj.str_Statisic_creator_id = dict_FlashCard.getStringForID(key: "creator_id")
                obj.str_Statisic_keyword = dict_FlashCard.getStringForID(key: "keyword")
                obj.str_Statisic_category_id = dict_FlashCard.getStringForID(key: "category_id")
                obj.str_Statisic_sub_category_id = dict_FlashCard.getStringForID(key: "sub_category_id")
                obj.str_Statisic_from_language = dict_FlashCard.getStringForID(key: "from_language")
                obj.str_Statisic_to_language = dict_FlashCard.getStringForID(key: "to_language")
                obj.str_Statisic_dictionary_id = dict_FlashCard.getStringForID(key: "dictionary_id")
                obj.str_Statisic_card_image = dict_FlashCard.getStringForID(key: "card_image")
                obj.str_Statisic_audio_file = dict_FlashCard.getStringForID(key: "audio_file")
                obj.str_Statisic_color_code = dict_FlashCard.getStringForID(key: "color_code")
                obj.str_Statisic_card_type = dict_FlashCard.getStringForID(key: "card_type")
                obj.str_Statisic_store_type = dict_FlashCard.getStringForID(key: "store_type")
                
                arr_Problemetic.add(obj)
            }
            self.reloadData()
        }else if strRequest == "reset_statistics"{
            self.Get_Statistics()
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}



//
//  AllWordsViewController.swift
//  Minnaz
//
//  Created by Apple on 28/12/17.
//  Copyright © 2017 iCoderz. All rights reserved.
//

import UIKit
import SwiftyJSON
import EmptyDataSet_Swift

class AllWordsViewController: UIViewController {
    var isShowCardAllDetails: Bool = false
    var longPressGesture = UILongPressGestureRecognizer()
    
    var bool_Move : Bool = false
    
     var arr_Main : NSMutableArray = []
    
    @IBOutlet var cv_Main: UICollectionView!
    
    @IBOutlet var btn_SaveFavorite: UIButton!
    
    //Bool Declaration
    var int_CountLoad: Int = 0
    var bool_Load: Bool = false
    var bool_ViewWill: Bool = false
    var bool_SearchMore: Bool = true
    
     var tbl_reload_Number : NSIndexPath!
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        self.setupView()
        self.commanMethod()
        
//        //First time sevice call for featured product
//        int_CountLoad = GlobalConstants.int_LoadMax
//        bool_ViewWill = true
//        bool_SearchMore = true
//        self.Get_SubCategory(count:int_CountLoad)
    }
    override func viewWillAppear(_ animated: Bool) {
        
        bool_Move = true
        btn_SaveFavorite.setTitle(objDetailView.str_category_name,for: .normal)
//
//        if selectedSection != -1 {
//            
//            let when = DispatchTime.now() + 0.3
//            DispatchQueue.main.asyncAfter(deadline: when) {
//                if let attributes = self.cv_Main.collectionViewLayout.layoutAttributesForSupplementaryView(ofKind: UICollectionElementKindSectionHeader, at: NSIndexPath.init(row: 0, section: selectedSection-1) as IndexPath) {
//                    self.cv_Main.setContentOffset(CGPoint(x: 0, y: attributes.frame.origin.y - self.cv_Main.contentInset.top), animated: true)
//                }
//                selectedSection = -1
//            }
//        }else{
//            if let attributes = cv_Main.collectionViewLayout.layoutAttributesForSupplementaryView(ofKind: UICollectionElementKindSectionHeader, at: NSIndexPath.init(row: 0, section: 0) as IndexPath) {
//                cv_Main.setContentOffset(CGPoint(x: 0, y: attributes.frame.origin.y - cv_Main.contentInset.top), animated: true)
//            }
//        }
//        cv_Main.reloadData()
        
        //First time sevice call for featured product
        int_CountLoad = GlobalConstants.int_LoadMax
        bool_ViewWill = true
        bool_SearchMore = true
        self.Get_SubCategory(count:int_CountLoad)
       
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - Scrollview Delegate -
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        if scrollView == cv_Main{
            if cv_Main.contentSize.height <= cv_Main.contentOffset.y + cv_Main.frame.size.height && cv_Main.contentOffset.y >= 0 {
                if bool_Load == false && arr_Main.count != 0 {
                    self.Get_SubCategory(count: int_CountLoad + GlobalConstants.int_LoadMax)
                }
            }
        }
    }
    
    
    //MARK: - Custom Method -
    func commanMethod(){
        cv_Main.emptyDataSetDelegate = self
        cv_Main.emptyDataSetSource = self
        
        let layout = cv_Main.collectionViewLayout as? UICollectionViewFlowLayout // casting is required because UICollectionViewLayout doesn't offer header pin. Its feature of UICollectionViewFlowLayout
        layout?.sectionHeadersPinToVisibleBounds = true
        
//        //Long press in cell
//        let longpress = UILongPressGestureRecognizer(target: self, action: #selector(self.longPressEvent(_:)))
//        cv_Main.addGestureRecognizer(longpress)
    }
    
    func setupView() {
        
        var subArray1:NSMutableArray = []
        
        var obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray1.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray1.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray1.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray1.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray1.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray1.add(obj)
        
        arr_Main.add(subArray1)
        
        
        var subArray2 :NSMutableArray = []
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray2.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray2.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray2.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray2.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray2.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray2.add(obj)
        
        arr_Main.add(subArray2)
        
        
        var subArray3 :NSMutableArray = []
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray3.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray3.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray3.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray3.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray3.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray3.add(obj)
        
        arr_Main.add(subArray3)
        
        
        var subArray4 :NSMutableArray = []
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray4.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray4.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray4.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray4.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray4.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray4.add(obj)
        
        arr_Main.add(subArray4)
        
        
        /////
        var subArray5 :NSMutableArray = []
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray5.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray5.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray5.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray5.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray5.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray5.add(obj)
        
        arr_Main.add(subArray5)
        
        //
        var subArray6:NSMutableArray = []
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray6.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray6.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        
        subArray6.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        
        subArray6.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        
        subArray6.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        
        subArray6.add(obj)
        
        arr_Main.add(subArray6)
        
        
        /////
        
        /////
        var subArray7 : NSMutableArray = []
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray7.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray7.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray7.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray7.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray7.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray7.add(obj)
        
        arr_Main.add(subArray7)
        
        //
        var subArray8:NSMutableArray = []
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray8.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        subArray8.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        
        subArray8.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        
        subArray8.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        
        subArray8.add(obj)
        
        obj = CardDetailsObject()
        obj.strCardName = "Bill"
        obj.strCardImageUrl = "photoDefault"
        obj.strCardOtherMeaning = "Car"
        obj.strCardGoogleMeaning = "Car"
        obj.isCardFront = true
        
        subArray8.add(obj)
        
        arr_Main.add(subArray8)
    }
    func completedServiceCalling(){
//        refresh_Item?.endRefreshing()
        
        bool_Load = false
    }
    func reloadData(){
        cv_Main.reloadData()
    }
    
    func indexPaths(forSection section: Int, withNumberOfRows numberOfRows: Int) -> [Any] {
        var indexPaths = [Any]()
        for i in 0..<numberOfRows {
            let indexPath = IndexPath(row: i, section: section)
            indexPaths.append(indexPath)
        }
        return indexPaths
    }
    
    //MARK: - Button Event -
    @IBAction func btn_Speak(_ sender : Any){
        let obj = arr_Main[0] as! GlobalObjectCard
        
        if (sender as AnyObject).tag < obj.arr_FlatCard.count{
            let objCard = obj.arr_FlatCard[(sender as AnyObject).tag] as! GlobalObjectCard

            if objCard.arr_FlatCardInfo.count != 0{
                let objInfo = objCard.arr_FlatCardInfo[0] as! GlobalObjectCard
                
                playMusic(str_TraslationText : objCard.str_FlatCard_keyword,Language : objCard.str_FlatCard_abbrivation ?? "en")

            }
        }
    }
    
    @IBAction func btn_Section(_ sender: Any) {
        //Get animation with table view reload data
//        cv_Main.beginUpdates()
        if ((tbl_reload_Number) != nil) {
            if (tbl_reload_Number.section == (sender as AnyObject).tag) {
            
                //Close Animation
                let obj : GlobalObjectCard = arr_Main[tbl_reload_Number.section] as! GlobalObjectCard
                let arr_DeleteIndex = self.indexPaths(forSection: ((sender as AnyObject).tag), withNumberOfRows: obj.arr_FlatCard.count)
                
                let indexSet = IndexSet(integer: tbl_reload_Number.section)
                
                tbl_reload_Number = nil;
                cv_Main.deleteItems(at: arr_DeleteIndex as! [IndexPath])
            
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: {
                    self.cv_Main.reloadSections(indexSet)
                })
            }else{
                
                let indexSet = IndexSet(integer: tbl_reload_Number.section)
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: {
                    self.cv_Main.reloadSections(indexSet)
                })
                
                //Close Animation
                let objDelete : GlobalObjectCard = arr_Main[tbl_reload_Number.section] as! GlobalObjectCard
                let arr_DeleteIndex = self.indexPaths(forSection: tbl_reload_Number.section, withNumberOfRows:objDelete.arr_FlatCard.count)
                tbl_reload_Number = nil;
                cv_Main.deleteItems(at: arr_DeleteIndex as! [IndexPath])
                
                let obj : GlobalObjectCard = arr_Main[(sender as AnyObject).tag] as! GlobalObjectCard
                if obj.arr_FlatCard.count != 0 {
                    tbl_reload_Number = IndexPath(row: obj.arr_FlatCard.count, section: (sender as AnyObject).tag) as NSIndexPath!

                    //Open Animation
                    let arr_AddIndex = self.indexPaths(forSection: ((sender as AnyObject).tag), withNumberOfRows:obj.arr_FlatCard.count)
                    cv_Main.insertItems(at: arr_AddIndex as! [IndexPath])
                    
                    let indexSet = IndexSet(integer: (sender as AnyObject).tag)
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: {
                        self.cv_Main.reloadSections(indexSet)
                    })
                }
            }
        }else{
            let obj : GlobalObjectCard = arr_Main[(sender as AnyObject).tag] as! GlobalObjectCard
            if obj.arr_FlatCard.count != 0 {
                tbl_reload_Number = IndexPath(row: obj.arr_FlatCard.count, section: (sender as AnyObject).tag) as NSIndexPath!

                //Open Animation
                let arr_AddIndex = self.indexPaths(forSection: ((sender as AnyObject).tag), withNumberOfRows: obj.arr_FlatCard.count)
                cv_Main.insertItems(at: arr_AddIndex as! [IndexPath])
                
                let indexSet = IndexSet(integer: (sender as AnyObject).tag)
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: {
                    self.cv_Main.reloadSections(indexSet)
                })

            }else{
                self.performSegue(withIdentifier: "postpurchasereview", sender: (sender as AnyObject).tag)
            }
        }
        
//        tbl_Main.endUpdates()
//
//        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: {
        
//        })
    }
    
    
    //MARK: - Gesture Method -
    //Called, when long press occurred
    @objc func longPress(_ sender: UILongPressGestureRecognizer) {
        if bool_Move == true{
//            self.performSegue(withIdentifier: "detail", sender: self)
//            bool_Move = false
            
            let p = sender.location(in: cv_Main)
            if let indexPath = cv_Main.indexPathForItem(at: p){
                
                let obj = arr_Main[indexPath.section] as! GlobalObjectCard
                let obj2 = obj.arr_FlatCard[indexPath.row] as! GlobalObjectCard
                
                let objSub = OCRSelectionObject()
                
                objSub.str_Title = obj2.str_FlatCard_keyword
                objSub.str_Image = obj2.str_FlatCard_card_image
                objSub.str_CardID = obj2.str_FlatCard_id
                objSub.str_category_id = obj.str_parent_id
                objSub.str_sub_category_id = obj.str_category_id
                objSub.str_from_language_id = obj2.str_FlatCard_from_language
                objSub.str_to_language_id = obj2.str_FlatCard_to_language
                objSub.str_dictionary_id = obj2.str_FlatCard_dictionary_id
 
                objSub.str_CurrentLang = obj2.str_FlatCard_abbrivation
                objSub.str_Traslation_Play = obj2.str_FlatCard_traslation_Play
                
                if obj2.arr_FlatCardInfo.count != 0{
                    let objInfo = obj2.arr_FlatCardInfo[0] as! GlobalObjectCard
                    
                    objSub.str_convert = objInfo.str_FlatCardInfo_translate
                    
                    objSub.arr_ConvertString.add(objInfo.str_FlatCardInfo_translate)
                }
                
                let view = self.storyboard?.instantiateViewController(withIdentifier: "ReviewDetailViewController") as! ReviewDetailViewController
                view.objGet = objSub
                view.bool_Edit = true
                self.navigationController?.pushViewController(view, animated: true)
                bool_Move = false
            }
            
        }
        
        
    }
    
    @objc func tapBarButton(_ sender: UITapGestureRecognizer) {
        
        let p = sender.location(in: cv_Main)
        if let indexPath = cv_Main.indexPathForItem(at: p) {
            // get the cell at indexPath (the one you long pressed)
            
            let objCard = arr_Main[indexPath.section] as! GlobalObjectCard
            let obj = objCard.arr_FlatCard[indexPath.row] as! GlobalObjectCard
            
            if obj.isCardFront {
                obj.isCardFront = false
                let cell = cv_Main.cellForItem(at: indexPath)
                UIView.transition(with: cell!, duration: 0.3, options: .transitionFlipFromLeft, animations: nil, completion: nil)
                self.showHideOtherViews(cell as! AllWordsCell, isShow: false)
                longPressGesture.isEnabled = true
            }else {
                obj.isCardFront = true
                let cell = cv_Main.cellForItem(at: indexPath)
                UIView.transition(with: cell!, duration: 0.3, options: .transitionFlipFromLeft, animations: nil, completion: nil)
                self.showHideOtherViews(cell as! AllWordsCell, isShow: true)
                longPressGesture.isEnabled = true
            }
            //        cv_Main.reloadData()
            // do stuff with the cell
        } else {
            print("couldn't find index path")
        }
        
        ///
        /*
         if isShowCardAllDetails {
         isShowCardAllDetails = false
         let p = sender.location(in: cv_Main)
         
         if let indexPath = cv_Main.indexPathForItem(at: p) {
         // get the cell at indexPath (the one you long pressed)
         let cell = cv_Main.cellForItem(at: indexPath)
         UIView.transition(with: cell!, duration: 0.3, options: .transitionFlipFromLeft, animations: nil, completion: nil)
         self.showHideOtherViews(cell as! AllWordsCell, isShow: true)
         longPressGesture.isEnabled = true
         // do stuff with the cell
         } else {
         print("couldn't find index path")
         }
         
         }else {
         isShowCardAllDetails = true
         let p = sender.location(in: cv_Main)
         
         if let indexPath = cv_Main.indexPathForItem(at: p) {
         // get the cell at indexPath (the one you long pressed)
         let cell = cv_Main.cellForItem(at: indexPath)
         // do stuff with the cell
         UIView.transition(with: cell!, duration: 0.3, options: .transitionFlipFromRight, animations: nil, completion: nil)
         longPressGesture.isEnabled = true
         self.showHideOtherViews(cell as! AllWordsCell, isShow: false)
         //          self.showAndHideOtherViews(false)
         } else {
         print("couldn't find index path")
         }
         }
         */
    }
    
    func showHideOtherViews(_ cell: AllWordsCell, isShow: Bool) {
        
        cell.imgVwWordPhoto.isHidden = isShow
        cell.lblWordCenter.isHidden = !isShow
        cell.lblWord.isHidden = isShow
        cell.lblGoogleMeaning.isHidden = isShow
//        cell.lblOtherDictMeaning.isHidden = isShow
        cell.btnGoogle.isHidden = isShow
//        cell.btnOtherDict.isHidden = isShow
        cell.btnSpeak.isHidden = isShow
        
        
        cell.btnSpeak.isHidden = isShow
        cell.btnSpeak2.isHidden = isShow
        
        cell.btnSpeak.alpha = 0.3
        cell.btnSpeak2.alpha = 0.3
        
        cell.btnSpeak.isUserInteractionEnabled = isShow
        cell.btnSpeak2.isUserInteractionEnabled = isShow
        
        //If get true and also play true then only show this button
        if isShow == false{
            if cell.btnGoogle.titleLabel?.text == "1"{
                cell.btnSpeak.isUserInteractionEnabled = true
                cell.btnSpeak2.isUserInteractionEnabled = true
                
                cell.btnSpeak.alpha = 1.0
                cell.btnSpeak2.alpha = 1.0
            }else{
                cell.btnSpeak.isUserInteractionEnabled = false
                cell.btnSpeak2.isUserInteractionEnabled = false
                
                cell.btnSpeak.alpha = 0.3
                cell.btnSpeak2.alpha = 0.3
            }
        }
    }
    
    
    //MARK: - Service Calling -
    func Get_SubCategory(count : Int){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)get_card_by_category"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "user_id" : objUser?.user_UserID,
            "category_id" : objDetailView.str_category_id,
            "skip" : "\(count - GlobalConstants.int_LoadMax)",
            "total" : "\(count)",
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "get_card_by_category"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        
        if bool_SearchMore == true{
            bool_Load = true
            webHelper.startDownload()
        }
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
class AllWordsCell: UICollectionViewCell {
    @IBOutlet var imgVwWordPhoto: UIImageView!
    @IBOutlet var lblWordCenter: UILabel!
    @IBOutlet var lblWord: UILabel!
    @IBOutlet var lblGoogleMeaning: UILabel!
    @IBOutlet var lblOtherDictMeaning: UILabel!
    
    @IBOutlet var lbl_Title: UILabel!
    @IBOutlet var lbl_Count: UILabel!
    @IBOutlet var btn_ClickCell: UIButton!
    @IBOutlet var img_Arrow: UIImageView!
    
    @IBOutlet var btnGoogle: UIButton!
    @IBOutlet var btnOtherDict: UIButton!
    @IBOutlet var btnSpeak: UIButton!
    @IBOutlet var btnSpeak2: UIButton!
    
    var data_ImageData: NSData? = nil
    
    @IBOutlet var btn_Close: UIButton!
    @IBOutlet var btn_Star: UIButton!
}
class AllWordsCellResuable: UICollectionReusableView {
    
    @IBOutlet var lbl_Title: UILabel!
    @IBOutlet var lbl_Count: UILabel!
    @IBOutlet var btn_ClickCell: UIButton!
    @IBOutlet var img_Arrow: UIImageView!
}

//MARK: - Collection View -
extension AllWordsViewController: UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        let obj = arr_Main[section] as! GlobalObjectCard
//        return obj.arr_FlatCard.count
        
        //If search and result 0 than show no data cell
        if ((tbl_reload_Number) != nil) {
            if (tbl_reload_Number.section == section) {
                
                let obj = arr_Main[section] as! GlobalObjectCard
                return obj.arr_FlatCard.count;
            }
        }
        return 0
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        return arr_Main.count
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: CGFloat((GlobalConstants.windowWidth-20)/3), height: CGFloat(((GlobalConstants.windowWidth-20)/3) * 1.375))
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize(width: collectionView.frame.size.width, height:50)
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        
        let reusableView : UICollectionReusableView? = nil

        
        switch kind {
            
        case UICollectionElementKindSectionHeader:
            
            let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "Header", for: indexPath) as! AllWordsCellResuable
            
            let obj = arr_Main[indexPath.section] as! GlobalObjectCard
            
            headerView.lbl_Title.text = obj.str_category_name
            
            headerView.lbl_Count.text = "\(obj.arr_FlatCard.count)";

            //Manage font
            headerView.lbl_Title.font = UIFont(name: GlobalConstants.kFontRegular, size: manageFont(font: 15))

            if obj.arr_FlatCard.count != 0{
                //Button Event
                headerView.btn_ClickCell.tag = indexPath.section;
                headerView.btn_ClickCell.addTarget(self, action:#selector(btn_Section(_:)), for: .touchUpInside)
            }
            
            headerView.backgroundColor = UIColor.white;

            headerView.img_Arrow.image = UIImage(named:"DownBlack")
            if tbl_reload_Number != nil {
                if tbl_reload_Number.section == indexPath.section {
                    headerView.img_Arrow.image = UIImage(named:"UPBlack")
                }
            }
            
            return headerView
            
        default:
            
            assert(false, "Unexpected element kind")
        }
        
        return reusableView!
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell  = collectionView.dequeueReusableCell(withReuseIdentifier: "cellVocablist", for: indexPath) as! AllWordsCell
        //    cell.lblWordCenter.text = String(format:"Lesson %d",indexPath.row)
        
        
        let obj = arr_Main[indexPath.section] as! GlobalObjectCard
        
        let objCard = obj.arr_FlatCard[indexPath.row] as! GlobalObjectCard
        
        cell.tag = indexPath.row
        if objCard.isCardFront {
            self.showHideOtherViews(cell , isShow: true)
        }else {
            self.showHideOtherViews(cell , isShow: false)
        }
        
        cell.btnGoogle.setTitle(objCard.str_FlatCard_traslation_Play, for: .normal)
        
        switch Int(objCard.str_FlatCard_dictionary_id) {
        case 1?:
            cell.btnGoogle.setImage(UIImage(named:"icon_Dictionary1"), for: UIControlState.normal)
            break
        case 2?:
            cell.btnGoogle.setImage(UIImage(named:"icon_Dictionary2"), for: UIControlState.normal)
            if validationforLexinEnglishDictionaryShowInputParamater(From: objCard.str_FlatCard_abbrivation_Lexin_From, To: objCard.str_FlatCard_abbrivation_Lexin_To) == true{
                cell.btnGoogle.setImage(UIImage(named:"icon_Dictionary2-1"), for: UIControlState.normal)
            }
            break
        case 3?:
            cell.btnGoogle.setImage(UIImage(named:"icon_Dictionary3"), for: UIControlState.normal)
            break
        case 4?:
            cell.btnGoogle.setImage(UIImage(named:"icon_Quizlet"), for: UIControlState.normal)
            break
        default:
            break
        }
        
        //Manage Data with user
        cell.imgVwWordPhoto.sd_setImage(with: URL(string: (objCard.str_FlatCard_card_image)), placeholderImage: UIImage(named:"img_PlaceHolderImage"))
        
        cell.lblWord.text = objCard.str_FlatCard_keyword
        cell.lblWordCenter.text = objCard.str_FlatCard_keyword
       
        
        if objCard.arr_FlatCardInfo.count != 0{
            let objInfo = objCard.arr_FlatCardInfo[0] as! GlobalObjectCard
             cell.lblGoogleMeaning.text = objInfo.str_FlatCardInfo_translate
        }

        cell.btnSpeak.isHidden = true
        
        if objUser?.traslation_Play == "1"{
            cell.btnSpeak2.isUserInteractionEnabled = true
            cell.btnSpeak2.alpha = 1.0
        }else{
            cell.btnSpeak2.isUserInteractionEnabled = false
            cell.btnSpeak2.alpha = 0.3
        }
        
        cell.btnSpeak2.tag = indexPath.row
        cell.btnSpeak2.addTarget(self, action:#selector(btn_Speak(_:)), for: .touchUpInside)
        
        //Manage font
        cell.lblWordCenter.font = UIFont(name: GlobalConstants.kFontRegular, size: manageFont(font: 22))
        cell.lblWord.font = UIFont(name: GlobalConstants.kFontRegular, size: manageFont(font: 20))
        cell.lblGoogleMeaning.font = UIFont(name: GlobalConstants.kFontRegular, size: manageFont(font: 12))
        
        //Press event
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.tapBarButton(_:)))
        cell.addGestureRecognizer(tapGesture)

        if objCard.str_FlatCard_dictionary_id != "4" {
            let tapGesture2 = UILongPressGestureRecognizer(target: self, action: #selector(self.longPress(_:)))
            tapGesture2.view?.tag = indexPath.row
            cell.addGestureRecognizer(tapGesture2)

        }
        
        
        //    self.showHideOtherViews(cell , isShow: !objCard.isCardFront)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        //    self.performSegue(withIdentifier: "segueCardDetails", sender: self)
    }
}

extension AllWordsViewController: EmptyDataSetSource,EmptyDataSetDelegate {

    func emptyDataSetShouldDisplay(_ scrollView: UIScrollView) -> Bool{
        if arr_Main.count == 0 && bool_Load == false{
            return true
        }
        return false
    }
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        var text: String?
        var font: UIFont?
        var textColor: UIColor?
        
        text = "Please create cateogry"
        
        font = UIFont(name: GlobalConstants.kFontSemiBold, size: manageFont(font: 20))
        textColor = UIColor(red: 109/255, green: 109/255, blue: 109/255, alpha: 1.0)
        
        if text == nil {
            return nil
        }
        var attributes: [NSAttributedStringKey: Any] = [:]
        
        if font != nil {
            attributes[NSAttributedStringKey.font] = font!
        }
        if textColor != nil {
            attributes[NSAttributedStringKey.foregroundColor] = textColor
        }
        return NSAttributedString.init(string: text!, attributes: attributes)
        
    }
}



extension AllWordsViewController : WebServiceHelperDelegate{
    //MARK: - Webservice Helper -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        self.completedServiceCalling()
        
        let response = data as! NSDictionary
        let json2 = try JSON(jsonObject : response)
        
        if strRequest == "get_card_by_category" {
            
            let arr_StoreTemp : NSMutableArray = []
            for i in (0..<json2["sub_categories"].array!.count) {
                let dict_Data = json2["sub_categories"][i].dictionaryObject! as NSDictionary
                
                //Other Tab Demo data
                let obj = GlobalObjectCard ()
                
                obj.str_category_id = dict_Data.getStringForID(key:"category_id")
                obj.str_category_name = dict_Data.getStringForID(key: "category_name")
                obj.str_user_id = dict_Data.getStringForID(key: "user_id")
                obj.str_parent_id = dict_Data.getStringForID(key: "parent_id")
                obj.str_sub_cat_count = dict_Data.getStringForID(key: "sub_cat_count")
                obj.str_total_card = dict_Data.getStringForID(key: "total_card")
                obj.str_percentage = dict_Data.getStringForID(key: "percentage")
                
                obj.arr_FlatCard = []
                
                let arr_FlashCard = dict_Data["flashcards"] as! NSArray
                for j in (0..<arr_FlashCard.count) {
                    let dict_Data2 = arr_FlashCard[j] as! NSDictionary
                    
                    let obj2 = GlobalObjectCard ()
                    
                    obj2.str_FlatCard_id = dict_Data2.getStringForID(key: "card_id")
                    obj2.str_FlatCard_keyword = dict_Data2.getStringForID(key: "keyword")
                    obj2.str_FlatCard_card_image = dict_Data2.getStringForID(key: "card_image")
                    obj2.str_FlatCard_card_type = dict_Data2.getStringForID(key: "card_type")
                    obj2.str_FlatCard_store_type = dict_Data2.getStringForID(key: "store_type")
                    obj2.str_FlatCard_dictionary_id = dict_Data2.getStringForID(key: "dictionary_id")
                    obj2.str_FlatCard_from_language = dict_Data2.getStringForID(key: "from_language")
                    obj2.str_FlatCard_to_language = dict_Data2.getStringForID(key: "to_language")
                    obj2.isCardFront = true
                    
                    let arr_CardInfo = dict_Data2["card_info"] as! NSArray
                    for k in (0..<arr_CardInfo.count) {
                        let dict_Data3 = arr_CardInfo[k] as! NSDictionary
                        
                        let obj3 = GlobalObjectCard ()
                        
                        let int_Value : Int = dict_Data3["id"] as! Int
                        obj3.str_FlatCardInfo_id = dict_Data3.getStringForID(key: "id")
                        obj3.str_FlatCardInfo_card_id = dict_Data3.getStringForID(key: "card_id")
                        obj3.str_FlatCardInfo_meanings = dict_Data3.getStringForID(key: "meanings")
                        obj3.str_FlatCardInfo_translate = dict_Data3.getStringForID(key: "translate")
                        obj3.str_FlatCardInfo_example = dict_Data3.getStringForID(key: "example")
                        obj3.str_FlatCardInfo_inflection = dict_Data3.getStringForID(key: "inflection")
                        obj3.str_FlatCardInfo_synonym = dict_Data3.getStringForID(key: "synonym")
                        obj3.str_FlatCardInfo_another_word = dict_Data3.getStringForID(key: "another_word")
                        obj3.str_FlatCardInfo_another_created_at = dict_Data3.getStringForID(key: "created_at")
                        
                        obj2.arr_FlatCardInfo.add(obj3)
                    }
                    
                    let dict_From = dict_Data2["to_lang"] as! NSDictionary
                    let dict_To = dict_Data2["from_lang"] as! NSDictionary
                    
                    obj2.str_FlatCard_traslation_Play = "0"
                    if playAvailble(Language : (dict_To.getStringForID(key: "abbrivation"))) == true{
                        obj2.str_FlatCard_traslation_Play = "1"
                        obj2.str_FlatCard_abbrivation = dict_To.getStringForID(key: "abbrivation")
                    }
                    obj.str_FlatCard_abbrivation_Lexin_From = dict_To.getStringForID(key: "abbrivation_lexin")
                    obj.str_FlatCard_abbrivation_Lexin_To = dict_From.getStringForID(key: "abbrivation_lexin")
                    
                    obj.arr_FlatCard.add(obj2)
                }
                
                arr_StoreTemp.add(obj)
            }
            
            //Refresh code
            if bool_ViewWill == true {
                arr_Main = []
                int_CountLoad = arr_StoreTemp.count
            }else{
                int_CountLoad = int_CountLoad + arr_StoreTemp.count
            }
            
            for i in (0...arr_StoreTemp.count-1){
                arr_Main.add(arr_StoreTemp[i])
            }
            
            //Load more data or not
            if GlobalConstants.int_LoadMax > arr_StoreTemp.count {
                //Bool Load more
                bool_SearchMore = false
            }
            else {
                //Bool Load more
                bool_SearchMore = true
            }
            
            bool_ViewWill = false
            self.reloadData()
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        self.completedServiceCalling()
        if bool_ViewWill == true{
            arr_Main = []
            self.reloadData()
        }
    }
}



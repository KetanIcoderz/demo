//
//  ReviewViewController.swift
//  Minnaz
//
//  Created by Apple on 28/12/17.
//  Copyright © 2017 iCoderz. All rights reserved.
//

import UIKit
import Koloda
import pop
import EmptyDataSet_Swift
import SwiftyJSON

var str_CatgorySaved = ""

private let numberOfCards: Int = 5
private let frameAnimationSpringBounciness: CGFloat = 9
private let frameAnimationSpringSpeed: CGFloat = 16
private let kolodaCountOfVisibleCards = 2
private let kolodaAlphaValueSemiTransparent: CGFloat = 0.1

class ReviewViewController: UIViewController {
    weak var  txtWord : UITextField!
    weak var  txtWord2 : UITextField!
    
    var lblOtherWord : UILabel!
    @IBOutlet var lbl_TotalCount : UILabel!
    @IBOutlet var lbl_Timer : UILabel!
    @IBOutlet var lbl_Timer_Header : UILabel!
    
    var viewCard : UIView!
    var viewFront : UIView!
    var viewWordDetails : UIView!
    
    var imgVwWord : UIImageView!
    var imgGoogle : UIImageView!
    @IBOutlet var img_GIF : UIImageView!
    
    var btnVolume : UIButton!
    var btnEditPhoto : UIButton!
    var btnGoogle : UIButton!
    var btnDetailDictIcon : UIButton!
    var btnCloseDialogImage : UIButton!
    var btnEditWordImage : UIButton!
    var btnEditImage : UIButton!
    var btnWordDetail : UIButton!
    
    var lbl_LevelShow : UILabel!
    
    @IBOutlet var btnAddCard : UIButton!
    @IBOutlet var btnRemovCard : UIButton!
    @IBOutlet var btnSound : UIButton!
    
    @IBOutlet weak var btn_SaveFavorite : UIButton!
    
    @IBOutlet weak var vw_NoData : UIView!
    
//    @IBOutlet weak var kolodaView: KolodaView!
    @IBOutlet weak var kolodaView: CustomKolodaView!
    
    @IBOutlet weak var con_SliderWidth: NSLayoutConstraint!
    
    //Image Picker
    let picker = UIImagePickerController()
    
    var isShowCardAllDetails: Bool = false
    var longPressGesture = UILongPressGestureRecognizer()
    
    var arr_TinderView : NSMutableArray  = []
    var arr_Main : NSMutableArray  = []
    
    var int_Selected : Int = 0
    var int_Selected2 : Int = 0
    var int_TotalCount : String = "0"
    var int_ReadedCount : String = "0"
    var int_NextQuation : String = "0"
    var int_AlertQuation : String = "0"
    var int_SubCategory : String = "0"
    var int_Review_timer : String = "0"
    
    var int_TimerValue : String = ""
    var bool_Fail : Bool = false
    var int_ScreenSecond : Int = 0
    
    var timer_Count = Timer()
    var timer_ScreenSecond = Timer()
    var timer_Quation = Timer()
    
    //MARK:
    override func viewDidLoad() {
        super.viewDidLoad()
//        self.viewSetup()
        
        arr_TinderView.add("icon_DownloadBlue")
        arr_TinderView.add("icon_DownloadBlue")
        arr_TinderView.add("icon_DownloadBlue")
        arr_TinderView.add("icon_DownloadBlue")
        arr_TinderView.add("icon_DownloadBlue")
        
        kolodaView.alphaValueSemiTransparent = kolodaAlphaValueSemiTransparent
        kolodaView.countOfVisibleCards = kolodaCountOfVisibleCards
        kolodaView.delegate = self
        kolodaView.dataSource = self
        kolodaView.animator = BackgroundKolodaAnimator(koloda: kolodaView)
        
//        kolodaView.dataSource = self
//        kolodaView.delegate = self
        
    }
    //str_CatgorySaved
    override func viewWillAppear(_ animated: Bool) {
        int_Selected2  = 0
        btn_SaveFavorite.setTitle(str_CatgorySaved,for: .normal)
        
        btn_SaveFavorite.titleLabel?.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFont(font: 15))
        self.get_FlashCard()
        
        timer_ScreenSecond = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(ScreenSecond), userInfo: nil, repeats: true)

    }
    override func viewWillDisappear(_ animated: Bool) {
        timer_Count.invalidate()
        timer_Quation.invalidate()
        
        self.post_AddTimeForTabUse(time: String(int_ScreenSecond))
        int_ScreenSecond = 0
        timer_ScreenSecond.invalidate()
        
        UIApplication.shared.endIgnoringInteractionEvents()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func viewSetup() {
        picker.delegate = self
        
        viewCard.backgroundColor = cardDefaultColor
        viewWordDetails.backgroundColor = cardDefaultColor
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.tapBarButton(_:)))
        
//        longPressGesture = UILongPressGestureRecognizer(target: self, action: #selector(self.longPressEvent(_:)))
//        longPressGesture.isEnabled = false
//        viewCard.addGestureRecognizer(longPressGesture)
        viewCard.addGestureRecognizer(tapGesture)
        
        self.showAndHideOtherViews(true)
        viewFront.isHidden = false
        viewWordDetails.isHidden = true
    }
    //MARK: - Gesture Method -
    @objc func tapBarButton(_ sender: UITapGestureRecognizer) {
        
        let vw = kolodaView.viewForCard(at: int_Selected) as? OverlayView

        if vw != nil{
            for subview in (vw?.subviews)! {
                self.vw_ManageTag(int_Value: subview.tag, view: subview)

                for subview2 in (subview.subviews) {
                    self.vw_ManageTag(int_Value: subview2.tag, view: subview2)

                    for subview3 in (subview2.subviews) {
                        self.vw_ManageTag(int_Value: subview3.tag, view: subview3)
                    }
                }
            }
            
//            longPressGesture = UILongPressGestureRecognizer(target: self, action: #selector(self.longPressEvent(_:)))
//            viewCard.addGestureRecognizer(longPressGesture)
            
            txtWord.isEnabled = false
            btnCloseDialogImage.isHidden = true
            btnEditWordImage.isHidden = true
            btnEditImage.isHidden = true
            if isShowCardAllDetails {
                isShowCardAllDetails = false
                UIView.transition(with: viewCard, duration: 0.3, options: .transitionFlipFromLeft, animations: nil, completion: nil)
                self.showAndHideOtherViews(true)
//                longPressGesture.isEnabled = false
                btnEditPhoto.isUserInteractionEnabled = false
            }else {
                isShowCardAllDetails = true
                UIView.transition(with: viewCard, duration: 0.3, options: .transitionFlipFromRight, animations: nil, completion: nil)
//                longPressGesture.isEnabled = true
                btnEditPhoto.isUserInteractionEnabled = true
                self.showAndHideOtherViews(false)
            }
        }
    }
    @objc func longPressEvent(_ sender: UILongPressGestureRecognizer) {
        txtWord.isEnabled = true
        btnCloseDialogImage.isHidden = false
        btnEditWordImage.isHidden = false
        btnEditImage.isHidden = false
        print("long preessssss")
    }
    
    // MARK: - Function -
    func showCameraOption() {
        self.picker.navigationBar.tintColor = UIColor.white
        let alert = UIAlertController(title: GlobalConstants.appName, message: "Select Photo Option", preferredStyle: UIAlertControllerStyle.actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: UIAlertActionStyle.default, handler: { (action) in
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera)
            {
                self.picker.allowsEditing = true
                self.picker.sourceType = .camera
                
                self.present(self.picker, animated: true, completion: nil)
            }
        }))
        alert.addAction(UIAlertAction(title: "Gallery", style: UIAlertActionStyle.default, handler: { (action) in
            self.picker.allowsEditing = true
            self.picker.sourceType = .photoLibrary
            self.present(self.picker, animated: true, completion: nil)
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
    }
    func showAndHideOtherViews(_ isShow: Bool) {
        viewFront.isHidden = !isShow
        txtWord.isHidden = isShow
        btnGoogle.isHidden = isShow
        btnEditPhoto.isHidden = isShow
        lblOtherWord.isHidden = isShow
        imgVwWord.isHidden = isShow
        btnVolume.isHidden = isShow
        
        imgGoogle.isHidden = isShow
    }
    func manageDataReload(){
        self.manageQuationTimer()
        
        if arr_Main.count == 0{
            vw_NoData.isHidden = false
            
            UIApplication.shared.beginBackgroundTask(expirationHandler: nil)
            timer_Count = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(timerManage), userInfo: nil, repeats: true)
            RunLoop.main.add(timer_Count, forMode: .defaultRunLoopMode)
            
            let imageData = try? Data(contentsOf: Bundle.main.url(forResource: "gif_Timer", withExtension: "gif")!)
            let advTimeGif = UIImage.gifImageWithData(imageData!)
            img_GIF.image = advTimeGif
            
        }else{
            vw_NoData.isHidden = true
            kolodaView.reloadData()
            self.reloadDataForKolodaView()
            
            lbl_TotalCount.text = "\(Int(int_ReadedCount)! + int_Selected2)/\(int_TotalCount) Words"
            btn_SaveFavorite.setTitle("\(str_CatgorySaved) (\(Int(int_ReadedCount)! + int_Selected2)/\(int_TotalCount) Words), To be review:\((Int(int_TotalCount)! - (Int(int_ReadedCount)! + int_Selected2))) ",for: .normal)
            
            if int_TotalCount != "0"{
                let int_TotalWidth : Int = Int(GlobalConstants.windowWidth - 40)
                let int_PerWord : Int = int_TotalWidth/Int(int_TotalCount)!
                con_SliderWidth.constant = CGFloat(int_PerWord * (Int(int_ReadedCount)! + int_Selected2))
            }
            
//            int_TotalCount = response.getStringForID(key: "total")
//            int_ReadedCount = response.getStringForID(key: "readed")
//            int_NextQuation = response.getStringForID(key: "next")
        }
    }
    func manageNextQua(){
        
        var bookMore : Bool = false
        if objDetailView.str_subcategory_id == "0"{
           
            if int_Selected2 < arr_Main.count{
                bookMore = true
            }else{
                vw_NoData.isHidden = false
                int_Selected = 0
                int_Selected2 = 0
                int_TotalCount = "0"
                int_ReadedCount = "0"
                int_TimerValue  = ""
                bool_Fail = true
                
                 if int_NextQuation == "1"{
                    int_NextQuation = "0"
                    
                    lbl_Timer_Header.text = "Review will start shortly"
                    let imageData = try? Data(contentsOf: Bundle.main.url(forResource: "gif_ServiceCalling", withExtension: "gif")!)
                    let advTimeGif = UIImage.gifImageWithData(imageData!)
                    img_GIF.image = advTimeGif
                    
                    Timer.scheduledTimer(timeInterval: 3.0, target: self, selector: #selector(get_FlashCard), userInfo: nil, repeats: false)

                 }else{
                    int_NextQuation = "0"
                    
                    lbl_Timer_Header.text = "Review will start shortly"
                    let imageData = try? Data(contentsOf: Bundle.main.url(forResource: "gif_Timer", withExtension: "gif")!)
                    let advTimeGif = UIImage.gifImageWithData(imageData!)
                    img_GIF.image = advTimeGif
                    
                    Timer.scheduledTimer(timeInterval: 3.0, target: self, selector: #selector(get_FlashCard), userInfo: nil, repeats: false)
                }
            }
        }else{
            if int_Selected2 < arr_Main.count{
                bookMore = true
            }else{
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
    
    func reloadDataForKolodaView(){
        
        let vw = kolodaView.viewForCard(at: int_Selected) as? OverlayView
        
        if vw != nil{
            for subview in (vw?.subviews)! {
                self.vw_ManageTag2(int_Value: subview.tag, view: subview)
                
                for subview2 in (subview.subviews) {
                    self.vw_ManageTag2(int_Value: subview2.tag, view: subview2)
                    
                    for subview3 in (subview2.subviews) {
                        self.vw_ManageTag2(int_Value: subview3.tag, view: subview3)
                    }
                }
            }
        }
    }
    
    @objc func ScreenSecond(){
        int_ScreenSecond = int_ScreenSecond + 1
    }
    
    
    //MARK: - Manage function for value save -
    @objc func timerManage()
    {
        lbl_Timer_Header.text = "Review will start shortly"
        
        let int_Time = Int(int_TimerValue)!/1000
        
        if int_Time > 0{
            let hours : Int = int_Time / 3600;
            let minutes : Int = (int_Time % 3600) / 60;
            let seconds : Int = int_Time % 60;
            
            var str_Hous : String = String(Int(hours))
            var str_Min : String = String(Int(minutes))
            var str_Sec : String = String(Int(seconds))
            if hours < 10{
                str_Hous = "0\(Int(hours))"
            }
            if minutes < 10{
                str_Min = "0\(Int(minutes))"
            }
            if seconds < 10{
                str_Sec = "0\(Int(seconds))"
            }
            
            lbl_Timer.text = "\(str_Hous):\(str_Min):\(str_Sec)"
        }else{
            timer_Count.invalidate()
            self.get_FlashCard()
            lbl_Timer_Header.text = ""
            lbl_Timer.text = ""
            img_GIF.image = nil
        }
        
        int_TimerValue = String(Int(int_TimerValue)! - 1000)
        
    }

    
    @objc func timerManage2()
    {
        let int_Time = Int(int_Review_timer)!/1000
        
        if int_Time > 0{
 
        }else{
            timer_Quation.invalidate()
//            self.navigationController?.popViewController(animated: true)
            Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(get_FlashCard), userInfo: nil, repeats: false)
        }
        
        int_Review_timer = String(Int(int_Review_timer)! - 1000)
    }
    func manageQuationTimer(){
        if Int(int_Review_timer)! > 0{
            
            UIApplication.shared.beginBackgroundTask(expirationHandler: nil)
            timer_Quation = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(timerManage2), userInfo: nil, repeats: true)
            RunLoop.main.add(timer_Quation, forMode: .defaultRunLoopMode)
        }
    }
    
    
    // MARK: - Button Event -
    @IBAction func editPhotoClick(_ sender: Any) {
//        self.showCameraOption()

    }
    @IBAction func backWordDetailsClick(_ sender: Any) {
        //        toggleLeft()
        viewWordDetails.isHidden = true
    }
    @IBAction func googleClick(_ sender: Any) {
//        viewWordDetails.isHidden = false
//        btnDetailDictIcon.setImage(UIImage(named:"google"), for: .normal)
    }
    @IBAction func otherDictClick(_ sender: Any) {
        //        toggleLeft()
        viewWordDetails.isHidden = false
        btnDetailDictIcon.setImage(UIImage(named:"convert"), for: .normal)
    }
    @IBAction func btn_Accept(_ sender: Any) {
//        let obj = arr_Main[int_Selected] as! GlobalObjectCard
//        self.get_AnsFlashCard(cardId: obj.str_FlatCard_id, box: obj.str_FlatCard_box, answer: "0")
        
        kolodaView?.swipe(.right)
    }
    @IBAction func btn_Reject(_ sender: Any) {
        
//        let obj = arr_Main[int_Selected] as! GlobalObjectCard
//        self.get_AnsFlashCard(cardId: obj.str_FlatCard_id, box: obj.str_FlatCard_box, answer: "1")
        
        kolodaView?.swipe(.left)
    }
    @IBAction func btn_CloseEdit(_ sender: Any) {
        btnCloseDialogImage.isHidden = true
        btnEditWordImage.isHidden = true
        btnEditImage.isHidden = true
        
        txtWord.isEnabled = false
    }
    @IBAction func btnSound(_ sender: Any) {
        var obj = arr_Main[int_Selected] as! GlobalObjectCard
        if obj.str_FlatCard_traslation_Play == "1"{
            playMusic(str_TraslationText : obj.str_FlatCard_keyword,Language : obj.str_FlatCard_abbrivation ?? "en")
        }
    }
    
    //MARK: - Service Method -
    @objc func get_FlashCard(){
        
        
        //Declaration URL
//        let strURL = "\(GlobalConstants.BaseURL)get_question_card"
        let strURL = "\(GlobalConstants.BaseURL)get_leitner_question"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "user_id" : objUser?.user_UserID,
            "category_id" : objDetailView.str_category_id,
            "sub_category_id" : objDetailView.str_subcategory_id,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "get_question_card"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.indicatorShowOrHide = false
        
        webHelper.startDownload()
    }
    
    func get_AnsFlashCard(cardId : String,box : String,answer : String,subcatgory : String){
        UIApplication.shared.beginIgnoringInteractionEvents()
        
        //Declaration URL
//        let strURL = "\(GlobalConstants.BaseURL)answer_leitner_card"
        let strURL = "\(GlobalConstants.BaseURL)set_leitner_answer"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "user_id" : objUser?.user_UserID,
            "category_id" : objDetailView.str_category_id,
            "sub_category_id" : subcatgory,
            "card_id" : cardId,
            "box" : box,
            "answer" : answer,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "answer_leitner_card"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.indicatorShowOrHide = false
        
        webHelper.startDownload()
    }
    
    func post_AddTimeForTabUse(time : String){
        
        if Int(time)! >= Int(GlobalConstants.int_AddedUsingReviewTime){
            //Declaration URL
            let strURL = "\(GlobalConstants.BaseURL)user_interaction"
            
            var localTimeZoneAbbreviation: String { return TimeZone.current.abbreviation() ?? "" }
            
            //Pass data in dictionary
            var jsonData : NSDictionary =  NSDictionary()
            jsonData = [
                "user_id" : objUser?.user_UserID,
                "timezone" : localTimeZoneAbbreviation,
                "time" : time,
            ]
            
            //Create object for webservicehelper and start to call method
            let webHelper = WebServiceHelper()
            webHelper.strMethodName = "user_interaction"
            webHelper.methodType = "post"
            webHelper.strURL = strURL
            webHelper.dictType = jsonData
            webHelper.dictHeader = NSDictionary()
            webHelper.delegateWeb = self
            webHelper.serviceWithAlert = false
            webHelper.indicatorShowOrHide = false
            
            webHelper.startDownload()
        }
    }
    
    func get_AlertAns(type : String,subCategory : String){
        
        //Declaration URL
        //        let strURL = "\(GlobalConstants.BaseURL)answer_leitner_card"
        let strURL = "\(GlobalConstants.BaseURL)read_new_cards"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "user_id" : objUser?.user_UserID,
            "category_id" : objDetailView.str_category_id,
            "sub_category_id" : subCategory,
            "next" : type,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "read_new_cards"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.indicatorShowOrHide = false
        
        webHelper.startDownload()
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
extension ReviewViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
extension ReviewViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any])
    {
        let pickedImage = info[UIImagePickerControllerEditedImage] as? UIImage
        imgVwWord.image = pickedImage

        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}

extension ReviewViewController: KolodaViewDelegate {
    func kolodaDidRunOutOfCards(_ koloda: KolodaView) {
        kolodaView.resetCurrentCardIndex()
    }
    
    func koloda(_ koloda: KolodaView, didSelectCardAt index: Int) {
//        UIApplication.shared.openURL(URL(string: "https://yalantis.com/")!)
    }
    
    func kolodaShouldApplyAppearAnimation(_ koloda: KolodaView) -> Bool {
        return true
    }
    
    func kolodaShouldMoveBackgroundCard(_ koloda: KolodaView) -> Bool {
        return false
    }
    
    func kolodaShouldTransparentizeNextCard(_ koloda: KolodaView) -> Bool {
        return true
    }
    
    func koloda(kolodaBackgroundCardAnimation koloda: KolodaView) -> POPPropertyAnimation? {
        let animation = POPSpringAnimation(propertyNamed: kPOPViewFrame)
        animation?.springBounciness = frameAnimationSpringBounciness
        animation?.springSpeed = frameAnimationSpringSpeed
        return animation
    }
    
    func koloda(_ koloda: KolodaView, didShowCardAt index: Int) {
        
        int_Selected = index
        
        print(index)
    }
    
    func koloda(_ koloda: KolodaView, didSwipeCardAt index: Int, in direction: SwipeResultDirection)
    {
        int_Selected2 = int_Selected2 + 1
        var obj = arr_Main[int_Selected2-1] as! GlobalObjectCard
        
        self.manageNextQua()
        
//        if int_Selected == 0{
//            obj = arr_Main[int_Selected] as! GlobalObjectCard
//        }else{
//            obj = arr_Main[int_Selected-1] as! GlobalObjectCard
//        }
        if direction.rawValue == "left"{
            self.get_AnsFlashCard(cardId: obj.str_FlatCard_id, box: obj.str_FlatCard_box, answer: "0", subcatgory : obj.str_FlatCard_sub_category_id)
        }else{
            self.get_AnsFlashCard(cardId: obj.str_FlatCard_id, box: obj.str_FlatCard_box, answer: "1", subcatgory : obj.str_FlatCard_sub_category_id)
        }
    }
    
}


extension ReviewViewController: KolodaViewDataSource {
    
    func kolodaNumberOfCards(_ koloda:KolodaView) -> Int {
        return arr_Main.count
    }
    
    func kolodaSpeedThatCardShouldDrag(_ koloda: KolodaView) -> DragSpeed {
        return .slow
    }
    
    func koloda(_ koloda: KolodaView, viewForCardAt index: Int) -> UIView {
        
        int_Selected = index - 1
        if int_Selected < 0{
            int_Selected = 0
        }

       let vw = Bundle.main.loadNibNamed("OverlayView", owner: self, options: nil)![0] as? OverlayView
        
       for subview in (vw?.subviews)! {
            self.vw_ManageTag(int_Value: subview.tag, view: subview)

            for subview2 in (subview.subviews) {
                self.vw_ManageTag(int_Value: subview2.tag, view: subview2)

                for subview3 in (subview2.subviews) {
                    self.vw_ManageTag(int_Value: subview3.tag, view: subview3)
                }
            }
        }

        if int_Selected < arr_Main.count{
            self.viewSetup()
        }
        
        int_Selected = index
        return vw!
    }
    
    func vw_ManageTag(int_Value : Int,view : Any) {
        
        if int_Selected < arr_Main.count{
            //Other Tab Demo data
            let obj = arr_Main[int_Selected] as! GlobalObjectCard
            
            switch int_Value {
            case 100:
                self.viewCard = view as! UIView
                break
            case 101:
                self.viewWordDetails = view as! UIView
                break
            case 102:
                self.viewFront = view as! UIView
                for subview2 in (self.viewFront.subviews) {
                    self.vw_ManageTag(int_Value: subview2.tag, view: subview2)
                }
                break
            case 201:
                self.txtWord = view as! UITextField
                self.txtWord.text = obj.str_FlatCard_keyword as! String
                break
            case 202:
                self.txtWord2 = view as! UITextField
                self.txtWord2.text = obj.str_FlatCard_keyword as! String
                break
            case 302:
                self.lblOtherWord = view as! UILabel
                if obj.arr_FlatCardInfo.count != 0{
                    let objInfo = obj.arr_FlatCardInfo[0] as! GlobalObjectCard
                    self.lblOtherWord.text = objInfo.str_FlatCardInfo_translate
                }
                break
            case 401:
                self.btnVolume = view as! UIButton
                if obj.str_FlatCard_traslation_Play == "1"{
                    self.btnVolume.isUserInteractionEnabled = true
                    self.btnVolume.alpha = 1.0
                }else{
                    self.btnVolume.isUserInteractionEnabled = false
                    self.btnVolume.alpha = 0.3
                }
                self.btnVolume.addTarget(self, action:#selector(self.btnSound(_:)), for: .touchUpInside)
                break
            case 402:
                self.btnEditPhoto = view as! UIButton
                self.btnEditPhoto.isUserInteractionEnabled = false
//                self.btnEditPhoto.addTarget(self, action:#selector(self.editPhotoClick(_:)), for: .touchUpInside)
                break
            case 404:
                self.btnDetailDictIcon = view as! UIButton
                switch Int(obj.str_FlatCard_dictionary_id) {
                case 1?:
                    self.btnDetailDictIcon.setImage(UIImage(named:"icon_Dictionary1"), for: UIControlState.normal)
                    break
                case 2?:
                    self.btnDetailDictIcon.setImage(UIImage(named:"icon_Dictionary2"), for: UIControlState.normal)
                        if validationforLexinEnglishDictionaryShowInputParamater(From: obj.str_FlatCard_abbrivation_Lexin_From, To: obj.str_FlatCard_abbrivation_Lexin_To) == true{
                        self.btnDetailDictIcon.setImage(UIImage(named:"icon_Dictionary2-1"), for: UIControlState.normal)
                    }
                    break
                case 3?:
                    self.btnDetailDictIcon.setImage(UIImage(named:"icon_Dictionary3"), for: UIControlState.normal)
                    break
                case 4?:
                    self.btnDetailDictIcon.setImage(UIImage(named:"icon_Quizlet"), for: UIControlState.normal)
                    break
                default:
                    break
                }
                
//                self.btnDetailDictIcon.addTarget(self, action:#selector(self.btn_CloseEdit(_:)), for: .touchUpInside)
                break
            case 405:
                self.btnCloseDialogImage = view as! UIButton
                self.btnCloseDialogImage.addTarget(self, action:#selector(self.btn_CloseEdit(_:)), for: .touchUpInside)
                break
            case 406:
                self.btnEditWordImage = view as! UIButton
                self.btnEditWordImage.addTarget(self, action:#selector(self.btn_CloseEdit(_:)), for: .touchUpInside)
                break
            case 407:
                self.btnEditImage = view as! UIButton
                break
            case 408:
                self.btnGoogle = view as! UIButton
                self.btnGoogle.addTarget(self, action:#selector(self.googleClick(_:)), for: .touchUpInside)
                break
            case 409:
                self.btnWordDetail = view as! UIButton
                self.btnWordDetail.addTarget(self, action:#selector(self.backWordDetailsClick(_:)), for: .touchUpInside)
                break
            case 410:
                self.btnSound = view as! UIButton
                if obj.str_FlatCard_traslation_Play == "1"{
                    self.btnSound.isUserInteractionEnabled = true
                    self.btnSound.alpha = 1.0
                }else{
                    self.btnSound.isUserInteractionEnabled = false
                    self.btnSound.alpha = 0.3
                }
                self.btnSound.addTarget(self, action:#selector(self.btnSound(_:)), for: .touchUpInside)
                
                break
                
                
            case 501:
                self.imgVwWord = view as! UIImageView
                self.imgVwWord.sd_setImage(with: URL(string: (obj.str_FlatCard_card_image)), placeholderImage: UIImage(named:"img_PlaceHolderImage"))
                break
            case 503:
                self.imgGoogle = view as! UIImageView
                
                switch Int(obj.str_FlatCard_dictionary_id) {
                case 1?:
                    self.imgGoogle.image = UIImage(named:"icon_Dictionary1")
                    break
                case 2?:
                    self.imgGoogle.image = UIImage(named:"icon_Dictionary2")
                    if validationforLexinEnglishDictionaryShowInputParamater(From: obj.str_FlatCard_abbrivation_Lexin_From, To: obj.str_FlatCard_abbrivation_Lexin_To) == true{
                        self.imgGoogle.image = UIImage(named:"icon_Dictionary2-1")
                    }
                    break
                case 3?:
                    self.imgGoogle.image = UIImage(named:"icon_Dictionary3")
                    break
                case 4?:
                    self.imgGoogle.image = UIImage(named:"icon_Quizlet")
                    break
                default:
                    break
                }
                
                break
            case 601:
                self.lbl_LevelShow = view as! UILabel
                self.lbl_LevelShow.text = "Level - \(obj.str_FlatCard_box as! String)"
                break
                
            default:
                break
            }
        }
    }
    func vw_ManageTag2(int_Value : Int,view : Any) {
        
        if int_Selected < arr_Main.count{
            //Other Tab Demo data
            let obj = arr_Main[int_Selected] as! GlobalObjectCard
            
            switch int_Value {
            case 102:
                for subview2 in (self.viewFront.subviews) {
                    self.vw_ManageTag2(int_Value: subview2.tag, view: subview2)
                }
                break
            case 201:
                self.txtWord.text = obj.str_FlatCard_keyword as! String
                break
            case 202:
                self.txtWord2.text = obj.str_FlatCard_keyword as! String
                break
            case 302:
                if obj.arr_FlatCardInfo.count != 0{
                    let objInfo = obj.arr_FlatCardInfo[0] as! GlobalObjectCard
                    self.lblOtherWord.text = objInfo.str_FlatCardInfo_translate
                }
                break
            case 401:
                if obj.str_FlatCard_traslation_Play == "1"{
                    self.btnVolume.isUserInteractionEnabled = true
                    self.btnVolume.alpha = 1.0
                }else{
                    self.btnVolume.isUserInteractionEnabled = false
                    self.btnVolume.alpha = 0.3
                }
                break
            case 402:
                self.btnEditPhoto.isUserInteractionEnabled = false
                break
            case 404:
                switch Int(obj.str_FlatCard_dictionary_id) {
                case 1?:
                    self.btnDetailDictIcon.setImage(UIImage(named:"icon_Dictionary1"), for: UIControlState.normal)
                    break
                case 2?:
                    self.btnDetailDictIcon.setImage(UIImage(named:"icon_Dictionary2"), for: UIControlState.normal)
                    if validationforLexinEnglishDictionaryShowInputParamater(From: obj.str_FlatCard_abbrivation_Lexin_From, To: obj.str_FlatCard_abbrivation_Lexin_To) == true{
                        self.btnDetailDictIcon.setImage(UIImage(named:"icon_Dictionary2-1"), for: UIControlState.normal)
                    }
                    break
                case 3?:
                    self.btnDetailDictIcon.setImage(UIImage(named:"icon_Dictionary3"), for: UIControlState.normal)
                    break
                case 4?:
                    self.btnDetailDictIcon.setImage(UIImage(named:"icon_Quizlet"), for: UIControlState.normal)
                    break
                default:
                    break
                }
                
                //                self.btnDetailDictIcon.addTarget(self, action:#selector(self.btn_CloseEdit(_:)), for: .touchUpInside)
                break
            case 405:
                self.btnCloseDialogImage.addTarget(self, action:#selector(self.btn_CloseEdit(_:)), for: .touchUpInside)
                break
            case 406:
                self.btnEditWordImage.addTarget(self, action:#selector(self.btn_CloseEdit(_:)), for: .touchUpInside)
                break
            case 408:
                self.btnGoogle.addTarget(self, action:#selector(self.googleClick(_:)), for: .touchUpInside)
                break
            case 409:
                self.btnWordDetail.addTarget(self, action:#selector(self.backWordDetailsClick(_:)), for: .touchUpInside)
                break
            case 410:
                if obj.str_FlatCard_traslation_Play == "1"{
                    self.btnSound.isUserInteractionEnabled = true
                    self.btnSound.alpha = 1.0
                }else{
                    self.btnSound.isUserInteractionEnabled = false
                    self.btnSound.alpha = 0.3
                }
                self.btnSound.addTarget(self, action:#selector(self.btnSound(_:)), for: .touchUpInside)
                
                break
                
                
            case 501:
                self.imgVwWord.sd_setImage(with: URL(string: (obj.str_FlatCard_card_image)), placeholderImage: UIImage(named:"img_PlaceHolderImage"))
                break
            case 503:
                
                switch Int(obj.str_FlatCard_dictionary_id) {
                case 1?:
                    self.imgGoogle.image = UIImage(named:"icon_Dictionary1")
                    break
                case 2?:
                    self.imgGoogle.image = UIImage(named:"icon_Dictionary2")
                    if validationforLexinEnglishDictionaryShowInputParamater(From: obj.str_FlatCard_abbrivation_Lexin_From, To: obj.str_FlatCard_abbrivation_Lexin_To) == true{
                        self.imgGoogle.image = UIImage(named:"icon_Dictionary2-1")
                    }
                    break
                case 3?:
                    self.imgGoogle.image = UIImage(named:"icon_Dictionary3")
                    break
                case 4?:
                    self.imgGoogle.image = UIImage(named:"icon_Quizlet")
                    break
                default:
                    break
                }
                
                break
            case 601:
                self.lbl_LevelShow.text = "Level - \(obj.str_FlatCard_box as! String)"
                break
                
            default:
                break
            }
        }
    }
    
    func koloda(_ koloda: KolodaView, viewForCardOverlayAt index: Int) -> OverlayView? {
        
        return Bundle.main.loadNibNamed("OverlayView", owner: self, options: nil)![0] as? OverlayView
    }
}


extension ReviewViewController : WebServiceHelperDelegate{
    //MARK: - Webservice Helper -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
//        self.completedServiceCalling()
        
        let response = data as! NSDictionary
        let json2 = try JSON(jsonObject : response)
        
        if strRequest == "get_question_card" {
            
            btn_SaveFavorite.setTitle(str_CatgorySaved,for: .normal)
            
            int_TotalCount = response.getStringForID(key: "total")
            int_ReadedCount = response.getStringForID(key: "readed")
            int_NextQuation = response.getStringForID(key: "next")
            int_SubCategory = response.getStringForID(key: "sub_category_id")
            
            arr_Main = []
            for i in (0..<json2["flashcards"].array!.count) {
                str_CatgorySaved = "\(response["category_name"] as! String)/\(response["sub_category_name"] as! String)"

                let dict_Data = json2["flashcards"][i].dictionaryObject! as NSDictionary
                
                //Other Tab Demo data
                let obj = GlobalObjectCard ()
                    
                obj.str_FlatCard_id = dict_Data.getStringForID(key: "card_id")
                obj.str_FlatCard_keyword = dict_Data.getStringForID(key: "keyword")
                obj.str_FlatCard_category_id = dict_Data.getStringForID(key: "category_id")
                obj.str_FlatCard_sub_category_id = dict_Data.getStringForID(key: "sub_category_id")
                obj.str_FlatCard_from_language = dict_Data.getStringForID(key: "from_language")
                obj.str_FlatCard_to_language = dict_Data.getStringForID(key: "to_language")
                obj.str_FlatCard_dictionary_id = dict_Data.getStringForID(key: "dictionary_id")
                obj.str_FlatCard_card_image = dict_Data.getStringForID(key: "card_image")
                obj.str_FlatCard_color_code = dict_Data.getStringForID(key: "color_code")
                obj.str_FlatCard_card_type = dict_Data.getStringForID(key: "card_type")
                obj.str_FlatCard_store_type = dict_Data.getStringForID(key: "store_type")
                obj.str_FlatCard_card_thumb = dict_Data.getStringForID(key: "card_thumb")
                obj.str_FlatCard_box = dict_Data.getStringForID(key: "box")
                
                obj.isCardFront = true
                
                let arr_CardInfo = dict_Data["card_info"] as! NSArray
                for k in (0..<arr_CardInfo.count) {
                    let dict_Data3 = arr_CardInfo[k] as! NSDictionary
                    
                    let obj3 = GlobalObjectCard ()
                    
                    obj3.str_FlatCardInfo_id = dict_Data3.getStringForID(key: "id")
                    obj3.str_FlatCardInfo_card_id = dict_Data3.getStringForID(key: "card_id")
                    obj3.str_FlatCardInfo_meanings = dict_Data3.getStringForID(key: "meanings")
                    obj3.str_FlatCardInfo_translate = dict_Data3.getStringForID(key: "translate")
                    obj3.str_FlatCardInfo_example = dict_Data3.getStringForID(key: "example")
                    obj3.str_FlatCardInfo_inflection = dict_Data3.getStringForID(key: "inflection")
                    obj3.str_FlatCardInfo_synonym = dict_Data3.getStringForID(key: "synonym")
                    obj3.str_FlatCardInfo_another_word = dict_Data3.getStringForID(key: "another_word")
                    obj3.str_FlatCardInfo_another_created_at = dict_Data3.getStringForID(key: "created_at")
                    
                    obj.arr_FlatCardInfo.add(obj3)
                }
                
                let dict_From = dict_Data["to_lang"] as! NSDictionary
                let dict_To = dict_Data["from_lang"] as! NSDictionary
                
                obj.str_FlatCard_traslation_Play = "0"
                if playAvailble(Language : (dict_To.getStringForID(key: "abbrivation"))) == true{
                    obj.str_FlatCard_traslation_Play = "1"
                    obj.str_FlatCard_abbrivation = dict_To.getStringForID(key: "abbrivation")
                }
                obj.str_FlatCard_abbrivation_Lexin_From = dict_To.getStringForID(key: "abbrivation_lexin")
                obj.str_FlatCard_abbrivation_Lexin_To = dict_From.getStringForID(key: "abbrivation_lexin")
                
                arr_Main.add(obj)
            }
            
            
            int_Review_timer = response.getStringForID(key: "review_timer")
            if arr_Main.count == 0{
                int_TimerValue = response.getStringForID(key: "timer")
                int_AlertQuation = response.getStringForID(key: "alert")
                
                if Int(int_AlertQuation) == 1{
                    let alert = UIAlertController(title: GlobalConstants.appName, message: response["message"] as! String, preferredStyle: UIAlertControllerStyle.alert)

                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: { (action) in
                        let indexpath_Header : NSIndexPath = NSIndexPath(row: 1, section: 0)
                        cardDetailsView?.collectionView((cardDetailsView?.cv_HeaderSelection)!, didSelectItemAt: indexpath_Header as IndexPath)
                    }))

                    self.present(alert, animated: true, completion: nil)
                }else if Int(int_AlertQuation) == 2{
                    let alert = UIAlertController(title: GlobalConstants.appName, message: response["message"] as! String, preferredStyle: UIAlertControllerStyle.alert)

                    alert.addAction(UIAlertAction(title: "YES", style: UIAlertActionStyle.default, handler: { (action) in
                        let indexpath_Header : NSIndexPath = NSIndexPath(row: 1, section: 0)
                        self.get_AlertAns(type: "1",subCategory: self.int_SubCategory)
                        self.manageDataReload()
                    }))
                    alert.addAction(UIAlertAction(title: "NO", style: UIAlertActionStyle.default, handler: { (action) in
                        let indexpath_Header : NSIndexPath = NSIndexPath(row: 1, section: 0)
                        
                        self.get_AlertAns(type: "0",subCategory: self.int_SubCategory)
                        self.navigationController?.popViewController(animated: true)
                    }))

                    self.present(alert, animated: true, completion: nil)
                }else{
                    self.manageDataReload()
                }
            }else{
                self.manageDataReload()
            }
        }else if strRequest == "answer_leitner_card" {
            UIApplication.shared.endIgnoringInteractionEvents()
            int_Review_timer = response.getStringForID(key: "review_timer")
            
            let alert = response.getStringForID(key: "alert")
            if alert == "2"{
                let alert = UIAlertController(title: GlobalConstants.appName, message: response["message"] as! String, preferredStyle: UIAlertControllerStyle.alert)
                
                alert.addAction(UIAlertAction(title: "YES", style: UIAlertActionStyle.default, handler: { (action) in
                    let indexpath_Header : NSIndexPath = NSIndexPath(row: 1, section: 0)
                    self.get_AlertAns(type: "1",subCategory: self.int_SubCategory)
                    self.manageDataReload()
                }))
                alert.addAction(UIAlertAction(title: "NO", style: UIAlertActionStyle.default, handler: { (action) in
                    let indexpath_Header : NSIndexPath = NSIndexPath(row: 1, section: 0)
                    self.get_AlertAns(type: "0",subCategory: self.int_SubCategory)
                    self.navigationController?.popViewController(animated: true)
                }))
                
                self.present(alert, animated: true, completion: nil)
            }else{
                if bool_Fail == false{
                 self.manageDataReload()
                }
                bool_Fail = false
            }
            
        }else if strRequest == "user_interaction"{
            
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        UIApplication.shared.endIgnoringInteractionEvents()
        
        if objDetailView.str_subcategory_id != "0"{
            self.navigationController?.popViewController(animated: true)
        }
        
        if error._code == 100{
            let alert = UIAlertController(title: GlobalConstants.appName, message: error._domain, preferredStyle: UIAlertControllerStyle.alert)
            
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: { (action) in
                let indexpath_Header : NSIndexPath = NSIndexPath(row: 1, section: 0)
                cardDetailsView?.collectionView((cardDetailsView?.cv_HeaderSelection)!, didSelectItemAt: indexpath_Header as IndexPath)
            }))
            
            self.present(alert, animated: true, completion: nil)
        }
//        self.completedServiceCalling()
        
//        if bool_ViewWill == true{
//            arr_Main = []
//            self.reloadData()
//        }
    }
}




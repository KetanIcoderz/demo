//
//  QuizletCardViewController.swift
//  Minnaz
//
//  Created by iCoderz_02 on 01/01/18.
//  Copyright © 2018 iCoderz. All rights reserved.
//

import UIKit
import Quizlet_iOS
import FMDB
import SwiftyJSON
import EmptyDataSet_Swift

class QuizletCardViewController: UIViewController, DismissViewDelegate, DismissWordSelectionDelegate {
    
    var aryCardData : NSMutableArray = []
    var arr_Main : NSMutableArray = []
    
    var str_ID : String = ""
    var bool_Load: Bool = false
    
    var objListSelected : setsListObject = setsListObject()
    
    
    @IBOutlet var cv_Main: UICollectionView!
    
    @IBOutlet var lblTotalFlashCard: UILabel!
    @IBOutlet var lbltopicTitle: UILabel!
    @IBOutlet var lblTopicOwner: UILabel!
    @IBOutlet var btnDownload: UIBarButtonItem!
    
    
    @IBOutlet var viewDocumentDirectory: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()
        
        arr_Main = []
        
        viewDocumentDirectory.isHidden = true;

        //First time sevice call for featured product
        bool_Load = true
        self.Get_QuizLetDetail()
        
//        //        let objstrID = objListSelected.strid
//
//        lblTotalFlashCard.text = "00 / \(objListSelected.strTotalCard) Flashcards used"
//
//        lbltopicTitle.text = "Search Result for: \(objListSelected.strSearch)"
//
//        lblTopicOwner.text = "Created By: \(objListSelected.strCreateBy)"
//
//        //Checkif Exist
//        arr_Main = getSelectedValues(setID: objListSelected.strid as! Int)
//
//        if arr_Main.count > 0
//        {
//            navigationItem.rightBarButtonItem = nil
//            self.aryCardData = []
//            aryCardData = getSavedCardData(setID: objListSelected.strid as! Int)
//
//        }
//        else{
//
//        indicatorShow()
//        Quizlet.shared().viewSet(bySetId: String(describing: objListSelected.strid), success: { (_ responseObject: Any) in
//
//            let response = responseObject as! NSDictionary
//            if response.count > 0
//            {
//                self.aryCardData = []
//                let aryData = response["terms"] as! NSArray
//                for i in (0..<aryData.count)
//                {
//                    let response = aryData[i] as! NSDictionary
//
//                    let objTerms = cardTermsObject()
//                    objTerms.strid = response["id"] ?? 0
//                    objTerms.strterm = response["term"] as! String
//                    objTerms.strdefinition = response["definition"] as! String
//
//                    let keyExists = response["image"] != nil
//                    if keyExists
//                    {
//                        let aryDataimg = response["image"] as? NSDictionary ?? NSDictionary()
//
//                        if aryDataimg.count > 0
//                        {
//                            objTerms.strimage = aryDataimg["url"] as! String
//                        }
//                    }
//
//                    self.aryCardData.add(objTerms)
//                }
//                self.tblViewCard.reloadData()
//                indicatorHide()
//            }
//
//        }, failure: { (_ error: Error?) in
//            indicatorHide()
//        })
//        }
//
//
    }
    
    //MARK: -  Delegate Popup -
    func ClickOption(info: NSInteger) {
        if info == 1 {
            if objUser?.category_SelectedSubCat != ""{
                self.post_CardSave(arr_Temp : arr_Main)
            }
        }
    }
    
    func ClickDismissWordSelectionOption(info: NSMutableArray) {
        
        var arr_Sub : NSMutableArray = []
        for count in 0..<arr_Main.count {
            let objCard = arr_Main[count] as! GlobalObjectCard
            
            var bool_value : Bool = true
            for count2 in 0..<info.count {
                let obj = info[count2] as! OCRSelectionObject
                
                if objCard.str_Quiz_Term == obj.str_Title{
                    bool_value = false
                    if obj.str_SaveOrNot == "1"{
                        arr_Sub.add(objCard)
                        break
                    }
                }
            }
            
            if bool_value == true{
                arr_Sub.add(objCard)
            }
        }
        self.post_CardSave(arr_Temp : arr_Sub)
    }
    
    
    //MARK: - Other Method -
    func commanMethod(){
        
        cv_Main.emptyDataSetDelegate = self
        cv_Main.emptyDataSetSource = self
        
    }
    func completedServiceCalling(){
        //        refresh_Item?.endRefreshing()
        bool_Load = false
    }
    func reloadData(){
        cv_Main.reloadData()
    }
    
    
    //MARK: - Button Method -
    @IBAction func btn_NavigationLeft(_ sender: Any) {
        //        toggleLeft()
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnDownloadPress(_ sender: Any) {
        
        if arr_Main.count != 0{
            if objUser?.category_SelectedSubCat == ""{
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let view = storyboard.instantiateViewController(withIdentifier: "SelectCategoryPopUpViewController") as! SelectCategoryPopUpViewController
                view.bool_Home = true
                view.delegate = self
                view.modalPresentationStyle = .custom
                view.modalTransitionStyle = .crossDissolve
                present(view, animated: true)
            }else{
                var arr_GetLocal : NSMutableArray = []
                for count in 0..<arr_Main.count {
                    let objCard = arr_Main[count] as! GlobalObjectCard
                    if objCard.str_CardSaveFlag != "-1" && objCard.str_CardSaveFlag != "0"{
                        let obj = OCRSelectionObject()
                        obj.str_Title = objCard.str_Quiz_Term
                        obj.str_SaveOrNot = "0"
                        obj.str_CatSave = objCard.str_CatSave
                        arr_GetLocal.add(obj)
                    }
                }
                
                if arr_GetLocal.count != 0{
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    let view = storyboard.instantiateViewController(withIdentifier: "WordSelectionViewController") as! WordSelectionViewController
                    view.arr_Data = arr_GetLocal
                    view.delegate = self
                    view.modalPresentationStyle = .custom
                    view.modalTransitionStyle = .crossDissolve
                    present(view, animated: true)
                }else{
                    self.post_CardSave(arr_Temp : arr_Main)
                }
                
            }
        }
    }
    
    @IBAction func btnClosePopup(_ sender: Any) {
        
        viewDocumentDirectory.isHidden = true;
    }
    
    @IBAction func CreateCategoryDone(_ sender: Any) {
        indicatorShow()
        perform(#selector(self.StartDownload), with: self, afterDelay: 1.0)
    }
    
    @IBAction func btn_Speak(_ sender : Any){
    
    }
    
    @objc func StartDownload()
    {
        insertQuizletSearchSet()
        if aryCardData.count > 0 {
            insertInTableCard()
        }
        navigationItem.rightBarButtonItem = nil
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //SQLite DB
    
    func insertQuizletSearchSet() {
        
        let setID = objListSelected.strid as! Int
        let setSearch = objListSelected.strSearch
        let setTitle = objListSelected.strtitle
        let setCreateBy = objListSelected.strCreateBy
        let setTermCount = objListSelected.strTotalCard as! Int

        
        database = FMDatabase(path: pathToDatabase!)
        
        if database != nil {
            // Open the database.
            if database.open() {

                let query = "insert into QuizletSearchSet (setID, setSearch, setTitle, setCreateBy, setTermCount) values (\(setID), '\(setSearch)', '\(setTitle)', '\(setCreateBy)', \(setTermCount));"
                
                if !database.executeStatements(query) {
                    print("Failed to insert initial data into the database.")
                    print(database.lastError(), database.lastErrorMessage())
                }
                database.close()
            }
            else {
                print("Could not open the database.")
            }
        }
            
        return
        
    }
    
    func insertInTableCard()
    {
        database = FMDatabase(path: pathToDatabase!)
        
        if database != nil {
            // Open the database.
            if database.open() {
                
                
                for i in (0..<aryCardData.count)
                {
                    var query = ""

                    let objSaveCard : cardTermsObject = aryCardData[i] as! cardTermsObject
                    
                    let setID = objListSelected.strid as! Int
                    let cardID = objSaveCard.strid
                    let cardTerm = objSaveCard.strterm
                    let cardDefi = objSaveCard.strdefinition
                    let cardimgURL = objSaveCard.strimage
                    
                    
                    query = "INSERT INTO QuizletCardSet (setID, cardID, cardTerm, cardDefi, cardimgURL) VALUES (\(setID), \(cardID), '\(cardTerm)', '\(cardDefi)', '\(cardimgURL)');"
                    
                    if !database.executeStatements(query) {
                        print("Failed to insert initial data into the database.")
                        print(database.lastError(), database.lastErrorMessage())
                    }

                }
            self.navigationController?.popViewController(animated: true)

                database.close()
            }
            else {
                print("Could not open the database.")
            }
        }
        indicatorHide()
        
        
    }
    
    func getSelectedValues(setID : Int) -> NSMutableArray {

        database = FMDatabase(path: pathToDatabase!)
        
        // Open the database.
        if database.open() {
            let queryString = "select * from QuizletSearchSet where setID = \(setID)"

            do {
                print(database)
                let results = try database.executeQuery(queryString, values: nil)
                
                while results.next() {
                    let objSetList = setsListObject()
                    
                    objSetList.strid        = Int(results.int(forColumn: "setID"))
                    objSetList.strSearch    = results.string(forColumn: "setSearch")!
                    objSetList.strtitle     = results.string(forColumn: "setTitle")!
                    objSetList.strCreateBy  = results.string(forColumn: "setCreateBy")!
                    objSetList.strTotalCard = Int(results.int(forColumn: "setTermCount"))
                    
                    self.arr_Main.add(objSetList)
                }
            }
            catch {
                print(error.localizedDescription)
            }
            
            database.close()
        }
        return self.arr_Main
    }

    func getSavedCardData(setID : Int) -> NSMutableArray{
        
        database = FMDatabase(path: pathToDatabase!)
        
        // Open the database.
        if database.open() {
            let queryString = "select * from QuizletCardSet where setID = \(setID)"

            do {
                print(database)
                let results = try database.executeQuery(queryString, values: nil)
                
                while results.next() {
                    let objTerms = cardTermsObject()
                    
                    objTerms.strid = Int(results.int(forColumn: "setID"))
                    objTerms.strterm = results.string(forColumn: "cardTerm")!
                    objTerms.strdefinition = results.string(forColumn: "cardDefi")!
                    objTerms.strimage = results.string(forColumn: "cardimgURL")!
                    
                    self.aryCardData.add(objTerms)

                }
            }
            catch {
                print(error.localizedDescription)
            }
            
            database.close()
        }
        return self.aryCardData
    }
    func showHideOtherViews(_ cell: AllWordsCell, isShow: Bool) {
        
        cell.imgVwWordPhoto.isHidden = isShow
        cell.lblWordCenter.isHidden = !isShow
        cell.lblWord.isHidden = isShow
        cell.btn_Star.isHidden = isShow
        cell.lblGoogleMeaning.isHidden = isShow
        //        cell.lblOtherDictMeaning.isHidden = isShow
//        cell.btnGoogle.isHidden = isShow
        //        cell.btnOtherDict.isHidden = isShow
        cell.btnSpeak.isHidden = isShow
        
        
        cell.btnSpeak.isHidden = isShow
        cell.btnSpeak2.isHidden = isShow
        
        cell.btnSpeak.alpha = 0.3
        cell.btnSpeak2.alpha = 0.3
        
        cell.btnSpeak.isUserInteractionEnabled = isShow
        cell.btnSpeak2.isUserInteractionEnabled = isShow
        
        //If get true and also play true then only show this button
        if isShow == false{
            if cell.btnGoogle.titleLabel?.text == "1"{
                cell.btnSpeak.isUserInteractionEnabled = true
                cell.btnSpeak2.isUserInteractionEnabled = true
                
                cell.btnSpeak.alpha = 1.0
                cell.btnSpeak2.alpha = 1.0
            }else{
                cell.btnSpeak.isUserInteractionEnabled = false
                cell.btnSpeak2.isUserInteractionEnabled = false
                
                cell.btnSpeak.alpha = 0.3
                cell.btnSpeak2.alpha = 0.3
            }
        }
        
        cell.btnGoogle.isHidden = true
    }
    
    //MARK: - Service Calling -
    func Get_QuizLetDetail(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)quizlet_get_cards"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "set_id" : str_ID,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "quizlet_get_cards"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.startDownload()
        
    }
    
    func post_CardSave(arr_Temp : NSMutableArray){
        
        indicatorShow()
        let when3 = DispatchTime.now() + 0.5
        DispatchQueue.main.asyncAfter(deadline: when3) {
            
            //Declaration URL
            //            let strURL = "\(GlobalConstants.BaseURL)add_card"
            let strURL = "\(GlobalConstants.BaseURL)add_card_new"
            
            //make array for image comment
            let arr_Comment : NSMutableArray = []
            let arr_Image : NSMutableArray = []
            let arr_ImageType : NSMutableArray = []
            let arr_ImageName : NSMutableArray = []
            
            for i in (0..<arr_Temp.count){
                
                let obj = arr_Temp[i] as! GlobalObjectCard
                
                let arr_Meaning : NSMutableArray = []
                let arr_MeaningTemp : NSMutableArray = []
                arr_MeaningTemp.add("")
                arr_Meaning.add(arr_MeaningTemp)
                
                //Create array for traslation
                let arr_Translation : NSMutableArray = []
                let arr_TraTemp : NSMutableArray = []
                arr_TraTemp.add(obj.str_Quiz_Defination)
                arr_Translation.add(arr_TraTemp)
                
                //Create array for Example
                let arr_Example : NSMutableArray = []
                let arr_ExampleTemp : NSMutableArray = []
                arr_ExampleTemp.add("")
                arr_Example.add(arr_ExampleTemp)
                
                
                //Create array for Inflection
                let arr_Inflection : NSMutableArray = []
                let arr_InflectionTemp : NSMutableArray = []
                arr_InflectionTemp.add("")
                arr_Inflection.add(arr_InflectionTemp)
                
                
                //Create array for Synonym
                let arr_Synonym : NSMutableArray = []
                let arr_SynonymTemp : NSMutableArray = []
                arr_SynonymTemp.add("")
                arr_Synonym.add(arr_SynonymTemp)
                
                
                //Create array for AnotherWord
                let arr_AnotherWord : NSMutableArray = []
                let arr_AnotherWordTemp : NSMutableArray = []
                arr_AnotherWordTemp.add("")
                arr_AnotherWord.add(arr_AnotherWordTemp)
                
                
                //Save data in dictionary
                let dict_Store : NSDictionary = [
                    "word" : removeSpecialCharsFromString(text: obj.str_Quiz_Term),
                    "meaning_array" : arr_Meaning,
                    "translate_array" : arr_Translation,
                    "example_array" : arr_Example,
                    "inflection_array" : arr_Inflection,
                    "synonym_array" : arr_Synonym,
                    "another_array" : arr_AnotherWord,
                    "is_replace" : "0",
                    "card_id" : obj.str_CardID,
                    ]
                arr_Comment.add(dict_Store)
                
                if obj.str_Quiz_Image != ""{
                    //Image save in array
                    let url = URL(string: obj.str_Quiz_Image as! String)
                    
                    let data = try? Data(contentsOf: url!)
                    
                    arr_Image.add(data)
                    arr_ImageType.add("photo")
                    arr_ImageName.add("image\(i)")
                }else{
                    arr_Image.add("")
                    arr_ImageType.add("")
                    arr_ImageName.add("")
                }
            }
            
            if arr_Comment.count != 0{
                //Convert array in string
                let string = notPrettyString(from : arr_Comment)
                
                //Pass data in dictionary
                var jsonData : NSMutableDictionary =  NSMutableDictionary()
                jsonData = [
                    "user_id" : objUser?.user_UserID ?? "0",
                    "keyword" : string ?? "",
                    "category_id" : objUser?.category_SelectedCatId ?? "0",
                    "sub_category_id" : objUser?.category_SelectedSubCatId ?? "0",
                    "from_language_id" : objUser?.traslation_FromId ?? "0",
                    "dictionary_id" : "4",
                    "store_type" : "1",
                    "card_type" : "quizlet"
                ]
                
                jsonData.setValue(objUser?.traslation_ToID ?? "0", forKey: "to_language_id")
                //        jsonData.setValue(objUser?.traslation_DictionaryName ?? "0", forKey: "dictionary_id")
                
                indicatorHide()
                //Create object for webservicehelper and start to call method
                let webHelper = WebServiceHelper()
                webHelper.strMethodName = "add_card_new"
                webHelper.methodType = "post"
                webHelper.strURL = strURL
                webHelper.dictType = jsonData
                webHelper.dictHeader = NSDictionary()
                webHelper.delegateWeb = self
                webHelper.serviceWithAlert = true
                webHelper.arr_MutlipleimagesAndVideo = arr_Image
                webHelper.arr_MutlipleimagesAndVideoType = arr_ImageType
                webHelper.arr_MutlipleimagesAndVideoName = arr_ImageName
                webHelper.imageUploadName = "image"
                webHelper.startUploadingMultipleImagesAndVideo()
            }
        }
    }
    
    func Get_CheckSaveOrNot(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)check_card"
        
        //make array for image comment
        let arr_Comment : NSMutableArray = []
        
        for i in (0..<Int(arr_Main.count)){
            let objCard = arr_Main[i] as! GlobalObjectCard
            
            //Create array for meaning
            var arr_Meaning : NSMutableArray = []
//            for j in (0..<1){
//                let dict_Store : NSDictionary = [
//                    "meaning" : objCard.str_Quiz_Defination,
//                    ]
//                arr_Meaning.add(dict_Store)
//            }
            
            //Save data in dictionary
            let dict_Store : NSDictionary = [
                "word" : removeSpecialCharsFromString(text: objCard.str_Quiz_Term),
                "meaning_array" : arr_Meaning,
                ]
            arr_Comment.add(dict_Store)
        }
        
        //Convert array in string
        let string = notPrettyString(from : arr_Comment)
        
        //Pass data in dictionary
        var jsonData : NSMutableDictionary =  NSMutableDictionary()
        jsonData = [
            "user_id" : objUser?.user_UserID ?? "0",
            "keyword" : string ?? "",
            "category_id" : objUser?.category_SelectedCatId ?? "0",
            "sub_category_id" : objUser?.category_SelectedSubCatId ?? "0",
            "from_language_id" : objUser?.traslation_FromId ?? "0",
            "dictionary_id" : "4",
        ]
        
        jsonData.setValue(objUser?.traslation_ToID ?? "0", forKey: "to_language_id")
        
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "check_card"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.startDownload()
    }
    
}


//MARK: - Collection View -
extension QuizletCardViewController: UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return arr_Main.count
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: CGFloat((GlobalConstants.windowWidth-20)/3), height: CGFloat(((GlobalConstants.windowWidth-20)/3) * 1.375))
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell  = collectionView.dequeueReusableCell(withReuseIdentifier: "cellVocablist", for: indexPath) as! AllWordsCell
       
        let obj = arr_Main[indexPath.row] as! GlobalObjectCard
        
        cell.tag = indexPath.row
         self.showHideOtherViews(cell , isShow: false)

//        cell.btnGoogle.setTitle(objCard.str_FlatCard_traslation_Play, for: .normal)
        
        //Manage Data with user
        cell.imgVwWordPhoto.sd_setImage(with: URL(string: (obj.str_Quiz_Image)), placeholderImage: UIImage(named:"img_PlaceHolderImage"))
        
        cell.lblWord.text = obj.str_Quiz_Term
        cell.lblWordCenter.text = obj.str_Quiz_Term

        cell.lblGoogleMeaning.text = obj.str_Quiz_Defination
        
        cell.btnSpeak.isHidden = true
        
        cell.btnGoogle.setImage(UIImage(named:"icon_Quizlet"), for: UIControlState.normal)

        if objUser?.traslation_Play == "1"{
            cell.btnSpeak2.isUserInteractionEnabled = true
            cell.btnSpeak2.alpha = 1.0
        }else{
            cell.btnSpeak2.isUserInteractionEnabled = false
            cell.btnSpeak2.alpha = 0.3
        }
        cell.btnSpeak2.alpha = 0.0

        if obj.str_CardSaveFlag == "-1"{ // Not Saved
            cell.btn_Star.setImage(UIImage(named:"icon_SaveBlck"), for: UIControlState.normal)
        }else if obj.str_CardSaveFlag == "0"{ //Personally Save
            cell.btn_Star.setImage(UIImage(named:"icon_SaveYello"), for: UIControlState.normal)
        }else if obj.str_CardSaveFlag == "1"{ //All Saved
            cell.btn_Star.setImage(UIImage(named:"icon_SaveBlck_S"), for: UIControlState.normal)
        }
        
//        cell.btnSpeak2.tag = indexPath.row
//        cell.btnSpeak2.addTarget(self, action:#selector(btn_Speak(_:)), for: .touchUpInside)
        
        //Manage font
        cell.lblWordCenter.font = UIFont(name: GlobalConstants.kFontRegular, size: manageFont(font: 22))
        cell.lblWord.font = UIFont(name: GlobalConstants.kFontRegular, size: manageFont(font: 20))
        cell.lblGoogleMeaning.font = UIFont(name: GlobalConstants.kFontRegular, size: manageFont(font: 12))
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    }
}

extension QuizletCardViewController: EmptyDataSetSource,EmptyDataSetDelegate {
    
    func emptyDataSetShouldDisplay(_ scrollView: UIScrollView) -> Bool{
        if arr_Main.count == 0 && bool_Load == false{
            return true
        }
        return false
    }
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        var text: String?
        var font: UIFont?
        var textColor: UIColor?
        
        text = "No result found"
        
        font = UIFont(name: GlobalConstants.kFontSemiBold, size: manageFont(font: 20))
        textColor = UIColor(red: 109/255, green: 109/255, blue: 109/255, alpha: 1.0)
        
        if text == nil {
            return nil
        }
        var attributes: [NSAttributedStringKey: Any] = [:]
        
        if font != nil {
            attributes[NSAttributedStringKey.font] = font!
        }
        if textColor != nil {
            attributes[NSAttributedStringKey.foregroundColor] = textColor
        }
        return NSAttributedString.init(string: text!, attributes: attributes)
        
    }
}




extension QuizletCardViewController : WebServiceHelperDelegate{
    //MARK: - Webservice Helper -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        self.completedServiceCalling()
        
        var response = data as! NSDictionary
        
        
        if strRequest == "quizlet_get_cards" {
            response = response["result"] as! NSDictionary
            let json2 = try JSON(jsonObject : response)

            lbltopicTitle.text = "Search result for: \(response["title"] as! String)"
            lblTopicOwner.text = "Created By: \(response["created_by"] as! String)"
            
            arr_Main = []
            for i in (0..<json2["terms"].array!.count) {
                let dict_Data = json2["terms"][i].dictionaryObject! as NSDictionary

                //Other Tab Demo data
                let obj = GlobalObjectCard ()
   
                obj.str_Quiz_Id = dict_Data.getStringForID(key:"id")
                obj.str_Quiz_Term = dict_Data.getStringForID(key: "term")
                obj.str_Quiz_Defination = dict_Data.getStringForID(key: "definition")
                
                if json2["terms"][i]["image"].dictionaryObject != nil{
                    obj.str_Quiz_Image = json2["terms"][i]["image"]["url"].string!
                }
                
                arr_Main.add(obj)
            }
           
            self.Get_CheckSaveOrNot()
            self.reloadData()
        }else if strRequest == "add_card_new" {
            self.navigationController?.popViewController(animated: true)
            self.navigationController?.popViewController(animated: true)
        }else if strRequest == "check_card"{
            let responseData = response["response"] as! NSDictionary
            let arr_Traslation = responseData["keyword"] as! NSArray
            
            for count in 0..<arr_Traslation.count {
                let objCard = arr_Main[count] as! GlobalObjectCard
                
                let dict_Result = arr_Traslation[count] as! NSDictionary
                
                objCard.str_CardSaveFlag = dict_Result.getStringForID(key : "is_saved")!
                objCard.str_CardID = dict_Result["card_id"]  as? String ?? ""
                
                var str_Cat : String = dict_Result["category_name"]  as? String ?? ""
                var str_SubCat : String = dict_Result["sub_category_name"]  as? String ?? ""
                if str_Cat != ""{
                    objCard.str_CatSave = "\(str_Cat)/\(str_SubCat)"
                }else{
                    objCard.str_CatSave = ""
                }
                
                objCard.str_Level = "3"
                
                arr_Main.replaceObject(at: count, with: objCard)
            }
            self.reloadData()
        }
    }
    

    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        self.completedServiceCalling()
        self.reloadData()
    }
}








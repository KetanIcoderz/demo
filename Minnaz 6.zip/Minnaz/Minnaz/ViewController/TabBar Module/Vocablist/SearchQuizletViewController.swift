//
//  SearchQuizletViewController.swift
//  Minnaz
//
//  Created by iCoderz_02 on 01/01/18.
//  Copyright © 2018 iCoderz. All rights reserved.
//

import UIKit
import Quizlet_iOS
import SwiftyJSON
import EmptyDataSet_Swift

class SearchQuizletViewController: UIViewController {

    @IBOutlet var txtSearchbar: UITextField!
    @IBOutlet var tbl_Main: UITableView!
    @IBOutlet var btnSavedRecord: UIBarButtonItem!
    
    var arr_Main:NSMutableArray = []
    
    //Bool Declaration
    var int_CountLoad: Int = 0
    var bool_Load: Bool = false
    var bool_ViewWill: Bool = false
    var bool_SearchMore: Bool = true
    
    var bool_Search: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()
        
        tbl_Main.tableFooterView = UIView()
        
//        //Quizlet
//        Quizlet.shared().start(withClientID: CLIENT_ID, withSecretKey: SECRET_KEY, withRedirectURI: "quizletdemo://after_oauth")
//
//        Quizlet.shared().authorize({(_: Void) -> Void in
//            print("User was authorized")
//
//        }, failure: {(_ error: Error?) -> Void in
//            print("User wasn't authorized")
//        })
    }
    override func viewWillAppear(_ animated: Bool) {
       
    }
  

    //MARK: - Scrollview Delegate -
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        if scrollView == tbl_Main{
            if tbl_Main.contentSize.height <= tbl_Main.contentOffset.y + tbl_Main.frame.size.height && tbl_Main.contentOffset.y >= 0 {
                if bool_Load == false && arr_Main.count != 0 {
                    self.Get_QuizLetList(count: int_CountLoad + GlobalConstants.int_LoadMax)
                }
            }
        }
    }
    
    //MARK: - Other Method -
    func commanMethod(){
        
        tbl_Main.emptyDataSetDelegate = self
        tbl_Main.emptyDataSetSource = self
        
    }
    func completedServiceCalling(){
//        refresh_Item?.endRefreshing()
        bool_Load = false
    }
    func reloadData(){
        tbl_Main.reloadData()
    }
    
    //MARK: - Button Event -
    @IBAction func btn_NavigationLeft(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btnSavedData(_ sender: Any) {
        
        self.performSegue(withIdentifier: "segueSavedRecord", sender: nil)
    }
    
    @IBAction func btnSearchOnQuizlet(_ sender: Any) {
        
        let strSearch : String = txtSearchbar.text!
        
        self.view.endEditing(true);
        
        if strSearch.characters.count > 0
        {
            bool_Search = true
            
            //First time sevice call for featured product
            int_CountLoad = GlobalConstants.int_LoadMax
            bool_ViewWill = true
            bool_SearchMore = true
            self.Get_QuizLetList(count:int_CountLoad)
            
//            indicatorShow()
//
//            Quizlet.shared().searchSets(withParameters: ["q": txtSearchbar.text ?? ""], success: {(_ responseObject: Any) -> Void in
//
//                let response = responseObject as! NSDictionary
//                if response.count > 0
//                {
//                    self.arr_Main = []
//
//                    let aryData = response["sets"] as! NSArray
//                    for i in (0..<aryData.count)
//                    {
//                        let response = aryData[i] as! NSDictionary
//
//                        let objSetList = setsListObject()
//                        objSetList.strid = response["id"] as! Int
//                        objSetList.strtitle = response["title"] as! String
//                        objSetList.strCreateBy = response["created_by"] as! String
//                        objSetList.strTotalCard = response["term_count"] as! Int
//
//                        objSetList.strSearch = strSearch
//
//                        self.arr_Main.add(objSetList)
//                    }
//
//                    indicatorHide()
//
//                    self.tbl_Main.reloadData()
////                    self.performSegue(withIdentifier: "segueSetList", sender: self.arr_Main)
//                }
//            }, failure: {(_ error: Error?) -> Void in
//                indicatorHide()
//            })
        }

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

class cellSetsList: UITableViewCell{
    
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var lblCellDetails: UILabel!
    @IBOutlet var lblFlashcard: UILabel!
}

extension SearchQuizletViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr_Main.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let  cell = tableView.dequeueReusableCell(withIdentifier: "CellReuseable", for: indexPath) as! cellSetsList
        
        let obj = arr_Main[indexPath.row] as! GlobalObjectCard
        
        cell.lblTitle.text = obj.str_Quiz_Title
        cell.lblCellDetails.text = obj.str_Quiz_SubTitle
        cell.lblFlashcard.text = "\(obj.str_Quiz_Count) flashcards"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let obj = arr_Main[indexPath.row] as! GlobalObjectCard
        
        //str_ID
        let view = self.storyboard?.instantiateViewController(withIdentifier: "QuizletCardViewController") as! QuizletCardViewController
        view.str_ID = obj.str_Quiz_Id
        self.navigationController?.pushViewController(view, animated: true)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "segueDetailsScreen"{
            
            let viewSub = segue.destination as? QuizletCardViewController
            viewSub?.objListSelected = sender as! setsListObject
        }
    }
    
    
    //MARK: - Service Calling -
    func Get_QuizLetList(count : Int){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)quizlet_search_sets"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "q" : txtSearchbar.text,
            "skip" : "\(count - GlobalConstants.int_LoadMax)",
            "total" : "\(count)",
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "quizlet_search_sets"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        
        if bool_SearchMore == true{
            bool_Load = true
            webHelper.startDownload()
        }
    }
    
}


extension SearchQuizletViewController: EmptyDataSetSource,EmptyDataSetDelegate {

    func emptyDataSetShouldDisplay(_ scrollView: UIScrollView) -> Bool{
        if arr_Main.count == 0 && bool_Load == false{
            return true
        }
        return false
    }
    
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        var text: String?
        var font: UIFont?
        var textColor: UIColor?
        
        if bool_Search == false{
            text = ""
        }else{
            text = "No result found\nPlease seach another words"
        }
        
        font = UIFont(name: GlobalConstants.kFontSemiBold, size: manageFont(font: 20))
        textColor = UIColor(red: 109/255, green: 109/255, blue: 109/255, alpha: 1.0)
        
        if text == nil {
            return nil
        }
        var attributes: [NSAttributedStringKey: Any] = [:]
        
        if font != nil {
            attributes[NSAttributedStringKey.font] = font!
        }
        if textColor != nil {
            attributes[NSAttributedStringKey.foregroundColor] = textColor
        }
        return NSAttributedString.init(string: text!, attributes: attributes)
        
    }
}


extension SearchQuizletViewController : WebServiceHelperDelegate{
    //MARK: - Webservice Helper -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        self.completedServiceCalling()
        
        let response = data as! NSDictionary
        let json2 = try JSON(jsonObject : response)
        
        if strRequest == "quizlet_search_sets" {
            
            let arr_StoreTemp : NSMutableArray = []
            for i in (0..<json2["sets"].array!.count) {
                let dict_Data = json2["sets"][i].dictionaryObject! as NSDictionary
                
                //Other Tab Demo data
                let obj = GlobalObjectCard ()
                
                obj.str_Quiz_Id = dict_Data.getStringForID(key:"id")
                obj.str_Quiz_Title = dict_Data.getStringForID(key: "title")
                obj.str_Quiz_SubTitle = dict_Data.getStringForID(key: "created_by")
                obj.str_Quiz_Count = dict_Data.getStringForID(key: "term_count")
                
                arr_StoreTemp.add(obj)
            }
            
            //Refresh code
            if bool_ViewWill == true {
                arr_Main = []
                int_CountLoad = arr_StoreTemp.count
            }else{
                int_CountLoad = int_CountLoad + arr_StoreTemp.count
            }
            
            for i in (0...arr_StoreTemp.count-1){
                arr_Main.add(arr_StoreTemp[i])
            }
            
            //Load more data or not
            if GlobalConstants.int_LoadMax > arr_StoreTemp.count {
                //Bool Load more
                bool_SearchMore = false
            }
            else {
                //Bool Load more
                bool_SearchMore = true
            }
            
            bool_ViewWill = false
            self.reloadData()
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        self.completedServiceCalling()
        
        if bool_ViewWill == true{
            arr_Main = []
            self.reloadData()
        }
    }
}


extension SearchQuizletViewController: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if bool_Search == true{
           bool_Search = false
           self.tbl_Main.reloadData()
        }
        return true
    }
}

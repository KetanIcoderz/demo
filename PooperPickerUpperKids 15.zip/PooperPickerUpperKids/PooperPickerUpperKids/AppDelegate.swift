//
//  AppDelegate.swift
//  PooperPickerUpperKids
//
//  Created by Apple on 30/07/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import SwiftMessages
import IQKeyboardManagerSwift
import CoreLocation
import GoogleMaps
import GooglePlaces
import SystemConfiguration
import Intents
import UserNotifications
import AVFoundation
import PushKit
import Contacts
import CallKit

//Global Declaration
var messageBar = MessageBarController()
var act_indicator = ActivityIndicatorViewController()
var currentLocation : CLLocation?
var objUser : UserDataObject?
var deviceTokenStored : Data?
var contactStore = CNContactStore()
var vw_Call = PlivoCallController()
var vw_Call_Nav = UINavigationController()
var vw_LeftMenu = LeftMenuViewController()
var str_CountryCode : String = "91"
var currentCityName : String = ""
var notificationSave : [UIApplicationLaunchOptionsKey: Any]? = nil
var dict_Push : NSDictionary = [:]
var str_NotificationCount : String = ""
var str_MessageCount : String = ""
var str_Home_Present : String = "1"
var str_LogoutSuccess : String = "0"

//com.app.ppuk
//com.app.ppuk.IntentHandler

@UIApplicationMain

class AppDelegate: UIResponder, UIApplicationDelegate, CLLocationManagerDelegate, PKPushRegistryDelegate, UNUserNotificationCenterDelegate {

    var window: UIWindow?
    var locationManager : CLLocationManager?
    var callObserver = CXCallObserver()
    
    let pushRegistry = PKPushRegistry(queue: DispatchQueue.main)
    
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        //Permission for app
        self.permissionForApp(application: application)
        
        //Login with plivo
        self.LoginWithPlivoApp()
        
        //Keyboard Activity
        keyboardActivityEnableorDisable(show: true)
        
        // app was launched from push notification, handling it
        let remoteNotification: NSDictionary! = launchOptions?[UIApplicationLaunchOptionsKey.remoteNotification] as? NSDictionary
        if (remoteNotification != nil) {
            notificationSave = launchOptions!
            
            let when = DispatchTime.now() + 1
            DispatchQueue.main.asyncAfter(deadline: when) {
                //do stuff here
//                self.openNotification(launchOptions!)
            }
        }
        
//        FontNamePrint()
        
        self.navigationSet(color: UIColor.white)
        self.location()
        self.deviceTockenGet(launchOptions: launchOptions)
        
        //Google Map
        GMSServices.provideAPIKey(GlobalConstants.apiKeyGoogle)
        GMSPlacesClient.provideAPIKey(GlobalConstants.apiKeyGoogle)
        GMSServices.provideAPIKey(GlobalConstants.apiKeyGoogle)
        
        //Get device token
        DispatchQueue.main.async {
            let settings = UIUserNotificationSettings(types: [.badge, .sound, .alert], categories: nil)
            
            application.registerUserNotificationSettings(settings)
            application.registerForRemoteNotifications()
        }
        
        
        return true
    }

    
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
        
        if alredyLoginOrNot() == true{
            locationErrorAlert()
        }
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any]) {
        //JRE = Job reschedule
        //JR = Job reminder
        //JA = Job Accept/Approve
        //JC = Job Canceled
        //PC = Prospect Customer
        //MR = get message from user
        
        UIApplication.shared.applicationIconBadgeNumber = 0
        var dict : NSDictionary = userInfo as NSDictionary
        
        if (GlobalConstants.developerTest == true) {
            //Notification formate generate
            let alert = UIAlertController(title: GlobalConstants.appName, message: "\(dict)", preferredStyle: UIAlertControllerStyle.alert)
            
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            GlobalConstants.appDelegate?.window?.rootViewController?.present(alert, animated: true, completion: nil)
            self.reloadPushView()
        }else{
            dict_Push = dict
            
            let dict_Data = dict["aps"] as! NSDictionary
            
            //Notification formate generate
            let alert = UIAlertController(title: GlobalConstants.appName, message: dict_Data["alert"] as? String, preferredStyle: UIAlertControllerStyle.alert)
            
            //Condition for open button visible or not for perticular notification
            if dict_Data["posttype"] as! String == "PC"{
                
                let firstAction = UIAlertAction(title: "Open", style: .default, handler: {(_ action: UIAlertAction) -> Void in
                    self.reloadPushView()
                    self.vw_OpenWhenNotificationCome(type : dict_Data["posttype"] as! String, key : "")
                })
                alert.addAction(firstAction)
            }else if dict_Data["posttype"] as! String == "JRE" || dict_Data["posttype"] as! String == "JR" ||  dict_Data["posttype"] as! String == "JA" {
                
                let firstAction = UIAlertAction(title: "Open", style: .default, handler: {(_ action: UIAlertAction) -> Void in
                    self.reloadPushView()
                    self.vw_OpenWhenNotificationCome(type : dict_Data["posttype"] as! String, key : "")
                })
                alert.addAction(firstAction)
            }
            

            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: {(_ action: UIAlertAction) -> Void in
                self.reloadPushView()
            })
            alert.addAction(cancelAction)

            GlobalConstants.appDelegate?.window?.rootViewController?.present(alert, animated: true, completion: nil)
        }
    }
    func reloadPushView(){
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "listmyschedule"), object: nil)
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "mapmyschedule"), object: nil)
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "listmyschedulejobs"), object: nil)
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "completedmyschedulejobs"), object: nil)
    }
    
    func openNotification(_ launchOptions: [AnyHashable: Any]) {
        UserDefaults.standard.set("0", forKey: "notificationCount")
        UIApplication.shared.applicationIconBadgeNumber = 0
        let dict = launchOptions[UIApplicationLaunchOptionsKey.remoteNotification] as? [AnyHashable: Any] ?? [AnyHashable: Any]()
        
        if (GlobalConstants.developerTest == true) {
            //Notification formate generate
            let alert = UIAlertController(title: GlobalConstants.appName, message: "\(dict)", preferredStyle: UIAlertControllerStyle.alert)
            
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            GlobalConstants.appDelegate?.window?.rootViewController?.present(alert, animated: true, completion: nil)
            
        }else{
            dict_Push = dict as! NSDictionary
            let dict_Data = dict["aps"] as! NSDictionary
            
            if dict_Data["posttype"] as! String == "PC"{
                vw_OpenWhenNotificationCome(type : dict_Data["posttype"] as! String, key : "")
            }else if dict_Data["posttype"] as! String == "JRE" || dict_Data["posttype"] as! String == "JR" ||  dict_Data["posttype"] as! String == "JA"{
                self.vw_OpenWhenNotificationCome(type : dict_Data["posttype"] as! String, key : "")
            }

        }
    }
   
    
    func vw_OpenWhenNotificationCome(type : String, key : NSString) {
        let rootViewController = self.window!.rootViewController as! UINavigationController
        let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        if type == "PC"{
            let dict_Data = dict_Push["aps"] as! NSDictionary
            let dict_Value = dict_Data["data"] as! NSDictionary
            
            let view = mainStoryboard.instantiateViewController(withIdentifier: "ReminderNotificationViewController") as! ReminderNotificationViewController
            
            view.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext;
            view.modalTransitionStyle = UIModalTransitionStyle.crossDissolve;
            rootViewController.present(view, animated: false, completion: nil)
            
            self.Post_NotificationRead(str_Id: dict_Value.getStringForID(key: "notification_id"))
        }else if type == "JRE" || type == "JR" ||  type == "JA"{
            let dict_Data = dict_Push["aps"] as! NSDictionary
            let dict_Value = dict_Data["data"] as! NSDictionary
            
            let dict_Customer = dict_Value["customer"] as! NSDictionary
            let dict_Payment = dict_Value["payment"] as! NSDictionary
            
            let obj = GlobalObject()
            obj.str_Notification_Id = dict_Value.getStringForID(key: "notification_id")
            obj.str_Id = dict_Value.getStringForID(key: "id")
            obj.str_Customer_Id = dict_Value.getStringForID(key: "customer_id")
            obj.str_Customer_Address = dict_Value.getStringForID(key: "address")
            obj.str_Customer_Lat = dict_Value.getStringForID(key: "lat")
            obj.str_Customer_Long = dict_Value.getStringForID(key: "longs")
            obj.str_Customer_DogName = dict_Value.getStringForID(key: "dog_name")
            obj.str_Customer_Spouse_Name = dict_Value.getStringForID(key: "spouse_name")
            obj.str_Customer_Note = dict_Value.getStringForID(key: "note")
            obj.str_Customer_DateOnly = dict_Value.getStringForID(key: "job_date")
            obj.str_Customer_StartTime = dict_Value.getStringForID(key: "start_time")
            obj.str_Customer_EndTime = dict_Value.getStringForID(key: "end_time")
            
            obj.str_Customer_Job_Amount = dict_Payment.getStringForID(key: "amount")
            obj.str_Customer_Job_Payment_Method = dict_Payment.getStringForID(key: "payment_method")
            obj.str_Customer_Job_Cheque_Num = dict_Payment.getStringForID(key: "cheque_num")
            
            obj.str_Customer_Title = "\(dict_Customer.getStringForID(key: "first_name") as! String) \(dict_Customer.getStringForID(key: "last_name") as! String)"
            

//            let alert = UIAlertController(title: GlobalConstants.appName, message: "\(obj.str_Customer_Title)", preferredStyle: UIAlertControllerStyle.alert)
//
//            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
//            GlobalConstants.appDelegate?.window?.rootViewController?.present(alert, animated: true, completion: nil)
            
            
            let view = mainStoryboard.instantiateViewController(withIdentifier: "MyJobsDetailViewController") as! MyJobsDetailViewController
            var objNav = UINavigationController(rootViewController: view)

            view.get_Data = obj
            view.str_Type = "navigation"
//            rootViewController.navigationController?.pushViewController(view, animated: false)
            rootViewController.present(objNav, animated: false, completion: nil)
            
            self.Post_NotificationRead(str_Id: dict_Value.getStringForID(key: "notification_id"))
        }
    }
    
    func permissionForApp(application : UIApplication){
        //For VOIP Notificaitons
        if #available(iOS 10.0, *)
        {
            let center = UNUserNotificationCenter.current()
            center.requestAuthorization(options:[.badge, .alert, .sound]) { (granted, error) in
                // Enable or disable features based on authorization.
            }
            application.registerForRemoteNotifications()
        }
        
        //Request Record permission
        let session = AVAudioSession.sharedInstance()
        if (session.responds(to: #selector(AVAudioSession.requestRecordPermission(_:)))) {
            AVAudioSession.sharedInstance().requestRecordPermission({(granted: Bool)-> Void in
                if granted {
                    print("granted")
                    
                    do {
                        try session.setCategory(AVAudioSessionCategoryPlayAndRecord)
                        try session.setActive(true)
                    }
                    catch {
                        
                        print("Couldn't set Audio session category")
                    }
                } else{
                    print("not granted")
                }
            })
        }
        
        //Request Siri authorization
        INPreferences.requestSiriAuthorization({(_ status: INSiriAuthorizationStatus) -> Void in
            if status == .authorized {
                print("User gave permission to use Siri")
            }
            else {
                print("User did not give permission to use Siri")
            }
        })
    }
    
    
    // MARK: - Navigation Manager -
    func navigationSet(color : UIColor) {
//        UINavigationBar.appearance().setBackgroundImage(image(with:GlobalConstants.appColor), for: .default)
        NaviationManager()

        UINavigationBar.appearance().titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white, NSAttributedStringKey.font: UIFont(name:  GlobalConstants.kFontOpenSansSemiBold, size: 17.0)!]
        //        UINavigationBar.appearance().shadowImage = UIImage(named: "img_Shadow")
        UINavigationBar.appearance().shadowImage = UIImage()
        UIApplication.shared.statusBarStyle = UIStatusBarStyle.default
        
        UIApplication.shared.statusBarView?.backgroundColor = color
        UINavigationBar.appearance().tintColor = color
        
    }

    func LoginWithPlivoApp(){
        //Check Authenticaiton status
        if UtilClass.getUserAuthenticationStatus() {
            //            Get Username and Password from NSUserDefaults and Login
            Phone.sharedInstance.login(withUserName: UserDefaults.standard.object(forKey: kUSERNAME) as! String, andPassword: UserDefaults.standard.object(forKey: kPASSWORD) as! String)
            
            self.voipRegistration()
        }else{
            //First time Log-In setup
            let _mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let loginVC: SignInViewController? = _mainStoryboard.instantiateViewController(withIdentifier: "SignInViewController") as? SignInViewController
            Phone.sharedInstance.setDelegate(loginVC!)
        }
    }
    
    // Register for VoIP notifications
    func voipRegistration() {
        
        let mainQueue = DispatchQueue.main
        // Create a push registry object
        let voipResistry = PKPushRegistry(queue: mainQueue)
        // Set the registry's delegate to self
        voipResistry.delegate = (self as? PKPushRegistryDelegate)
        //Set the push type to VOIP
        voipResistry.desiredPushTypes = Set<AnyHashable>([PKPushType.voIP]) as? Set<PKPushType>
    }
    
    // MARK: PKPushRegistryDelegate
    func pushRegistry(_ registry: PKPushRegistry, didUpdate credentials: PKPushCredentials, for type: PKPushType) {
        
        NSLog("pushRegistry:didUpdatePushCredentials:forType:");
        
        if credentials.token.count == 0 {
            print("VOIP token NULL")
            
            return
        }
        print("Credentials token: \(credentials.token)")
        if UtilClass.isNetworkAvailable() {
            
            Phone.sharedInstance.registerToken(credentials.token)
        }
    }
    
    func pushRegistry(_ registry: PKPushRegistry, didInvalidatePushTokenFor type: PKPushType) {
        NSLog("pushRegistry:didInvalidatePushTokenForType:")
    }
    
    func pushRegistry(_ registry: PKPushRegistry, didReceiveIncomingPushWith payload: PKPushPayload, for type: PKPushType) {
        
        NSLog("pushRegistry:didReceiveIncomingPushWithPayload:forType:")
        
        if (type == PKPushType.voIP) {
            
            DispatchQueue.main.async(execute: {() -> Void in

                let view = vw_Call_Nav.topViewController
                view?.navigationController?.popToRootViewController(animated: true)
                vw_LeftMenu.slideMenuController()?.changeMainViewController((view?.navigationController!)!, close: true)
                Phone.sharedInstance.relayVoipPushNotification(payload.dictionaryPayload)
            })
        }
    }
    
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (_ options: UNNotificationPresentationOptions) -> Void) {
        //Called when a notification is delivered to a foreground app.
        print("willPresentNotification Userinfo \(notification.request.content.userInfo)")
        completionHandler(.alert)
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        //Called to let your app know which action was selected by the user for a given notification.
        print("didReceiveNotificationResponse Userinfo \(response.notification.request.content.userInfo)")
    }
    
    
    @nonobjc func application(_ app: UIApplication, open url: URL, options: [String: Any]) -> Bool {
        
        return application(app, processOpenURLAction: url, sourceApplication:UIApplicationOpenURLOptionsKey.sourceApplication.rawValue, annotation: UIApplicationOpenURLOptionsKey.annotation, iosVersion: 9)
        
    }
    
    func application(_ application: UIApplication, open url: URL, sourceApplication: String?, annotation: Any) -> Bool {
        return self.application(application, processOpenURLAction: url, sourceApplication: sourceApplication!, annotation: annotation, iosVersion: 8)
    }
    
    func application(_ application: UIApplication, processOpenURLAction url: URL, sourceApplication: String, annotation: Any, iosVersion version: Int) -> Bool {
        
        //Deep linking
        let latlngArray: [Any] = url.absoluteString.components(separatedBy: "://")
        handleDeepLinking(latlngArray[1] as! String)
        return true
    }
    
    func application(_ application: UIApplication, continue userActivity: NSUserActivity, restorationHandler: @escaping (_ restorableObjects: [Any]?) -> Void) -> Bool {
        
        if UtilClass.getUserAuthenticationStatus() {
            //When user taps on iPhone's native call list
            //This method will be called only if the call is related to Plivo
            let interaction: INInteraction? = userActivity.interaction
            let startAudioCallIntent: INStartAudioCallIntent? = (interaction?.intent as? INStartAudioCallIntent)
            let contact: INPerson? = startAudioCallIntent?.contacts?[0]
            print("\(String(describing: contact?.displayName))")
            let personHandle: INPersonHandle? = contact?.personHandle
            let contactValue: String? = personHandle?.value
            /*
             * Handle Siri input
             * From Siri we will get contact name
             * Check whether this name exists in phone contacts
             * If yes make a call
             */
            if !(contactValue != nil) && ((contact?.displayName) != nil)
            {
                
            }
            else
            {
                CallKitInstance.sharedInstance.callUUID = UUID()
                
                manageTabBarandSideBar()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    
                    Phone.sharedInstance.setDelegate(vw_Call)
                    vw_Call.performStartCallAction(with: CallKitInstance.sharedInstance.callUUID!, handle: contactValue!)
                }
                
//
//
//                CallKitInstance.sharedInstance.callUUID = UUID()
//                //PlivoCallController handles the incoming/outgoing calls
//                let _mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
//                let tabBarContrler: UITabBarController? = _mainStoryboard.instantiateViewController(withIdentifier: "tabbar") as? UITabBarController
//                let plivoVC: PlivoCallController? = (tabBarContrler?.viewControllers?[0] as? PlivoCallController)
//                tabBarContrler?.selectedViewController = tabBarContrler?.viewControllers?[0]
//                Phone.sharedInstance.setDelegate(plivoVC!)
//                plivoVC?.performStartCallAction(with: CallKitInstance.sharedInstance.callUUID!, handle: contactValue!)
//                window?.rootViewController = tabBarContrler
            }
            return true
        }
        else {
            UtilClass.makeToast("Please login to make a call")
            return false
        }
    }
    
    func handleDeepLinking(_ phoneNumber: String) {
      
     
            CallKitInstance.sharedInstance.callUUID = UUID()            
            
//            //PlivoCallController handles the incoming/outgoing calls
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//            let plivoVC = storyboard.instantiateViewController(withIdentifier: "PlivoCallController") as! PlivoCallController
//
//            Phone.sharedInstance.setDelegate(plivoVC)
//            plivoVC.performStartCallAction(with: CallKitInstance.sharedInstance.callUUID!, handle: phoneNumber)
//            window?.rootViewController = plivoVC

            manageTabBarandSideBar()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                //PlivoCallController handles the incoming/outgoing calls
                //                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                //                    let plivoVC = storyboard.instantiateViewController(withIdentifier: "PlivoCallController") as! PlivoCallController
                
                Phone.sharedInstance.setDelegate(vw_Call)
                vw_Call.performStartCallAction(with: CallKitInstance.sharedInstance.callUUID!, handle: phoneNumber)
                
                //                    window?.rootViewController = plivoVC
            }
    }
    
    
    // MARK: - Location Manager -
    func location(){
        currentLocation = CLLocation(latitude: 0, longitude: 0)
        
        locationManager = CLLocationManager()
        locationManager?.delegate = self
        self.locationManager?.requestAlwaysAuthorization()
        locationManager?.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        locationManager?.startUpdatingLocation()
    }
    
    // Below method will provide you current location.
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        if currentLocation != nil {
            currentLocation = locations.last
            
            locationManager?.stopMonitoringSignificantLocationChanges()
            let locationValue:CLLocationCoordinate2D = manager.location!.coordinate
            
            print("locations = \(locationValue)")
            locationManager?.stopUpdatingLocation()
            
            let geocoder = CLGeocoder()
            
            geocoder.reverseGeocodeLocation(currentLocation!, completionHandler: {(placemarks, error)->Void in
                var placemark:CLPlacemark!
                
                if error == nil && (placemarks?.count)! > 0 {
                    placemark = (placemarks?[0])! as CLPlacemark
                    
                    var addressString : String = ""
                    
                    if placemark.locality != nil {
                        addressString = addressString + placemark.locality! + ", "
                        currentCityName = placemark.locality!
//                        print(placemark.postalCode)
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadhomescreen"), object: nil)
                        
                        //Update :pcatopm
                        if alredyLoginOrNot() == true{
                            self.Post_UpdateLocation(str_lat: String(format:"%.5f", (currentLocation?.coordinate.latitude)!), str_long: String(format:"%.5f", (currentLocation?.coordinate.longitude)!), address: placemark.locality!)
                        }
                    }
                }
            })
        }
    }
    // Below Mehtod will print error if not able to update location.
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error")
        
    }

    // MARK: - Device Tocken -
    func deviceTockenGet(launchOptions : [UIApplicationLaunchOptionsKey: Any]?){
        // app was launched from push notification, handling it
        let remoteNotification: NSDictionary! = launchOptions?[UIApplicationLaunchOptionsKey.remoteNotification] as? NSDictionary
        if (remoteNotification != nil) {
            
        }
        UIApplication.shared.applicationIconBadgeNumber = 0
    }
    
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        
        let token = deviceToken.map { String(format: "%02.2hhx", $0) }.joined()
        UserDefaults.standard.set(token, forKey: "DeviceToken")
        
        deviceTokenStored = deviceToken
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        UserDefaults.standard.set("", forKey: "DeviceToken")
        print("Print ::Failed to get token, error: \(error)")
    }
    
    //MARK: - Get/Post -
    func Post_NotificationRead(str_Id : String){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)notification/read"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "notification_id" : str_NotificationCount,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "notification"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.indicatorShowOrHide = false
        webHelper.startDownload()
    }

    func Post_UpdateLocation(str_lat: String, str_long : String, address : String){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)comman/location/update"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "lat" : str_lat,
            "longs" : str_long,
            "address" : address,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "update"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.indicatorShowOrHide = false
        webHelper.startDownload()
    }
}


extension UIApplication {
    var statusBarView: UIView? {
        if responds(to: Selector("statusBar")) {
            return value(forKey: "statusBar") as? UIView
        }
        return nil
    }
}

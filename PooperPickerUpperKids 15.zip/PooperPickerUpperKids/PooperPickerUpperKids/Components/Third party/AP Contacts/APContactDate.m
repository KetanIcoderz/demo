//
//  APContactDate.m
//  APAddressBook
//
//  Created by Alexandre Plisson on 14/01/2016.
//
//

#import "APContactDate.h"

@implementation APContactDate

@end

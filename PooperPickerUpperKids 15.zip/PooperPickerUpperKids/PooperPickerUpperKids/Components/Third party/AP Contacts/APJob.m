//
//  APJob 
//  APAddressBook
//
//  Created by Alexey Belkevich on 05.10.15.
//  Copyright © 2015 alterplay. All rights reserved.
//

#import "APJob.h"

@implementation APJob
@end
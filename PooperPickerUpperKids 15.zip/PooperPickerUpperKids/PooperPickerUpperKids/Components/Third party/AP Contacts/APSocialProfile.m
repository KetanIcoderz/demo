//
//  APSocialContact.m
//  APAddressBook
//
//  Created by David on 2014-08-01.
//  Copyright (c) 2014 David Muzi. All rights reserved.
//

#import "APSocialProfile.h"

@implementation APSocialProfile

@end

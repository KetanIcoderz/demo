//
//  NSArray+NBAdditions.h
//  libPhoneNumber
//
//  Created by Frane Bandov on 04.10.13.
//

#import <Foundation/Foundation.h>

@interface NSArray (NBAdditions)

- (id)safeObjectAtIndex:(NSUInteger)index;

@end

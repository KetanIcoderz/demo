//
//  Constant.swift
//  SportLite
//
//  Created by iCoderz_07 on 11/09/17.
//  Copyright © 2017 iCoderz. All rights reserved.
//

import Foundation
import UIKit
import AVFoundation
import MediaPlayer
import SwiftMessages
import IQKeyboardManagerSwift
import CoreLocation
import GiFHUD_Swift

//com.pooperpickerupperkids
//com.app.ppuk

struct GlobalConstants
{
    // Constant define here.
    static let developerTest : Bool = false
    static let appLive : Bool = true
  
    //Implementation View height
    static let screenHeightDeveloper : Double = 667
    static let screenWidthDeveloper : Double = 375
    
    //Base URL
    static let BaseURL = "http://icoderzsolutions.com/client_c/PPUK/api/v1/"
    static let BaseURLCalling = "http://icoderzsolutions.com/client_c/PPUK/api/communication/v1/"
//    static let BaseURLCalling2 = "http://www.icoderzsolutions.com/client_f/PPUK/api/v1/" //Communication app url
    
    //Name And Appdelegate Object
    static let appName: String = "Pooper Picker Upper Kids"
    static let appDelegate = (UIApplication.shared.delegate as? AppDelegate)
    static let kFontRatio =  (UIScreen.main.bounds.size.width/375)
  
    //System width height
    static let windowWidth: Double = Double(UIScreen.main.bounds.size.width)
    static let windowHeight: Double = Double(UIScreen.main.bounds.size.height)
    
    //Google Api forKey
    static let apiKeyGoogle = "AIzaSyAdxRHtO-HSBKPGlDYOz6A6Ck0AXjbrXFQ"
//    static let apiKeyGoogle = "AIzaSyCPqTFbFp2FQOLzpsmSgWQUjA_24ssCFx8"
    
    //Font
    static let kFontRegular = "MyriadPro-Regular"
    static let kFontMyriadProSemiBold = "MyriadPro-Semibold"
    static let kFontKarlaRegular = "Karla-Regular"
    static let kFontOpenSansSemiBold = "OpenSans-Semibold"
    static let kFontOpenSansRegular = "OpenSans"
    
    //Loading data pagination
    static let int_LoadMax = 8
    static let int_LoadMaxCollection = 12
    
    //Device Token
    static let DeviceToken = UserDefaults.standard.object(forKey: "DeviceToken")
    
    //Place holder
    static let placeHolder_User = "icon_PlaceHolderUser"
    static let placeHolder_Comman = "img_HeaderLogin"
    
    //App Color
    static let appColor = UIColor(red: 255/255, green: 130/255, blue: 0/255, alpha: 1.0)
    static let appColor2 = UIColor(red: 20/255, green: 204/255, blue: 147/255, alpha: 1.0)
    static let appGreenColor = UIColor(red: 0/255, green: 207/255, blue: 255/255, alpha: 1.0)
    static let appPopupBackgroundColor = UIColor(red: 232/255, green: 232/255, blue: 232/255, alpha: 1.0)

    //Registration
    static let deviceType = "iphone"
    
    //Player Controller
    static let playerWordPerPlaySecond = 0.073
}


// MARK: - User Object Updatet -
func userObjectUpdate(dict_Get : NSDictionary,remember : String){
    
    let dict_result = dict_Get["Result"] as! NSDictionary

    //Store data in object
    let obj = UserDataObject(user_UserID : dict_result.getStringForID(key: "user_id"),
                             user_First_Name : dict_result.getStringForID(key: "first_name"),
                             user_Last_Name : dict_result.getStringForID(key: "last_name"),
                             user_Address : dict_result.getStringForID(key: "address"),
                             user_Parent_Name_1 : dict_result.getStringForID(key: "parent_name_1"),
                             user_Parent_Name_2 : dict_result.getStringForID(key: "parent_name_2"),
                             user_Email : dict_result.getStringForID(key: "email"),
                             user_Phone_Number : dict_result.getStringForID(key: "phone_number"),
                             user_Photo : dict_result.getStringForID(key: "photo"),
                             user_AccessToken : dict_result.getStringForID(key: "accessToken"),
                             user_RememberMe : remember,
                             user_Lat : dict_result.getStringForID(key: "lat"),
                             user_Long : dict_result.getStringForID(key: "longs"),
                             user_PlivoUserName : dict_result.getStringForID(key: "plivo_username"),
                             user_PlivoPassword : dict_result.getStringForID(key: "plivo_password"),
                             user_RunMode : dict_result.getStringForID(key: "run_mode"),
                             user_Reward_Point : dict_result.getStringForID(key: "reward_point"))
    
//    user_PlivoUserName : "icoderzteam180629152438",
//    user_PlivoPassword : "123456")
//    dict_result.getStringForID(key: "plivo_username")
//     dict_result.getStringForID(key: "plivo_password")

    //Save User Object
    saveCustomObject(obj, key: "userobject");

    //Save Object In global variable
    objUser = obj
}


func removeSpecialCharsFromString(text: String) -> String {

    let charsToRemove: Set<Character> = Set("[{}\\[\\]+:?,\"\'".characters)
    let newNumberCharacters = String(text.characters.filter { !charsToRemove.contains($0) })
    print(newNumberCharacters) //prints 1 832 8316486
     return newNumberCharacters
}


//MARK: - Manage Font -
func manageFontHeight(font : Double) -> CGFloat{
    let cal : Double = GlobalConstants.windowHeight * font
    
    return CGFloat(cal / GlobalConstants.screenHeightDeveloper)
}

func manageFont(font : Double) -> CGFloat{
    let cal : Double = GlobalConstants.windowWidth * font
    
    return CGFloat(cal / GlobalConstants.screenWidthDeveloper)
}


// MARK: - Make Image with Color -
func imageWithColor(with color: UIColor) -> UIImage {
    let rect = CGRect(x: CGFloat(0.0), y: CGFloat(0.0), width: CGFloat(1.0), height: CGFloat(1.0))
    UIGraphicsBeginImageContext(rect.size)
    let context: CGContext? = UIGraphicsGetCurrentContext()
    context?.setFillColor(color.cgColor)
    context?.fill(rect)
    let image: UIImage? = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    
    return image!
}

////MARK: -- Inicator --
//func indicatorShow() {
//    let size = CGSize(width: 30, height: 30)
//
//    act_indicator.startAnimating(size, message: "Loading", type: NVActivityIndicatorType(rawValue:2)!)
//}
//func indicatorHide() {
//    act_indicator.stopAnimating()
//}

//MARK: -- Email Validation --
func validateEmail(enteredEmail:String) -> Bool {
    
    let emailFormat = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
    let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailFormat)
    return emailPredicate.evaluate(with: enteredEmail)
}

func validatePhoneNumber(value: String) -> Bool {
    let charcterSet  = NSCharacterSet(charactersIn: "+0123456789").inverted
    let inputString = value.components(separatedBy: charcterSet)
    let filtered = inputString.joined(separator: "")
    return  value == filtered
}

//MARK: - Manage function for value save -
extension NSDictionary {
    func getStringForID(key: String) -> String! {
        
        var strKeyValue : String = ""
        if self[key] != nil {
            if (self[key] as? Int) != nil {
                strKeyValue = String(self[key] as? Int ?? 0)
            } else if (self[key] as? String) != nil {
                strKeyValue = self[key] as? String ?? ""
            }else if (self[key] as? Double) != nil {
                strKeyValue = String(self[key] as? Double ?? 0)
            }else if (self[key] as? Float) != nil {
                strKeyValue = String(self[key] as? Float ?? 0)
            }else if (self[key] as? Bool) != nil {
                let bool_Get = self[key] as? Bool ?? false
                if bool_Get == true{
                    strKeyValue = "1"
                }else{
                    strKeyValue = "0"
                }
            }
        }
        return strKeyValue
    }
    
    func getArrayVarification(key: String) -> NSArray {
        
        var strKeyValue : NSArray = []
        if self[key] != nil {
            if (self[key] as? NSArray) != nil {
                strKeyValue = self[key] as? NSArray ?? []
            }
        }
        return strKeyValue
    }
}

//MARK: --User Object--
func saveCustomObject(_ object: UserDataObject, key: String) {
    let encodedObject = NSKeyedArchiver.archivedData(withRootObject: object)
    let defaults = UserDefaults.standard
    defaults.set(encodedObject, forKey: key)
    defaults.synchronize()
}

func loadCustomObject(withKey key: String) -> UserDataObject? {
    let defaults = UserDefaults.standard
    let encodedObject: Data? = defaults.object(forKey: key) as! Data?
    if encodedObject != nil {
        let object: UserDataObject? = NSKeyedUnarchiver.unarchiveObject(with: encodedObject!) as! UserDataObject?
        return object!
    }
    return nil
}


////MARK: -- Share To All --
//func shareFunction(textData : String,viewPresent: UIViewController){
//    // text to share
//    let text = "This is some text that I want to share."
//
//    // set up activity view controller
//    let textToShare = [ textData ]
//    let activityViewController = UIActivityViewController(activityItems: textToShare, applicationActivities: nil)
//    activityViewController.popoverPresentationController?.sourceView = viewPresent.view // so that iPads won't crash
//
//    // exclude some activity types from the list (optional)
//    // activityViewController.excludedActivityTypes = [ UIActivityType.airDrop, UIActivityType.postToFacebook ]
//
//    // present the view controller
//    viewPresent.present(activityViewController, animated: true, completion: nil)
//}


//MARK: - Calculate widht or height of string -
extension String {
    
    func capitalizingFirstLetter() -> String {
        return prefix(1).uppercased() + dropFirst()
    }
    
    mutating func capitalizeFirstLetter() {
        self = self.capitalizingFirstLetter()
    }
    
    func widthOfString(usingFont font: UIFont) -> CGFloat {
        let fontAttributes = [NSAttributedStringKey.font: font]
        let size = self.size(withAttributes: fontAttributes)
        return size.width
    }
    
    func heightOfString(usingFont font: UIFont) -> CGFloat {
        let fontAttributes = [NSAttributedStringKey.font: font]
        let size = self.size(withAttributes: fontAttributes)
        return size.height
    }
    
    func height(withConstrainedWidth width: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: width, height: .greatestFiniteMagnitude)
        let boundingBox = self.boundingRect(with: constraintRect, options: .usesLineFragmentOrigin, attributes: [NSAttributedStringKey.font: font], context: nil)
        
        return ceil(boundingBox.height)
    }
    
    func width(withConstrainedHeight height: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: .greatestFiniteMagnitude, height: height)
        let boundingBox = self.boundingRect(with: constraintRect, options: .usesLineFragmentOrigin, attributes: [NSAttributedStringKey.font: font], context: nil)
        
        return ceil(boundingBox.width)
    }
}



//MARK: -- Selected Index --
func selectedIndex(arr : NSArray, value : NSString) -> Int{
    for (index, element) in arr.enumerated() {
        if value as String == arr[index] as! String {
            return index
        }
    }
    return 0
}
extension UserDefaults {
    func setString(string:String, forKey:String) {
        set(string, forKey: forKey)
    }
    func setDate(date:NSDate, forKey:String) {
        set(date, forKey: forKey)
    }
    //  func dateForKey(string:String) -> NSDate? {
    //    return objectForKey(string) as? NSDate
    //  }
}


func TabbarManager(view : UIViewController){
    let storyboard = UIStoryboard(name: "PlivoCall", bundle: nil)
    
    //1. Home controller
    let TabBarViewController = storyboard.instantiateViewController(withIdentifier: "PlivoCallController") as! PlivoCallController
    TabBarViewController.delegate = view as! PlaceViewController
    TabBarViewController.strPlace = "1"
    view.navigationController?.pushViewController(TabBarViewController, animated: false)
    

    /*
 
 let storyboard = UIStoryboard(name: "Main", bundle: nil)
 let view2 = storyboard.instantiateViewController(withIdentifier: "PlivoCallController") as! PlivoCallController
 
 view.navigationController?.pushViewController(view2, animated: true)
 */
}



// MARK: - All Object -
class SideMenuModuleObject : NSObject {
    var str_Title: String = ""
    var str_Selected: String = ""
    var str_Image: String = ""
}

class GlobalObject : NSObject {
    //Map
    var str_Id: String = ""
    var str_Customer_Id: String = ""
    var str_Customer_Lat: String = ""
    var str_Customer_Long: String = ""
    var str_Customer_Title: String = ""
    var str_Customer_FirstName: String = ""
    var str_Customer_LastName: String = ""
    var str_Customer_Address: String = ""
    var str_Customer_Interest: String = ""
    var str_Customer_Note: String = ""
    var str_Customer_PhoneNumber: String = ""
    var str_Customer_DogName: String = ""
    var str_Customer_Time: String = ""
    var str_Customer_TimeOnly: String = ""
    var str_Customer_DateOnly: String = ""
    var str_Customer_MonthOnly: String = ""
    var str_Customer_StartTime: String = ""
    var str_Customer_EndTime: String = ""
    var str_Customer_Spouse_Name: String = ""
    var str_Customer_job_status: String = ""
    var str_Customer_job_status_Text: String = ""
    var arr_Customer_ScheduleJob: NSMutableArray = []
    var str_Customer_ScheduleType: String = ""
    var str_Customer_JobType : String = ""
    var str_Customer_Job_Amount : String = ""
    var str_Customer_Job_Payment_Method : String = ""
    var str_Customer_Job_Cheque_Num: String = ""
    var str_Customer_ProspectDate: String = ""
    var str_Customer_Confirm_Msg_Count: String = ""
    
    //Customer
    var str_Customer_Name: String = ""
    var str_Customer_Name2: String = ""
    var str_Customer_Date: String = ""
    var str_Customer_Month: String = ""
    
    var str_Customer_SheduleType: String = ""
    var str_Customer_SheduleSelected: String = ""
    
    //Other User
    var str_User_Id : String = ""
    var str_User_Name : String = ""
    var str_User_AccessToken : String = ""
    var str_User_Email : String = ""
    var str_User_Phone : String = ""
    
    //Message
    var str_MessageTo_FirstName : String = ""
    var str_MessageTo_LastName : String = ""
    var str_MessageTo_Email : String = ""
    var str_MessageTo_Phone : String = ""
    var str_MessageTo_ContatId : String = ""
    var str_MessageTo_Address : String = ""
    
    var str_MessageFrom_FirstName : String = ""
    var str_MessageFrom_LastName : String = ""
    var str_MessageFrom_Email : String = ""
    var str_MessageFrom_Phone : String = ""
    var str_MessageFrom_ContatId : String = ""
    var str_MessageFrom_Address : String = ""
    
    //Recent
    var str_Recent_Title : String = ""
    var str_Recent_From_Title : String = ""
    var str_Recent_Descriptino : String = ""
    var img_Recent_Image = UIImage()
    var str_Recent_Live : String = ""
    var str_Recent_Time : String = ""
    var str_Recent_To_Number : String = ""
    var str_Recent_CallDirection : String = ""
    var str_Recent_CallDuration : String = ""
    var str_Recent_Callstate : String = ""
    var str_Recent_Initiation_Time : String = ""
    var str_Recent_Total_Amount : String = ""
    
    //Messages
    var str_Message : String = ""
    var str_Message_Tital : String = ""
    var str_Message_Discription : String = ""
    var str_Message_From_Tital : String = ""
    var str_Message_Error_code : String = ""
    var str_Message_From_Number : String = ""
    var img_Message_Direction : String = ""
    var str_Message_State : String = ""
    var str_Message_Time : String = ""
    var str_Message_Type : String = ""
    var str_Message_UIID : String = ""
    var str_Message_URI : String = ""
    var str_Message_To_Number : String = ""
    var str_Message_Total_Amount : String = ""
    var str_Message_Total_Rate : String = ""
    var str_Message_Unit : String = ""
    
    //Messages
    var str_Notification_Id : String = ""
    var str_Notification_User_Id : String = ""
    var str_Notification_Text : String = ""
    var str_Notification_Type : String = ""
    var str_Notification_Is_Read : String = ""
    var str_Notification_Time : String = ""
}

class BannerObject : NSObject {
    //Map
    var str_BannerImage: String = ""
    var str_BannerLink: String = ""
}

class VideoObject : NSObject {
    //Map
    var str_VideoURL: String = ""
    var str_VideoImage: String = ""
    var str_VideoCategory: String = ""
    var str_VideoID: String = ""
    
    var arr_SaveVideos: NSMutableArray = []
}


class JobsObject : NSObject {
    //Comman
    var str_Type : String = "" //text,textnumber,textnote,startendtime,addresspicker,selection
    var str_PlaceHolder : String = ""
    var str_PlaceHolder2 : String = ""
    
    var str_Title : String = ""
    
    //Address attibute
    var str_Lat : String = ""
    var str_Long : String = ""
    var str_Address : String = ""
    
    //Text attribute
    var str_TextValue : String = ""
    var str_TextValue2 : String = ""
    
    //Start time end time attribute
    var str_StartTime : String = ""
    var str_EndTime : String = ""
    
    //Date pickert attribute
    var str_DatePickerDate : String = ""
    
    //Array selection array
    var str_SelectionId : String = ""
    var arr_SelectionArray : NSMutableArray = []
    
}

//MARK: - Array To string convertion -
func notPrettyString(from object: Any) -> String? {
    if let objectData = try? JSONSerialization.data(withJSONObject: object, options: JSONSerialization.WritingOptions(rawValue: 0)) {
        let objectString = String(data: objectData, encoding: .utf8)
        return objectString
    }
    return nil
}
func notPrettyArray(from: String) -> NSArray?{
    let str = "{\"name\":\(from)}"
    let data = str.data(using: String.Encoding.utf8, allowLossyConversion: false)!
    
    do {
        let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String: AnyObject]
        //        if let names = json["names"] as? [String] {
        //            print(names)
        //        }
        return json["name"] as! NSArray
    } catch let error as NSError {
        print("Failed to load: \(error.localizedDescription)")
    }
    return []
}




func removeNewLineToSpace(str_Value : String) -> String{
    let newString = str_Value.replacingOccurrences(of: "\n", with: " ")
    
    return newString
}


func keyboardActivityEnableorDisable(show : Bool){
    if show == true{
        IQKeyboardManager.sharedManager().enable = true
        IQKeyboardManager.sharedManager().enableAutoToolbar = true
        IQKeyboardManager.sharedManager().shouldShowTextFieldPlaceholder = true
        IQKeyboardManager.sharedManager().keyboardDistanceFromTextField = 20.0
    }else{
        IQKeyboardManager.sharedManager().enable = false
        IQKeyboardManager.sharedManager().enableAutoToolbar = true
        IQKeyboardManager.sharedManager().shouldShowTextFieldPlaceholder = false
        IQKeyboardManager.sharedManager().keyboardDistanceFromTextField = 20.0
    }
}


func FontNamePrint(){
        for family: String in UIFont.familyNames
        {
            print("\(family)")
            for names: String in UIFont.fontNames(forFamilyName: family)
            {
                print("== \(names)")
            }
        }
}

//Device Identifier
func deviceIdentifier() -> String{
    switch UIScreen.main.nativeBounds.height {
    case 1136:
        return "iPhone 5 or 5S or 5C"
    case 1334:
        return "iPhone 6/6S/7/8"
    case 1920, 2208:
        return "iPhone iPhone 6+/6S+/7+/8+"
    case 2436, 2688:
        return "iPhone X"
    default:
        return "unknown"
    }
}


//MARK: -- Inicator --
func indicatorShow(){
    let size = CGSize(width: 30, height: 30)

    act_indicator.startAnimating(size, message: "", type: NVActivityIndicatorType(rawValue:5)!)
    
//    // Setup gif image
//    GIFHUD.shared.setGif(named: "testloading.gif")
//    GIFHUD.shared.show()
//    GIFHUD.shared.overlayView?.alpha = 0.5
}
func indicatorHide(){
    act_indicator.stopAnimating()
    
//    GIFHUD.shared.dismiss()
}


//MARK: -- Set up Tabbar and sidebar controller --
func manageTabBarandSideBar(){
    //Push Notification
    if notificationSave != nil{
        let when = DispatchTime.now() + 1
        DispatchQueue.main.asyncAfter(deadline: when) {
            GlobalConstants.appDelegate?.openNotification(notificationSave!)
            notificationSave = nil
        }
    }
    
    //Store data in object
    
    //Declare alloc init for storyboard/Mange Tab bar
    let storyboard = UIStoryboard(name: "Main", bundle: nil)
    
    let mainViewController = storyboard.instantiateViewController(withIdentifier: "PlivoCallController") as! PlivoCallController
    let leftViewController = storyboard.instantiateViewController(withIdentifier: "navsidemenu") as! UINavigationController
    
    let nvc: UINavigationController = UINavigationController(rootViewController: mainViewController)
    
    //Declare Slidemenucontroller with connect sidebar and menubar
    let slideMenuController = ExSlideMenuController(mainViewController:nvc, leftMenuViewController: leftViewController)
    slideMenuController.automaticallyAdjustsScrollViewInsets = true
    slideMenuController.delegate = mainViewController
    slideMenuController.changeLeftViewWidth(CGFloat(0))
//    SlideMenuOptions.opacityViewBackgroundColor = UIColor.clear
    
    let when = DispatchTime.now() + 0.5
    DispatchQueue.main.asyncAfter(deadline: when) {
        let calculationValue = (GlobalConstants.windowWidth * 78) / 100
        slideMenuController.changeLeftViewWidth(CGFloat(calculationValue))
    }
    
    //Manage Slidemenu
    SlideMenuOptions.hideStatusBar = false
    SlideMenuOptions.contentViewOpacity = 1.0
    SlideMenuOptions.contentViewScale = 1.0
    
    //    SlideMenuOptions.rightPanFromBezel = false
    //Call navigation with push view controller
    let mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
    _ =  mainStoryboard.instantiateViewController(withIdentifier: "PlivoCallController") as! PlivoCallController
    
    let appDelegate2 = UIApplication.shared.delegate as! AppDelegate
    let nav2: UINavigationController! = (appDelegate2.window?.rootViewController as! UINavigationController)
    nav2?.pushViewController(slideMenuController, animated: true)
    
    //Location Alert
    locationErrorAlert()
    NaviationManager()
}



// MARK: - Make Image with Color -
func image(with color: UIColor) -> UIImage {
    let rect = CGRect(x: CGFloat(0.0), y: CGFloat(0.0), width: CGFloat(1.0), height: CGFloat(1.0))
    UIGraphicsBeginImageContext(rect.size)
    let context: CGContext? = UIGraphicsGetCurrentContext()
    context?.setFillColor(color.cgColor)
    context?.fill(rect)
    let image: UIImage? = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    
    return image!
}


//MARK: -- Data Formate Convertion --
func localDateToStrignDate(date : Date,type : Int) -> String {
    
    let dateFormatter = DateFormatter()
    
    //Required formate convert
    dateFormatter.dateFormat = "dd/MM"
    let str_Date = dateFormatter.string(from: date)
    dateFormatter.dateFormat  = "EE"
    let str_DayName = dateFormatter.string(from: date)
    
    if type == 0{
        return "\(str_Date)\n\(str_DayName)"
    }else if type == 1{
        dateFormatter.dateFormat = "dd"
        let str_Date = dateFormatter.string(from: date)
        return str_Date
    }else if type == 2{
        return str_DayName
    }else if type == 3{
        //Required formate convert
        dateFormatter.dateFormat = "MMMM"
        let str_Month = dateFormatter.string(from: date)
        
        dateFormatter.dateFormat = "YYYY"
        let str_Year = dateFormatter.string(from: date)
        return "\(str_Month) \(str_Year)"
    }
    
    return "\(str_Date)\n\(str_DayName)"
}
func localDateToStrignDate2(date : Date) -> String {
    
    let dateFormatter = DateFormatter()
    
    //Required formate convert
    dateFormatter.dateFormat = "yyyy-MM-dd"
    let str_Date = dateFormatter.string(from: date)
    
    return str_Date
}

func localStrignToDate(date : String) -> Date {
    
    let dateFormatter = DateFormatter()
    
    //Required formate convert
    dateFormatter.dateFormat = "h:mm a"
    return dateFormatter.date(from: date)!
    
}

func localDateStringToString(date : String) -> String {
    
    let dateFormatter = DateFormatter()
    
    //Required formate convert
    dateFormatter.dateFormat = "HH:mm:ss"
    let dateConvert = dateFormatter.date(from: date)!
    
    
    dateFormatter.dateFormat = "h:mm a"
    return dateFormatter.string(from: dateConvert)
}

func localDateStringToString2(date : String) -> String {
    
    let dateFormatter = DateFormatter()
    
    //Required formate convert
    dateFormatter.dateFormat = "yyyy-MM-dd"
    let dateConvert = dateFormatter.date(from: date)!
    
    //Required formate convert
    dateFormatter.dateFormat = "dd/MM/yyyy"
    let str_Date = dateFormatter.string(from: dateConvert)
    dateFormatter.dateFormat  = "EE"
    let str_DayName = dateFormatter.string(from: dateConvert)
    
    return "\(str_Date) \(str_DayName)"
}

func localDateStringToString3(date : String) -> String {
    
    let dateFormatter = DateFormatter()
    
    //Required formate convert
    dateFormatter.dateFormat = "yyyy-MM-dd"
    let dateConvert = dateFormatter.date(from: date)!
    
    //Required formate convert
    dateFormatter.dateFormat = "dd"
    let str_Date = dateFormatter.string(from: dateConvert)
    
    return str_Date
}

func localDateStringToString4(date : String) -> String {
    
    let dateFormatter = DateFormatter()
    
    //Required formate convert
    dateFormatter.dateFormat = "yyyy-MM-dd"
    let dateConvert = dateFormatter.date(from: date)!
    
    //Required formate convert
    dateFormatter.dateFormat = "MMM"
    let str_Date = dateFormatter.string(from: dateConvert)
    
    return str_Date
}



//MARK: - addCountryCode -
func addCountryCode(str_Get : String) -> String{
    var newHandleString: String = str_Get.replacingOccurrences(of: "-", with: "")
    if newHandleString.prefix(str_CountryCode.count) != str_CountryCode && (newHandleString as NSString).range(of: "+\(str_CountryCode)").location == NSNotFound{
        newHandleString = "+\(str_CountryCode)\(newHandleString)"
    }
    return newHandleString
}


//MARK: - App Permission Checking -
extension Bool {
    
    func locationPermissionCheck() -> Bool{
        if CLLocationManager.locationServicesEnabled() {
            switch CLLocationManager.authorizationStatus() {
            case .notDetermined, .restricted, .denied:
                return false
            case .authorizedAlways, .authorizedWhenInUse:
                return true
            default:
                return false
            }
        } else {
            return false
        }
    }
}


func locationErrorAlert(){
    let bool : Bool = false
    if bool.locationPermissionCheck() == false {
        let alert = UIAlertController(title: GlobalConstants.appName, message: "You MUST enable Location Services at ALL times for app to work properly. Please enable location permission.", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Setting", style: UIAlertActionStyle.default, handler: { (action) in
            var appSettings = URL(string: UIApplicationOpenSettingsURLString)
            UIApplication.shared.openURL(appSettings!)
        }))
        GlobalConstants.appDelegate?.window?.rootViewController?.present(alert, animated: true, completion: nil)
    }
}


//MARK: - Login User Check -
func alredyLoginOrNot() -> Bool{
    if ((loadCustomObject(withKey: "userobject")) != nil){
        var objUserTemp : UserDataObject = loadCustomObject(withKey: "userobject")!
        
        //Condition get data from userdefault
        if objUserTemp.user_RememberMe == "1" {
            
            objUser = objUserTemp
            return true
        }else{
            let defaults = UserDefaults.standard
            defaults.removeObject(forKey: "userobject")
            defaults.synchronize()
        }
    }
    return false
}
func alredyLoginOrNot2() -> Bool{
    if ((loadCustomObject(withKey: "userobject")) != nil){
        return true
    }
    return false
}


//MARK: - Plivo Call Methods -

//MARK: - Count Down -
struct StopWatch {
    
    var totalSeconds: Int
    
    var years: Int {
        return totalSeconds / 31536000
    }
    
    var days: Int {
        return (totalSeconds % 31536000) / 86400
    }
    
    var hours: Int {
        return (totalSeconds % 86400) / 3600
    }
    
    var minutes: Int {
        return (totalSeconds % 3600) / 60
    }
    
    var seconds: Int {
        return totalSeconds % 60
    }
    
    //simplified to what OP wanted
    var hoursMinutesAndSeconds: (hours: Int, minutes: Int, seconds: Int) {
        return (hours, minutes, seconds)
    }
    
    var getFormate:(String){
        if years > 0{
            return ("\(years) Year")
        }else if days > 0{
            return ("\(days) Day")
        }else if hours > 0{
            return ("\(hours) Hr")
        }else if minutes > 0{
            return ("\(minutes) Min")
        }else if seconds > 0{
            return ("\(seconds) Sec")
        }
        return ("")
    }
}




//MARK: - Date Fromate -
func getTimeBetweenCurrentDateTo(date : String) -> String {
    
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ssZZZZZ"
    
    //First convert date in server formate
    let dateHere = dateFormatter.date(from: date)
    
    dateFormatter.dateFormat = "ZZZZZ"
    let str = dateFormatter.string(from: dateHere!)
    
    let dateCurrent = NSDate()
    let dateFormatter2 = DateFormatter()
    dateFormatter2.dateFormat = "yyyy-MM-dd HH:mm:ss"
    //    dateFormatter2.timeZone = NSTimeZone(name: "UTC") as! TimeZone
    let str_CurrentDate = dateFormatter2.string(from: dateCurrent as Date)
    
    dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
    let str_GetDate = dateFormatter.string(from: dateHere!)
    
    
    let startDate = dateFormatter.date(from: str_CurrentDate)
    let endDate = dateFormatter.date(from: str_GetDate)
    let calendar = NSCalendar.current
    let dateComponents = Calendar.current.dateComponents([.hour, .minute, .second, .year , .day], from: endDate!, to: startDate!)
    
    if dateComponents.year! > 0{
        if "\(dateComponents.year!)" == "1"{
            return ("\(dateComponents.year!) year ago")
        }
        return ("\(dateComponents.year!) years ago")
    }else if dateComponents.day! > 0{
        if "\(dateComponents.day!)" == "1"{
            return ("\(dateComponents.day!) day ago")
        }
        return ("\(dateComponents.day!) days ago")
    }else if dateComponents.hour! > 0{
        if "\(dateComponents.hour!)" == "1"{
            return ("\(dateComponents.hour!) hr ago")
        }
        return ("\(dateComponents.hour!) hrs ago")
    }else if dateComponents.minute! > 0{
        if "\(dateComponents.minute!)" == "1"{
            return ("\(dateComponents.minute!) min ago")
        }
        return ("\(dateComponents.minute!) mins ago")
    }else if dateComponents.second! > 0{
        if "\(dateComponents.second!)" == "1"{
            return ("\(dateComponents.second!) sec ago")
        }
        return ("\(dateComponents.second!) secs ago")
    }
    return ""
}


func getTimeBetweenCurrentDateToMessage(date : String) -> String {
    
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss.SSSZZZZZ"
    
    //First convert date in server formate
    let dateHere = dateFormatter.date(from: date)
    
    dateFormatter.dateFormat = "ZZZZZ"
    let str = dateFormatter.string(from: dateHere!)
    
    let dateCurrent = NSDate()
    let dateFormatter2 = DateFormatter()
    dateFormatter2.dateFormat = "yyyy-MM-dd HH:mm:ss"
    //    dateFormatter2.timeZone = NSTimeZone(name: "UTC") as! TimeZone
    let str_CurrentDate = dateFormatter2.string(from: dateCurrent as Date)
    
    dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
    let str_GetDate = dateFormatter.string(from: dateHere!)
    
    
    let startDate = dateFormatter.date(from: str_CurrentDate)
    let endDate = dateFormatter.date(from: str_GetDate)
    let calendar = NSCalendar.current
    let dateComponents = Calendar.current.dateComponents([.hour, .minute, .second, .year , .day], from: endDate!, to: startDate!)
    
    if dateComponents.year! > 0{
        if "\(dateComponents.year!)" == "1"{
            return ("\(dateComponents.year!) year ago")
        }
        return ("\(dateComponents.year!) years ago")
    }else if dateComponents.day! > 0{
        if "\(dateComponents.day!)" == "1"{
            return ("\(dateComponents.day!) year ago")
        }
        return ("\(dateComponents.day!) days ago")
    }else if dateComponents.hour! > 0{
        if "\(dateComponents.hour!)" == "1"{
            return ("\(dateComponents.hour!) hr ago")
        }
        return ("\(dateComponents.hour!) hrs ago")
    }else if dateComponents.minute! > 0{
        if "\(dateComponents.minute!)" == "1"{
            return ("\(dateComponents.minute!) min ago")
        }
        return ("\(dateComponents.minute!) mins ago")
    }else if dateComponents.second! > 0{
        if "\(dateComponents.second!)" == "1"{
            return ("\(dateComponents.second!) sec ago")
        }
        return ("\(dateComponents.second!) sec ago")
    }
    return ""
}



func manageArray(arry : NSArray) -> NSMutableArray{
    let dict_Value : NSMutableArray = []
    let arr_Keyword : NSMutableArray = ["0","1","2","3","4","5","6","7","8","9","10","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
    
    for i in 0..<arr_Keyword.count{
        for j in 0..<arry.count{
            if arry[j] as! String == arr_Keyword[i] as! String{
                dict_Value.add(arry[j] as! String)
                break
            }
        }
    }
    return dict_Value
}



//MARK: - Navigation Manager -
func NaviationManager(){
    if alredyLoginOrNot(){
        if objUser?.user_RunMode == "1"{
            UINavigationBar.appearance().setBackgroundImage(image(with:GlobalConstants.appColor), for: .default)
        }else{
            UINavigationBar.appearance().setBackgroundImage(image(with:GlobalConstants.appColor2), for: .default)
        }
    }else{
        UINavigationBar.appearance().setBackgroundImage(image(with:GlobalConstants.appColor), for: .default)
    }
    
}


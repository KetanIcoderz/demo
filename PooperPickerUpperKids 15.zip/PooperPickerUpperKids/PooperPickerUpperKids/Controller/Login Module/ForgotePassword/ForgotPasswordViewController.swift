//
//  ForgotPasswordViewController.swift
//  PooperPickerUpperKids
//
//  Created by Apple on 30/07/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import SwiftMessages

class ForgotPasswordViewController: UIViewController {

    
    //Declaration Button
    @IBOutlet weak var btn_ResetPassword: UIButton!
    @IBOutlet weak var btn_Back: UIButton!
    
    @IBOutlet weak var tf_Email: HoshiTextField!
    
    @IBOutlet weak var lbl_Header: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - Other Files -
    func commanMethod(){
        
        btn_ResetPassword.titleLabel?.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        btn_Back.titleLabel?.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        
        tf_Email.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 18))
        
        lbl_Header.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 18))
    }
    
    // MARK: - Button Event -
    @IBAction func btn_ResetPassword(_ sender:Any){
        var boolEmail : Bool = true
        
        var isValidEmail : Bool = false
        
        if((tf_Email.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: ValidationMessages.ForgotPasswordViewController_BlackEmail as NSString, alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
            
            boolEmail = false
        }else if(isValidEmail ==  validateEmail(enteredEmail: tf_Email.text!) && GlobalConstants.developerTest == false){
            if isValidEmail == true {
                
            }else{
                //Alert show for Header
                messageBar.MessageShow(title: ValidationMessages.ForgotPasswordViewController_ValidEmail as NSString, alertType: MessageView.Layout.cardView, alertTheme: .success, TopBottom: true)
                
                boolEmail = false
            }
        }
        
        if boolEmail == true{
            self.view.endEditing(true)
            
            self.Post_ForgotPassword()
            
//            //Alert show for Header
//            messageBar.MessageShow(title: "Successfull sent forgot password link in your mail account", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
//
//            self.btn_Back(self)
        }
    }
    @IBAction func btn_Back(_ sender:Any){
        self.navigationController?.popViewController(animated: true)
    }

    
    // MARK: - Get/Post Method -
    func Post_ForgotPassword(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)customer/forget_password"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "email" : tf_Email.text ?? "",
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "forget_password"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = true
        webHelper.startDownload()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  PlaceViewController.swift
//  PooperPickerUpperKids
//
//  Created by Apple on 30/07/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import CoreLocation
import LocalAuthentication
import CallKit
import AVFoundation

class PlaceViewController: UIViewController, CLLocationManagerDelegate, PlivoCallControllerProtocol{
    

    var locationManager: CLLocationManager!
    var strCallComing : String = "0"
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        //THis method only call when phone call coming
        if alredyLoginOrNot() == true{
            let Delay = DispatchTime.now() + 0.5
            DispatchQueue.main.asyncAfter(deadline: Delay) {
                TabbarManager(view : self)
            }
        }
        
        
        let Delay = DispatchTime.now() + 2
        DispatchQueue.main.asyncAfter(deadline: Delay) {
            if self.strCallComing == "0"{
                vw_Call.navigationController?.popViewController(animated: false)
                let Delay = DispatchTime.now() + 0.5
                DispatchQueue.main.asyncAfter(deadline: Delay) {
                    self.locationManager = CLLocationManager()
                    self.locationManager.delegate = self
                    self.locationManager.requestAlwaysAuthorization()
                }
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        GlobalConstants.appDelegate?.navigationSet(color: UIColor.clear)
        
        if str_LogoutSuccess == "1"{
            self.moveView()
            str_LogoutSuccess = "0"
        }
    }
    override func viewWillDisappear(_ animated: Bool) {
        GlobalConstants.appDelegate?.navigationSet(color: UIColor.white)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    //MARK: - Delegate -
    func comingCall(){
        strCallComing = "1"
    }
    func callEnd(){
        vw_Call.navigationController?.popViewController(animated: false)
        self.navigationController?.isNavigationBarHidden = true
        let Delay = DispatchTime.now() + 1.0
        DispatchQueue.main.asyncAfter(deadline: Delay) {
            self.locationManager = CLLocationManager()
            self.locationManager.delegate = self
            self.locationManager.requestAlwaysAuthorization()
        }
    }
    
    // MARK: - Other Methods -
    @objc func moveView(){
        if alredyLoginOrNot() == false{
            self.performSegue(withIdentifier: "signin", sender: self)
        }else{
            let Delay = DispatchTime.now() + 0.5
            DispatchQueue.main.asyncAfter(deadline: Delay) {
//                TabbarManager(view : self)
//                manageTabBarandSideBar()
                self.authenticateUser()
            }
        }
    }
    
    func authenticateUser() {
        let context = LAContext()
        var error: NSError?
        
        context.localizedFallbackTitle = ""
        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
            let reason = "Unlock PPUK"
            
            context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason) {
                [unowned self] success, authenticationError in
                
                DispatchQueue.main.async {
                    if success {
                        manageTabBarandSideBar()
                        self.Post_DeviceTocken()
                    } else {
                        exit(0)
                    }
                }
            }
        } else {
            manageTabBarandSideBar()
            self.Post_DeviceTocken()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status != .notDetermined {
            Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(moveView), userInfo: nil, repeats: false)
        }
    }
    
    // MARK: - Get/Post Method -
    func Post_DeviceTocken(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)customer/pushtoken"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "devicetype" : GlobalConstants.deviceType,
            "devicetoken" :  UserDefaults.standard.value(forKey: "DeviceToken") == nil ? "123" : UserDefaults.standard.value(forKey: "DeviceToken")! as! String,
            "unique_id" : "",
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "pushtoken"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.serviceWithAlertErrorMessage = false
        webHelper.indicatorShowOrHide = false
        webHelper.startDownload()
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

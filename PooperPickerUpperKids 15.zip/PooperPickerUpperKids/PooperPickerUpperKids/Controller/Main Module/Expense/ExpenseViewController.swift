//
//  ExpenseViewController.swift
//  PooperPickerUpperKids
//
//  Created by Apple on 07/08/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import ActionSheetPicker_3_0
import SwiftMessages

class ExpenseViewController: UIViewController {

    var get_Data = GlobalObject()
    
    @IBOutlet var cv_Header : UICollectionView!
    
    @IBOutlet var lbl_TakeAPicker : UILabel!
    @IBOutlet var lbl_EnterAmount : UILabel!
    @IBOutlet var lbl_TypeOfExpense : UILabel!
    
    @IBOutlet var tf_EnterAmount : UITextField!
    @IBOutlet var tf_TypeOfExpense : UITextField!
    
    @IBOutlet var btn_TypeOfExpense : UIButton!
    @IBOutlet var btn_Submit : UIButton!
    
    var arr_Main : NSMutableArray = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()

        self.navigationItem.title = get_Data.str_Customer_Title
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    //MARK: - Other Method -
    func commanMethod(){
        
        lbl_TakeAPicker.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_EnterAmount.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_TypeOfExpense.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        
        tf_EnterAmount.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 14))
        tf_TypeOfExpense.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 14))
        
        tf_TypeOfExpense.attributedPlaceholder = NSAttributedString(string: "Select option",
                                                               attributes: [NSAttributedStringKey.foregroundColor: UIColor(red: 119.0/255.0, green: 119.0/255.0, blue: 119.0/255.0, alpha: 1.0)])
    }
    
    //MARK: - Other Method -
    @IBAction func btn_Back(_ sender:Any){
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btn_TypeOfExpense(_ sender:Any){
        let arr_Data : [Any] = ["First Type","Second Type","Third Type"]
        
        let picker = ActionSheetStringPicker(title: "Type of expense", rows: arr_Data, initialSelection:selectedIndex(arr: arr_Data as NSArray, value: tf_TypeOfExpense.text! as String as NSString), doneBlock: { (picker, indexes, values) in
            
            self.tf_TypeOfExpense.text = "\(values as! NSString as! String)"
            
        }, cancel: {ActionSheetStringPicker in return}, origin: sender)
        
        //        picker?.hideCancel = true
        picker?.setDoneButton(UIBarButtonItem(title: "Select", style: .plain, target: nil, action: nil))
        picker?.setCancelButton(UIBarButtonItem(title: "Cancel", style: .plain, target: nil, action: nil))
        picker?.toolbarButtonsColor = UIColor.black
        
        picker?.show()
        
        
    }
    @IBAction func btn_Submit(_ sender:Any){
        if(arr_Main.count == 0 && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please add attachment for your expense", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }else if((tf_EnterAmount.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please enter amount", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }else if((tf_TypeOfExpense.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please select type of expense.", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }else{
            //Alert show for Header
            messageBar.MessageShow(title: "Saved expense successfully.", alertType: MessageView.Layout.cardView, alertTheme: .success, TopBottom: true)
            
            self.navigationController?.popViewController(animated: true)
        }
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension ExpenseViewController : UIImagePickerControllerDelegate , UINavigationControllerDelegate{
    
    // MARK: - ImagePicker Delegate -
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let image = info[UIImagePickerControllerEditedImage] as! UIImage
        
        if arr_Main.count == 0{
            arr_Main.add(image)
        }else{
            arr_Main.insert(image, at: 0)
        }
        
//        arr_Main.add(image)
        cv_Header.reloadData()
        self.dismiss(animated: true, completion: nil);
    }
}

//MARK: - Collection View Cell -
class ExpenseViewCollectioncell : UICollectionViewCell{
    //Cell for tabbar
    @IBOutlet weak var img_Seleted: UIImageView!
}

//MARK: - Collection View -
extension ExpenseViewController : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return arr_Main.count + 1
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.size.height, height: collectionView.frame.size.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        var str_Identifier : String = "cell"
        if indexPath.row != 0{
            str_Identifier = "cell2"
        }
        
        let cell  = collectionView.dequeueReusableCell(withReuseIdentifier: str_Identifier, for: indexPath) as! ExpenseViewCollectioncell
        
        if indexPath.row != 0{
            cell.img_Seleted.image = arr_Main[indexPath.row - 1] as! UIImage
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if indexPath.row == 0{
            //Change Profile Pic Alert
            let alert = UIAlertController(title: GlobalConstants.appName, message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
            alert.addAction(UIAlertAction(title: "Camera", style: UIAlertActionStyle.default, handler: { (action) in
                if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera) {
                    let imagePicker = UIImagePickerController()
                    imagePicker.delegate = self
                    imagePicker.sourceType = UIImagePickerControllerSourceType.camera
                    imagePicker.allowsEditing = true
                    self.present(imagePicker, animated: true, completion: nil)
                }
                
            }))
            alert.addAction(UIAlertAction(title: "Gallery", style: UIAlertActionStyle.default, handler: { (action) in
                if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.photoLibrary) {
                    let imagePicker = UIImagePickerController()
                    imagePicker.delegate = self
                    imagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary
                    imagePicker.allowsEditing = true
                    self.present(imagePicker, animated: true, completion: nil)
                }
            }))
            
            alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
    }
}

//
//  ConfrimArrivalViewController.swift
//  PooperPickerUpperKids
//
//  Created by Apple on 02/08/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import GoogleMaps

class ConfrimArrivalViewController: UIViewController {

    @IBOutlet weak var btn_Confirm : UIButton!
    
    @IBOutlet weak var lbl_Address : UILabel!
    @IBOutlet weak var lbl_Address2 : UILabel!
    
    @IBOutlet var vw_MapGoogle : GMSMapView!
    
    var get_Data = GlobalObject()
    
    var getPolygline : GMSPolyline!
    var getGMSPath : GMSPath!
    
    var str_Complete : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - Other Method -
    func commanMethod(){
        
        btn_Confirm.titleLabel?.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        
        lbl_Address.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 17))
        lbl_Address2.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 15))
        
        lbl_Address.text = get_Data.str_Customer_Title
        lbl_Address2.text = get_Data.str_Customer_Address
        
        //Set up move to my location
        let arr_Temp : NSMutableArray = []
        
        let pin1: CLLocationCoordinate2D = CLLocationCoordinate2DMake(currentLocation!.coordinate.latitude, currentLocation!.coordinate.longitude)
        var pin2: CLLocationCoordinate2D = CLLocationCoordinate2DMake(currentLocation!.coordinate.latitude, currentLocation!.coordinate.longitude)
        pin2.latitude = CLLocationDegrees(Float(get_Data.str_Customer_Lat)!)
        pin2.longitude = CLLocationDegrees(Float(get_Data.str_Customer_Long)!)
        
        let marker = GMSMarker(position: pin1)
        marker.title = "Your Location"
        marker.snippet = ""
        marker.isFlat = false
        marker.map = vw_MapGoogle
        marker.icon = UIImage(named: "icon_MapPin")
        marker.tracksViewChanges = false
        marker.map = vw_MapGoogle
        arr_Temp.add(marker)
        
        let marker2 = GMSMarker(position: pin2)
        marker2.title = get_Data.str_Customer_Address
        marker2.snippet = ""
        marker2.isFlat = false
        marker2.map = vw_MapGoogle
        marker2.icon = UIImage(named: "icon_MapPin")
        marker2.tracksViewChanges = false
        marker2.map = vw_MapGoogle
        arr_Temp.add(marker2)
        
        let location = CLLocation(latitude: Double(get_Data.str_Customer_Lat)!, longitude: Double(get_Data.str_Customer_Long)!)
        self.drawPath(startLocation: currentLocation!, endLocation: location)
        
        if str_Complete == "1"{
            btn_Confirm .setTitle("Complete Job", for: .normal)
            self.navigationItem.title = "Complete Job"
        }else{
            //Job already confirmed or not
            if get_Data.str_Customer_job_status == "0"{
                if get_Data.str_Customer_Confirm_Msg_Count != "" && get_Data.str_Customer_Confirm_Msg_Count != "0"{
                    btn_Confirm .setTitle("Resend Confirmation", for: .normal)
                    self.navigationItem.title = "Confirm Arrival"
                }else{
                    btn_Confirm .setTitle("Confirm Job", for: .normal)
                    self.navigationItem.title = "Confirm Arrival"
                }
            }else{
                btn_Confirm .setTitle("Confirmed Job", for: .normal)
                self.navigationItem.title = "Confirmed"
            }
        }
        
        //Set position for both pin zoom level
        self.didTapFitBounds(withMarkers: arr_Temp , withPadding : 100)
        
    }
    func drawPath(startLocation: CLLocation,endLocation: CLLocation){
        let origin = "\(startLocation.coordinate.latitude),\(startLocation.coordinate.longitude)"
        let destination = "\(endLocation.coordinate.latitude),\(endLocation.coordinate.longitude)"
//        let url = "https://maps.googleapis.com/maps/api/directions/json?origin=\(origin)&destination=\(destination)&mode=driving&key=\(GlobalConstants.apiKeyGoogle)"

        let url = "https://maps.googleapis.com/maps/api/directions/json?origin=\(origin)&destination=\(destination)&mode=driving&key=AIzaSyAMcdkEdP7OtEi60XUoL5iHeeMvOhB07_4"
        
        self.getRoutes(url)
    }
    func didTapFitBounds(withMarkers markers: NSMutableArray , withPadding : Int) {
        var bounds = GMSCoordinateBounds()
        
        for i in 0..<markers.count{
            let markerHere : GMSMarker = (markers[i] as? GMSMarker)!
            bounds = bounds.includingCoordinate(markerHere.position)
        }
        
        vw_MapGoogle.animate(with: GMSCameraUpdate.fit(bounds, withPadding: CGFloat(withPadding)))
        vw_MapGoogle.animate(toViewingAngle: 0)
    }

    // MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any){
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btn_Confirm(_ sender:Any){
        if str_Complete == "1"{
            self.postCompleted()
        }else{
            //Job already confirmed or not
            if get_Data.str_Customer_job_status == "0"{
                self.postConformation()
            }
        }
    }
    
    
    //MARK: - Get/Post Method -
    func getRoutes(_ url:String) {
        
        let strURL = url
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [:]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "mapRoute"
        webHelper.methodType = "get"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.indicatorShowOrHide = false
        webHelper.startDownload()
    }
    
    func postConformation() {
        
        let strURL = "\(GlobalConstants.BaseURL)customer/job/confirm"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "job_id" : get_Data.str_Id,
            "type" : "1",
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "confirm"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlertDefault = true
        webHelper.serviceWithAlertErrorMessage = true
        webHelper.indicatorShowOrHide = true
        webHelper.startDownload()
    }
    
    func postCompleted(){

        let strURL = "\(GlobalConstants.BaseURL)customer/job/complete"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "job_id" : get_Data.str_Id,
            "type" : "2",
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "complete"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = true
        webHelper.indicatorShowOrHide = true
        webHelper.startDownload()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

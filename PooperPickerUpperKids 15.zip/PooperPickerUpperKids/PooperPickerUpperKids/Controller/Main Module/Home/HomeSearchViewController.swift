//
//  HomeSearchViewController.swift
//  PooperPickerUpperKids
//
//  Created by Apple on 21/09/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import EmptyDataSet_Swift
import ViewAnimator


class HomeSearchViewController: UIViewController {

    @IBOutlet weak var vw_Header : UIView!
    @IBOutlet weak var vw_HeaderSub : UIView!
    
    @IBOutlet var tf_Search : UITextField!
    
    private let animations = [AnimationType.from(direction: .bottom, offset: 30.0)]
    
    @IBOutlet var tbl_Main : UITableView!
    
    var arr_Main : NSMutableArray! = []
    
    var int_CountLoad: Int = 0
    var str_Search: String = ""
    
    //Bool Declaration
    var bool_Load: Bool = false
    var bool_ViewWill: Bool = false
    var bool_SearchMore: Bool = true
    var viewdidload: Bool = false
    
    //Refresh Controller
    var refresh_Item: UIRefreshControl?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()
        viewdidload = true
        
        self.tf_Search.becomeFirstResponder()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if viewdidload == false{
            int_CountLoad = GlobalConstants.int_LoadMax
            bool_ViewWill = true
            bool_SearchMore = true
            
            arr_Main = []
            self.Post_CustomerListing(count : int_CountLoad)
        }
        viewdidload = false
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //MARK: - Scrollview Delegate -
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        view.endEditing(true)
        if scrollView == tbl_Main{
            if tbl_Main.contentSize.height <= tbl_Main.contentOffset.y + tbl_Main.frame.size.height && tbl_Main.contentOffset.y >= 0 {
                if bool_Load == false && arr_Main.count != 0 {
                    self.Post_CustomerListing(count: int_CountLoad + GlobalConstants.int_LoadMax)
                }
            }
        }
    }
    
    
    //MARK: - Other Method -
    func commanMethod(){
        
        //Refresh Controller
        refresh_Item = UIRefreshControl()
        refresh_Item?.addTarget(self, action: #selector(self.refreshItem), for: .valueChanged)
        tbl_Main.addSubview(refresh_Item!)
        
        tbl_Main.emptyDataSetSource = self
        tbl_Main.emptyDataSetDelegate = self
        
        vw_Header.frame = CGRect(x: 0, y: 0, width: GlobalConstants.windowWidth - 100, height: 35)
        vw_HeaderSub.frame = CGRect(x: 0, y: 0, width: GlobalConstants.windowWidth - 120, height: 35)
        
        //Text change method in textfield
        tf_Search.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        UITextField.appearance().tintColor = GlobalConstants.appColor
    }
    @objc func refreshItem(_ refresh: UIRefreshControl) {
        if bool_Load == false {
            int_CountLoad = GlobalConstants.int_LoadMax
            bool_ViewWill = true
            bool_SearchMore = true
            
            self.Post_CustomerListing(count:int_CountLoad)
        }else{
            refresh_Item?.endRefreshing()
        }
    }
    func completedServiceCalling(){
        refresh_Item?.endRefreshing()
        bool_Load = false
        
        tbl_Main.reloadData()
        
        if bool_ViewWill == true{
            UIView.animate(views: self.tbl_Main.visibleCells, animations: animations, completion: {
            })
            bool_ViewWill = false
        }
    }
    @objc func textFieldDidChange(textField: UITextField){
        if (textField.text?.count)! > 2{
            str_Search = tf_Search.text!
            NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(changeText), object: nil)
            self.perform(#selector(changeText), with: nil, afterDelay: 0.5)
        }else{
            str_Search = ""
            
            int_CountLoad = GlobalConstants.int_LoadMax
            bool_ViewWill = true
            bool_SearchMore = true
            
            arr_Main = []
            tbl_Main.reloadData()
        }
    }
    @objc func changeText(){
        int_CountLoad = GlobalConstants.int_LoadMax
        bool_ViewWill = true
        bool_SearchMore = true
        
        arr_Main = []
        self.Post_CustomerListing(count: int_CountLoad)
    }
    
    //MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any){
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btn_Add(_ sender:Any){
        
    }
    
    // MARK: - Get/Post Method -
    func Post_CustomerListing(count: Int){
//        I wiss you, Your team and iCoderz solutions nothing but success for feature.
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)comman/search"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "skip" : "\(count - GlobalConstants.int_LoadMax)",
            "total" : "\(GlobalConstants.int_LoadMax)",
            "search" : str_Search,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "search"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.indicatorShowOrHide = false
        
        if bool_SearchMore == true{
            bool_Load = true
            webHelper.startDownload()
        }
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}

// MARK: - Table Delegate -
extension HomeSearchViewController : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr_Main.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return UITableViewAutomaticDimension
    }
    public func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 85
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cellIdentifier : String = "cell"
        
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for:indexPath as IndexPath) as! ListMyViewCollectioncell
        
        let obj = arr_Main[indexPath.row] as! GlobalObject
        cell.lbl_Tital.text = obj.str_Customer_Title
        cell.lbl_Address.text = obj.str_Customer_JobType
        
        //Manage font
        cell.lbl_Tital.font = UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFont(font: 16))
        cell.lbl_Address.font = UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFont(font: 14))
        
        return cell;
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let obj = arr_Main[indexPath.row] as! GlobalObject
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        if obj.str_Customer_JobType == "Customer"{
            let view = storyboard.instantiateViewController(withIdentifier: "AddCustomersViewController") as! AddCustomersViewController
            view.get_Data = obj
            self.navigationController?.pushViewController(view, animated: true)
        }else if obj.str_Customer_JobType == "Prospect"{
            let view = storyboard.instantiateViewController(withIdentifier: "AddProspectiveCustomersViewController") as! AddProspectiveCustomersViewController
            view.get_Data = obj
            self.navigationController?.pushViewController(view, animated: true)
        }else{
            let view = storyboard.instantiateViewController(withIdentifier: "AddContactViewController") as! AddContactViewController
            view.get_Data = obj
            self.navigationController?.pushViewController(view, animated: true)
        }
    }
}


extension HomeSearchViewController : EmptyDataSetSource, EmptyDataSetDelegate
{
    func emptyDataSetShouldDisplay(_ scrollView: UIScrollView) -> Bool {
        
        if arr_Main.count == 0 && bool_Load == false{
            return true
        }
        return false
    }
    
    //Header image show in list
    func image(forEmptyDataSet scrollView: UIScrollView) -> UIImage? {
        
        return UIImage.init(named: "img_PlaceHeader")
    }
    
    //set tital in list
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        
        var text: String?
        var font: UIFont?
        var textColor: UIColor?
        
        textColor = UIColor.lightGray
        
        text = "No results found"
        
        font = UIFont(name: GlobalConstants.kFontRegular, size:GlobalConstants.kFontRatio*14.0)
        
        if text == nil {
            return nil
        }
        var attributes: [NSAttributedStringKey: Any] = [:]
        if font != nil {
            attributes[NSAttributedStringKey.font] = font!
        }
        if textColor != nil {
            attributes[NSAttributedStringKey.foregroundColor] = textColor
        }
        
        textColor = UIColor.clear
        
        return NSAttributedString.init(string: text!, attributes: attributes)
    }
}


extension HomeSearchViewController : UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
//        int_CountLoad = GlobalConstants.int_LoadMax
//        bool_ViewWill = true
//        bool_SearchMore = true
//
//        arr_Main = []
//        self.Post_CustomerListing(count: int_CountLoad)
        
        return true
    }
}



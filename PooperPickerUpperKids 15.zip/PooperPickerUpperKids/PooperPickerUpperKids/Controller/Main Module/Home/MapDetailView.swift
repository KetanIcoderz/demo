//
//  MapDetailView.swift
//  PooperPickerUpperKids
//
//  Created by Apple on 31/07/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import GoogleMaps

class MapDetailView: UIViewController {

    @IBOutlet var vw_MapGoogle : GMSMapView!
    
    var arr_Marker : NSMutableArray! = []
    var arr_Main : NSMutableArray! = []
    
    var str_Complete : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "mapmyschedule"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(viewWillAppear(_:)), name: NSNotification.Name(rawValue: "mapmyschedule"), object: nil)
    }

    override func viewWillAppear(_ animated: Bool) {
        self.commanMethod()
        self.manageMapView()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewDidAppear(_ animated: Bool) {
        
        self.view.layoutIfNeeded()
    }
    //MARK: - Other Method -
    func commanMethod(){
        
        //Manage Google Map
        vw_MapGoogle.settings.myLocationButton = true
        vw_MapGoogle.delegate = self
        vw_MapGoogle.isMyLocationEnabled = true
        vw_MapGoogle.clear()
        
        //Set up move to my location
        let arr_Temp : NSMutableArray = []
        
        for _ in 0..<1 {
            var c2D: CLLocationCoordinate2D = CLLocationCoordinate2DMake(currentLocation!.coordinate.latitude, currentLocation!.coordinate.longitude)
            
            let marker = GMSMarker(position: c2D)
            marker.title = "Your Location"
            marker.snippet = ""
            marker.isFlat = false
            marker.map = vw_MapGoogle
            marker.icon = UIImage(named: "icon_MapPin")
            marker.tracksViewChanges = false
            marker.map = vw_MapGoogle
            arr_Temp.add(marker)
        }
        self.didTapFitBounds(withMarkers: arr_Temp , withPadding : 100)
        vw_MapGoogle.animate(toZoom: 14)
    }
    
    func manageMapView(){
        
        arr_Marker = []
        
        //My location
        var c2D: CLLocationCoordinate2D = CLLocationCoordinate2DMake(currentLocation!.coordinate.latitude, currentLocation!.coordinate.longitude)
        
        let marker = GMSMarker(position: c2D)
        marker.title = "Your Location"
        marker.snippet = ""
        marker.isFlat = false
        marker.map = vw_MapGoogle
        marker.icon = UIImage(named: "icon_MapPin")
        marker.tracksViewChanges = false
        marker.map = vw_MapGoogle
        arr_Marker.add(marker)
        
        for count in 0..<arr_Main.count {
            let obj: GlobalObject = arr_Main[count] as! GlobalObject
            var c2D: CLLocationCoordinate2D = CLLocationCoordinate2DMake(currentLocation!.coordinate.latitude, currentLocation!.coordinate.longitude)
            
            c2D.latitude = CLLocationDegrees(Float(obj.str_Customer_Lat)!)
            c2D.longitude = CLLocationDegrees(Float(obj.str_Customer_Long)!)
            
            let marker = GMSMarker(position: c2D)
            marker.title = obj.str_Customer_Title
            marker.snippet = ""
            marker.isFlat = false
            marker.map = vw_MapGoogle
            marker.icon = UIImage(named: "icon_MapPin")
            marker.tracksViewChanges = false
            marker.userData = "\(count)"
            marker.map = vw_MapGoogle
            arr_Marker.add(marker)
        }
        
        self.didTapFitBounds(withMarkers: arr_Marker, withPadding: 100)
    }
    
    func didTapFitBounds(withMarkers markers: NSMutableArray, withPadding : Int) {
        var bounds = GMSCoordinateBounds()
        
        for i in 0..<markers.count{
            let markerHere : GMSMarker = (markers[i] as? GMSMarker)!
            bounds = bounds.includingCoordinate(markerHere.position)
        }
        
        vw_MapGoogle.animate(with: GMSCameraUpdate.fit(bounds, withPadding: CGFloat(withPadding)))
        vw_MapGoogle.animate(toViewingAngle: 0)
    }
    
    //MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any){
        self.navigationController?.popViewController(animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}


//MARK: - MapView Delegate -
extension MapDetailView : GMSMapViewDelegate{
    func mapView(_ mapView: GMSMapView, didTapInfoWindowOf marker: GMSMarker) {
        //Check for locatin is my or not
        if marker.userData != nil{
            let obj: GlobalObject = arr_Main[Int(marker.userData as! String)!] as! GlobalObject
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let view = storyboard.instantiateViewController(withIdentifier: "ConfrimArrivalViewController") as! ConfrimArrivalViewController
            view.get_Data = obj
            view.str_Complete = str_Complete
            self.navigationController?.pushViewController(view, animated: true)
        }
    }
}


//
//  MyScheduleViewController.swift
//  PooperPickerUpperKids
//
//  Created by Apple on 31/07/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit

class MyScheduleViewController: UIViewController {

    //Collectionview declaration
    @IBOutlet weak var cv_HeaderSelection : UICollectionView!
    
    //Other declaationdeclaration
    var indexpath_Header : NSIndexPath = NSIndexPath(row: 0, section: 0)
    var arr_Header = ["List View","Map View"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    //MARK: - Page view controller -
    var MySchedulePageViewController: MySchedulePageViewController? {
        didSet {
            MySchedulePageViewController?.tutorialDelegate = self
        }
    }
    
    // MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any){
        self.navigationController?.popViewController(animated: true)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let MyScheduleViewController = segue.destination as? MySchedulePageViewController {
            self.MySchedulePageViewController = MyScheduleViewController
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}



//MARK: - Pageview controller Delegate -
extension MyScheduleViewController: MySchedulePageViewControllerDelegate {
    
    func MySchedulePageViewController(_ MySchedulePageViewController: MySchedulePageViewController, didUpdatePageCount count: Int) {
        
    }
    func MySchedulePageViewController(_ MySchedulePageViewController: MySchedulePageViewController,
                                didUpdatePageIndex index: Int) {
        indexpath_Header = NSIndexPath(row: index, section: 0)
        self.cv_HeaderSelection.reloadData()
        
        MySchedulePageViewController.scrollToViewController(index: index)
        //        cv_Main_TabBar.reloadData()
    }
    
}

//MARK: - Collection View -
extension MyScheduleViewController : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return arr_Header.count
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: CGFloat(GlobalConstants.windowWidth/2), height: collectionView.frame.size.height)
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell  = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        
        let lbl_Title : UILabel = cell.viewWithTag(100) as! UILabel
        let img_Bottom : UIImageView = cell.viewWithTag(101) as! UIImageView
        let img_Icon : UIImageView = cell.viewWithTag(102) as! UIImageView
        
        lbl_Title.text = arr_Header[indexPath.row]
        
        //Manage font
        lbl_Title.font = UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFont(font: 16))
        
        lbl_Title.textColor = UIColor(red: 203/255, green: 203/255, blue: 203/255, alpha: 1.0)
        img_Bottom.isHidden = true
        
        if indexPath.row == 0 {
            img_Icon.image = UIImage(named: "icon_List_UnSelected")
            if indexpath_Header.row == indexPath.row{
                img_Icon.image = UIImage(named: "icon_List_Selected")
                img_Bottom.isHidden = false
                 lbl_Title.textColor = GlobalConstants.appColor
            }
        }else if indexPath.row == 1 {
            img_Icon.image = UIImage(named: "icon_Map_UnSelected")
            if indexpath_Header.row == indexPath.row{
                img_Icon.image = UIImage(named: "icon_Map_Selected")
                img_Bottom.isHidden = false
                lbl_Title.textColor = GlobalConstants.appColor
            }
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        MySchedulePageViewController?.scrollToPreviewsViewController(indexCall:indexPath.row)
        indexpath_Header = indexPath as NSIndexPath
        cv_HeaderSelection.reloadData()
    }
}



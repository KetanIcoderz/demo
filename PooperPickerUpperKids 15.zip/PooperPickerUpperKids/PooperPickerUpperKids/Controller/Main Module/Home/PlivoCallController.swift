//
//  PlivoCallController.swift
//  SwiftVoiceCallingApp
//
//  Created by Siva  on 24/05/17.
//  Copyright © 2017 Plivo. All rights reserved.
//

import UIKit
import CallKit
import AVFoundation
import PlivoVoiceKit
import ReachabilitySwift
import SwiftMessages
import GoogleMaps
import ViewAnimator

protocol PlivoCallControllerProtocol : class {
    func comingCall()
    func callEnd()
}

class PlivoCallController: UIViewController, CXProviderDelegate, CXCallObserverDelegate, JCDialPadDelegate, PlivoEndpointDelegate {

    
    weak var delegate : PlivoCallControllerProtocol? = nil
    
    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var callerNameLabel: UILabel!
    @IBOutlet weak var callStateLabel: UILabel!
    @IBOutlet weak var dialPadView: UIView!
    @IBOutlet weak var callButton: UIButton!
    @IBOutlet weak var hideButton: UIButton!
    @IBOutlet weak var muteButton: UIButton!
    @IBOutlet weak var holdButton: UIButton!
    @IBOutlet weak var keypadButton: UIButton!
    @IBOutlet weak var speakerButton: UIButton!
    @IBOutlet weak var activeCallImageView: UIImageView!

    var pad: JCDialPad?
    var timer: MZTimerLabel?
    var callObserver: CXCallObserver?
    
    var isItUserAction: Bool = false
    var isItGSMCall: Bool = false
    
    var outCall: PlivoOutgoing?
    var incCall: PlivoIncoming?
    
    var isSpeakerOn: Bool = false

    let reachability = Reachability()!
    
    var strCall : String = ""
    var strPlace : String = ""
    
    
    //Home View
    @IBOutlet weak var vw_Header : UIView!
    @IBOutlet weak var vw_HeaderSub : UIView!
    @IBOutlet weak var vw_HomeView : UIView!
    @IBOutlet weak var vw_Place : UIView!
    
    @IBOutlet var pg_Header : UIPageControl!
    
    @IBOutlet var cv_Header : UICollectionView!
    
    @IBOutlet var vw_MapGoogle : GMSMapView!
    
    @IBOutlet var btn_CityName : UIBarButtonItem!
    
    var arr_Marker : NSMutableArray! = []
    var arr_Main : NSMutableArray! = []
    var arr_Banner : NSMutableArray! = []
    
    var timer_Adverticement = Timer()
    var timer_Value : Int = 0
    
    override func viewDidLoad() {
        

        super.viewDidLoad()

        if strPlace == "1"{
            vw_Place.isHidden = false
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                self.vw_Place.isHidden = true
            })
        }
        
        vw_Call = self
        vw_Call_Nav = self.navigationController!
        
        self.navigationController?.isNavigationBarHidden = true
        
        if vw_HomeView != nil{
            vw_HomeView.isHidden = true
            
            if str_Home_Present == "1"{
                self.navigationController?.isNavigationBarHidden = false
                vw_HomeView.isHidden = false
                
                //Home View
                self.Post_Banner()
//                self.Get_CommanAPI()
                
                NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "reloadhomescreen"), object: nil)
                NotificationCenter.default.addObserver(self, selector: #selector(navigationSet), name: NSNotification.Name(rawValue: "reloadhomescreen"), object: nil)
            }
        }
        //
        
        
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: {
            self.tabBarController?.tabBar.isHidden = true
        })
        
        // Do any additional setup after loading the view.
        
        //Dial pad to enter phone number or to Enter DTMF Text
        pad = JCDialPad(frame: dialPadView.bounds)
        pad?.buttons = JCDialPad.defaultButtons()
        pad?.delegate = self
        pad?.showDeleteButton = true
        pad?.formatTextToPhoneNumber = false
//        pad?.backgroundColor = UIColor(red: 57/256.0, green: 54.0/256.0, blue: 217/256.0, alpha: 1.0)
        pad?.backgroundColor = UIColor.white
        pad?.digitsTextField.textColor = UIColor.black
//        dialPadView.backgroundColor = UIColor(red: 57/256.0, green: 54.0/256.0, blue: 217/256.0, alpha: 1.0)
        dialPadView.backgroundColor = UIColor.white
        dialPadView.addSubview(pad!)
        timer = MZTimerLabel(label: callStateLabel, andTimerType: MZTimerLabelTypeStopWatch)
        timer?.timeFormat = "HH:mm:ss"
        CallKitInstance.sharedInstance.callKitProvider?.setDelegate(self, queue: DispatchQueue.main)
        CallKitInstance.sharedInstance.callObserver?.setDelegate(self, queue: DispatchQueue.main)
        //Add Call Interruption observers
        addObservers()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        Phone.sharedInstance.setDelegate(self)
        hideActiveCallView()
        pad?.buttons = JCDialPad.defaultButtons()
        pad?.layoutSubviews()
        
        if strCall != ""{
            pad?.digitsTextField.text = strCall
            self.userNameTextField.text = strCall
            self.callButtonTapped(vw_Call.callButton)
            strCall = ""
        }
        
         if vw_HomeView != nil{
            if str_Home_Present == "1"{
                arr_Marker = []
                arr_Main = []
                self.commanMethod()
                self.Post_TodayAppointment()
                self.Get_CommanAPI()
                self.navigationController?.isNavigationBarHidden = false
                vw_HomeView.isHidden = false
                
            }else{
                
                self.navigationController?.isNavigationBarHidden = true
                vw_HomeView.isHidden = true
            }
        }
        
        timer_Adverticement.invalidate()
        timer_Adverticement = Timer.scheduledTimer(timeInterval: 3.0, target: self, selector: #selector(reloadHeder), userInfo: nil, repeats: true)
        
        NaviationManager()
    }
    override func viewDidLayoutSubviews() {
        if str_Home_Present == "1"{
            self.commanMethod()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        UserDefaults.standard.set(false, forKey: "Keypad Enabled")
        UserDefaults.standard.synchronize()
        pad?.layoutSubviews()
        pad?.digitsTextField.text = ""
        pad?.showDeleteButton = false
        pad?.rawText = ""
        muteButton.isEnabled = false
        holdButton.isEnabled = false
        keypadButton.isEnabled = false
        hideActiveCallView()
        
        timer_Adverticement.invalidate()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var prefersStatusBarHidden : Bool {
        return true
    }
    
    func addObservers() {
        // add interruption handler
        NotificationCenter.default.addObserver(self, selector: #selector(PlivoCallController.handleInterruption), name: NSNotification.Name.AVAudioSessionInterruption, object: AVAudioSession.sharedInstance())
        // we don't do anything special in the route change notification
        NotificationCenter.default.addObserver(self, selector: #selector(PlivoCallController.handleRouteChange), name: NSNotification.Name.AVAudioSessionRouteChange, object: AVAudioSession.sharedInstance())
        // if media services are reset, we need to rebuild our audio chain
        NotificationCenter.default.addObserver(self, selector: #selector(PlivoCallController.handleMediaServerReset), name: NSNotification.Name.AVAudioSessionMediaServicesWereReset, object: AVAudioSession.sharedInstance())
        NotificationCenter.default.addObserver(self, selector: #selector(PlivoCallController.appWillTerminate), name: NSNotification.Name.UIApplicationWillTerminate, object: nil)
        
        //To check Network Reachability
        NotificationCenter.default.addObserver(self, selector: #selector(reachabilityChanged),name: ReachabilityChangedNotification,object: reachability)
        do{
            try reachability.startNotifier()
        }catch{
            print("could not start reachability notifier")
        }
    }
    
    @objc func reachabilityChanged(note: Notification) {
        
        let reachability = note.object as! Reachability
        
        if reachability.isReachable {
            if reachability.isReachableViaWiFi {
                print("Reachable via WiFi")
            } else {
                print("Reachable via Cellular")
            }
        } else {
            print("Network not reachable")
            
//            UtilClass.makeToast(kNOINTERNETMSG)
            messageBar.MessageShow(title: kNOINTERNETMSG as NSString, alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)

            self.isItUserAction = true
            if CallKitInstance.sharedInstance.callUUID != nil{
                self.performEndCallAction(with: CallKitInstance.sharedInstance.callUUID!)
            }

        }
    }
    
    //To unregister with SIP Server
    
    func unRegisterSIPEndpoit() {
        Phone.sharedInstance.logout()
    }
    
    func manageCalling(){
            callStateLabel.text = "Calling..."
            callerNameLabel.text = pad?.digitsTextField.text
            unhideActiveCallView()
            var handle: String
            if !(pad?.digitsTextField.text == "") {
                handle = (pad?.digitsTextField.text!)!
            }
            else if !(userNameTextField.text == "") {
                handle = userNameTextField.text!
            }
            else {
//                UtilClass.makeToast(kINVALIDSIPENDPOINTMSG)
                 messageBar.MessageShow(title: "Please enter phone number", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
                return
            }

            userNameTextField.text = ""
            pad?.digitsTextField.text = ""
            pad?.rawText = ""
            CallKitInstance.sharedInstance.callUUID = UUID()
            /* outgoing call */
            performStartCallAction(with: CallKitInstance.sharedInstance.callUUID!, handle: handle)

            self.speakerButton.setImage(UIImage(named: "Speaker.png"), for: .normal)
            Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(next12312), userInfo: nil, repeats: false)
    }
    // MARK: - PlivoSDK Delegate Methods

    /**
     * onLogin delegate implementation.
     */
    func onLogin() {
        
        DispatchQueue.main.async(execute: {() -> Void in
            
            UtilClass.hideToastActivity()
//            UtilClass.makeToast(kLOGINSUCCESS)
            let appDelegate: AppDelegate? = (UIApplication.shared.delegate as? AppDelegate)
            appDelegate?.voipRegistration()
            
        })
        print("Ready to make a call");
    }
    
    /**
     * onLoginFailed delegate implementation.
     */
    func onLoginFailed() {
        DispatchQueue.main.async(execute: {() -> Void in
//            UtilClass.makeToast("408:Timedout Error")
            messageBar.MessageShow(title: "408:Timedout Error", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
            
            UtilClass.hideToastActivity()
            print("%@",kLOGINFAILMSG);
            UtilClass.setUserAuthenticationStatus(false)
            UserDefaults.standard.removeObject(forKey: kUSERNAME)
            UserDefaults.standard.removeObject(forKey: kPASSWORD)
            UserDefaults.standard.synchronize()
            let _mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
//            let loginVC: LoginViewController? = _mainStoryboard.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController
//            Phone.sharedInstance.setDelegate(loginVC!)
//            let _appDelegate: AppDelegate? = (UIApplication.shared.delegate as? AppDelegate)
//            _appDelegate?.window?.rootViewController = loginVC
        })
    }
    
    /**
     * onLogout delegate implementation.
     */
    func onLogout() {
        
        DispatchQueue.main.async(execute: {() -> Void in
            
            if (CallKitInstance.sharedInstance.callUUID != nil){
                self.performEndCallAction(with: CallKitInstance.sharedInstance.callUUID!)
            }
            
            UtilClass.setUserAuthenticationStatus(false)
            UserDefaults.standard.removeObject(forKey: kUSERNAME)
            UserDefaults.standard.removeObject(forKey: kPASSWORD)
            UserDefaults.standard.synchronize()
            UtilClass.hideToastActivity()
            
            //Store data nill value when user logout
            let defaults = UserDefaults.standard
            defaults.removeObject(forKey: "userobject")
            defaults.synchronize()
            
            //Move to home view in when app is launch
            str_LogoutSuccess = "1"
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let nav: UINavigationController! = (appDelegate.window?.rootViewController as! UINavigationController)
            let view : UIViewController = nav.viewControllers[0]
            nav.popToViewController(view, animated: true)
        })
    }

    /**
     * onIncomingCall delegate implementation
     */
    
    func onIncomingCall(_ incoming: PlivoIncoming) {
        
        str_Home_Present = "0"
         if vw_HomeView != nil{
            vw_HomeView.isHidden = true
        }
        self.delegate?.comingCall()
        
        self.navigationController?.isNavigationBarHidden = false
        
        switch AVAudioSession.sharedInstance().recordPermission()
        {
            case AVAudioSessionRecordPermission.granted:
               
                print("Permission granted")
                
                DispatchQueue.main.async(execute: {() -> Void in
                    self.tabBarController?.selectedViewController = self.tabBarController?.viewControllers?[0]
                    self.userNameTextField.text = ""
                    self.pad?.digitsTextField.text = ""
                    self.pad?.rawText = ""
                    self.callerNameLabel.text = incoming.fromUser
                    self.callStateLabel.text = "Incoming call..."
                })
                CallKitInstance.sharedInstance.callKitProvider?.setDelegate(self, queue: DispatchQueue.main)
                CallKitInstance.sharedInstance.callObserver?.setDelegate(self, queue: DispatchQueue.main)
                CallInfo.addCallsInfo(callInfo:[incoming.fromUser,Date()])
                
                //Added by Siva on Tue 11th, 2017
                if !(incCall != nil) && !(outCall != nil) {
                    /* log it */
                    print("Incoming Call from %@", incoming.fromContact);
                    /* assign incCall var */
                    incCall = incoming
                    outCall = nil
                    CallKitInstance.sharedInstance.callUUID = UUID()
                    reportIncomingCall(from: incoming.fromUser, with: CallKitInstance.sharedInstance.callUUID!)
                }
                else {
                    /*
                     * Reject the call when we already have active ongoing call
                     */
                    incoming.reject()
                    return
                }
                break
            
            case AVAudioSessionRecordPermission.denied:
                print("Pemission denied")
//                UtilClass.makeToast("Please go to settings and turn on Microphone service for incoming/outgoing calls.")
                messageBar.MessageShow(title: "Please go to settings and turn on Microphone service for incoming/outgoing calls.", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
                
                incoming.reject()
                break
            
            case AVAudioSessionRecordPermission.undetermined:
                print("Request permission here")
                break
            
            default:
                break
        }
        
    }
    
    /**
     * onIncomingCallHangup delegate implementation.
     */
    
    func onIncomingCallHangup(_ incoming: PlivoIncoming) {
        
        let Delay = DispatchTime.now() + 1.0
        DispatchQueue.main.asyncAfter(deadline: Delay) {
//            self.navigationController?.popViewController(animated: false)
            self.delegate?.callEnd()
        }
        
        print("- Incoming call ended");
        if (incCall != nil) {
            self.isItUserAction = true
            performEndCallAction(with: CallKitInstance.sharedInstance.callUUID!)
            incCall = nil 
        }
    }
    
    /**
     * onIncomingCallRejected implementation.
     */
    func onIncomingCallRejected(_ incoming: PlivoIncoming) {
        let Delay = DispatchTime.now() + 1.0
        DispatchQueue.main.asyncAfter(deadline: Delay) {
//            self.navigationController?.popViewController(animated: false)
            self.delegate?.callEnd()
        }
        
        /* log it */
        self.isItUserAction = true
        performEndCallAction(with: CallKitInstance.sharedInstance.callUUID!)
        incCall = nil
    }
    
    /**
     * onOutgoingCallAnswered delegate implementation
     */
    func onOutgoingCallAnswered(_ call: PlivoOutgoing) {
       
        str_Home_Present = "0"
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0, execute: {
             if self.vw_HomeView != nil{
                self.vw_HomeView.isHidden = true
                self.navigationController?.isNavigationBarHidden = true
            }
        })
        
        print("Call id in Answerd is:")
        print(call.callId)
        
        print("- On outgoing call answered");
        DispatchQueue.main.async(execute: {() -> Void in
            self.muteButton.isEnabled = true
            self.keypadButton.isEnabled = true
            self.holdButton.isEnabled = true
            self.pad?.digitsTextField.isHidden = true
            if !(self.timer != nil) {
                self.timer = MZTimerLabel(label: self.callStateLabel, andTimerType: MZTimerLabelTypeStopWatch)
                self.timer?.timeFormat = "HH:mm:ss"
                self.timer?.start()
            }
            else {
                self.timer?.start()
            }
        })
    }
    
    /**
     * onOutgoingCallHangup delegate implementation.
     */
    
    func onOutgoingCallHangup(_ call: PlivoOutgoing) {
        
        print("Call id in Hangup is:")
        print(call.callId)

        self.isItUserAction = true

        performEndCallAction(with: CallKitInstance.sharedInstance.callUUID!)
    }
    
    func onCalling(_ call: PlivoOutgoing) {
        
        print("Call id in onCalling is:")
        print(call.callId)

        print("On Caling");
    }
    
    /**
     * onOutgoingCallRinging delegate implementation.
     */
    func onOutgoingCallRinging(_ call: PlivoOutgoing) {
        
        print("Call id in Ringing is:")
        print(call.callId)

        DispatchQueue.main.async(execute: {() -> Void in
            self.callStateLabel.text = "Ringing..."
        })
    }
    
    /**
     * onOutgoingCallrejected delegate implementation.
     */
    func onOutgoingCallRejected(_ call: PlivoOutgoing) {
        
        print("Call id in Rejected is:")
        print(call.callId)

        self.isItUserAction = true

        performEndCallAction(with: CallKitInstance.sharedInstance.callUUID!)
    }
    
    /**
     * onOutgoingCallInvalid delegate implementation.
     */
    func onOutgoingCallInvalid(_ call: PlivoOutgoing) {
        
        print("Call id in Invalid is:")
        print(call.callId)

        self.isItUserAction = true

        performEndCallAction(with: CallKitInstance.sharedInstance.callUUID!)
    }
    
    
    // MARK: - CallKit Actions
    func performStartCallAction(with uuid: UUID, handle: String) {
        
        if UtilClass.isNetworkAvailable(){
            
            switch AVAudioSession.sharedInstance().recordPermission() {
                
            case AVAudioSessionRecordPermission.granted:
                print("Permission granted");
                hideActiveCallView()
                unhideActiveCallView()
                print("Outgoing call uuid is: %@", uuid);
                CallKitInstance.sharedInstance.callKitProvider?.setDelegate(self, queue: DispatchQueue.main)
                CallKitInstance.sharedInstance.callObserver?.setDelegate(self, queue: DispatchQueue.main)
                print("provider:performStartCallActionWithUUID:");
                if uuid == nil || handle == nil {
                    print("UUID or Handle nil");
                    return
                }
                
                CallInfo.addCallsInfo(callInfo:[handle,Date()])

                let newHandleString: String = addCountryCode(str_Get: handle)
                
                let callHandle = CXHandle(type: .generic, value: newHandleString)
                let startCallAction = CXStartCallAction(call: uuid, handle: callHandle)
                let transaction = CXTransaction(action:startCallAction)
                CallKitInstance.sharedInstance.callKitCallController?.request(transaction, completion: {(_ error: Error?) -> Void in
                    if error != nil {
                        print("StartCallAction transaction request failed: %@", error.debugDescription);
                        DispatchQueue.main.async(execute: {() -> Void in
//                            UtilClass.makeToast(kSTARTACTIONFAILED)
                            messageBar.MessageShow(title: kSTARTACTIONFAILED as NSString, alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
                        })
                    }
                    else {
                        print("StartCallAction transaction request successful");
                        let callUpdate = CXCallUpdate()
                        callUpdate.remoteHandle = callHandle
                        callUpdate.supportsDTMF = true
                        callUpdate.supportsHolding = true
                        callUpdate.supportsGrouping = false
                        callUpdate.supportsUngrouping = false
                        callUpdate.hasVideo = false
                        DispatchQueue.main.async(execute: {() -> Void in
                            self.callerNameLabel.text = handle
                            self.callStateLabel.text = "Calling..."
                            self.unhideActiveCallView()
                            CallKitInstance.sharedInstance.callKitProvider?.reportCall(with: uuid, updated: callUpdate)
                        })
                    }
                })
                break
            case AVAudioSessionRecordPermission.denied:
//                UtilClass.makeToast("Please go to settings and turn on Microphone service for incoming/outgoing calls.")
                messageBar.MessageShow(title: "Please go to settings and turn on Microphone service for incoming/outgoing calls.", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
                break
            case AVAudioSessionRecordPermission.undetermined:
                // This is the initial state before a user has made any choice
                // You can use this spot to request permission here if you want
                break
            default:
                break
            }
            
        }else{
            
//            UtilClass.makeToast("Please connect to internet")
            messageBar.MessageShow(title: "Please connect to internet", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }
        
    }
    
    func reportIncomingCall(from: String, with uuid: UUID) {
        
        let callHandle = CXHandle(type: .generic, value: from)
        let callUpdate = CXCallUpdate()
        callUpdate.remoteHandle = callHandle
        callUpdate.supportsDTMF = true
        callUpdate.supportsHolding = true
        callUpdate.supportsGrouping = false
        callUpdate.supportsUngrouping = false
        callUpdate.hasVideo = false
        
        CallKitInstance.sharedInstance.callKitProvider?.reportNewIncomingCall(with: uuid, update: callUpdate, completion: {(_ error: Error?) -> Void in
            if error != nil {
                print("Failed to report incoming call successfully: %@", error.debugDescription);
                //[UtilityClass makeToast:kREQUESTFAILED];
                Phone.sharedInstance.stopAudioDevice()
                if (self.incCall != nil) {
                    if self.incCall?.state != Ongoing {
                        print("Incoming call - Reject");
                        self.incCall?.reject()
                    }
                    else {
                        print("Incoming call - Hangup");
                        self.incCall?.hangup()
                    }
                    self.incCall = nil
                }
            }
            else {
                print("Incoming call successfully reported.");
                Phone.sharedInstance.configureAudioSession()
            }
        })
    }
    
    func performEndCallAction(with uuid: UUID) {
        
        DispatchQueue.main.async(execute: {() -> Void in
            
            print("performEndCallActionWithUUID: %@",uuid);

            let endCallAction = CXEndCallAction(call: uuid)
            let trasanction = CXTransaction(action:endCallAction)
            CallKitInstance.sharedInstance.callKitCallController?.request(trasanction, completion: {(_ error: Error?) -> Void in
                if error != nil {
                    print("EndCallAction transaction request failed: %@", error.debugDescription);
                    
                    DispatchQueue.main.async(execute: {() -> Void in
                        
                        Phone.sharedInstance.stopAudioDevice()
                        
                        if (self.incCall != nil) {
                            if self.incCall?.state != Ongoing {
                                print("Incoming call - Reject");
                                self.incCall?.reject()
                            }
                            else {
                                print("Incoming call - Hangup");
                                self.incCall?.hangup()
                            }
                            self.incCall = nil
                        }
                        
                        if (self.outCall != nil) {
                            print("Outgoing call - Hangup");
                            self.outCall?.hangup()
                            self.outCall = nil
                        }
                        
                        self.hideActiveCallView()
                        
//                        self.tabBarController?.tabBar.isHidden = false
                        self.tabBarController?.tabBar.isHidden = true
                        self.tabBarController?.selectedViewController = self.tabBarController?.viewControllers?[0]
                    })
                }
                else {
                    print("EndCallAction transaction request successful");
                }
            })
        })
    }

    
    // MARK: - CXCallObserverDelegate
    func callObserver(_ callObserver: CXCallObserver, callChanged call: CXCall) {
        if call == nil || call.hasEnded == true {
            print("CXCallState : Disconnected");
            self.hideActiveCallView()
            
        }
        if call.isOutgoing == true && call.hasConnected == false {
            print("CXCallState : Dialing");
        }
        if call.isOutgoing == false && call.hasConnected == false && call.hasEnded == false && call != nil {
            print("CXCallState : Incoming");
        }
        if call.hasConnected == true && call.hasEnded == false {
            str_Home_Present = "0"
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3, execute: {
                 if self.vw_HomeView != nil{
                    self.vw_HomeView.isHidden = true
                    self.navigationController?.isNavigationBarHidden = true
                }
            })
            
            print("CXCallState : Connected");
        }
    }
    
    
    // MARK: - CXProvider Handling

    func providerDidReset(_ provider: CXProvider) {
        print("ProviderDidReset");
    }
    
    func providerDidBegin(_ provider: CXProvider) {
        print("providerDidBegin");
    }
    
    func provider(_ provider: CXProvider, didActivate audioSession: AVAudioSession) {
        print("provider:didActivateAudioSession");
        Phone.sharedInstance.startAudioDevice()
    }
    
    func provider(_ provider: CXProvider, didDeactivate audioSession: AVAudioSession) {
        print("provider:didDeactivateAudioSession:");
    }
    
    func provider(_ provider: CXProvider, timedOutPerforming action: CXAction) {
        print("provider:timedOutPerformingAction:");
    }
    
    func provider(_ provider: CXProvider, perform action: CXStartCallAction) {
        print("provider:performStartCallAction:");
        Phone.sharedInstance.configureAudioSession()
        //Set extra headers
        let extraHeaders: [AnyHashable: Any] = [
            "X-PH-Header1" : "Value1",
            "X-PH-Header2" : "Value2"
        ]
        
        let dest: String = action.handle.value
        //Make the call
        outCall = Phone.sharedInstance.call(withDest: dest, andHeaders: extraHeaders)
        if (outCall != nil) {
            action.fulfill(withDateStarted: Date())
        }
        else {
            action.fail()
        }
    }
    
    func provider(_ provider: CXProvider, perform action: CXSetHeldCallAction) {
        if action.isOnHold {
            Phone.sharedInstance.stopAudioDevice()
        }
        else {
            Phone.sharedInstance.startAudioDevice()
        }
    }
    
    func provider(_ provider: CXProvider, perform action: CXSetMutedCallAction) {
        if action.isMuted {
            muteButton.setImage(UIImage(named: "Unmute.png"), for: .normal)
            if (incCall != nil) {
                incCall?.unmute()
            }
            if (outCall != nil) {
                outCall?.unmute()
            }
        }
        else {
            muteButton.setImage(UIImage(named: "MuteIcon.png"), for: .normal)
            if (incCall != nil) {
                incCall?.mute()
            }
            if (outCall != nil) {
                outCall?.mute()
            }
        }
    }
    
    func provider(_ provider: CXProvider, perform action: CXAnswerCallAction) {
        print("provider:performAnswerCallAction:");
        //Answer the call
        if (incCall != nil) {
            CallKitInstance.sharedInstance.callUUID = action.callUUID
            incCall?.answer()
        }
        outCall = nil
        action.fulfill()
        DispatchQueue.main.async(execute: {() -> Void in
            self.unhideActiveCallView()
            self.muteButton.isEnabled = true
            self.holdButton.isEnabled = true
            self.keypadButton.isEnabled = true
            if !(self.timer != nil) {
                self.timer = MZTimerLabel(label: self.callStateLabel, andTimerType: MZTimerLabelTypeStopWatch)
                self.timer?.timeFormat = "HH:mm:ss"
                self.timer?.start()
            }
            else {
                self.timer?.start()
            }
        })
    }
    
    func provider(_ provider: CXProvider, perform action: CXPlayDTMFCallAction) {
        print("provider:performPlayDTMFCallAction:");
        let dtmfDigits: String = action.digits
        if (incCall != nil) {
            incCall?.sendDigits(dtmfDigits)
        }
        if (outCall != nil) {
            outCall?.sendDigits(dtmfDigits)
        }
        action.fulfill()
    }
    
    func provider(_ provider: CXProvider, perform action: CXEndCallAction) {

        DispatchQueue.main.async(execute: {() -> Void in
            
            if !self.isItGSMCall || self.isItUserAction {
            
                print("provider:performEndCallAction:");
                
                Phone.sharedInstance.stopAudioDevice()
                if (self.incCall != nil) {
                    if self.incCall?.state != Ongoing {
                        print("Incoming call - Reject");
                        self.incCall?.reject()
                    }
                    else {
                        print("Incoming call - Hangup");
                        self.incCall?.hangup()
                    }
                    self.incCall = nil
                }
                if (self.outCall != nil) {
                    print("Outgoing call - Hangup");
                    self.outCall?.hangup()
                    self.outCall = nil
                }
                action.fulfill()
                self.isItUserAction = false
//                self.tabBarController?.tabBar.isHidden = false
                self.tabBarController?.tabBar.isHidden = true
                self.tabBarController?.selectedViewController = self.tabBarController?.viewControllers?[0]
            }
            else {
                print("GSM - provider:performEndCallAction:");
            }
        })
    }
    
    // MARK: - Handling IBActions
    @IBAction func callButtonTapped(_ sender: Any) {
        
        if UtilClass.isNetworkAvailable(){

        switch AVAudioSession.sharedInstance().recordPermission() {
            
        case AVAudioSessionRecordPermission.granted:
            
            if (!(userNameTextField.text! == "Phone Number") && !UtilClass.isEmpty(userNameTextField.text!)) || !UtilClass.isEmpty(pad!.digitsTextField.text!) || (incCall != nil) || (outCall != nil) {
                
                let img: UIImage? = (sender as AnyObject).image(for: .normal)
                let data1: NSData? = UIImagePNGRepresentation(img!) as NSData?
                
                
                if (data1?.isEqual(UIImagePNGRepresentation(UIImage(named: "MakeCall.png")!)))! {

                    self.PostXMLchange(toNumber: (pad?.digitsTextField.text)!, fromNumber: (objUser?.user_Phone_Number)!)
                }
                else if (data1?.isEqual(UIImagePNGRepresentation(UIImage(named: "EndCall.png")!)))! {

                    isItUserAction = true
                    performEndCallAction(with: CallKitInstance.sharedInstance.callUUID!)
                }
            }
            else {
//                UtilClass.makeToast(kINVALIDSIPENDPOINTMSG)
                  messageBar.MessageShow(title: "Please enter phone number", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
            }
            break
        case AVAudioSessionRecordPermission.denied:
//            UtilClass.makeToast("Please go to settings and turn on Microphone service for incoming/outgoing calls.")
              messageBar.MessageShow(title: "Please go to settings and turn on Microphone service for incoming/outgoing calls.", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
            
            break
        case AVAudioSessionRecordPermission.undetermined:
            // This is the initial state before a user has made any choice
            // You can use this spot to request permission here if you want
            break
        default:
            break
        }
        }else{
//            UtilClass.makeToast("Please connect to internet")
            messageBar.MessageShow(title: "Please connect to internet", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }
        
    }
    
    @objc func next12312(){
        let _mainStoryboard = UIStoryboard(name: "PlivoCall", bundle: nil)
        let tabBarContrler: UITabBarController? = _mainStoryboard.instantiateViewController(withIdentifier: "tabbar") as? UITabBarController
        tabBarContrler?.selectedViewController = tabBarContrler?.viewControllers?[1]
    }
    /*
     * Display Dial pad to enter DTMF text
     * Hide Mute/Unmute button
     * Hide Hold/Unhold button
     */
    @IBAction func keypadButtonTapped(_ sender: Any) {
        UserDefaults.standard.set(true, forKey: "Keypad Enabled")
        UserDefaults.standard.synchronize()
        holdButton.isHidden = true
        muteButton.isHidden = true
        keypadButton.isHidden = true
        hideButton.isHidden = false
        speakerButton.isHidden = true
        activeCallImageView.isHidden = true
        userNameTextField.text = ""
        view.bringSubview(toFront: hideButton)
        userNameTextField.isHidden = false
        userNameTextField.textColor = UIColor.white
        dialPadView.isHidden = false
//        dialPadView.backgroundColor = UIColor(red: CGFloat(0.0 / 255.0), green: CGFloat(75.0 / 255.0), blue: CGFloat(58.0 / 255.0), alpha: CGFloat(1.0))
        dialPadView.backgroundColor = UIColor.white
        dialPadView.alpha = 0.7
        pad?.buttons = JCDialPad.defaultButtons()
        pad?.layoutSubviews()
        callerNameLabel.isHidden = true
        callStateLabel.isHidden = true
    }
    
    /*
     * Hide Dial pad view
     * UnHide Mute/Unmute button
     * UnHide Hold/Unhold button
     */
    
    @IBAction func hideButtonTapped(_ sender: Any) {
        UserDefaults.standard.set(false, forKey: "Keypad Enabled")
        UserDefaults.standard.synchronize()
        holdButton.isHidden = false
        muteButton.isHidden = false
        speakerButton.isHidden = false
        keypadButton.isHidden = false
        dialPadView.isHidden = true
        hideButton.isHidden = true
        activeCallImageView.isHidden = false
        userNameTextField.isHidden = true
        userNameTextField.textColor = UIColor.white
        pad?.rawText = ""
        callerNameLabel.isHidden = false
        callStateLabel.isHidden = false
        dialPadView.backgroundColor = UIColor.white
        pad?.buttons = JCDialPad.defaultButtons()
        pad?.layoutSubviews()
    }
    
    /*
     * Mute/Unmute calls
     */
    @IBAction func muteButtonTapped(_ sender: Any) {
        let img: UIImage? = (sender as AnyObject).image(for: .normal)
        
        let data1: NSData? = UIImagePNGRepresentation(img!) as NSData?
        
        if (data1?.isEqual(UIImagePNGRepresentation(UIImage(named: "Unmute.png")!)))! {

            DispatchQueue.main.async(execute: {() -> Void in
                self.muteButton.setImage(UIImage(named: "MuteIcon.png"), for: .normal)
            })
            if (incCall != nil) {
                incCall?.mute()
            }
            if (outCall != nil) {
                outCall?.mute()
            }
        }
        else {
            
            DispatchQueue.main.async(execute: {() -> Void in
                self.muteButton.setImage(UIImage(named: "Unmute.png"), for: .normal)
            })
            if (incCall != nil) {
                incCall?.unmute()
            }
            if (outCall != nil) {
                outCall?.unmute()
            }
        }
    }
    
    /*
     * Hold/Unhold calls
     */
    @IBAction func holdButtonTapped(_ sender: Any) {
        
        let img: UIImage? = (sender as AnyObject).image(for: .normal)
        
        let data1: NSData? = UIImagePNGRepresentation(img!) as NSData?
        
        if (data1?.isEqual(UIImagePNGRepresentation(UIImage(named: "UnholdIcon.png")!)))! {

            DispatchQueue.main.async(execute: {() -> Void in
                self.holdButton.setImage(UIImage(named: "HoldIcon.png"), for: .normal)
            })
            if (incCall != nil) {
                incCall?.hold()
            }
            if (outCall != nil) {
                outCall?.hold()
            }
            Phone.sharedInstance.stopAudioDevice()
            
        }
        else {
            
            DispatchQueue.main.async(execute: {() -> Void in
                self.holdButton.setImage(UIImage(named: "UnholdIcon.png"), for: .normal)
            })
            if (incCall != nil) {
                incCall?.unhold()
            }
            if (outCall != nil) {
                outCall?.unhold()
            }
            Phone.sharedInstance.startAudioDevice()
        }
    }
    
    
    @IBAction func speakerButtonTapped(_ sender: Any) {
    
        handleSpeaker()
        
    }
    
    @IBAction func btn_Dismiss(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func handleSpeaker() {

        let audioSession = AVAudioSession.sharedInstance()
        if(isSpeakerOn)
        {
            self.speakerButton.setImage(UIImage(named: "Speaker.png"), for: .normal)
            do {
                try audioSession.overrideOutputAudioPort(AVAudioSessionPortOverride.none)
            } catch let error as NSError {
                print("audioSession error: \(error.localizedDescription)")
            }
            isSpeakerOn = false
        }
        else
        {
            self.speakerButton.setImage(UIImage(named: "Speaker_Selected.png"), for: .normal)

            /* Enable Speaker Phone mode */
            
            do {
                try audioSession.overrideOutputAudioPort(AVAudioSessionPortOverride.speaker)
            } catch let error as NSError {
                print("audioSession error: \(error.localizedDescription)")
            }
            
            isSpeakerOn = true
            
        }
    }
    
    func hideActiveCallView() {
        UIDevice.current.isProximityMonitoringEnabled = false
        callerNameLabel.isHidden = true
        callStateLabel.isHidden = true
        activeCallImageView.isHidden = true
        muteButton.isHidden = true
        keypadButton.isHidden = true
        holdButton.isHidden = true
        dialPadView.isHidden = false
        userNameTextField.isHidden = false
        userNameTextField.isEnabled = true
        pad?.digitsTextField.isHidden = false
        pad?.showDeleteButton = true
        pad?.rawText = ""
        userNameTextField.text = "Phone Number"
//        tabBarController?.tabBar.isHidden = false
        self.tabBarController?.tabBar.isHidden = true
        callButton.setImage(UIImage(named: "MakeCall.png"), for: .normal)
        timer?.reset()
        timer?.removeFromSuperview()
        timer = nil
        callStateLabel.text = "Calling..."
        dialPadView.alpha = 1.0
        dialPadView.backgroundColor = UIColor.white
        
        handleSpeaker()
    }
    
    func unhideActiveCallView() {
        UIDevice.current.isProximityMonitoringEnabled = true
        callerNameLabel.isHidden = false
        callStateLabel.isHidden = false
        activeCallImageView.isHidden = false
        muteButton.isHidden = false
        keypadButton.isHidden = false
        holdButton.isHidden = false
        dialPadView.isHidden = true
        userNameTextField.isHidden = true
        pad?.digitsTextField.isHidden = true
        pad?.showDeleteButton = false
        tabBarController?.tabBar.isHidden = true
        callButton.setImage(UIImage(named: "EndCall.png"), for: .normal)
    }
    
    
    /*
     * Handle audio interruptions
     * AVAudioSessionInterruptionTypeBegan
     * AVAudioSessionInterruptionTypeEnded
     */
    
    @objc func handleInterruption(_ notification: Notification)
    {
        
        if self.incCall != nil || self.outCall != nil
        {
            guard let userInfo = notification.userInfo,
                let interruptionTypeRawValue = userInfo[AVAudioSessionInterruptionTypeKey] as? UInt,
                let interruptionType = AVAudioSessionInterruptionType(rawValue: interruptionTypeRawValue) else {
                    return
            }
            
            switch interruptionType {
                
            case .began:
                
                self.isItGSMCall = true
                Phone.sharedInstance.stopAudioDevice()
                print("----------AVAudioSessionInterruptionTypeBegan-------------")
                break
                
            case .ended:
                
                self.isItGSMCall = false
                
                // make sure to activate the session
                let error: Error? = nil
                try? AVAudioSession.sharedInstance().setActive(true)
                if nil != error {
                    print("AVAudioSession set active failed with error")
                    Phone.sharedInstance.startAudioDevice()
                }
                print("----------AVAudioSessionInterruptionTypeEnded-------------")
                break
            }
        }
    }
    
    @objc func handleRouteChange(_ notification: Notification)
    {
        
    }
    
    @objc func handleMediaServerReset(_ notification: Notification) {
        print("Media server has reset");
        // rebuild the audio chain
        Phone.sharedInstance.configureAudioSession()
        Phone.sharedInstance.startAudioDevice()
    }
    
    /*
     * Will be called when app terminates
     * End on going calls(If any)
     */
    
    @objc func appWillTerminate() {
        let endCallAction = CXEndCallAction(call: CallKitInstance.sharedInstance.callUUID!)
        let trasanction = CXTransaction(action:endCallAction)
        
        CallKitInstance.sharedInstance.callKitCallController?.request(trasanction, completion: {(_ error: Error?) -> Void in
            if error != nil {
                print("EndCallAction transaction request failed: %@", error.debugDescription);
                
                DispatchQueue.main.async(execute: {() -> Void in
                    
                    Phone.sharedInstance.stopAudioDevice()
                    
                    if (self.incCall != nil) {
                        if self.incCall?.state != Ongoing {
                            print("Incoming call - Reject");
                            self.incCall?.reject()
                        }
                        else {
                            print("Incoming call - Hangup");
                            self.incCall?.hangup()
                        }
                        self.incCall = nil
                    }
                    
                    if (self.outCall != nil) {
                        print("Outgoing call - Hangup");
                        self.outCall?.hangup()
                        self.outCall = nil
                    }
                    
                    self.hideActiveCallView()
                    
//                    self.tabBarController?.tabBar.isHidden = false
                    self.tabBarController?.tabBar.isHidden = true
                    self.tabBarController?.selectedViewController = self.tabBarController?.viewControllers?[0]
                })
            }
            else {
                //                     Phone.sharedInstance.stopAudioDevice()
                
                //                     self.hideActiveCallView()
                //                     self.tabBarController?.tabBar.isHidden = false
                //                    self.tabBarController?.selectedViewController = self.tabBarController?.viewControllers?[0]
                //                     self.tabBarController?.selectedViewController = self.tabBarController?.viewControllers?[1]
                print("EndCallAction transaction request successful");
            }
        })
        
        performEndCallAction(with: CallKitInstance.sharedInstance.callUUID!)// Crash here
    }
    
    
    // MARK: - JCDialPadDelegates
    func dialPad(_ dialPad: JCDialPad, shouldInsertText text: String, forButtonPress button: JCPadButton) -> Bool {
        if !(incCall != nil) && !(outCall != nil) {
            userNameTextField.isEnabled = false
            userNameTextField.text = ""
        }
        return true
    }
    
    func dialPad(_ dialPad: JCDialPad, shouldInsertText text: String, forLongButtonPress button: JCPadButton) -> Bool {
        if !(incCall != nil) && !(outCall != nil) {
            userNameTextField.text = ""
            userNameTextField.isEnabled = false
        }
        return true
    }
    
    func getDtmfText(_ dtmfText: String, withAppendStirng appendText: String) {
        if (incCall != nil) {
            incCall?.sendDigits(dtmfText)
            userNameTextField.text = appendText
            userNameTextField.textColor = UIColor.white
        }
        if (outCall != nil) {
            outCall?.sendDigits(dtmfText)
            userNameTextField.text = appendText
            userNameTextField.textColor = UIColor.white
        }
    }
    
    // MARK: - Handling TextField
    /**
     * Hide keyboard after user press 'return' key
     */
    func textFieldShouldReturn(_ theTextField: UITextField) -> Bool {
        if theTextField == userNameTextField {
            theTextField.resignFirstResponder()
        }
        return true
    }
    
    /**
     * Hide keyboard when text filed being clicked
     */
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        // return NO to disallow editing.
        userNameTextField.text = ""
        return true
    }
    
    /**
     *  Hide keyboard when user touches on UI
     *
     */
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            // ...
            if touch.phase == .began
            {
                userNameTextField.resignFirstResponder()
            }
        }
        super.touchesBegan(touches, with: event)
    }

    
    // MARK: - Get/Post Method -
    func Post_Logout(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)customer/logout"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "devicetype" : GlobalConstants.deviceType,
            "devicetoken" :  UserDefaults.standard.value(forKey: "DeviceToken") == nil ? "123" : UserDefaults.standard.value(forKey: "DeviceToken")! as! String,
            "unique_id" : "",
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "logout"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = true
        webHelper.startDownload()
    }
    
    func CallAPICalling(toNumber: String,fromNumber : String){
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURLCalling)account/call"
        
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "to" : toNumber,
            "from" : fromNumber,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "Call"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.serviceWithAlertErrorMessage = true
        webHelper.startDownload()
    }
    
    func PostXMLchange(toNumber: String,fromNumber : String){
        
        let newHandleString: String = addCountryCode(str_Get: toNumber)
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURLCalling)account/call"
        
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "to" : newHandleString,
            "from" : fromNumber,
        ]
        
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "xmlupdate"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.serviceWithAlertErrorMessage = true
//        webHelper.strAuthorize = "6d827cb3a915252859c0d76644453ed5"
        webHelper.startDownload()
    }
    
    
    
    //MARK: - Other Method -
    func commanMethod(){
        self.navigationSet()
        
        if vw_HomeView != nil{
            //Page header color set
            pg_Header.pageIndicatorTintColor = UIColor(patternImage:UIImage(named: "img_PageSelected")!)
            pg_Header.currentPageIndicatorTintColor = UIColor(red: CGFloat((255 / 255.0)), green: CGFloat((130 / 255.0)), blue: CGFloat((0 / 255.0)), alpha: CGFloat(1.0))
            
            if arr_Marker.count == 0{
                
                //Manage Google Map
                vw_MapGoogle.settings.myLocationButton = true
                vw_MapGoogle.delegate = self
                vw_MapGoogle.isMyLocationEnabled = true
                vw_MapGoogle.clear()
                
                //Set up move to my location
                let arr_Temp : NSMutableArray = []
                
                for _ in 0..<1 {
                    var c2D: CLLocationCoordinate2D = CLLocationCoordinate2DMake(currentLocation!.coordinate.latitude, currentLocation!.coordinate.longitude)
                    
                    let marker = GMSMarker(position: c2D)
                    marker.title = "Your Location"
                    marker.snippet = ""
                    marker.isFlat = false
                    marker.map = vw_MapGoogle
                    marker.icon = UIImage(named: "icon_MapPin")
                    marker.tracksViewChanges = false
                    marker.map = vw_MapGoogle
                    arr_Temp.add(marker)
                }
                self.didTapFitBounds(withMarkers: arr_Temp , withPadding : 100)
                vw_MapGoogle.animate(toZoom: 14)
            }
        }
    }
    @objc func navigationSet(){
         if vw_HomeView != nil{
            btn_CityName.title = currentCityName
            
            let str = currentCityName
            let starWidth = str.widthOfString(usingFont: UIFont(name:  GlobalConstants.kFontOpenSansSemiBold, size: manageFont(font: 17))!)
            
            if vw_HomeView != nil{
                vw_Header.frame = CGRect(x: 0, y: 0, width: GlobalConstants.windowWidth - 100, height: 35)
                if str == ""{
                    vw_HeaderSub.frame = CGRect(x: 0, y: 0, width: GlobalConstants.windowWidth - 100 - Double(starWidth), height: 35)
                }else{
                    vw_HeaderSub.frame = CGRect(x: 0, y: 0, width: GlobalConstants.windowWidth - 80 - Double(starWidth), height: 35)
                }
            }
        }
    }
    
    func manageMapView(){
        
        arr_Marker = []
        
        //My location
        var c2D: CLLocationCoordinate2D = CLLocationCoordinate2DMake(currentLocation!.coordinate.latitude, currentLocation!.coordinate.longitude)
        
        let marker = GMSMarker(position: c2D)
        marker.title = "Your Location"
        marker.snippet = ""
        marker.isFlat = false
        marker.map = vw_MapGoogle
        marker.icon = UIImage(named: "icon_MapPin")
        marker.tracksViewChanges = false
        marker.map = vw_MapGoogle
        arr_Marker.add(marker)
        
        for count in 0..<arr_Main.count {
            let obj: GlobalObject = arr_Main[count] as! GlobalObject
            var c2D: CLLocationCoordinate2D = CLLocationCoordinate2DMake(currentLocation!.coordinate.latitude, currentLocation!.coordinate.longitude)
            
            c2D.latitude = CLLocationDegrees(Float(obj.str_Customer_Lat)!)
            c2D.longitude = CLLocationDegrees(Float(obj.str_Customer_Long)!)
            
            let marker = GMSMarker(position: c2D)
            marker.title = obj.str_Customer_Title
            marker.snippet = ""
            marker.isFlat = false
            marker.map = vw_MapGoogle
            marker.icon = UIImage(named: "icon_MapPin")
            marker.tracksViewChanges = false
            marker.userData = "\(count)"
            marker.map = vw_MapGoogle
            arr_Marker.add(marker)
        }
        
        self.didTapFitBounds(withMarkers: arr_Marker, withPadding : 100)
    }
    
    func didTapFitBounds(withMarkers markers: NSMutableArray , withPadding : Int) {
        var bounds = GMSCoordinateBounds()
        
        for i in 0..<markers.count{
            let markerHere : GMSMarker = (markers[i] as? GMSMarker)!
            bounds = bounds.includingCoordinate(markerHere.position)
        }
        
        vw_MapGoogle.animate(with: GMSCameraUpdate.fit(bounds, withPadding: CGFloat(withPadding)))
        vw_MapGoogle.animate(toViewingAngle: 0)
    }
    
    @objc func reloadHeder(){
        if arr_Banner.count != 0{
            let int_Count = timer_Value + 1
            if int_Count < arr_Banner.count {
                timer_Value = timer_Value + 1
            }else{
                timer_Value = 0
            }
            
            let indexpathSelect : NSIndexPath = NSIndexPath(row:timer_Value, section: 0)
            pg_Header.currentPage = (indexpathSelect.row)
            cv_Header.scrollToItem(at: indexpathSelect as IndexPath, at: UICollectionViewScrollPosition.left, animated: true)
        }
    }
    
    
    //MARK: - Button Method -
    @IBAction func btn_Back(_ sender:Any){
        toggleLeft()
    }
    @IBAction func btn_Search(_ sender:Any){
        self.performSegue(withIdentifier: "search", sender: self)
    }
    @IBAction func btn_MapZoom(_ sender:Any){
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let view = storyboard.instantiateViewController(withIdentifier: "MapDetailView") as! MapDetailView
        view.arr_Main = arr_Main
        view.str_Complete = "1"
        self.navigationController?.pushViewController(view, animated: true)
    }
    
    func Post_TodayAppointment(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)customer/job/today"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "skip" : "0",
            "total" : "1000",
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "today"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.serviceWithAlertErrorMessage = false
        webHelper.startDownload()
    }
    func Post_Banner(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)banner/get"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "banner"
        webHelper.methodType = "get"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.indicatorShowOrHide = false
        webHelper.serviceWithAlert = false
        webHelper.serviceWithAlertErrorMessage = false
        webHelper.startDownload()
    }
    func Get_CommanAPI(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)comman"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "comman"
        webHelper.methodType = "get"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.indicatorShowOrHide = false
        webHelper.serviceWithAlert = false
        webHelper.serviceWithAlertErrorMessage = false
        webHelper.startDownload()
    }
    
}

//MARK: - Home Controller -
//MARK: - MapView Delegate -
extension PlivoCallController : GMSMapViewDelegate{
    func mapView(_ mapView: GMSMapView, didTapInfoWindowOf marker: GMSMarker) {
        
        if marker.userData != nil{
            let obj: GlobalObject = arr_Main[Int(marker.userData as! String)!] as! GlobalObject
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let view = storyboard.instantiateViewController(withIdentifier: "ConfrimArrivalViewController") as! ConfrimArrivalViewController
            view.get_Data = obj
            view.str_Complete = "1"
            self.navigationController?.pushViewController(view, animated: true)
        }
        
        //        view.hero.modalAnimationType = .zoomSlide(direction: .left)
        //        hero.replaceViewController(with: view)
        
    }
}


//MARK: - Scrollview Delegate -
extension PlivoCallController : UIScrollViewDelegate{
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let visibleRect = CGRect(origin: cv_Header.contentOffset, size: cv_Header.bounds.size)
        let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)
        let indexPath = cv_Header.indexPathForItem(at: visiblePoint)
        
        pg_Header.currentPage = (indexPath?.row)!
    }
}

//MARK: - Collection View Cell -
class HomeViewCollectioncell : UICollectionViewCell{
    //Cell for tabbar
    @IBOutlet weak var img_Seleted: UIImageView!
}

//MARK: - Collection View -
extension PlivoCallController : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        pg_Header.numberOfPages = arr_Banner.count
        return arr_Banner.count
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: collectionView.frame.size.width, height: collectionView.frame.size.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let str_Identifier : String = "cell"
        
        let cell  = collectionView.dequeueReusableCell(withReuseIdentifier: str_Identifier, for: indexPath) as! HomeViewCollectioncell
        
        let obj = arr_Banner[indexPath.row] as! BannerObject
        
        cell.img_Seleted.sd_setImage(with: URL(string: (obj.str_BannerImage)), placeholderImage: UIImage(named: "img_Demo"))
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let obj = arr_Banner[indexPath.row] as! BannerObject
        
        if let url = URL(string: obj.str_BannerLink) {
            UIApplication.shared.open(url, options: [:])
        }
    }
}


// MARK: - Side Bar Controller -
extension PlivoCallController : SlideMenuControllerDelegate {
    
    func leftWillOpen() {
        print("SlideMenuControllerDelegate: leftWillOpen")
    }
    
    func leftDidOpen() {
        print("SlideMenuControllerDelegate: leftDidOpen")
    }
    
    func leftWillClose() {
        print("SlideMenuControllerDelegate: leftWillClose")
    }
    
    func leftDidClose() {
        print("SlideMenuControllerDelegate: leftDidClose")
    }
    
    func rightWillOpen() {
        print("SlideMenuControllerDelegate: rightWillOpen")
    }
    
    func rightDidOpen() {
        print("SlideMenuControllerDelegate: rightDidOpen")
    }
    
    func rightWillClose() {
        print("SlideMenuControllerDelegate: rightWillClose")
    }
    
    func rightDidClose() {
        print("SlideMenuControllerDelegate: rightDidClose")
    }
}


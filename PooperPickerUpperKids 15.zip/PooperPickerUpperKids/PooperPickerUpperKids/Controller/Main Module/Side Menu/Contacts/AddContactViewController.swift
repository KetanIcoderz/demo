//
//  AddContactViewController.swift
//  PooperPickerUpperKids
//
//  Created by Apple on 06/08/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import SwiftMessages
import ActionSheetPicker_3_0
import GooglePlaces
import GooglePlacePicker

class AddContactViewController: UIViewController {

    var placesClient: GMSPlacesClient!

    var get_Data = GlobalObject()
   
    @IBOutlet weak var tbl_Main: UITableView!
    
    @IBOutlet weak var lbl_FirstName: UILabel!
    @IBOutlet weak var lbl_LastName: UILabel!
    @IBOutlet weak var lbl_DogName: UILabel!
    @IBOutlet weak var lbl_Address: UILabel!
    @IBOutlet weak var lbl_PhoneNumber: UILabel!
    @IBOutlet weak var lbl_Comment: UILabel!
    
    @IBOutlet weak var vw_FirstName: extensionView!
    @IBOutlet weak var vw_LastName: extensionView!
    @IBOutlet weak var vw_DogName: extensionView!
    @IBOutlet weak var vw_Address: extensionView!
    @IBOutlet weak var vw_PhoneNumber: extensionView!
    @IBOutlet weak var vw_Comment: extensionView!
    
    @IBOutlet weak var tf_FirstName: UITextField!
    @IBOutlet weak var tf_lastName: UITextField!
    @IBOutlet weak var tf_DogName: UITextField!
    @IBOutlet weak var tf_Address: UITextField!
    @IBOutlet weak var tf_PhoneNumber: UITextField!
    
    @IBOutlet weak var tv_Comments: UITextView!
    
    @IBOutlet weak var btn_Save: UIButton!
    @IBOutlet weak var btn_Delete: UIButton!
    @IBOutlet weak var btn_Edit: UIBarButtonItem!
    
    @IBOutlet weak var con_Button: NSLayoutConstraint!
    
    @IBOutlet weak var vw_Bottom: UIView!
    
    var str_Lat : String = ""
    var str_Long : String = ""
    var str_Type : String = ""
    var str_EditPage : String = ""
    
    var arr_Main : NSMutableArray = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()

        placesClient = GMSPlacesClient.shared()
    }
    override func viewWillAppear(_ animated: Bool) {
        tbl_Main.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - Other Method -
    func commanMethod(){
        
        let vw_Table = tbl_Main.tableHeaderView
        vw_Table?.frame = CGRect(x: 0, y: 0, width: tbl_Main.frame.size.width, height: CGFloat(GlobalConstants.windowHeight * 0.7016491754))
        tbl_Main.tableHeaderView = vw_Table
        
        lbl_FirstName.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_LastName.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_DogName.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_Address.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_PhoneNumber.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_Comment.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        
        tf_FirstName.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))
        tf_lastName.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))
        tf_DogName.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))
        tf_Address.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))
        tf_PhoneNumber.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))
        tv_Comments.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))
        
        if get_Data.str_Customer_Title == ""{
            self.navigationItem.title = "Add Contact"
            btn_Save .setTitle("Save", for: .normal)
            
            btn_Edit.isEnabled = false
            btn_Edit.tintColor = GlobalConstants.appColor
            tbl_Main.tableFooterView = UIView()
            
            //Schedule job manage
            saveArr_ScheduleDate = []
            saveType_ScheduleDate = "1"
            str_Type = "Contact Only"
            
            for _ in 0..<7{
                let obj2 = GlobalObject()
                saveArr_ScheduleDate.add(obj2)
            }
        }else{
            self.navigationItem.title = "Update Customer"
            
            tf_FirstName.text = get_Data.str_Customer_FirstName
            tf_lastName.text = get_Data.str_Customer_LastName
            tf_DogName.text = get_Data.str_Customer_DogName
            tf_Address.text = get_Data.str_Customer_Address
            tf_PhoneNumber.text = get_Data.str_Customer_PhoneNumber
            tv_Comments.text = get_Data.str_Customer_Note
            str_Lat = get_Data.str_Customer_Lat
            str_Lat = get_Data.str_Customer_Long
            str_Type = get_Data.str_Customer_JobType
            
            saveArr_ScheduleDate = get_Data.arr_Customer_ScheduleJob
            saveType_ScheduleDate = get_Data.str_Customer_ScheduleType
            
            self.navigationItem.title = get_Data.str_Customer_Title
            btn_Save .setTitle("Update Contact", for: .normal)
               
            //Edit Page on
            if str_EditPage == "1"{
                btn_Edit.isEnabled = false
                btn_Edit.tintColor = GlobalConstants.appColor
            }else{
                con_Button.constant = -CGFloat(GlobalConstants.windowHeight * 0.0749625)
                self.editable(edit: false)
                vw_Bottom.isHidden = true
                tbl_Main.tableFooterView = UIView()
                
                vw_FirstName.borderWidth = 0.0
                vw_FirstName.borderWidth = 0.0
                vw_LastName.borderWidth = 0.0
                vw_DogName.borderWidth = 0.0
                vw_Address.borderWidth = 0.0
                vw_PhoneNumber.borderWidth = 0.0
                vw_Comment.borderWidth = 0.0
            }
        }
    }
    func manageScheduleTime() -> String{
        //Schedule job manage
        var str_Value = ""
        for i in 0..<saveArr_ScheduleDate.count{
            let obj2 = saveArr_ScheduleDate[i] as! GlobalObject
            if obj2.str_Customer_StartTime != ""{
                if str_Value == ""{
                    str_Value = "\(obj2.str_Customer_Name2) : \(obj2.str_Customer_StartTime) : \(obj2.str_Customer_EndTime)"
                }else{
                    str_Value = "\(str_Value)\n\(obj2.str_Customer_Name2) : \(obj2.str_Customer_StartTime) : \(obj2.str_Customer_EndTime)"
                }
            }
        }
        return str_Value
    }
    func makeScheduleArray() -> NSMutableArray{
        var dict_Sub : NSDictionary =  NSDictionary()
        
        let arr_Temp : NSMutableArray = []
        for count in (0..<saveArr_ScheduleDate.count){
            let obj = saveArr_ScheduleDate[count] as! GlobalObject
            
            dict_Sub =  NSDictionary()
            
            dict_Sub = [
                "day" : obj.str_Customer_Name2,
                "start" : obj.str_Customer_StartTime,
                "end" : obj.str_Customer_EndTime,
                "date" : obj.str_Customer_DateOnly,
            ]
            arr_Temp.add(dict_Sub)
        }
        return arr_Temp
    }
    func manageType(Str_Type : String) -> String{
        var str_Value : String = ""
        let arr : NSMutableArray = ["Contact Only","Prospect","Declined","Customer"]
        for i in 0..<arr.count{
            if Str_Type == arr[i] as! String{
                str_Value = "\(i+1)"
                break
            }
        }
        return str_Value
    }
    func editable(edit : Bool){
        self.view.endEditing(true)
        
        if edit{
            tf_FirstName.isUserInteractionEnabled = true
            tf_lastName.isUserInteractionEnabled = true
            tf_DogName.isUserInteractionEnabled = true
            tf_PhoneNumber.isUserInteractionEnabled = true
            tv_Comments.isUserInteractionEnabled = true
        }else{
            tf_FirstName.isUserInteractionEnabled = false
            tf_lastName.isUserInteractionEnabled = false
            tf_DogName.isUserInteractionEnabled = false
            tf_PhoneNumber.isUserInteractionEnabled = false
            tv_Comments.isUserInteractionEnabled = false
        }
    }
    
    //MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any){
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btn_Interest(_ sender:Any){
        let arr_Data : [Any] = ["First Type","Second Type","Third Type"]
        
        let picker = ActionSheetStringPicker(title: "Type of interest", rows: arr_Data, initialSelection:selectedIndex(arr: arr_Data as NSArray, value: tf_PhoneNumber.text! as String as NSString), doneBlock: { (picker, indexes, values) in
            
            self.tf_PhoneNumber.text = "\(values as! NSString as! String)"
            
        }, cancel: {ActionSheetStringPicker in return}, origin: sender)
        
        //        picker?.hideCancel = true
        picker?.setDoneButton(UIBarButtonItem(title: "Select", style: .plain, target: nil, action: nil))
        picker?.setCancelButton(UIBarButtonItem(title: "Cancel", style: .plain, target: nil, action: nil))
        picker?.toolbarButtonsColor = UIColor.black
        
        picker?.show()
    }
    @IBAction func btn_Save(_ sender:Any){
        
        if((tf_FirstName.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please enter first name.", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }else if((tf_lastName.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please enter last name", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }
//        else if((tf_DogName.text?.isEmpty)! && GlobalConstants.developerTest == false){
//            //Alert show for Header
//            messageBar.MessageShow(title: "Please enter dog's name", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
//        }else if((tf_Address.text?.isEmpty)! && GlobalConstants.developerTest == false){
//            //Alert show for Header
//            messageBar.MessageShow(title: "Please enter address", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
//        }
        else if((tf_PhoneNumber.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please enter phone number", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }
//        else if((tv_Comments.text?.isEmpty)! && GlobalConstants.developerTest == false){
//            //Alert show for Header
//            messageBar.MessageShow(title: "Please enter comments", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
//        }
        else{
            if get_Data.str_Customer_Title == ""{
                self.Post_CreateCustomer()
            }else{
                self.Post_UpdateCustomer()
            }
        }
       
    }
    @IBAction func btn_Delete(_ sender:Any){
        let alert = UIAlertController(title: GlobalConstants.appName, message: NSLocalizedString(ValidationMessages.AddCustomersViewController_Delete, comment: ""), preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: NSLocalizedString("Yes", comment: ""), style: UIAlertActionStyle.default, handler: { (action) in
            
            self.Post_DeleteCustomer(str_Id: self.get_Data.str_Customer_Id)
            
        }))
        alert.addAction(UIAlertAction(title: NSLocalizedString("No", comment: ""), style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    @IBAction func btn_Edit(_ sender:Any){
        
        if get_Data.str_Customer_Title == ""{
           
        }else{
            
            //Edit Page on
            if str_EditPage == ""{
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let view = storyboard.instantiateViewController(withIdentifier: "AddContactViewController") as! AddContactViewController
                view.get_Data = get_Data
                view.str_EditPage = "1"
                self.navigationController?.pushViewController(view, animated: true)
            }
        }
        
//        UIView.animate(withDuration: 0.3, delay: 0.0, options: .allowAnimatedContent, animations: {() -> Void in
//            if self.con_Button.constant != 0{
//                self.con_Button.constant = 0
//                self.editable(edit: true)
//            }else{
//                self.con_Button.constant = -CGFloat(GlobalConstants.windowHeight * 0.0749625)
//                self.editable(edit: false)
//            }
//            self.view.layoutIfNeeded()
//            // Ensures that all pending layout operations have been completed
//        }, completion: {(_ finished: Bool) -> Void in
//            if self.con_Button.constant == 0{
//                self.vw_Bottom.isHidden = false
//            }else{
//                self.vw_Bottom.isHidden = true
//            }
//        })
//
    }
    
    
    // MARK: - Get/Post Method -
    func Post_CreateCustomer(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)contact/create"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "first_name" : tf_FirstName.text ?? "",
            "last_name" : tf_lastName.text ?? "",
            "dog_name" : tf_DogName.text ?? "",
            "address" : tf_Address.text ?? "",
            "phone_number" : addCountryCode(str_Get: tf_PhoneNumber.text ?? ""),
            "note" : tv_Comments.text ?? "",
            "lat" : str_Lat,
            "longs" : str_Long,
            "type" : manageType(Str_Type: str_Type),
            "schedule_type" : saveType_ScheduleDate,
            "schedule" : "[]",
        ]
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "create"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.serviceWithAlertErrorMessage = true
        webHelper.startDownload()
    }
    
    func Post_UpdateCustomer(){
        
        let string = "[]"
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)contact/update"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "contact_id" : get_Data.str_Customer_Id,
            "first_name" : tf_FirstName.text ?? "",
            "last_name" : tf_lastName.text ?? "",
            "dog_name" : tf_DogName.text ?? "",
            "address" : tf_Address.text ?? "",
            "phone_number" : addCountryCode(str_Get: tf_PhoneNumber.text ?? ""),
            "note" : tv_Comments.text ?? "",
            "lat" : str_Lat,
            "longs" : str_Long,
            "type" : manageType(Str_Type: str_Type),
            "schedule_type" : saveType_ScheduleDate,
            "schedule" : "[]",
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "update"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.serviceWithAlertErrorMessage = true
        webHelper.startDownload()
    }
    
    
    func Post_DeleteCustomer(str_Id : String){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)contact/delete"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "contact_id" : str_Id,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "delete"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.serviceWithAlertErrorMessage = true
        webHelper.startDownload()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}

extension AddContactViewController : UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        let config = GMSPlacePickerConfig(viewport: nil)
        let placePicker = GMSPlacePickerViewController(config: config)
        placePicker.delegate = self
        present(placePicker, animated: true, completion: nil)

//        placesClient.currentPlace(callback: { (placeLikelihoodList, error) -> Void in
//            if let error = error {
//                print("Pick Place error: \(error.localizedDescription)")
//                return
//            }
//
////            self.nameLabel.text = "No current place"
//            self.tf_Address.text = ""
//
//            if let placeLikelihoodList = placeLikelihoodList {
//                let place = placeLikelihoodList.likelihoods.first?.place
//                if let place = place {
////                    self.nameLabel.text = place.name
//                    self.tf_Address.text = place.formattedAddress?.components(separatedBy: ", ")
//                        .joined(separator: "\n")
//                }
//            }
//        })
//
    }
}

extension AddContactViewController : GMSPlacePickerViewControllerDelegate{
    func placePicker(_ viewController: GMSPlacePickerViewController, didPick place: GMSPlace) {
        // Dismiss the place picker, as it cannot dismiss itself.
        viewController.dismiss(animated: true, completion: nil)
        
        self.tf_Address.text = place.formattedAddress
        
        str_Lat = String(place.coordinate.latitude)
        str_Long = String(place.coordinate.longitude)
        
//        print("Place name \(place.name)")
//        print("Place address \(place.formattedAddress)")
//        print("Place attributions \(place.attributions)")
    }
    
    func placePickerDidCancel(_ viewController: GMSPlacePickerViewController) {
        // Dismiss the place picker, as it cannot dismiss itself.
        viewController.dismiss(animated: true, completion: nil)
        
        print("No place selected")
    }
}



// MARK: - Table Delegate -
extension AddContactViewController : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if get_Data.str_Customer_Title != "" && str_EditPage == "1"{
            return 1
        }
        return 0
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if indexPath.row == 1{
            if saveArr_ScheduleDate.count == 0{
                return 40
            }
            
            return UITableViewAutomaticDimension
        }
        return 50
    }
    public func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 60
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cellIdentifier : String = "cell"
        if indexPath.row == 0{
            cellIdentifier = "type"
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for:indexPath as IndexPath) as! AddCustomersViewTableViewcell
        
        if indexPath.row == 1{
            cell.lbl_Tital.text = "Schedule"
            cell.lbl_Description.text = manageScheduleTime()
            cell.img_Icon.isHidden = true
            
            if cell.lbl_Description.text != ""{
                cell.img_Icon.isHidden = false
            }
            
            //Manage font
            cell.lbl_Tital.font = UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFont(font: 18))
            cell.lbl_Description.font = UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFont(font: 14))
        }else{
            
            cell.lbl_Description.text = str_Type
            
            cell.lbl_Tital.font = UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFont(font: 18))
            cell.lbl_Description.font = UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFont(font: 14))
        }
        
        return cell;
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 1{
            self.performSegue(withIdentifier: "schedule", sender: self)
        }else if indexPath.row == 0{
            
            let arr_Data = ["Contact Only","Prospect","Declined","Customer"]
            let picker = ActionSheetStringPicker(title: "Contact Type", rows: arr_Data as! [Any], initialSelection:selectedIndex(arr: arr_Data as NSArray, value: str_Type as NSString), doneBlock: { (picker, indexes, values) in
                
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                if values as! String == "Prospect"{
                    let view = storyboard.instantiateViewController(withIdentifier: "AddProspectiveCustomersViewController") as! AddProspectiveCustomersViewController
                    view.get_Data = self.get_Data
                    view.str_TypeCustomer = "contact"
                    self.navigationController?.pushViewController(view, animated: true)
                    
                }else if values as! String == "Customer"{
                    
                    let view = storyboard.instantiateViewController(withIdentifier: "AddCustomersViewController") as! AddCustomersViewController
                    view.get_Data = self.get_Data
                    view.str_Type = "contact"
                    self.navigationController?.pushViewController(view, animated: true)
                    
                }else{
                    self.str_Type = values as! String
                    self.tbl_Main.reloadData()
                }
            }, cancel: {ActionSheetStringPicker in return}, origin: tableView)
            
            picker?.setDoneButton(UIBarButtonItem(title: "Select", style: .plain, target: nil, action: nil))
            picker?.setCancelButton(UIBarButtonItem(title: "Cancel", style: .plain, target: nil, action: nil))
            picker?.toolbarButtonsColor = UIColor.black
            
            picker?.show()
            
        }
    }
}

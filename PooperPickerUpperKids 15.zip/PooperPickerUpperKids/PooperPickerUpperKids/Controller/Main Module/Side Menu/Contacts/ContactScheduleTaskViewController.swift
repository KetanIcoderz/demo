//
//  ContactScheduleTaskViewController.swift
//  PooperPickerUpperKids
//
//  Created by Apple on 29/08/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import ActionSheetPicker_3_0
import SwiftMessages

class ContactScheduleTaskViewController: UIViewController {

    var arr_Main : NSMutableArray! = []
    var arr_Save : NSMutableArray! = []
    var arr_Type : NSMutableArray! = []
    
    @IBOutlet weak var lbl_StartTime: UILabel!
    @IBOutlet weak var lbl_EndTime: UILabel!
    @IBOutlet weak var lbl_SelectedStartTime: UILabel!
    @IBOutlet weak var lbl_SelectedEndTime: UILabel!
    
    @IBOutlet weak var btn_SelectedStartTime: UIButton!
    @IBOutlet weak var btn_SelectedEndTime: UIButton!
    @IBOutlet weak var btn_SaveDate: UIButton!
    @IBOutlet weak var btn_ResetDate: UIButton!
    
    var int_SelectedDate : Int = 0
    var str_StartTime : String = ""
    var str_EndTime : String = ""
    
    @IBOutlet weak var cv_Header: UICollectionView!
    @IBOutlet weak var cv_Option: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()
    }
    
    //MARK: Other Method -
    func commanMethod(){
        
        lbl_StartTime.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 14))
        lbl_EndTime.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 14))
        lbl_SelectedStartTime.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 14))
        lbl_SelectedEndTime.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 14))
        
        arr_Main = []
        let arr_Week = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]
        for i in 0..<7{
            var tenDaysfromNow: Date {
                return (Calendar.current as NSCalendar).date(byAdding: .day, value: i+1, to: Date(), options: [])!
            }
            let obj = GlobalObject()
            obj.str_Customer_Name = localDateToStrignDate(date : tenDaysfromNow,type: 1)
            obj.str_Customer_Name2 = localDateToStrignDate(date : tenDaysfromNow,type: 2)
            obj.str_Customer_Month = localDateToStrignDate(date : tenDaysfromNow,type: 3)
            obj.str_Customer_DateOnly = localDateToStrignDate2(date : tenDaysfromNow)
            
            arr_Main.add(obj)
        }
        
        arr_Save = NSMutableArray(array: saveArr_ScheduleDate)
        
//        arr_Save = saveArr_ScheduleDate.copy() as! NSMutableArray
//        arr_Save = []
//        for i in 0..<saveArr_ScheduleDate.count{
//            let obj = saveArr_ScheduleDate[i] as! GlobalObject
//            arr_Save.add(obj)
//        }
        self.manageSavedData()
        
        //Type
        arr_Type = []
        let obj = GlobalObject()
        obj.str_Customer_SheduleType = "Weekly"
        obj.str_Customer_SheduleSelected = saveType_ScheduleDate == "1" ? "1" : "0"
        arr_Type.add(obj)
        
        let obj2 = GlobalObject()
        obj2.str_Customer_SheduleType = "By Weekly"
        obj2.str_Customer_SheduleSelected = saveType_ScheduleDate == "2" ? "1" : "0"
        arr_Type.add(obj2)
        
    }
    func manageSavedData(){
        let obj = arr_Save[int_SelectedDate] as! GlobalObject
        if obj.str_Customer_StartTime == ""{
            lbl_SelectedStartTime.text = "Select"
            lbl_SelectedEndTime.text = "Select"
        }else{
            lbl_SelectedStartTime.text = obj.str_Customer_StartTime
            lbl_SelectedEndTime.text = obj.str_Customer_EndTime
        }
    }
    func calculateTimeInterval() -> String{
        
        if lbl_SelectedStartTime.text != "Select" && lbl_SelectedEndTime.text != "Select"{
            
            let startDate = localStrignToDate(date: lbl_SelectedStartTime.text!)
            let endDate = localStrignToDate(date: lbl_SelectedEndTime.text!)
            
            if startDate < endDate{
                let minutes = endDate.minutes(from: startDate)
                return String(minutes)
            }else{
                //Alert show for Header
                messageBar.MessageShow(title: "Invalid time slot", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
                return ""
            }
        }else{
            if lbl_SelectedStartTime.text == "Select"{
                //Alert show for Header
                messageBar.MessageShow(title: "Please enter start date", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
            }else{
                //Alert show for Header
                messageBar.MessageShow(title: "Please enter end date", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
            }
            return ""
        }
    }
    
    
    //MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any){
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btn_Save(_ sender:Any){
        saveArr_ScheduleDate = NSMutableArray(array: arr_Save)
        
        saveType_ScheduleDate =  "0"
        for i in 0..<arr_Type.count{
            let obj2 = arr_Type[i] as! GlobalObject
            if obj2.str_Customer_SheduleSelected == "1"{
                saveType_ScheduleDate = "\(i+1)"
            }
        }
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btn_SelectedStartTime(_ sender:Any){
        let datePicker = ActionSheetDatePicker(title: "Start Time", datePickerMode:  UIDatePickerMode.time, selectedDate: lbl_SelectedStartTime.text == "Select" ? Date() : localStrignToDate(date: lbl_SelectedStartTime.text!), doneBlock: {
            picker, value, index in
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "h:mm a"
            self.lbl_SelectedStartTime.text = dateFormatter.string(from: (value as! NSDate) as Date)
            
            dateFormatter.dateFormat = "HH:mm"
            self.str_StartTime = "\(dateFormatter.string(from: (value as! NSDate) as Date)):00"
            
//            self.calculateTimeInterval()
            
            return
        }, cancel: { ActionStringCancelBlock in return }, origin: btn_SelectedStartTime)
        datePicker?.minuteInterval = 15
        datePicker?.show()
    }
    @IBAction func btn_SelectedEndTime(_ sender:Any){
        let datePicker = ActionSheetDatePicker(title: "End Time", datePickerMode:  UIDatePickerMode.time, selectedDate: lbl_SelectedEndTime.text == "Select" ? Date() : localStrignToDate(date: lbl_SelectedEndTime.text!), doneBlock: {
            picker, value, index in
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "h:mm a"
            self.lbl_SelectedEndTime.text = dateFormatter.string(from: (value as! NSDate) as Date)
            
            dateFormatter.dateFormat = "HH:mm"
            self.str_EndTime = "\(dateFormatter.string(from: (value as! NSDate) as Date)):00"
            
//            self.calculateTimeInterval()
            return
        }, cancel: { ActionStringCancelBlock in return }, origin: btn_SelectedStartTime)
        datePicker?.minuteInterval = 15
        datePicker?.show()
    }
    @IBAction func btn_SaveDate(_ sender:Any){
        let obj = arr_Save[int_SelectedDate] as! GlobalObject
        let obj2 = arr_Main[int_SelectedDate] as! GlobalObject
        let obj3 = saveArr_ScheduleDate[int_SelectedDate] as! GlobalObject
        
        if calculateTimeInterval() != ""{
            obj.str_Customer_StartTime = lbl_SelectedStartTime.text ?? ""
            obj.str_Customer_EndTime = lbl_SelectedEndTime.text ?? ""
            obj.str_Customer_DateOnly = obj2.str_Customer_DateOnly
            obj.str_Customer_Name2 = obj2.str_Customer_Name2
            
            arr_Save.replaceObject(at: int_SelectedDate, with: obj)
            
            print(obj.str_Customer_StartTime)
            print(obj3.str_Customer_StartTime)
            
            messageBar.MessageShow(title: "Saved", alertType: MessageView.Layout.tabView, alertTheme: .info, TopBottom: false)
            
            cv_Header.reloadData()
        }
    }
    @IBAction func btn_ResetDate(_ sender:Any){
        
        let obj2 = GlobalObject()
        arr_Save.replaceObject(at: int_SelectedDate, with: obj2)
        
        manageSavedData()
        cv_Header.reloadData()
        
        messageBar.MessageShow(title: "Reset", alertType: MessageView.Layout.tabView, alertTheme: .info, TopBottom: false)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


//MARK: - Collection View -
extension ContactScheduleTaskViewController : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == cv_Option{
            return arr_Type.count
        }
        
        return arr_Main.count
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if collectionView == cv_Option{
            return CGSize(width: collectionView.frame.size.width/CGFloat(arr_Type.count), height: collectionView.frame.size.height)
        }
        
        return CGSize(width: collectionView.frame.size.width / 7, height: collectionView.frame.size.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        var str_Identifier : String = "cell"
        
        let cell  = collectionView.dequeueReusableCell(withReuseIdentifier: str_Identifier, for: indexPath) as! AddJobsCollectioncell
        
        if collectionView == cv_Option{
            let obj = arr_Type[indexPath.row] as! GlobalObject
            
            cell.lbl_Tital.text = obj.str_Customer_SheduleType
            
            if obj.str_Customer_SheduleSelected == "1"{
                cell.img_Icon.image = UIImage(named:"img_CheckSelected")
                cell.img_Icon.layer.borderColor = UIColor.clear.cgColor
                cell.img_Icon.layer.borderWidth = 1.0
                
                cell.lbl_Tital.textColor = GlobalConstants.appColor
            }else{
                 cell.lbl_Tital.textColor = UIColor.black
                
                cell.img_Icon.image = UIImage(named:"img_CheckUnSelected")
                cell.img_Icon.layer.borderColor = GlobalConstants.appColor.cgColor
                cell.img_Icon.layer.borderWidth = 1.0
            }
            
            cell.lbl_Tital.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 15))
        }else{
            let obj = arr_Main[indexPath.row] as! GlobalObject
            let obj2 = arr_Save[indexPath.row] as! GlobalObject
            
            cell.lbl_Tital.text = obj.str_Customer_Name
            cell.lbl_Description.text = obj.str_Customer_Name2
            
            cell.lbl_Tital.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 12))
            cell.lbl_Description.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 12))
            
            
            if int_SelectedDate == indexPath.row{
                cell.lbl_Tital.textColor = GlobalConstants.appColor
                cell.lbl_Description.textColor = GlobalConstants.appColor
                
                self.navigationItem.title = obj.str_Customer_Month
            }else{
                cell.lbl_Tital.textColor = UIColor.black
                cell.lbl_Description.textColor = UIColor.black
            }
            
            cell.img_Icon.isHidden = true
            if obj2.str_Customer_StartTime != ""{
                cell.img_Icon.isHidden = false
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == cv_Option{
            let obj = arr_Type[indexPath.row] as! GlobalObject
            
            for i in 0..<arr_Type.count{
//                if i != indexPath.row{
                    let obj2 = arr_Type[i] as! GlobalObject
                    obj2.str_Customer_SheduleSelected = "0"
                    arr_Type.replaceObject(at: i, with: obj2)
//                }
            }
            
            obj.str_Customer_SheduleSelected = "1"
//            if obj.str_Customer_SheduleSelected == "1"{
//                obj.str_Customer_SheduleSelected = "0"
//            }else{
//                obj.str_Customer_SheduleSelected = "1"
//            }
            arr_Type.replaceObject(at: indexPath.row, with: obj)
            cv_Option.reloadData()
        }else{
            int_SelectedDate = indexPath.row
            collectionView.reloadData()
            self.manageSavedData()
        }
    }
}


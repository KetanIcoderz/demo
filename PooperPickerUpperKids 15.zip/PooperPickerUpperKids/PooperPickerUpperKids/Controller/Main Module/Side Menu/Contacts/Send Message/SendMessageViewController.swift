//
//  NewMessageViewController.swift
//  Communication
//
//  Created by Apple on 09/07/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import THContactPicker
import Contacts
import ContactsUI
import EmptyDataSet_Swift
import IQKeyboardManagerSwift
import SwiftMessages

class SendMessageViewController: UIViewController {
    
    @IBOutlet weak var tv_Main: UITextView!
    
    @IBOutlet weak var con_Bottom: NSLayoutConstraint!
    @IBOutlet weak var con_Bottom2: NSLayoutConstraint!
    
    var arr_Main : NSMutableArray = []
    
    var str_Number : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()
    }
    override func viewWillAppear(_ animated: Bool) {
        IQKeyboardManager.sharedManager().enable = false
    }
    override func viewWillDisappear(_ animated: Bool) {
        IQKeyboardManager.sharedManager().enable = true
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - NSNotificationCenter
    @objc func keyboardDidShow(_ notification: Notification?) {
        if let keyboardFrame: NSValue = notification?.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue {
            let keyboardRectangle = keyboardFrame.cgRectValue
            let keyboardHeight = keyboardRectangle.height
            //            let duration:TimeInterval = (notification.userInfo![UIKeyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0
            
            UIView.animate(withDuration: 0.0, delay: 0.0, options: .allowAnimatedContent, animations: {() -> Void in
                self.con_Bottom2.constant = keyboardHeight
                
                self.view.layoutIfNeeded()
                // Ensures that all pending layout operations have been completed
            }, completion: {(_ finished: Bool) -> Void in
            })
        }
    }
    
    @objc func keyboardDidHide(_ notification: Notification?) {
        // Move the scroll view back into its original position.
        UIView.animate(withDuration: 0.01, delay: 0.0, options: .allowAnimatedContent, animations: {() -> Void in
            self.con_Bottom2.constant = 10
            
            self.view.layoutIfNeeded()
            // Ensures that all pending layout operations have been completed
        }, completion: {(_ finished: Bool) -> Void in
        })
    }

    
    //MARK : - Other Methods -
    func commanMethod(){

        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardDidShow(_:)), name: .UIKeyboardDidShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardDidHide(_:)), name: .UIKeyboardDidHide, object: nil)
        
        tv_Main.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 17))
        
        tv_Main.text = "Enter Message"
        tv_Main.textColor = UIColor.lightGray
    }
    
    // MARK: - Button Event -
    @IBAction func btn_Dismiss(_ sender:Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btn_Send(_ sender:Any) {

        if((tv_Main.text?.isEmpty)! || tv_Main.text == "Enter Message"){
            //Alert show for Header
            messageBar.MessageShow(title: "Please enter message first", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
            
        }else{
            self.CallAPIMessage(dst: (objUser?.user_Phone_Number)!, src: str_Number, text: tv_Main.text)
        }
    }
    
    
    func CallAPIMessage(dst: String,src : String,text : String){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURLCalling)message/send"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "from" : dst,
            "to" : src,
            "text" : text,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "Message"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = true
        webHelper.startDownload()
        
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        if segue.identifier == "addcontact"{
            
        }
    }
}

extension SendMessageViewController : UITextViewDelegate{
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == UIColor.lightGray {
            textView.text = nil
            textView.textColor = UIColor.black
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = "Enter Message"
            textView.textColor = UIColor.lightGray
        }
    }
}

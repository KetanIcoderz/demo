//
//  MessagePlivoViewController.swift
//  PooperPickerUpperKids
//
//  Created by Apple on 24/09/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import EmptyDataSet_Swift
import ViewAnimator

class MessagePlivoViewController: UIViewController {
    
    private let animations = [AnimationType.from(direction: .bottom, offset: 30.0)]
    
    @IBOutlet var tbl_Main : UITableView!
    
    var arr_Main : NSMutableArray! = []
    
    var int_CountLoad: Int = 0
    
    //Bool Declaration
    var bool_Load: Bool = false
    var bool_ViewWill: Bool = false
    var bool_SearchMore: Bool = true
    
    //Refresh Controller
    var refresh_Item: UIRefreshControl?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        arr_Main = []
        bool_ViewWill = true
        self.Post_MessageListing()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //MARK: - Other Method -
    func commanMethod(){
        
        //Refresh Controller
        refresh_Item = UIRefreshControl()
        refresh_Item?.addTarget(self, action: #selector(self.refreshItem), for: .valueChanged)
        tbl_Main.addSubview(refresh_Item!)
        
        tbl_Main.emptyDataSetSource = self
        tbl_Main.emptyDataSetDelegate = self
        
    }
    @objc func refreshItem(_ refresh: UIRefreshControl) {
        if bool_Load == false {
            bool_ViewWill = true
            self.Post_MessageListing()
        }else{
            refresh_Item?.endRefreshing()
        }
    }
    func completedServiceCalling(){
        
        refresh_Item?.endRefreshing()
        bool_Load = false
        
        tbl_Main.reloadData()
        
        if bool_ViewWill == true{
            UIView.animate(views: self.tbl_Main.visibleCells, animations: animations, completion: {
            })
            bool_ViewWill = false
        }
    }
    
    
    //MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any){
        toggleLeft()
    }
    @IBAction func btn_Add(_ sender:Any){
        
    }
    
    // MARK: - Get/Post Method -
    func Post_MessageListing(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURLCalling)message/history"
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "Message"
        webHelper.methodType = "get"
        webHelper.strURL = strURL
        webHelper.dictType = NSDictionary()
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.startDownload()
        bool_Load = true
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}

// MARK: - Table Delegate -
extension MessagePlivoViewController : UITableViewDelegate,UITableViewDataSource,MGSwipeTableCellDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr_Main.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    public func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 72
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let str_Identifier : String = "cell"
        
        var cell = tableView.dequeueReusableCell(withIdentifier: str_Identifier)as! RecentsMessageViewControllerTableViewCell
        cell.delegate = self
        cell.tag = indexPath.row
        
        let obj = arr_Main[indexPath.row] as! GlobalObject
        
        //        let watch = StopWatch(totalSeconds: Int(obj.str_Recent_CallDuration)!)
        
        cell.lbl_Tital.text = (obj.str_Message_Tital == "") ? (obj.str_Message_To_Number) : (obj.str_Message_Tital)
        cell.lbl_Description.text =  obj.str_Message
        cell.tv_Description.text =  obj.str_Message
        cell.lbl_Description2.text =  getTimeBetweenCurrentDateToMessage(date:obj.str_Message_Time)
        //        cell.lbl_Time.text = watch.getFormate
        cell.lbl_Time.text = obj.str_Message_State.capitalizingFirstLetter()
        
        cell.img_Icon.image = obj.img_Recent_Image
        
        cell.tv_Description.isEditable = false
        cell.tv_Description.dataDetectorTypes = .link
        
        cell.img_Live.isHidden = true
        if obj.str_Recent_Live == "1"{
            cell.img_Live.isHidden = false
        }
        
        //Declare text in icon in tableview cell
        cell.lbl_Tital.font =  UIFont(name: GlobalConstants.kFontMyriadProSemiBold, size: 17)
        cell.lbl_Description.font =  UIFont(name: GlobalConstants.kFontRegular, size: 15)
        cell.tv_Description.font =  UIFont(name: GlobalConstants.kFontRegular, size: 13)
        cell.lbl_Time.font =  UIFont(name: GlobalConstants.kFontMyriadProSemiBold, size: 12)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
    func swipeTableCell(_ cell: MGSwipeTableCell, canSwipe direction: MGSwipeDirection) -> Bool {
        return false;
    }
    
    
    func swipeTableCell(_ cell: MGSwipeTableCell, swipeButtonsFor direction: MGSwipeDirection, swipeSettings: MGSwipeSettings, expansionSettings: MGSwipeExpansionSettings) -> [UIView]? {
    
        return nil
        
    }
    
}


extension MessagePlivoViewController : EmptyDataSetSource, EmptyDataSetDelegate
{
    func emptyDataSetShouldDisplay(_ scrollView: UIScrollView) -> Bool {
        
        if arr_Main.count == 0 && bool_Load == false{
            return true
        }
        return false
    }
    
    //Header image show in list
    func image(forEmptyDataSet scrollView: UIScrollView) -> UIImage? {
        
        return UIImage.init(named: "img_PlaceHeader")
    }
    
    //set tital in list
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        
        var text: String?
        var font: UIFont?
        var textColor: UIColor?
        
        textColor = UIColor.lightGray
        
        text = "No message history"
        
        font = UIFont(name: GlobalConstants.kFontRegular, size:GlobalConstants.kFontRatio*14.0)
        
        if text == nil {
            return nil
        }
        var attributes: [NSAttributedStringKey: Any] = [:]
        if font != nil {
            attributes[NSAttributedStringKey.font] = font!
        }
        if textColor != nil {
            attributes[NSAttributedStringKey.foregroundColor] = textColor
        }
        
        textColor = UIColor.clear
        
        return NSAttributedString.init(string: text!, attributes: attributes)
    }
}



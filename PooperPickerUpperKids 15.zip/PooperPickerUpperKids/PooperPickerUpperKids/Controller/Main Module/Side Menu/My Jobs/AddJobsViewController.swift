//
//  AddJobsViewController.swift
//  PooperPickerUpperKids
//
//  Created by Apple on 03/08/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import ActionSheetPicker_3_0
import SwiftMessages
import GooglePlaces
import GooglePlacePicker

class AddJobsViewController: UIViewController {

    var placesClient: GMSPlacesClient!
    
    var arr_Main : NSMutableArray! = []
    var arr_Customer : NSMutableArray! = []
    var arr_DynamicDatabase : NSMutableArray = []
    
    @IBOutlet weak var cv_Header: UICollectionView!
    
    @IBOutlet weak var tbl_Main: UITableView!
    
    @IBOutlet weak var lbl_Header: UILabel!
    
    //Time
    @IBOutlet weak var lbl_SelectTime: UILabel!
    @IBOutlet weak var lbl_StartTime: UILabel!
    @IBOutlet weak var lbl_EndTime: UILabel!
    @IBOutlet weak var lbl_SelectedStartTime: UILabel!
    @IBOutlet weak var lbl_SelectedEndTime: UILabel!
    @IBOutlet weak var lbl_SelectedCustomer: UILabel!
    
    //Time To Clar
    @IBOutlet weak var lbl_TimeToClean: UILabel!
    @IBOutlet weak var lbl_TimeToCleanSelect: UILabel!
    
    //OTher
    @IBOutlet weak var lbl_Address: UILabel!
    @IBOutlet weak var lbl_SpouseName: UILabel!
    @IBOutlet weak var lbl_DogName: UILabel!
    @IBOutlet weak var lbl_Notes: UILabel!
    
    @IBOutlet weak var tf_Address: UITextField!
    @IBOutlet weak var tf_SpouseName: UITextField!
    @IBOutlet weak var tf_DogName: UITextField!
    
    @IBOutlet weak var tv_Notes: UITextView!
    
    @IBOutlet weak var btn_Save: UIButton!
    
    //Time
    @IBOutlet weak var btn_SelectedStartTime: UIButton!
    @IBOutlet weak var btn_SelectedEndTime: UIButton!
    @IBOutlet weak var btn_TimeToCleanSelect: UIButton!

    var int_SelectedDate : Int = 0
    var str_CustomerID : String = ""
    var str_Lat : String = ""
    var str_Long : String = ""
    var str_StartTime : String = ""
    var str_EndTime : String = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()
        
        placesClient = GMSPlacesClient.shared()
    }
    override func viewWillAppear(_ animated: Bool) {
        self.Post_CustomerListing()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    //MARK: - Other Method -
    func commanMethod(){
        
        let vw_Table = tbl_Main.tableHeaderView
        vw_Table?.frame = CGRect(x: 0, y: 0, width: tbl_Main.frame.size.width, height: CGFloat(GlobalConstants.windowHeight * 0.7016491754))
        tbl_Main.tableHeaderView = vw_Table
        
        lbl_Header.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        
        lbl_SelectTime.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_StartTime.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 14))
        lbl_EndTime.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 14))
        lbl_SelectedStartTime.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 14))
        lbl_SelectedEndTime.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 14))
        
        lbl_TimeToClean.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_TimeToCleanSelect.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 14))
        
        lbl_Address.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_SpouseName.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_DogName.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_Notes.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        
        tf_Address.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))
        tf_SpouseName.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))
        tf_DogName.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))
        tv_Notes.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))
        
        btn_Save.titleLabel?.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        
        arr_Main = []
        for i in 0..<30{
            var tenDaysfromNow: Date {
                return (Calendar.current as NSCalendar).date(byAdding: .day, value: i+1, to: Date(), options: [])!
            }
            let obj = GlobalObject()
            obj.str_Customer_Name = localDateToStrignDate(date : tenDaysfromNow,type: 0)
            obj.str_Customer_Date = localDateToStrignDate2(date : tenDaysfromNow)
            
            arr_Main.add(obj)
        }
        
        arr_DynamicDatabase = []
        //Data structure
        let obj1 = JobsObject()
        obj1.str_Type = "selection"
        obj1.str_Title = "Select Customer"
        obj1.str_TextValue = "Select Customer"
        obj1.str_PlaceHolder = ""
        obj1.arr_SelectionArray = []
        
        let objCustomer = GlobalObject()
        objCustomer.str_Customer_Id = "0"
        objCustomer.str_Customer_Title = "Customer 1"
        obj1.arr_SelectionArray.add(objCustomer)
        
        let objCustomer2 = GlobalObject()
        objCustomer2.str_Customer_Id = "0"
        objCustomer2.str_Customer_Title = "Customer 2"
        obj1.arr_SelectionArray.add(objCustomer2)
        
        arr_DynamicDatabase.add(obj1)
        
        
        let obj = JobsObject()
        obj.str_Type = "text"
        obj.str_Title = "Spouses Name"
        obj.str_TextValue = ""
        obj.str_PlaceHolder = ""
        arr_DynamicDatabase.add(obj)
        
        let obj2 = JobsObject()
        obj2.str_Type = "addresspicker"
        obj2.str_Title = "Address"
        obj2.str_TextValue = ""
        obj2.str_PlaceHolder = ""
        obj2.str_Lat = ""
        obj2.str_Long = ""
        arr_DynamicDatabase.add(obj2)
        
        let obj3 = JobsObject()
        obj3.str_Type = "startendtime"
        obj3.str_Title = "Select Time"
        obj3.str_TextValue = "SELECT"
        obj3.str_TextValue2 = "SELECT"
        obj3.str_PlaceHolder = "Start Time"
        obj3.str_PlaceHolder = "End Time"
        arr_DynamicDatabase.add(obj3)
        
        let obj4 = JobsObject()
        obj4.str_Type = "textnumber"
        obj4.str_Title = "Phone"
        obj4.str_TextValue = ""
        obj4.str_PlaceHolder = ""
        arr_DynamicDatabase.add(obj4)
        
        let obj5 = JobsObject()
        obj5.str_Type = "textnote"
        obj5.str_Title = "Note"
        obj5.str_TextValue = ""
        obj5.str_PlaceHolder = "Note"
        arr_DynamicDatabase.add(obj5)
        
    }
    func moveCollectionToFrame(contentOffset : CGFloat) {
        let frame: CGRect = CGRect(x : contentOffset ,y : cv_Header.contentOffset.y ,width : cv_Header.frame.width,height : cv_Header.frame.height)
        cv_Header.scrollRectToVisible(frame, animated: true)
    }
    func calculateTimeInterval(){
        if lbl_SelectedStartTime.text != "Select" && lbl_SelectedEndTime.text != "Select"{
            
            let startDate = localStrignToDate(date: lbl_SelectedStartTime.text!)
            let endDate = localStrignToDate(date: lbl_SelectedEndTime.text!)
            
            if startDate < endDate{
                let minutes = endDate.minutes(from: startDate)
                self.lbl_TimeToCleanSelect.text = "\(minutes) Min"
                print(minutes)
            }else{
                self.lbl_TimeToCleanSelect.text = ""
            }
        }else{
            self.lbl_TimeToCleanSelect.text = ""
        }
    }
    func option_Select(tag : Int){
        let obj_Get = arr_DynamicDatabase[tag] as! JobsObject

        let arr_Data : NSMutableArray = []
        for i in 0..<obj_Get.arr_SelectionArray.count{
            let obj : GlobalObject = obj_Get.arr_SelectionArray[i] as! GlobalObject
            
            arr_Data.add(obj.str_Customer_Title)
        }
        let picker = ActionSheetStringPicker(title: obj_Get.str_TextValue, rows: arr_Data as! [Any], initialSelection:selectedIndex(arr: arr_Data as NSArray, value: lbl_SelectedCustomer.text as! String as NSString), doneBlock: { (picker, indexes, values) in
            
            let obj : GlobalObject = obj_Get.arr_SelectionArray[indexes] as! GlobalObject
            obj_Get.str_SelectionId = obj.str_Customer_Id
            obj_Get.str_Title = obj.str_Customer_Title
            self.arr_DynamicDatabase.replaceObject(at: tag, with: obj_Get)
            self.tbl_Main.reloadData()
        }, cancel: {ActionSheetStringPicker in return}, origin: lbl_Header)
        
        picker?.setDoneButton(UIBarButtonItem(title: "Select", style: .plain, target: nil, action: nil))
        picker?.setCancelButton(UIBarButtonItem(title: "Cancel", style: .plain, target: nil, action: nil))
        picker?.toolbarButtonsColor = UIColor.black
        
        picker?.show()
    }
    
    //MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any){
//        toggleLeft()
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btn_Left(_ sender:Any){
        let collectionBounds = cv_Header.bounds
        let contentOffset = CGFloat(floor(cv_Header.contentOffset.x - collectionBounds.size.width))
        self.moveCollectionToFrame(contentOffset: contentOffset)
    }
    @IBAction func btn_Right(_ sender:Any){
        let collectionBounds = cv_Header.bounds
        let contentOffset = CGFloat(floor(cv_Header.contentOffset.x + collectionBounds.size.width))
        self.moveCollectionToFrame(contentOffset: contentOffset)
    }
    @IBAction func btn_Save(_ sender:Any){
        
        if((lbl_SelectedCustomer.text?.isEmpty)! && lbl_SelectedCustomer.text != "Select Customer" && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please select customer", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }else if lbl_SelectedCustomer.text == "Select Customer" && GlobalConstants.developerTest == false{
            //Alert show for Header
            messageBar.MessageShow(title: "Please select customer", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }else if((lbl_TimeToCleanSelect.text?.isEmpty)! && GlobalConstants.developerTest == false){
            if lbl_StartTime.text != "" || lbl_EndTime.text != ""{
                //Alert show for Header
                messageBar.MessageShow(title: "Invalid time slot", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
            }else{
                //Alert show for Header
                messageBar.MessageShow(title: "Please select start time and end time", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
            }
        }else if((tf_Address.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please enter address", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }
//        else if((tf_SpouseName.text?.isEmpty)! && GlobalConstants.developerTest == false){
//            //Alert show for Header
//            messageBar.MessageShow(title: "Please enter spouse name", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
//        }
        else if((tf_DogName.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please enter dog name", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }
//        else if((tv_Notes.text?.isEmpty)! && GlobalConstants.developerTest == false){
//            //Alert show for Header
//            messageBar.MessageShow(title: "Please enter notes", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
//        }
        else{
            self.Post_AddJobs()
//            //Alert show for Header
//            messageBar.MessageShow(title: "Customer saved successfully.", alertType: MessageView.Layout.cardView, alertTheme: .success, TopBottom: true)
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//            let view = storyboard.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
//            let nav = UINavigationController(rootViewController: view)
//
//            self.slideMenuController()?.changeMainViewController(nav, close: true)
        }
    }
    @IBAction func btn_SelectedStartTime(_ sender:Any){
        let datePicker = ActionSheetDatePicker(title: "Start Time", datePickerMode:  UIDatePickerMode.time, selectedDate: lbl_SelectedStartTime.text == "Select" ? Date() : localStrignToDate(date: lbl_SelectedStartTime.text!), doneBlock: {
            picker, value, index in
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "h:mm a"
            self.lbl_SelectedStartTime.text = dateFormatter.string(from: (value as! NSDate) as Date)
            
            dateFormatter.dateFormat = "HH:mm"
            self.str_StartTime = "\(dateFormatter.string(from: (value as! NSDate) as Date)):00"
            
            self.calculateTimeInterval()
            
            return
        }, cancel: { ActionStringCancelBlock in return }, origin: btn_SelectedStartTime)
        datePicker?.minuteInterval = 15
        datePicker?.show()
    }
    @IBAction func btn_SelectedEndTime(_ sender:Any){
        let datePicker = ActionSheetDatePicker(title: "End Time", datePickerMode:  UIDatePickerMode.time, selectedDate: lbl_SelectedEndTime.text == "Select" ? Date() : localStrignToDate(date: lbl_SelectedEndTime.text!), doneBlock: {
            picker, value, index in
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "h:mm a"
            self.lbl_SelectedEndTime.text = dateFormatter.string(from: (value as! NSDate) as Date)
            
            dateFormatter.dateFormat = "HH:mm"
            self.str_EndTime = "\(dateFormatter.string(from: (value as! NSDate) as Date)):00"
            
            self.calculateTimeInterval()
            return
        }, cancel: { ActionStringCancelBlock in return }, origin: btn_SelectedStartTime)
        datePicker?.minuteInterval = 15
        datePicker?.show()
    }
    @IBAction func btn_TimeToCleanSelect(_ sender:Any){
    
    }
    @IBAction func btn_SelectCustomer(_ sender:Any){
        
        let arr_Data : NSMutableArray = []
        for i in 0..<arr_Customer.count{
            let obj : GlobalObject = arr_Customer[i] as! GlobalObject
            
            arr_Data.add(obj.str_Customer_Title)
        }
        let picker = ActionSheetStringPicker(title: "Select Customer", rows: arr_Data as! [Any], initialSelection:selectedIndex(arr: arr_Data as NSArray, value: lbl_SelectedCustomer.text as! String as NSString), doneBlock: { (picker, indexes, values) in
          
            
            self.lbl_SelectedCustomer.text = "\(values as! NSString as! String)"
            self.lbl_SelectedCustomer.textColor = UIColor.black
            
            let obj : GlobalObject = self.arr_Customer[indexes] as! GlobalObject
            self.str_CustomerID = obj.str_Customer_Id
            self.tf_DogName.text = obj.str_Customer_DogName
            
        }, cancel: {ActionSheetStringPicker in return}, origin: sender)
        
        picker?.setDoneButton(UIBarButtonItem(title: "Select", style: .plain, target: nil, action: nil))
        picker?.setCancelButton(UIBarButtonItem(title: "Cancel", style: .plain, target: nil, action: nil))
        picker?.toolbarButtonsColor = UIColor.black
        
        picker?.show()
    }
    
    
    // MARK: - Get/Post Method -
    func Post_CustomerListing(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)customer/get"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "skip" : "0",
            "total" : "1000",
            "type" : "1",
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "customer"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.startDownload()
    }
    func Post_AddJobs(){
        
        let obj = arr_Main[int_SelectedDate] as! GlobalObject
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)customer/job/add"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "customer_id" : str_CustomerID,
            "job_date" : obj.str_Customer_Date,
            "start_time" : str_StartTime,
            "end_time" : str_EndTime,
            "address" : tf_Address.text as! String,
            "lat" : str_Lat,
            "longs" : str_Long,
            "spouse_name" : tf_SpouseName.text as! String,
            "dog_name" : tf_DogName.text as! String,
            "note" : tv_Notes.text as! String,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "add"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlertDefault = true
        webHelper.serviceWithAlertErrorMessage = true
        webHelper.startDownload()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

//MARK: - UITextFieldDelegate -
extension AddJobsViewController : UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        let config = GMSPlacePickerConfig(viewport: nil)
        let placePicker = GMSPlacePickerViewController(config: config)
        placePicker.delegate = self
        present(placePicker, animated: true, completion: nil)
    }
}

//MARK: - GMSPlacePickerViewControllerDelegate -
extension AddJobsViewController : GMSPlacePickerViewControllerDelegate{

    func placePicker(_ viewController: GMSPlacePickerViewController, didPick place: GMSPlace) {
        // Dismiss the place picker, as it cannot dismiss itself.
        viewController.dismiss(animated: true, completion: nil)
        
        self.tf_Address.text = place.formattedAddress
        
        str_Lat = String(place.coordinate.latitude)
        str_Long = String(place.coordinate.longitude)
        
        //        print("Place name \(place.name)")
        //        print("Place address \(place.formattedAddress)")
        //        print("Place attributions \(place.attributions)")
    }
    
    func placePickerDidCancel(_ viewController: GMSPlacePickerViewController) {
        // Dismiss the place picker, as it cannot dismiss itself.
        viewController.dismiss(animated: true, completion: nil)
        
        print("No place selected")
    }
}


//MARK: - Collection View Cell -
class AddJobsCollectioncell : UICollectionViewCell{
    
    @IBOutlet weak var lbl_Tital: UILabel!
    @IBOutlet weak var lbl_Description: UILabel!
    
    @IBOutlet weak var img_Icon: UIImageView!
    
    @IBOutlet weak var vw_BG: UIView!
}

//MARK: - Collection View -
extension AddJobsViewController : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {

//        return 0
        return arr_Main.count
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: collectionView.frame.size.width/5, height: collectionView.frame.size.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        var str_Identifier : String = "cell"
        
        let cell  = collectionView.dequeueReusableCell(withReuseIdentifier: str_Identifier, for: indexPath) as! AddJobsCollectioncell
        
        let obj = arr_Main[indexPath.row] as! GlobalObject
        
        cell.lbl_Tital.text = obj.str_Customer_Name
        cell.lbl_Tital.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 11))
        
        
        if int_SelectedDate == indexPath.row{
            cell.lbl_Tital.textColor = UIColor.white
            cell.vw_BG.backgroundColor = GlobalConstants.appColor
        }else{
            cell.lbl_Tital.textColor = UIColor.black
            cell.vw_BG.backgroundColor = UIColor(red: 235.0/256.0, green: 235.0/256.0, blue: 235.0/256.0, alpha: 1.0)
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        int_SelectedDate = indexPath.row
        collectionView.reloadData()
    }
}


//MARK: - TableView View Cell -
class AddJobsViewTableViewcell : UITableViewCell{
    
    @IBOutlet weak var lbl_Tital: UILabel!
    @IBOutlet weak var lbl_Description: UILabel!
    @IBOutlet weak var lbl_Description2: UILabel!
    @IBOutlet weak var lbl_Select: UILabel!
    @IBOutlet weak var lbl_Select2: UILabel!
    
    @IBOutlet weak var btn_Selection: UIButton!
    @IBOutlet weak var btn_Selection2: UIButton!
    
    @IBOutlet weak var tf_Text: UITextField!
    @IBOutlet weak var tv_Text: UITextView!
    
    @IBOutlet weak var img_Icon: UIImageView!
}


// MARK: - Table Delegate -
extension AddJobsViewController : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 0
//        return arr_DynamicDatabase.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        let obj_Get = arr_DynamicDatabase[indexPath.row] as! JobsObject
        if obj_Get.str_Type == "text" || obj_Get.str_Type == "textnumber" || obj_Get.str_Type == "addresspicker"{
            return CGFloat(GlobalConstants.windowHeight * 0.09295352324)
        }else if obj_Get.str_Type == "startendtime"{
            return CGFloat(GlobalConstants.windowHeight * 0.1274362819)
        }else if obj_Get.str_Type == "selection"{
            return CGFloat(GlobalConstants.windowHeight * 0.07496251874)
        }else if obj_Get.str_Type == "textnote"{
            return CGFloat(GlobalConstants.windowHeight * 0.1709145427)
        }
        
        return CGFloat(GlobalConstants.windowHeight * 0.09295352324)
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let obj_Get = arr_DynamicDatabase[indexPath.row] as! JobsObject
        
        var cellIdentifier : String = "text"
        if obj_Get.str_Type == "text" || obj_Get.str_Type == "textnumber" || obj_Get.str_Type == "addresspicker"{
            cellIdentifier = "text"
        }else if obj_Get.str_Type == "startendtime"{
             cellIdentifier = "startendtime"
        }else if obj_Get.str_Type == "selection"{
            cellIdentifier = "selection"
        }else if obj_Get.str_Type == "textnote"{
            cellIdentifier = "textnote"
        }
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for:indexPath as IndexPath) as! AddJobsViewTableViewcell
  
        cell.lbl_Tital.text = obj_Get.str_Title
        
        if obj_Get.str_Type == "text"{
            cell.tf_Text.delegate = self
            cell.tf_Text.keyboardType = UIKeyboardType.default
        }else if obj_Get.str_Type == "textnumber"{
            cell.tf_Text.delegate = self
            cell.tf_Text.keyboardType = UIKeyboardType.phonePad
        }else if obj_Get.str_Type == "addresspicker"{
            cell.tf_Text.delegate = self
        }else if obj_Get.str_Type == "startendtime"{
            cell.lbl_Select.font = UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
            cell.lbl_Select2.font = UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
            cell.lbl_Description.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 14))
            cell.lbl_Description2.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 14))
            
            cell.btn_Selection.tag = indexPath.row
            cell.btn_Selection.addTarget(self, action: #selector(btn_SelectedStartTime(_:)), for: .touchUpInside)
            cell.btn_Selection2.tag = indexPath.row
            cell.btn_Selection2.addTarget(self, action: #selector(btn_SelectedEndTime(_:)), for: .touchUpInside)
            
        }else if obj_Get.str_Type == "selection"{
            
        }else if obj_Get.str_Type == "textnote"{
            cell.tv_Text.font = UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))
        }
        
        //Manage font
        cell.lbl_Tital.font = UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        
        return cell;
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let obj_Get = arr_DynamicDatabase[indexPath.row] as! JobsObject
        
         if obj_Get.str_Type == "selection"{
            self.option_Select(tag: indexPath.row)
        }
    }
}




extension Date {
    /// Returns the amount of years from another date
    func years(from date: Date) -> Int {
        return Calendar.current.dateComponents([.year], from: date, to: self).year ?? 0
    }
    /// Returns the amount of months from another date
    func months(from date: Date) -> Int {
        return Calendar.current.dateComponents([.month], from: date, to: self).month ?? 0
    }
    /// Returns the amount of weeks from another date
    func weeks(from date: Date) -> Int {
        return Calendar.current.dateComponents([.weekOfMonth], from: date, to: self).weekOfMonth ?? 0
    }
    /// Returns the amount of days from another date
    func days(from date: Date) -> Int {
        return Calendar.current.dateComponents([.day], from: date, to: self).day ?? 0
    }
    /// Returns the amount of hours from another date
    func hours(from date: Date) -> Int {
        return Calendar.current.dateComponents([.hour], from: date, to: self).hour ?? 0
    }
    /// Returns the amount of minutes from another date
    func minutes(from date: Date) -> Int {
        return Calendar.current.dateComponents([.minute], from: date, to: self).minute ?? 0
    }
    /// Returns the amount of seconds from another date
    func seconds(from date: Date) -> Int {
        return Calendar.current.dateComponents([.second], from: date, to: self).second ?? 0
    }
    /// Returns the amount of nanoseconds from another date
    func nanoseconds(from date: Date) -> Int {
        return Calendar.current.dateComponents([.nanosecond], from: date, to: self).nanosecond ?? 0
    }
    /// Returns the a custom time interval description from another date
    func offset(from date: Date) -> String {
        if years(from: date)   > 0 { return "\(years(from: date))y"   }
        if months(from: date)  > 0 { return "\(months(from: date))M"  }
        if weeks(from: date)   > 0 { return "\(weeks(from: date))w"   }
        if days(from: date)    > 0 { return "\(days(from: date))d"    }
        if hours(from: date)   > 0 { return "\(hours(from: date))h"   }
        if minutes(from: date) > 0 { return "\(minutes(from: date))m" }
        if seconds(from: date) > 0 { return "\(seconds(from: date))s" }
        if nanoseconds(from: date) > 0 { return "\(nanoseconds(from: date))ns" }
        return ""
    }
}


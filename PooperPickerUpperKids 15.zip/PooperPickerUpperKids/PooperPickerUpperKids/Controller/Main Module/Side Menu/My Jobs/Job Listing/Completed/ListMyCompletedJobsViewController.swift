//
//  ListMyCompletedJobsViewController.swift
//  PooperPickerUpperKids
//
//  Created by Apple on 31/07/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import SwiftMessages
import ActionSheetPicker_3_0
import EmptyDataSet_Swift
import ViewAnimator

class ListMyCompletedJobsViewController: UIViewController {
    
    @IBOutlet var tbl_Main : UITableView!
    
    var arr_Main : NSMutableArray! = []
    
    var int_CountLoad: Int = 0
    
    //Bool Declaration
    var bool_Load: Bool = false
    var bool_ViewWill: Bool = false
    var bool_SearchMore: Bool = true
    
    //Refresh Controller
    var refresh_Item: UIRefreshControl?
    
    //Table Animation
    private let animations = [AnimationType.from(direction: .bottom, offset: 30.0)]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()
        
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "completedmyschedulejobs"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(viewWillAppear(_:)), name: NSNotification.Name(rawValue: "completedmyschedulejobs"), object: nil)
    }

    override func viewWillAppear(_ animated: Bool) {
        int_CountLoad = GlobalConstants.int_LoadMax
        bool_ViewWill = true
        bool_SearchMore = true
        
        arr_Main = []
        self.Post_JobsListing(count : int_CountLoad)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //MARK: - Scrollview Delegate -
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        view.endEditing(true)
        if scrollView == tbl_Main{
            if tbl_Main.contentSize.height <= tbl_Main.contentOffset.y + tbl_Main.frame.size.height && tbl_Main.contentOffset.y >= 0 {
                if bool_Load == false && arr_Main.count != 0 {
                    self.Post_JobsListing(count: int_CountLoad + GlobalConstants.int_LoadMax)
                }
            }
        }
    }
    
    
    //MARK: - Other Method -
    func commanMethod(){
        
        //Refresh Controller
        refresh_Item = UIRefreshControl()
        refresh_Item?.addTarget(self, action: #selector(self.refreshItem), for: .valueChanged)
        tbl_Main.addSubview(refresh_Item!)
        
        tbl_Main.emptyDataSetSource = self
        tbl_Main.emptyDataSetDelegate = self
        
//        arr_Main = []
//        var obj = GlobalObject()
//        obj.str_Customer_Lat = "23.0497"
//        obj.str_Customer_Long = "72.5117"
//        obj.str_Customer_Title = "Mr.  John"
//        obj.str_Customer_Address = "Houes no. 45, Kenilworth Houes no. 45, Kenilworth Houes no. 45, Kenilworth Houes no. 45, Kenilworth"
//        obj.str_Customer_Time = "29 May, 2018 09:00AM"
//        obj.str_Customer_TimeOnly = "09:00AM"
//        obj.str_Customer_MonthOnly = "May"
//        obj.str_Customer_DateOnly  = "29"
//        arr_Main.add(obj)
//        
//        obj = GlobalObject()
//        obj.str_Customer_Lat = "23.0326"
//        obj.str_Customer_Long = "72.6645"
//        obj.str_Customer_Title = "Mr.  John"
//        obj.str_Customer_Address = "Houes no. 45, Kenilworth"
//        obj.str_Customer_Time = "29 May, 2018 09:00AM"
//        obj.str_Customer_TimeOnly = "09:00AM"
//        obj.str_Customer_MonthOnly = "May"
//        obj.str_Customer_DateOnly  = "29"
//        arr_Main.add(obj)
//        
//        obj = GlobalObject()
//        obj.str_Customer_Lat = "23.0235"
//        obj.str_Customer_Long = "72.5290"
//        obj.str_Customer_Title = "Mr.  John"
//        obj.str_Customer_Address = "Houes no. 45, Kenilworth"
//        obj.str_Customer_Time = "29 May, 2018 09:00AM"
//        obj.str_Customer_TimeOnly = "09:00AM"
//        obj.str_Customer_MonthOnly = "May"
//        obj.str_Customer_DateOnly  = "29"
//        arr_Main.add(obj)
    }
    
    @objc func refreshItem(_ refresh: UIRefreshControl) {
        if bool_Load == false {
            int_CountLoad = GlobalConstants.int_LoadMax
            bool_ViewWill = true
            bool_SearchMore = true
            
            self.Post_JobsListing(count:int_CountLoad)
        }else{
            refresh_Item?.endRefreshing()
        }
    }
    func completedServiceCalling(){
        refresh_Item?.endRefreshing()
        bool_Load = false
        
        tbl_Main.reloadData()
        
        if bool_ViewWill == true{
            UIView.animate(views: self.tbl_Main.visibleCells, animations: animations, completion: {
            })
            bool_ViewWill = false
        }
    }
    
    // MARK: - Get/Post Method -
    func Post_JobsListing(count: Int){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)customer/job/schedule"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "skip" : "\(count - GlobalConstants.int_LoadMax)",
            "total" : "\(GlobalConstants.int_LoadMax)",
            "type" : "1",
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "schedule"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        
        if bool_SearchMore == true{
            bool_Load = true
            webHelper.startDownload()
        }
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}


// MARK: - Table Delegate -
extension ListMyCompletedJobsViewController : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr_Main.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return CGFloat(GlobalConstants.windowHeight * 0.1454272864)
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cellIdentifier : String = "cell"
        
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for:indexPath as IndexPath) as! ListMyJobsViewCollectioncell
        
        let obj = arr_Main[indexPath.row] as! GlobalObject
        
        cell.lbl_Tital.text = obj.str_Customer_Title

        if obj.str_Customer_Job_Payment_Method != "" && obj.str_Customer_Job_Payment_Method != "0"{
            cell.lbl_PaidOrNot.text = "Paid"
            cell.lbl_PaidOrNot.textColor = UIColor.blue
        }else{
            cell.lbl_PaidOrNot.text = "UnPaid"
            cell.lbl_PaidOrNot.textColor = UIColor.red
        }
        
        cell.lbl_Description.text = obj.str_Customer_Address
        cell.lbl_Date.text = localDateStringToString3(date : obj.str_Customer_DateOnly)
        cell.lbl_Month.text = localDateStringToString4(date : obj.str_Customer_DateOnly)
        cell.lbl_Time.text = localDateStringToString(date: obj.str_Customer_StartTime)
        cell.lbl_JobID.text = "Job Id : \(obj.str_Id)"
        
        //Manage font
        cell.lbl_Tital.font = UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFont(font: 16))
        cell.lbl_JobID.font = UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFont(font: 14))
        cell.lbl_PaidOrNot.font = UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFont(font: 14))
        cell.lbl_Description.font = UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFont(font: 14))
        cell.lbl_Date.font = UIFont(name: GlobalConstants.kFontMyriadProSemiBold, size: manageFont(font: 16))
        cell.lbl_Month.font = UIFont(name: GlobalConstants.kFontMyriadProSemiBold, size: manageFont(font: 16))
        cell.lbl_Time.font = UIFont(name: GlobalConstants.kFontMyriadProSemiBold, size: manageFont(font: 11.5))
        
        cell.btn_Cancel.titleLabel?.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        
//        cell.btn_Cancel.tag = indexPath.row
//        cell.btn_Cancel.addTarget(self, action: #selector(btn_Cancel(_:)), for: .touchUpInside)
        
        return cell;
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let obj = arr_Main[indexPath.row] as! GlobalObject
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let view = storyboard.instantiateViewController(withIdentifier: "MyJobsDetailViewController") as! MyJobsDetailViewController
        view.get_Data = obj
        view.str_Type = "completed"
        self.navigationController?.pushViewController(view, animated: true)
    }
}

extension ListMyCompletedJobsViewController : EmptyDataSetSource, EmptyDataSetDelegate
{
    func emptyDataSetShouldDisplay(_ scrollView: UIScrollView) -> Bool {
        
        if arr_Main.count == 0 && bool_Load == false{
            return true
        }
        return false
    }
    
    //Header image show in list
    func image(forEmptyDataSet scrollView: UIScrollView) -> UIImage? {
        
        return UIImage.init(named: "img_PlaceHeader")
    }
    
//    //Set button title
//    func buttonTitle(forEmptyDataSet scrollView: UIScrollView, for state: UIControlState) -> NSAttributedString?
//    {
//        var text: String?
//        var font: UIFont?
//        var textColor: UIColor?
//        
//        text = "Create Jobs"
//        font = UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size:GlobalConstants.kFontRatio*22.0 )
//        textColor = UIColor.white
//        
//        if text == nil {
//            return nil
//        }
//        
//        var attributes: [NSAttributedStringKey: Any] = [:]
//        
//        if font != nil {
//            attributes[NSAttributedStringKey.font] = font!
//        }
//        if textColor != nil {
//            attributes[NSAttributedStringKey.foregroundColor] = GlobalConstants.appColor
//        }
//        
//        textColor = GlobalConstants.appColor
//        
//        return NSAttributedString.init(string: text!, attributes: attributes)
//    }
    
    //Mothod for set background color in button click
    //    func buttonBackgroundImage(forEmptyDataSet scrollView: UIScrollView, for state: UIControlState) -> UIImage?
    //    {
    //        let capInsets: UIEdgeInsets = UIEdgeInsetsMake(10.0, 10.0, 10.0, 10.0)
    //        let rectInsets = UIEdgeInsets.zero as? UIEdgeInsets
    //        let image = imageWithColor(with: GlobalConstants.appColor)
    //        return image.resizableImage(withCapInsets: capInsets, resizingMode: .stretch).withAlignmentRectInsets(rectInsets!)
    //    }
    
//    //Click button event
//    func emptyDataSet(_ scrollView: UIScrollView, didTapButton button: UIButton) {
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//        let view = storyboard.instantiateViewController(withIdentifier: "AddJobsViewController") as! AddJobsViewController
//        self.navigationController?.pushViewController(view, animated: true)
//    }
    
    //set tital in list
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        
        var text: String?
        var font: UIFont?
        var textColor: UIColor?
        
        textColor = UIColor.lightGray
        
        text = "No jobs available"
        
        font = UIFont(name: GlobalConstants.kFontRegular, size:GlobalConstants.kFontRatio*14.0)
        
        if text == nil {
            return nil
        }
        var attributes: [NSAttributedStringKey: Any] = [:]
        if font != nil {
            attributes[NSAttributedStringKey.font] = font!
        }
        if textColor != nil {
            attributes[NSAttributedStringKey.foregroundColor] = textColor
        }
        
        textColor = UIColor.clear
        
        return NSAttributedString.init(string: text!, attributes: attributes)
    }
}







//
//  MyJobPaymentTypeViewController.swift
//  PooperPickerUpperKids
//
//  Created by Apple on 17/09/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import ActionSheetPicker_3_0
import SwiftMessages

class MyJobPaymentTypeViewController: UIViewController {

    @IBOutlet weak var lbl_SelectedType: UILabel!
    @IBOutlet weak var lbl_AmountTitle: UILabel!
    @IBOutlet weak var lbl_CheckTitle: UILabel!
    @IBOutlet weak var lbl_Dollar: UILabel!
    
    @IBOutlet weak var tf_Amount : UITextField!
    @IBOutlet weak var tf_CheckNo : UITextField!
    
    @IBOutlet weak var con_Amount : NSLayoutConstraint!
    @IBOutlet weak var con_CheckNo : NSLayoutConstraint!
    
    @IBOutlet weak var vw_Save : UIView!
    @IBOutlet weak var btn_Option : UIButton!
    
    var get_Data = GlobalObject()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        con_Amount.constant = 0
        con_CheckNo.constant = 0
        
        self.commanMethod()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - Comman Method -
    func commanMethod(){
        
        lbl_SelectedType.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_CheckTitle.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_AmountTitle.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        

        if get_Data.str_Customer_Job_Payment_Method != ""{
            var boolSet : Bool = false
            var boolCheck : Bool = false
            
            if get_Data.str_Customer_Job_Payment_Method == "1"{
                lbl_SelectedType.text = "Card"
                tf_Amount.text = get_Data.str_Customer_Job_Amount
                boolSet = true
            }else if get_Data.str_Customer_Job_Payment_Method == "2"{
                lbl_SelectedType.text = "Cash"
                tf_Amount.text = get_Data.str_Customer_Job_Amount
                boolSet = true
            }else if get_Data.str_Customer_Job_Payment_Method == "3"{
                lbl_SelectedType.text = "Cheque"
                tf_Amount.text = get_Data.str_Customer_Job_Amount
                tf_CheckNo.text = get_Data.str_Customer_Job_Cheque_Num
                boolCheck = true
            }
            if boolSet == true{
                vw_Save.isHidden = true
                tf_Amount.isUserInteractionEnabled = false
                tf_CheckNo.isUserInteractionEnabled = false
                btn_Option.isUserInteractionEnabled = false
            }
            if boolCheck == true{
                vw_Save.isHidden = false
                tf_Amount.isUserInteractionEnabled = false
                tf_CheckNo.isUserInteractionEnabled = true
                btn_Option.isUserInteractionEnabled = false
            }
            
        }
        self.manageData()
        
    }
    
    func manageData(){
        con_Amount.constant = 0
        con_CheckNo.constant = 0
        if lbl_SelectedType.text == "Card" || lbl_SelectedType.text == "Cash"{
            con_Amount.constant = 66
            tf_CheckNo.text = ""
        }else if lbl_SelectedType.text == "Cheque"{
            con_Amount.constant = 66
            con_CheckNo.constant = 66
        }
    }
    
    func manageType(Str_Type : String) -> String{
        var str_Value : String = ""
        let arr : NSMutableArray = ["Card","Cash","Cheque"]
        for i in 0..<arr.count{
            if Str_Type == arr[i] as! String{
                str_Value = "\(i+1)"
                break
            }
        }
        return str_Value
    }
    
    
    //MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any){
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btn_Option(_ sender:Any){
        let arr_Data : [Any] = ["Card","Cash","Cheque"]
        
        let picker = ActionSheetStringPicker(title: "Select Payment Type", rows: arr_Data, initialSelection:selectedIndex(arr: arr_Data as NSArray, value: lbl_SelectedType.text! as String as NSString), doneBlock: { (picker, indexes, values) in
            
            self.lbl_SelectedType.text = "\(values as! NSString as! String)"
            self.manageData()
            
        }, cancel: {ActionSheetStringPicker in return}, origin: sender)
        
        //        picker?.hideCancel = true
        picker?.setDoneButton(UIBarButtonItem(title: "Select", style: .plain, target: nil, action: nil))
        picker?.setCancelButton(UIBarButtonItem(title: "Cancel", style: .plain, target: nil, action: nil))
        picker?.toolbarButtonsColor = UIColor.black
        
        picker?.show()
    }
    
    @IBAction func btn_Save(_ sender:Any){
        var bool_Show : Bool = false
        
        if lbl_SelectedType.text == "Select Payment Type"{
            //Alert show for Header
            messageBar.MessageShow(title:"Please select payment type", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }else{
            if lbl_SelectedType.text == "Card" || lbl_SelectedType.text == "Cash"{
                 if tf_Amount.text == ""{
                    messageBar.MessageShow(title:"Please enter amount", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
                }else{
                    bool_Show = true
                }
            }else if lbl_SelectedType.text == "Cheque"{
                if tf_Amount.text == ""{
                    messageBar.MessageShow(title:"Please enter amount", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
                }else if tf_CheckNo.text == ""{
                    messageBar.MessageShow(title:"Please enter Cheque number", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
                }else {
                    bool_Show = true
                }
            }
            
            if bool_Show == true{
                self.Post_SavePayment()
            }
        }
    }
    
    // MARK: - Get/Post Method -
    func Post_SavePayment(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)customer/job/payment"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "job_id" : get_Data.str_Id,
            "amount" : tf_Amount.text,
            "cheque_num" : tf_CheckNo.text,
            "payment_method" : manageType(Str_Type: lbl_SelectedType.text!),
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "payment"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.startDownload()
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  MyJobsDetailViewController.swift
//  PooperPickerUpperKids
//
//  Created by Apple on 07/08/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit

class MyJobsDetailViewController: UIViewController {

    var get_Data = GlobalObject()
    
    //Time
    @IBOutlet weak var lbl_CustomerName: UILabel!
    @IBOutlet weak var lbl_SpouseName: UILabel!
    @IBOutlet weak var lbl_Location: UILabel!
    @IBOutlet weak var lbl_DateTime: UILabel!
    @IBOutlet weak var lbl_StartTime: UILabel!
    @IBOutlet weak var lbl_EndTime: UILabel!
    @IBOutlet weak var lbl_StartTimeSelected: UILabel!
    @IBOutlet weak var lbl_EndTimeSelected: UILabel!
    @IBOutlet weak var lbl_DogName: UILabel!
    @IBOutlet weak var lbl_Notes: UILabel!
    @IBOutlet weak var lbl_PaymentType: UILabel!
    
    @IBOutlet weak var tf_CustomerName: UITextField!
    @IBOutlet weak var tf_SpouseName: UITextField!
    @IBOutlet weak var tf_Location: UITextField!
    @IBOutlet weak var tf_DateTime: UITextField!
    @IBOutlet weak var tf_DogName: UITextField!
    @IBOutlet weak var tv_Notes: UITextView!
    
    @IBOutlet weak var vw_PaymentType: UIView!
    
    var str_Type : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = false
        
        self.commanMethod()

        self.navigationItem.title = get_Data.str_Customer_Title

    }
    override func viewWillAppear(_ animated: Bool) {
//        self.navigationController?.isNavigationBarHidden = false
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    //MARK: - Other Method -
    func commanMethod(){
        
        if str_Type != "completed"{
            vw_PaymentType.isHidden = true
        }
        
        lbl_CustomerName.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_SpouseName.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_Location.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_DateTime.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_StartTime.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_EndTime.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_DogName.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_Notes.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_PaymentType.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        
        tf_CustomerName.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 14))
        tf_SpouseName.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 14))
        tf_Location.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 14))
        tf_DateTime.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 14))
        lbl_StartTimeSelected.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 14))
        lbl_EndTimeSelected.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 14))
        tf_DogName.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 14))
        tv_Notes.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 14))
        
        tf_CustomerName.text = get_Data.str_Customer_Title
        tf_SpouseName.text = get_Data.str_Customer_Spouse_Name
        tf_Location.text = get_Data.str_Customer_Address
        tf_DateTime.text = localDateStringToString2(date:get_Data.str_Customer_DateOnly)
        lbl_StartTimeSelected.text = localDateStringToString(date: get_Data.str_Customer_StartTime)
        lbl_EndTimeSelected.text = localDateStringToString(date: get_Data.str_Customer_EndTime)
        tf_DogName.text = get_Data.str_Customer_DogName
        tv_Notes.text = get_Data.str_Customer_Note
    }
    
    //MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any){
        if str_Type == "navigation"{
            self.dismiss(animated: false, completion: nil)
        }else{
            self.navigationController?.popViewController(animated: true)
        }
    }
    @IBAction func btn_PaymentDetail(_ sender:Any){
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let view = storyboard.instantiateViewController(withIdentifier: "MyJobPaymentTypeViewController") as! MyJobPaymentTypeViewController
        view.get_Data = get_Data
        self.navigationController?.pushViewController(view, animated: true)
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

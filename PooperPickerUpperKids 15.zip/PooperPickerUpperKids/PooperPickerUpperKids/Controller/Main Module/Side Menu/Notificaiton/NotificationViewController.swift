//
//  NotificationViewController.swift
//  PooperPickerUpperKids
//
//  Created by Apple on 07/08/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import EmptyDataSet_Swift
import ViewAnimator

class NotificationViewController: UIViewController {
    
    private let animations = [AnimationType.from(direction: .bottom, offset: 30.0)]
    
    @IBOutlet var tbl_Main : UITableView!
    
    var arr_Main : NSMutableArray! = []
    
    var int_CountLoad: Int = 0
    
    //Bool Declaration
    var bool_Load: Bool = false
    var bool_ViewWill: Bool = false
    var bool_SearchMore: Bool = true
    
    //Refresh Controller
    var refresh_Item: UIRefreshControl?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        int_CountLoad = GlobalConstants.int_LoadMax
        bool_ViewWill = true
        bool_SearchMore = true
        
        arr_Main = []
        self.Post_CustomerListing(count : int_CountLoad)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //MARK: - Scrollview Delegate -
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        view.endEditing(true)
        if scrollView == tbl_Main{
            if tbl_Main.contentSize.height <= tbl_Main.contentOffset.y + tbl_Main.frame.size.height && tbl_Main.contentOffset.y >= 0 {
                if bool_Load == false && arr_Main.count != 0 {
                    self.Post_CustomerListing(count: int_CountLoad + GlobalConstants.int_LoadMax)
                }
            }
        }
    }
    
    
    //MARK: - Other Method -
    func commanMethod(){
        
        //Refresh Controller
        refresh_Item = UIRefreshControl()
        refresh_Item?.addTarget(self, action: #selector(self.refreshItem), for: .valueChanged)
        tbl_Main.addSubview(refresh_Item!)
        
        tbl_Main.emptyDataSetSource = self
        tbl_Main.emptyDataSetDelegate = self
      
    }
    @objc func refreshItem(_ refresh: UIRefreshControl) {
        if bool_Load == false {
            int_CountLoad = GlobalConstants.int_LoadMax
            bool_ViewWill = true
            bool_SearchMore = true
            
            self.Post_CustomerListing(count:int_CountLoad)
        }else{
            refresh_Item?.endRefreshing()
        }
    }
    func completedServiceCalling(){
        refresh_Item?.endRefreshing()
        bool_Load = false
        
        tbl_Main.reloadData()
        
        if bool_ViewWill == true{
            UIView.animate(views: self.tbl_Main.visibleCells, animations: animations, completion: {
            })
            bool_ViewWill = false
        }
    }
    
    //MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any){
        toggleLeft()
    }
    @IBAction func btn_Add(_ sender:Any){
        
    }
    @IBAction func btn_Delete(_ sender:Any){
        if arr_Main.count != 0{
            let alert = UIAlertController(title: GlobalConstants.appName, message: "Are you sure you want to delete notification history?", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: NSLocalizedString("Yes", comment: ""), style: UIAlertActionStyle.default, handler: { (action) in
                
                self.Post_DeleteNotification()
                
            }))
            alert.addAction(UIAlertAction(title: NSLocalizedString("No", comment: ""), style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    
    // MARK: - Get/Post Method -
    func Post_CustomerListing(count: Int){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)notification/get"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "skip" : "\(count - GlobalConstants.int_LoadMax)",
            "total" : "\(GlobalConstants.int_LoadMax)",
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "notification"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        
        if bool_SearchMore == true{
            bool_Load = true
            webHelper.startDownload()
        }
    }
    
    func Post_DeleteNotification(){
        
        //Declaration URL
        var strURL = "\(GlobalConstants.BaseURL)notification/delete"
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "delete"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = NSDictionary()
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.serviceWithAlertErrorMessage = true
        webHelper.startDownload()
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}

// MARK: - Table Delegate -
extension NotificationViewController : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr_Main.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return UITableViewAutomaticDimension
    }
    public func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 85
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cellIdentifier : String = "cell"
        
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for:indexPath as IndexPath) as! ListMyViewCustomeCollectioncell
        
        let obj = arr_Main[indexPath.row] as! GlobalObject
        cell.lbl_Tital.text = obj.str_Notification_Text
        cell.lbl_Address.text = obj.str_Notification_Time
        
        //Manage font
        cell.lbl_Tital.font = UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFont(font: 16))
        cell.lbl_Address.font = UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFont(font: 14))
        
        return cell;
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}


extension NotificationViewController : EmptyDataSetSource, EmptyDataSetDelegate
{
    func emptyDataSetShouldDisplay(_ scrollView: UIScrollView) -> Bool {
        
        if arr_Main.count == 0 && bool_Load == false{
            return true
        }
        return false
    }
    
    //Header image show in list
    func image(forEmptyDataSet scrollView: UIScrollView) -> UIImage? {
        
        return UIImage.init(named: "img_PlaceHeader")
    }
    
   
    //set tital in list
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        
        var text: String?
        var font: UIFont?
        var textColor: UIColor?
        
        textColor = UIColor.lightGray
        
        text = "No notification available"
        
        font = UIFont(name: GlobalConstants.kFontRegular, size:GlobalConstants.kFontRatio*14.0)
        
        if text == nil {
            return nil
        }
        var attributes: [NSAttributedStringKey: Any] = [:]
        if font != nil {
            attributes[NSAttributedStringKey.font] = font!
        }
        if textColor != nil {
            attributes[NSAttributedStringKey.foregroundColor] = textColor
        }
        
        textColor = UIColor.clear
        
        return NSAttributedString.init(string: text!, attributes: attributes)
    }
}



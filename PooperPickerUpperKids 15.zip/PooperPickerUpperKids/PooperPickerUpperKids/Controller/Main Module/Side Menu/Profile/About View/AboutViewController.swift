//
//  AboutViewController.swift
//  PooperPickerUpperKids
//
//  Created by Apple on 13/08/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit


class AboutViewController: UIViewController {

    @IBOutlet weak var tbl_Main: UITableView!
    
    var arr_Main : NSMutableArray! = ["First Name","Last Name","Email","Address","Parents Name 1","Parents Name 2","Change Password"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        tbl_Main.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

// MARK: - Table Delegate -
extension AboutViewController : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr_Main.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 45
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cellIdentifier : String = "cell2"
        if indexPath.row == arr_Main.count - 1{
            cellIdentifier = "cell"
        }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for:indexPath as IndexPath) as! ProfileViewCollectioncell
        
        cell.lbl_Tital.text = arr_Main[indexPath.row] as! String
        
        //Manage font
        cell.lbl_Tital.font = UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFont(font: 16))
        if indexPath.row != arr_Main.count - 1{
            cell.lbl_Description.font = UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFont(font: 15))
        }
        
        switch indexPath.row {
        case 0:
            cell.lbl_Description.text = objUser?.user_First_Name
        case 1:
            cell.lbl_Description.text = objUser?.user_Last_Name
        case 2:
            cell.lbl_Description.text = objUser?.user_Email
        case 3:
            cell.lbl_Description.text = objUser?.user_Address
        case 4:
            cell.lbl_Description.text = objUser?.user_Parent_Name_1
        case 5:
            cell.lbl_Description.text = objUser?.user_Parent_Name_2
        default:
            break
        }
        
        return cell;
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == arr_Main.count - 1{
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let view = storyboard.instantiateViewController(withIdentifier: "ChangePasswordViewController") as! ChangePasswordViewController
            self.navigationController?.pushViewController(view, animated: true)
        }
    }
}





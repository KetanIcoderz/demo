//
//  ChangeProfileDetailViewController.swift
//  PooperPickerUpperKids
//
//  Created by Apple on 21/08/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import SwiftMessages
import GooglePlaces
import GooglePlacePicker

class ChangeProfileDetailViewController: UIViewController, UINavigationControllerDelegate {

    var placesClient: GMSPlacesClient!
    
     @IBOutlet weak var img_Profile : UIImageView!
    
    @IBOutlet weak var tbl_Main: UITableView!
    
    @IBOutlet weak var lbl_FirstName: UILabel!
    @IBOutlet weak var lbl_LastName: UILabel!
    @IBOutlet weak var lbl_Address: UILabel!
    @IBOutlet weak var lbl_Parents1: UILabel!
    @IBOutlet weak var lbl_Parents2: UILabel!
    
    @IBOutlet weak var tf_FirstName: UITextField!
    @IBOutlet weak var tf_lastName: UITextField!
    @IBOutlet weak var tf_Address: UITextField!
    @IBOutlet weak var tf_Parents1: UITextField!
    @IBOutlet weak var tf_Parents2: UITextField!
    
    var str_Lat : String = ""
    var str_Long : String = ""
    
    let picker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        placesClient = GMSPlacesClient.shared()
        self.commanMethod()
    }
    override func viewWillAppear(_ animated: Bool) {
        
    }
    override func viewWillLayoutSubviews() {
        img_Profile.layer.cornerRadius = img_Profile.frame.size.height / 2
        img_Profile.layer.masksToBounds = true
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    //MARK: - Other Method -
    func commanMethod(){
        
        //Picker Delegates
        picker.delegate = self
        
        let vw_Table = tbl_Main.tableHeaderView
        vw_Table?.frame = CGRect(x: 0, y: 0, width: tbl_Main.frame.size.width, height: CGFloat(GlobalConstants.windowHeight * 0.7016491754))
        tbl_Main.tableHeaderView = vw_Table
        
        lbl_FirstName.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_LastName.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_Address.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_Parents1.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_Parents2.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        
        tf_FirstName.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))
        tf_lastName.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))
        tf_Address.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))
        tf_Parents1.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))
        tf_Parents2.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))

        
        tf_FirstName.text = objUser?.user_First_Name
        tf_lastName.text = objUser?.user_Last_Name
        tf_Address.text = objUser?.user_Address
        tf_Parents1.text = objUser?.user_Parent_Name_1
        tf_Parents2.text = objUser?.user_Parent_Name_2
        
        str_Lat = (objUser?.user_Lat)!
        str_Long = (objUser?.user_Long)!
        
        img_Profile.sd_setImage(with: URL(string: (objUser?.user_Photo)!), placeholderImage: UIImage(named: GlobalConstants.placeHolder_User))
    }
    
    //MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any){
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btn_Profile(_ sender:Any){
    
        let alert = UIAlertController(title: GlobalConstants.appName, message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: UIAlertActionStyle.default, handler: { (action) in
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera)
            {
                self.picker.sourceType = .camera
                self.picker.allowsEditing = true
                self.present(self.picker, animated: true, completion: nil)
            }
        }))
        alert.addAction(UIAlertAction(title: "Gallery", style: UIAlertActionStyle.default, handler: { (action) in
            self.picker.allowsEditing = true
            self.picker.sourceType = .photoLibrary
            
            self.present(self.picker, animated: true, completion: nil)
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
        
    }
    
    @IBAction func btn_Update(_ sender:Any){
        
        if((tf_FirstName.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please enter first name", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }else if((tf_lastName.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please enter last name", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }else  if((tf_Address.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please enter address", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }else  if((tf_Parents1.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please enter parents 1", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }else  if((tf_Parents2.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please enter parents 2", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }
        else
        {
            
            self.Post_UpdateProfile()
//            self.navigationController?.popViewController(animated: true)
//
//            messageBar.MessageShow(title: "Profile updated successfully", alertType: MessageView.Layout.cardView, alertTheme: .success, TopBottom: true)
        }
    }
    
    // MARK: - Get/Post Method -
    func Post_UpdateProfile(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)customer/update_profile"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "first_name" : tf_FirstName.text ?? "",
            "last_name" : tf_lastName.text,
            "address" : tf_Address.text,
            "parent_name_1" : tf_Parents1.text,
            "parent_name_2" : tf_Parents2.text,
            "lat" : str_Lat,
            "longs" : str_Long,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "update_profile"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.startDownload()
        
    }
    
    func Post_ChangeProfilePic(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)customer/upload_profile_img"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        
        //print("URL :\n\(strURL)\n============\n\(jsonData)")
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "upload_profile_img"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.indicatorShowOrHide = true
        webHelper.imageUpload = img_Profile.image
        webHelper.imageUploadName = "photo"
        webHelper.startDownloadWithImage()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}


extension ChangeProfileDetailViewController : UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        let config = GMSPlacePickerConfig(viewport: nil)
        let placePicker = GMSPlacePickerViewController(config: config)
        placePicker.delegate = self
        present(placePicker, animated: true, completion: nil)

    }
}

extension ChangeProfileDetailViewController : GMSPlacePickerViewControllerDelegate{
    func placePicker(_ viewController: GMSPlacePickerViewController, didPick place: GMSPlace) {
        // Dismiss the place picker, as it cannot dismiss itself.
        viewController.dismiss(animated: true, completion: nil)
        
        self.tf_Address.text = place.formattedAddress
        
        str_Lat = String(place.coordinate.latitude)
        str_Long = String(place.coordinate.longitude)
        
        //        print("Place name \(place.name)")
        //        print("Place address \(place.formattedAddress)")
        //        print("Place attributions \(place.attributions)")
    }
    
    func placePickerDidCancel(_ viewController: GMSPlacePickerViewController) {
        // Dismiss the place picker, as it cannot dismiss itself.
        viewController.dismiss(animated: true, completion: nil)
        
        print("No place selected")
    }
}


extension ChangeProfileDetailViewController : UIImagePickerControllerDelegate {
    //MARK: - Imagepicker Delegates
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        let chosenImage = info[UIImagePickerControllerEditedImage] as! UIImage
        self.img_Profile.image = chosenImage
//        isImage = true
        dismiss(animated:true, completion: nil)
        
        //Call save image in server
        self.Post_ChangeProfilePic()
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}


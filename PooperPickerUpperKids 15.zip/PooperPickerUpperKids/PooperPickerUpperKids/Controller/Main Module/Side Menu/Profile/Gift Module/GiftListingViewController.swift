//
//  GiftListingViewController.swift
//  PooperPickerUpperKids
//
//  Created by Apple on 04/10/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import FTImageViewer
import EmptyDataSet_Swift

class GiftListingViewController: UIViewController {

    //Declaration Tableview
    @IBOutlet var tbl_Main : UITableView!
    var indexpath_Header : NSIndexPath = NSIndexPath(row: 0, section: 0)
    
    //Array declaration
    var arr_Featured : NSMutableArray = []
    
    //Refresh Controller
    var refresh_FeaturedTab: UIRefreshControl?
    
    //Bool Declaration
    var bool_Load: Bool = false
    var bool_ViewWill: Bool = false
    var bool_SearchMore_Feature: Bool = true
    
    //Max Min Limit
    var int_CountLoad_Feature: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()
        
        //First time sevice call for featured product
        int_CountLoad_Feature = GlobalConstants.int_LoadMax
        bool_ViewWill = true
        self.Get_Product(count:int_CountLoad_Feature)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //MARK: - Scrollview Delegate -
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        if scrollView.tag >= 100 && scrollView is UICollectionView{
            let visibleRect = CGRect(origin: scrollView.contentOffset, size: scrollView.bounds.size)
            let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)
            
            let indexpath_Cell : NSIndexPath = NSIndexPath(row: scrollView.tag - 100, section: 0)
            print(indexpath_Cell.row)
            
            let obj : GiftListingObject = arr_Featured[scrollView.tag - 100] as! GiftListingObject
            let arr_Images : NSMutableArray = obj.arrImage_OtherTab;
            
            if (tbl_Main.indexPathsForVisibleRows?.contains(indexpath_Cell as IndexPath))! {
                let cellLocally = tbl_Main.cellForRow(at: indexpath_Cell as IndexPath) as! GiftListingTableviewCell
                let indexPath = cellLocally.cv_Sub.indexPathForItem(at: visiblePoint)
                
                cellLocally.pg_Product.currentPage = (indexPath?.row)!
                //  tbl_Main.reloadData()
            }
            
        }
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        //        print("call from scrollview")
        
        if scrollView == tbl_Main{
            if tbl_Main.contentSize.height <= tbl_Main.contentOffset.y + tbl_Main.frame.size.height && tbl_Main.contentOffset.y >= 0 {
                if bool_Load == false && arr_Featured.count != 0 {
                    self.Get_Product(count: int_CountLoad_Feature + GlobalConstants.int_LoadMax)
                }
            }
        }
    }
    
    
    //MARK: - Other Files -
    func commanMethod(){
        
        //Refresh Controller
        refresh_FeaturedTab = UIRefreshControl()
        refresh_FeaturedTab?.addTarget(self, action: #selector(self.refresh), for: .valueChanged)
        tbl_Main.addSubview(refresh_FeaturedTab!)
        
        tbl_Main.emptyDataSetSource = self
        tbl_Main.emptyDataSetDelegate = self
    }
    func reloadData(){
        tbl_Main.reloadData()
    }
    func completedServiceCalling(){
        //Comman fuction action
        refresh_FeaturedTab?.endRefreshing()
        bool_Load = false
    }
    
    //MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any){
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btn_FavTab(_ sender: Any){
        
        let alert = UIAlertController(title: GlobalConstants.appName, message: "Are you sure you want to buy this product?", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: NSLocalizedString("Buy", comment: ""), style: UIAlertActionStyle.default, handler: { (action) in
            let alert = UIAlertController(title: GlobalConstants.appName, message: "Successfully purchased product. Track your product showing in history page.", preferredStyle: UIAlertControllerStyle.alert)
            
            alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: ""), style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        }))
        alert.addAction(UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    // MARK: - refersh controller -
    @objc func refresh(_ refreshControl: UIRefreshControl) {
        
        if bool_Load == false {
            int_CountLoad_Feature = GlobalConstants.int_LoadMax
            bool_ViewWill = true
            bool_SearchMore_Feature = true
            
            self.Get_Product(count:int_CountLoad_Feature)
        }else{
            refresh_FeaturedTab?.endRefreshing()
        }
    }
    
    
    // MARK: - Get/Post Method -
    func Get_Product(count : Int){
        
        //Declaration URL
        let baseUrl = "https://shopkatika.com/development/api/v2/"
        var strURL = "\(baseUrl)get_products_new"
       
        //Get type when click on tab bar in header
        var set_Type : String = "Featured"
        
        //Pass data in dictionary
        var jsonData : NSMutableDictionary =  NSMutableDictionary()
        jsonData = [
            "user_id" : "417",
            "skip" : "\(count - GlobalConstants.int_LoadMax)",
            "total" : "\(count)",
            "type" : set_Type,
        ]
        
        if indexpath_Header.row == 0{
            jsonData["country_id"] = "0"
        }
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "get_products"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        
        
        //If first time call than only show loader otherwise not showing loader
        (arr_Featured.count == 0) ? (webHelper.indicatorShowOrHide = true) : (webHelper.indicatorShowOrHide = false)
        
        //Not limit for end data than only service call
        if bool_SearchMore_Feature == true{
            bool_Load = true
            webHelper.startDownload()
        }
        
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}


//MARK: - Home Object -
class GiftListingObject: NSObject {
    var str_ID : String = ""
    var str_Title : String = ""
    var str_SubTitle : String = ""
    var str_Prize : String = ""
    var str_DiscountPrize : String = ""
    var str_Site : String = ""
    var str_Image : String = ""
    var arrImage : NSMutableArray = []
    var str_ShopName : String = ""
    var str_PriceSymbol : String = ""
    
    //Lastest,Recommended,Recently tab
    var str_ID_OtherTab : String = ""
    var str_Title_OtherTab : String = ""
    var str_SubTitle_OtherTab : String = ""
    var str_Prize_OtherTab : String = ""
    var str_Site_OtherTab : String = ""
    var str_DiscountPrize_OtherTab : String = ""
    var str_Image_OtherTab : String = ""
    var arrImage_OtherTab : NSMutableArray = []
    var str_Fav_OtherTab : String = ""
    var str_ShopName_OtherTab : String = ""
    var str_PriceSymbol_OtherTab : String = ""
    var str_Product_CateogryName : String = ""
    
    //Advertisement
    var str_Adv_ID : String = ""
    var str_Adv_Type : String = ""
    var str_Adv_Image : String = ""
}



class GiftListingTableviewCell : UITableViewCell{
    //MARK: - Tableview View Cell -
    @IBOutlet weak var lbl_Title: UILabel!
    @IBOutlet weak var lbl_Point: UILabel!
    
    @IBOutlet weak var vw_SubView: UIView!
    
    @IBOutlet weak var cv_Sub: UICollectionView!
    @IBOutlet var pg_Product : UIPageControl!
    
    @IBOutlet weak var btn_Favorite : UIButton!
}


// MARK: - Tableview Files -
extension GiftListingViewController : UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return CGFloat(Int((GlobalConstants.windowHeight * 190)/GlobalConstants.screenHeightDeveloper))
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr_Featured.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for:indexPath as IndexPath) as! GiftListingTableviewCell
        
        let obj : GiftListingObject = arr_Featured[indexPath.row] as! GiftListingObject
        
        //Value Set
        cell.lbl_Title.text = (obj.str_Title_OtherTab ) as String
        
        //Manage Count for pagination
        let arr_Images : NSMutableArray = obj.arrImage_OtherTab;
        cell.pg_Product.numberOfPages = arr_Images.count
        cell.pg_Product.tag = indexPath.row
        cell.pg_Product.pageIndicatorTintColor = UIColor(patternImage:UIImage(named: "img_PageSelected")!)
        cell.pg_Product.currentPageIndicatorTintColor = UIColor(red: CGFloat((255 / 255.0)), green: CGFloat((130 / 255.0)), blue: CGFloat((0 / 255.0)), alpha: CGFloat(1.0))
        
        cell.btn_Favorite.tag = indexPath.row
        cell.btn_Favorite.addTarget(self, action: #selector(self.btn_FavTab(_:)), for:.touchUpInside)
        
        
        //Layer set
        cell.vw_SubView.layer.cornerRadius = 5.0
        cell.vw_SubView.layer.masksToBounds = true
        
        if obj.arrImage_OtherTab.count == 0 {
            cell.cv_Sub.isHidden = true
        }else{
            cell.cv_Sub.isHidden = false
        }
        
        cell.cv_Sub.tag = indexPath.row + 100
        cell.cv_Sub.delegate = self
        cell.cv_Sub.dataSource = self
        cell.cv_Sub.reloadData()
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
}



//MARK: - Collection View Cell -
class GiftListingViewCollectioncell : UICollectionViewCell{
    
    //cell for in cell product
    @IBOutlet weak var img_Product : UIImageView!
}


//MARK: - Collection View -
extension GiftListingViewController : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        //Returen number of cell with content available in array
       
            if (arr_Featured.count != 0){
                let obj : GiftListingObject = arr_Featured[collectionView.tag - 100] as! GiftListingObject
                let arr_Images : NSMutableArray = obj.arrImage_OtherTab;
                return arr_Images.count
            }
        return 0;
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        //This box for array in tableview cell
        return CGSize(width: collectionView.frame.size.width, height: collectionView.frame.size.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        var str_Identifier : String = "cell"
        
        let cell  = collectionView.dequeueReusableCell(withReuseIdentifier: str_Identifier, for: indexPath) as! GiftListingViewCollectioncell
        
        let obj : GiftListingObject = arr_Featured[collectionView.tag - 100] as! GiftListingObject
        let arr_Images : NSMutableArray = obj.arrImage_OtherTab;
        
        let obj2 : GiftListingObject = arr_Images[indexPath.row] as! GiftListingObject
        
        //This box for array in tableview cell
        cell.img_Product.sd_setImage(with: URL(string: obj2.str_Image_OtherTab as String), placeholderImage: UIImage(named: GlobalConstants.placeHolder_Comman))

        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        DispatchQueue.main.async {
            let cell  = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! GiftListingViewCollectioncell
            
            //Create arr for Slide image post to FTImageviewer
            var imageArray : [String] = []
            let obj : GiftListingObject = self.arr_Featured[collectionView.tag - 100] as! GiftListingObject
            let arr_Images : NSMutableArray = obj.arrImage_OtherTab;
            
            for i in 0...arr_Images.count-1{
                let obj : GiftListingObject = arr_Images[i] as! GiftListingObject
                imageArray += [obj.str_Image_OtherTab as String]
            }
            
            //Create arr for frame with all images position
            var views = [UIView]()
            for _ in 0...arr_Images.count-1 {
                views.append(cell.img_Product)
            }
            
            //Call method present imageviewer
            FTImageViewer.showImages(imageArray, atIndex: indexPath.row, fromSenderArray: views)
        }
    }
}




extension GiftListingViewController : WebServiceHelperDelegate{
    //MARK: - Webservice Helper -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        self.completedServiceCalling()
        
        let response = data as! NSDictionary
        if strRequest == "get_products" {
            
            //Manage Sub category Data
            let arr_result = response["Result"] as! NSArray
            
            var arr_StoreTemp : NSMutableArray = []
            for i in (0..<arr_result.count) {
                let dict_Data = arr_result[i] as! NSDictionary
                
                //Other Tab Demo data
                let obj = GiftListingObject ()
                obj.str_ID_OtherTab = dict_Data.getStringForID(key:"product_id")
                obj.str_Title_OtherTab = dict_Data.getStringForID(key:"p_title")  as String
                obj.str_SubTitle_OtherTab = dict_Data.getStringForID(key:"p_descriiption")
                obj.str_Prize_OtherTab = dict_Data.getStringForID(key:"price")
                obj.str_DiscountPrize_OtherTab = dict_Data.getStringForID(key:"discount_price")
                obj.str_Site_OtherTab = dict_Data.getStringForID(key:"site")
                obj.str_Fav_OtherTab = dict_Data.getStringForID(key:"is_favourite")
                obj.str_ShopName_OtherTab = dict_Data.getStringForID(key:"shop_name")
                obj.str_PriceSymbol_OtherTab = dict_Data.getStringForID(key:"price_symbole")
                
                //Image Array
                let arr_Image = dict_Data["product_images"] as! NSArray
                let arr_Image_Store : NSMutableArray = []
                for j in (0..<arr_Image.count){
                    let dict_DataOther = arr_Image[j] as! NSDictionary
                    
                    let obj1 = GiftListingObject ()
                    obj1.str_Image_OtherTab = dict_DataOther["image"] as! String
                    
                    arr_Image_Store.add(obj1)
                }
                
                obj.arrImage_OtherTab = arr_Image_Store
                
                arr_StoreTemp.add(obj)
            }
            
           
            if bool_ViewWill == true {
                arr_Featured = []
                int_CountLoad_Feature = arr_StoreTemp.count
            }else{
                int_CountLoad_Feature = int_CountLoad_Feature + arr_StoreTemp.count
            }
            
            for i in (0...arr_StoreTemp.count-1){
                arr_Featured.add(arr_StoreTemp[i])
            }
            
            //Load more data or not
            if GlobalConstants.int_LoadMax > arr_StoreTemp.count {
                //Bool Load more
                bool_SearchMore_Feature = false
            }
            else {
                //Bool Load more
                bool_SearchMore_Feature = true
            }
            
            bool_ViewWill = false
            self.reloadData()
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
        self.completedServiceCalling()
        self.reloadData()
    }
    
}


extension GiftListingViewController : EmptyDataSetSource, EmptyDataSetDelegate
{
    func emptyDataSetShouldDisplay(_ scrollView: UIScrollView) -> Bool {
        
        if arr_Featured.count == 0 && bool_Load == false{
            return true
        }
        return false
    }
    
    //Header image show in list
    func image(forEmptyDataSet scrollView: UIScrollView) -> UIImage? {
        
        return UIImage.init(named: "img_PlaceHeader")
    }
    
    
    //set tital in list
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        
        var text: String?
        var font: UIFont?
        var textColor: UIColor?
        
        textColor = UIColor.lightGray
        
        text = "No any gift available"
        
        font = UIFont(name: GlobalConstants.kFontRegular, size:GlobalConstants.kFontRatio*14.0)
        
        if text == nil {
            return nil
        }
        var attributes: [NSAttributedStringKey: Any] = [:]
        if font != nil {
            attributes[NSAttributedStringKey.font] = font!
        }
        if textColor != nil {
            attributes[NSAttributedStringKey.foregroundColor] = textColor
        }
        
        textColor = UIColor.clear
        
        return NSAttributedString.init(string: text!, attributes: attributes)
    }
}





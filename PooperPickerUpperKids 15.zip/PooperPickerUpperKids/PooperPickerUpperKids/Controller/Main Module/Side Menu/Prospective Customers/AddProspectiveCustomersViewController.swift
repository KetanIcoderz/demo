//
//  AddProspectiveCustomersViewController.swift
//  PooperPickerUpperKids
//
//  Created by Apple on 06/08/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import SwiftMessages
import ActionSheetPicker_3_0
import GooglePlaces
import GooglePlacePicker


class AddProspectiveCustomersViewController: UIViewController {

    var placesClient: GMSPlacesClient!

    var get_Data = GlobalObject()
   
    @IBOutlet weak var tbl_Main: UITableView!
    
    @IBOutlet weak var lbl_FirstName: UILabel!
    @IBOutlet weak var lbl_LastName: UILabel!
    @IBOutlet weak var lbl_DogName: UILabel!
    @IBOutlet weak var lbl_Address: UILabel!
    @IBOutlet weak var lbl_PhoneNumber: UILabel!
    @IBOutlet weak var lbl_Interest: UILabel!
    @IBOutlet weak var lbl_Comment: UILabel!
    
    @IBOutlet weak var vw_FirstName: extensionView!
    @IBOutlet weak var vw_LastName: extensionView!
    @IBOutlet weak var vw_DogName: extensionView!
    @IBOutlet weak var vw_Address: extensionView!
    @IBOutlet weak var vw_PhoneNumber: extensionView!
    @IBOutlet weak var vw_Comment: extensionView!
    @IBOutlet weak var vw_Interest: extensionView!
    
    @IBOutlet weak var tf_FirstName: UITextField!
    @IBOutlet weak var tf_lastName: UITextField!
    @IBOutlet weak var tf_DogName: UITextField!
    @IBOutlet weak var tf_Address: UITextField!
    @IBOutlet weak var tf_PhoneNumber: UITextField!
    @IBOutlet weak var tf_Interests: UITextField!
    
    @IBOutlet weak var tv_Comments: UITextView!
    
    @IBOutlet weak var btn_Save: UIButton!
    @IBOutlet weak var btn_Update: UIButton!
    @IBOutlet weak var btn_Delete: UIButton!
    @IBOutlet weak var btn_Edit: UIBarButtonItem!
    @IBOutlet weak var btn_Inerest: UIButton!
    
    @IBOutlet weak var con_Button: NSLayoutConstraint!
    
    @IBOutlet weak var vw_Bottom: UIView!
    
    var str_Lat : String = ""
    var str_Long : String = ""
    var str_Type : String = ""
    var str_Date : String = ""
    var str_TypeCustomer : String = ""
    var str_EditPage : String = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()

        placesClient = GMSPlacesClient.shared()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - Other Method -
    func commanMethod(){
        
        let vw_Table = tbl_Main.tableHeaderView
        vw_Table?.frame = CGRect(x: 0, y: 0, width: tbl_Main.frame.size.width, height: CGFloat(GlobalConstants.windowHeight * 0.7946026987))
        tbl_Main.tableHeaderView = vw_Table

        
        lbl_FirstName.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_LastName.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_DogName.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_Address.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_Interest.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_Comment.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        lbl_PhoneNumber.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        
        tf_FirstName.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))
        tf_lastName.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))
        tf_DogName.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))
        tf_Address.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))
        tf_Interests.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))
        tv_Comments.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))
        tf_PhoneNumber.font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))

        tf_Interests.attributedPlaceholder = NSAttributedString(string: "Select interests",
                                                                    attributes: [NSAttributedStringKey.foregroundColor: UIColor(red: 119.0/255.0, green: 119.0/255.0, blue: 119.0/255.0, alpha: 1.0)])
        
        var boolMatch : Bool = false
        if get_Data.str_Customer_Title == ""{
            self.navigationItem.title = "Add Prospective Customer"
            btn_Save .setTitle("Save", for: .normal)
            
            
            boolMatch = false
        }else{
            
            boolMatch = true
            
            if str_TypeCustomer == "contact"{
                self.navigationItem.title = "Prospective Customer"
                btn_Save .setTitle("Save to Prospective Customer", for: .normal)
                btn_Edit.tintColor = GlobalConstants.appColor
            }else{
                self.navigationItem.title = "Update Customer"
                btn_Save .setTitle("Convert to Customer", for: .normal)
                
            }
            
//            tf_FirstName.isUserInteractionEnabled = false
//            tf_lastName.isUserInteractionEnabled = false
//            tf_DogName.isUserInteractionEnabled = false
//            tf_Address.isUserInteractionEnabled = false
//            tf_Interests.isUserInteractionEnabled = false
//            tf_PhoneNumber.isUserInteractionEnabled = false
//            tv_Comments.isUserInteractionEnabled = false
            
            tf_FirstName.text = get_Data.str_Customer_FirstName
            tf_lastName.text = get_Data.str_Customer_LastName
            tf_DogName.text = get_Data.str_Customer_DogName
            tf_Address.text = get_Data.str_Customer_Address
            tf_Interests.text = get_Data.str_Customer_Interest
            tf_PhoneNumber.text = get_Data.str_Customer_PhoneNumber
            tv_Comments.text = get_Data.str_Customer_Note
            str_Lat = get_Data.str_Customer_Lat
            str_Lat = get_Data.str_Customer_Long
            str_Type = get_Data.str_Customer_JobType
            str_Date = get_Data.str_Customer_ProspectDate
            
            self.navigationItem.title = get_Data.str_Customer_Title
        }
        
        if get_Data.str_Customer_Title == ""{
            boolMatch = false
            self.btn_Update.removeFromSuperview()
        }else{
            if str_TypeCustomer == "contact"{
                boolMatch = false
                self.btn_Update.removeFromSuperview()
            }else{
                boolMatch = true
            }
        }
        
        if boolMatch == true{
            //Edit Page on
            if str_EditPage == "1"{
                btn_Edit.isEnabled = false
                btn_Edit.tintColor = GlobalConstants.appColor
            }else{
                tbl_Main.tableFooterView = UIView()
                btn_Inerest.isHidden = true
                
                vw_FirstName.borderWidth = 0.0
                vw_FirstName.borderWidth = 0.0
                vw_LastName.borderWidth = 0.0
                vw_DogName.borderWidth = 0.0
                vw_Address.borderWidth = 0.0
                vw_PhoneNumber.borderWidth = 0.0
                vw_Comment.borderWidth = 0.0
                vw_Interest.borderWidth = 0.0
                
                con_Button.constant = -CGFloat(GlobalConstants.windowHeight * 0.0749625)
                self.editable(edit: false)
                vw_Bottom.isHidden = true
            }
            
        }else{
            btn_Edit.isEnabled = false
            btn_Edit.tintColor = GlobalConstants.appColor
            tbl_Main.tableFooterView = UIView()
        }
        
    }
    func matchParamater() -> Bool{
        if((tf_FirstName.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please enter first name", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }else if((tf_lastName.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please enter last name", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }else if((tf_DogName.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please enter dog's name", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }else if((tf_Address.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please enter address", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }else if((tf_Interests.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please enter interest", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }else if((tf_PhoneNumber.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please enter phone number", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }
//        else if((tv_Comments.text?.isEmpty)! && GlobalConstants.developerTest == false){
//            //Alert show for Header
//            messageBar.MessageShow(title: "Please enter comments", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
//        }
        else if str_Type == "" ||  str_Type == "Contact Only" ||  str_Type == "Declined"{
            //Alert show for Header
            messageBar.MessageShow(title: "Please select reminder type", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }else{
            return true
        }
        
        return false
    }
    func editable(edit : Bool){
        self.view.endEditing(true)
        
        if edit{
            tf_FirstName.isUserInteractionEnabled = true
            tf_lastName.isUserInteractionEnabled = true
            tf_DogName.isUserInteractionEnabled = true
            tf_PhoneNumber.isUserInteractionEnabled = true
            tv_Comments.isUserInteractionEnabled = true
            btn_Inerest.isUserInteractionEnabled = true
        }else{
            tf_FirstName.isUserInteractionEnabled = false
            tf_lastName.isUserInteractionEnabled = false
            tf_DogName.isUserInteractionEnabled = false
            tf_PhoneNumber.isUserInteractionEnabled = false
            tv_Comments.isUserInteractionEnabled = false
            btn_Inerest.isUserInteractionEnabled = false
        }
    }
    
    
    //MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any){
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btn_Interest(_ sender:Any){
        let arr_Data : [Any] = ["Interested but check back","Not interested","No answer","No soliciting"]
        
        let picker = ActionSheetStringPicker(title: "Type of interest", rows: arr_Data, initialSelection:selectedIndex(arr: arr_Data as NSArray, value: tf_Interests.text! as String as NSString), doneBlock: { (picker, indexes, values) in
            
            self.tf_Interests.text = "\(values as! NSString as! String)"
            
        }, cancel: {ActionSheetStringPicker in return}, origin: sender)
        
        //        picker?.hideCancel = true
        picker?.setDoneButton(UIBarButtonItem(title: "Select", style: .plain, target: nil, action: nil))
        picker?.setCancelButton(UIBarButtonItem(title: "Cancel", style: .plain, target: nil, action: nil))
        picker?.toolbarButtonsColor = UIColor.black
        
        picker?.show()
        
        
    }
    @IBAction func btn_Save(_ sender:Any){
        
        if matchParamater() == true{
            
            if get_Data.str_Customer_Title == ""{
                self.Post_CreateCustomer()
            }else{
                 if str_TypeCustomer == "contact"{
                    self.Post_CreateCustomer()
                 }else{
                    
                    let alert = UIAlertController(title: GlobalConstants.appName, message: "Once you convert into customer it can't be undone. Do you wish to proceed?", preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Yes", style: UIAlertActionStyle.default, handler: { (action) in
                        self.Post_SwapCustomer(str_Id: self.get_Data.str_Customer_Id)
                    }))
                    alert.addAction(UIAlertAction(title: "No", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    @IBAction func btn_Delete(_ sender:Any){
        let alert = UIAlertController(title: GlobalConstants.appName, message: NSLocalizedString(ValidationMessages.AddCustomersViewController_Delete, comment: ""), preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: NSLocalizedString("Yes", comment: ""), style: UIAlertActionStyle.default, handler: { (action) in
            
            self.Post_DeleteCustomer(str_Id: self.get_Data.str_Customer_Id)
            
        }))
        alert.addAction(UIAlertAction(title: NSLocalizedString("No", comment: ""), style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func btn_Update(_ sender:Any){
        if matchParamater() == true{
            
            self.Post_UpdateCustomer()
        }
    }
    @IBAction func btn_Edit(_ sender:Any){
        
        //Edit Page on
        if str_EditPage == ""{
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let view = storyboard.instantiateViewController(withIdentifier: "AddProspectiveCustomersViewController") as! AddProspectiveCustomersViewController
            view.get_Data = get_Data
            view.str_EditPage = "1"
            self.navigationController?.pushViewController(view, animated: true)
        }
        
//        UIView.animate(withDuration: 0.3, delay: 0.0, options: .allowAnimatedContent, animations: {() -> Void in
//            if self.con_Button.constant != 0{
//                self.con_Button.constant = 0
//                self.editable(edit: true)
//            }else{
//                self.con_Button.constant = -CGFloat(GlobalConstants.windowHeight * 0.0749625)
//                self.editable(edit: false)
//            }
//            self.view.layoutIfNeeded()
//            // Ensures that all pending layout operations have been completed
//        }, completion: {(_ finished: Bool) -> Void in
//            if self.con_Button.constant == 0{
//                self.vw_Bottom.isHidden = false
//            }else{
//                self.vw_Bottom.isHidden = true
//            }
//        })
        
    }
    
    // MARK: - Get/Post Method -
    func Post_CreateCustomer(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)customer/create"
        
        var prosValue = ""
        if str_Date != ""{
            prosValue = str_Date
        }else{
            if str_Type == "Tomorrow"{
                var tenDaysfromNow: Date {
                    return (Calendar.current as NSCalendar).date(byAdding: .day, value: 1, to: Date(), options: [])!
                }
                prosValue = localDateToStrignDate2(date : tenDaysfromNow)
            }else{
                var tenDaysfromNow: Date {
                    return (Calendar.current as NSCalendar).date(byAdding: .day, value: 7, to: Date(), options: [])!
                }
                prosValue = localDateToStrignDate2(date : tenDaysfromNow)
            }
        }
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "customer_id" : get_Data.str_Customer_Id,
            "first_name" : tf_FirstName.text ?? "",
            "last_name" : tf_lastName.text ?? "",
            "dog_name" : tf_DogName.text ?? "",
            "address" : tf_Address.text ?? "",
            "interest" : tf_Interests.text ?? "",
            "phone_number" : addCountryCode(str_Get: tf_PhoneNumber.text ?? ""),
            "note" : tv_Comments.text ?? "",
            "lat" : str_Lat,
            "longs" : str_Long,
            "type" : "0",
            "pros_noty_date" : prosValue,
            "schedule" : "[]",
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "create"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.serviceWithAlertErrorMessage = true
        webHelper.startDownload()
    }
    
    func Post_SwapCustomer(str_Id : String){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)customer/swap"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "type" : "1",
            "customer_id" : str_Id,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "swap"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.serviceWithAlertErrorMessage = true
        webHelper.startDownload()
    }
    
    
    func Post_DeleteCustomer(str_Id : String){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)customer/delete"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "customer_id" : str_Id,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "delete"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.serviceWithAlertErrorMessage = true
        webHelper.startDownload()
    }
    
    func Post_UpdateCustomer(){
        
        //Declaration URL
        var strURL = "\(GlobalConstants.BaseURL)customer/update"
        
        var prosValue = ""
        if str_Date != ""{
            prosValue = str_Date
        }else{
            if str_Type == "Tomorrow"{
                var tenDaysfromNow: Date {
                    return (Calendar.current as NSCalendar).date(byAdding: .day, value: 1, to: Date(), options: [])!
                }
                prosValue = localDateToStrignDate2(date : tenDaysfromNow)
            }else{
                var tenDaysfromNow: Date {
                    return (Calendar.current as NSCalendar).date(byAdding: .day, value: 7, to: Date(), options: [])!
                }
                prosValue = localDateToStrignDate2(date : tenDaysfromNow)
            }
        }
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "customer_id" : get_Data.str_Customer_Id,
            "first_name" : tf_FirstName.text ?? "",
            "last_name" : tf_lastName.text ?? "",
            "dog_name" : tf_DogName.text ?? "",
            "address" : tf_Address.text ?? "",
            "interest" : tf_Interests.text ?? "",
            "phone_number" : addCountryCode(str_Get: tf_PhoneNumber.text ?? ""),
            "note" : tv_Comments.text ?? "",
            "lat" : str_Lat,
            "longs" : str_Long,
            "type" : "0",
            "pros_noty_date" : prosValue,
            "schedule" : "[]",
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "update"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.serviceWithAlertErrorMessage = true
        webHelper.startDownload()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension AddProspectiveCustomersViewController : UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        let config = GMSPlacePickerConfig(viewport: nil)
        let placePicker = GMSPlacePickerViewController(config: config)
        placePicker.delegate = self
        present(placePicker, animated: true, completion: nil)

        
//        placesClient.currentPlace(callback: { (placeLikelihoodList, error) -> Void in
//            if let error = error {
//                print("Pick Place error: \(error.localizedDescription)")
//                return
//            }
//
////            self.nameLabel.text = "No current place"
//            self.tf_Address.text = ""
//
//            if let placeLikelihoodList = placeLikelihoodList {
//                let place = placeLikelihoodList.likelihoods.first?.place
//                if let place = place {
////                    self.nameLabel.text = place.name
//                    self.tf_Address.text = place.formattedAddress?.components(separatedBy: ", ")
//                        .joined(separator: "\n")
//                }
//            }
//        })
//
    }
}

extension AddProspectiveCustomersViewController : GMSPlacePickerViewControllerDelegate{
    func placePicker(_ viewController: GMSPlacePickerViewController, didPick place: GMSPlace) {
        // Dismiss the place picker, as it cannot dismiss itself.
        viewController.dismiss(animated: true, completion: nil)
        
        self.tf_Address.text = place.formattedAddress
        
        str_Lat = String(place.coordinate.latitude)
        str_Long = String(place.coordinate.longitude)
        
//        print("Place name \(place.name)")
//        print("Place address \(place.formattedAddress)")
//        print("Place attributions \(place.attributions)")
    }
    
    func placePickerDidCancel(_ viewController: GMSPlacePickerViewController) {
        // Dismiss the place picker, as it cannot dismiss itself.
        viewController.dismiss(animated: true, completion: nil)
        
        print("No place selected")
    }
}


// MARK: - Table Delegate -
extension AddProspectiveCustomersViewController : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 87
    }
    public func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 60
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cellIdentifier : String = "type"
        
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for:indexPath as IndexPath) as! AddCustomersViewTableViewcell
        
        if str_Type == "" || str_Type == "Prospect" || str_Type == "Contact Only" ||  str_Type == "Declined"{
            cell.lbl_Description.text = str_Date
            cell.tf_Description.text = str_Date
        }else{
            if str_Type != "Custom"{
                cell.lbl_Description.text = str_Type
                cell.tf_Description.text = str_Type
            }else{
                cell.lbl_Description.text = str_Date
                cell.tf_Description.text = str_Date
            }
        }

        if str_EditPage == ""{
            cell.vw_Extension.borderWidth = 0.0
            cell.img_Arrow.isHidden = true
        }
        
        
        cell.lbl_Tital.font = UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFont(font: 18))
        cell.lbl_Description.font = UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFont(font: 14))
        cell.tf_Description  .font =  UIFont(name: GlobalConstants.kFontOpenSansRegular, size: manageFontHeight(font: 16))
        cell.tf_Description.attributedPlaceholder = NSAttributedString(string: "Select reminder",
                                                                attributes: [NSAttributedStringKey.foregroundColor: UIColor(red: 119.0/255.0, green: 119.0/255.0, blue: 119.0/255.0, alpha: 1.0)])
        
        
        return cell;
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let arr_Data = ["Tomorrow","Next Week","Custom"]
        let picker = ActionSheetStringPicker(title: "Reminder", rows: arr_Data as! [Any], initialSelection:selectedIndex(arr: arr_Data as NSArray, value: str_Type as NSString), doneBlock: { (picker, indexes, values) in
            
            self.str_Type = values as! String
            if self.str_Type == "Custom"{
               
                    let datePicker = ActionSheetDatePicker(title: "Custom Date", datePickerMode:  UIDatePickerMode.date, selectedDate: Date(), doneBlock: {
                        picker, value, index in
        
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd"
                        self.str_Date = dateFormatter.string(from: (value as! NSDate) as Date)
                        
                        self.tbl_Main.reloadData()
                        return
                    }, cancel: { ActionStringCancelBlock in return }, origin: tableView)
                    datePicker?.minimumDate = Date()
                    datePicker?.show()
            }else{
                self.str_Date = ""
            }
            self.tbl_Main.reloadData()
        }, cancel: {ActionSheetStringPicker in return}, origin: tableView)
        
        picker?.setDoneButton(UIBarButtonItem(title: "Select", style: .plain, target: nil, action: nil))
        picker?.setCancelButton(UIBarButtonItem(title: "Cancel", style: .plain, target: nil, action: nil))
        picker?.toolbarButtonsColor = UIColor.black
        
        picker?.show()
            
    }
}


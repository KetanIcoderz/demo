//
//  TrainingViewController.swift
//  PooperPickerUpperKids
//
//  Created by Apple on 06/08/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import AVFoundation
import MediaPlayer
import AVFoundation
import AVKit
import EmptyDataSet_Swift

class TrainingViewController: UIViewController {

    @IBOutlet weak var vw_Header : UIView!
    @IBOutlet weak var vw_HeaderSub : UIView!
    
    @IBOutlet var cv_Header : UICollectionView!
    @IBOutlet var tbl_Main : UITableView!
    
    @IBOutlet var tf_Search : UITextField!
    
    var arr_Main : NSMutableArray! = []
    
    var tbl_reload_Number : NSIndexPath!
    var viewdidload: Bool = false
    var str_Search: String = ""
    var videoPlay = VideoObject()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.commanMethod()
        
        self.Post_Video(str_Text:"")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - Other Method -
    func commanMethod(){
        let str = "New York"
        let starWidth = str.widthOfString(usingFont: UIFont(name:  GlobalConstants.kFontOpenSansSemiBold, size: manageFont(font: 17))!)
        
        vw_Header.frame = CGRect(x: 0, y: 0, width: GlobalConstants.windowWidth - 100, height: 35)
        vw_HeaderSub.frame = CGRect(x: 0, y: 0, width: GlobalConstants.windowWidth - 120, height: 35)
        
        
        tbl_Main.emptyDataSetSource = self
        tbl_Main.emptyDataSetDelegate = self
        
        //Text change method in textfield
        tf_Search.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
    }
    func indexPaths(forSection section: Int, withNumberOfRows numberOfRows: Int) -> [Any] {
        var indexPaths = [Any]()
        for i in 0..<numberOfRows {
            let indexPath = IndexPath(row: i, section: section)
            indexPaths.append(indexPath)
        }
        return indexPaths
    }
    
    @objc func playerDidFinishPlaying(note: NSNotification) {
        Post_VideoWatch(str_Id: videoPlay.str_VideoID)
    }
    
    
    //MARK: - Button Method -
    @IBAction func btn_Back(_ sender:Any){
        toggleLeft()
    }

    @IBAction func btn_Section(_ sender: Any) {
        //Get animation with table view reload data
        //        cv_Main.beginUpdates()
        
        tbl_Main.beginUpdates()
        if ((tbl_reload_Number) != nil) {
            if (tbl_reload_Number.section == (sender as AnyObject).tag) {
                
                //Close Animation
                let obj : VideoObject = arr_Main[tbl_reload_Number.section] as! VideoObject
                let arr_DeleteIndex = self.indexPaths(forSection: ((sender as AnyObject).tag), withNumberOfRows: obj.arr_SaveVideos.count)
                
                let indexSet = IndexSet(integer: tbl_reload_Number.section)
                
                tbl_reload_Number = nil;
                tbl_Main.deleteRows(at: arr_DeleteIndex as! [IndexPath], with: .automatic)
                
            }else{
                
                let indexSet = IndexSet(integer: tbl_reload_Number.section)
                
                //Close Animation
                let objDelete : VideoObject = arr_Main[tbl_reload_Number.section] as! VideoObject
                
                let arr_DeleteIndex = self.indexPaths(forSection: tbl_reload_Number.section, withNumberOfRows:objDelete.arr_SaveVideos.count)
                
                tbl_reload_Number = nil;
                tbl_Main.deleteRows(at: arr_DeleteIndex as! [IndexPath], with: .automatic)
                
                let obj : VideoObject = arr_Main[(sender as AnyObject).tag] as! VideoObject
                if obj.arr_SaveVideos.count != 0 {
                    tbl_reload_Number = IndexPath(row: obj.arr_SaveVideos.count, section: (sender as AnyObject).tag) as NSIndexPath!
                    
                    //Open Animation
                    let arr_AddIndex = self.indexPaths(forSection: ((sender as AnyObject).tag), withNumberOfRows:obj.arr_SaveVideos.count)
                    tbl_Main.insertRows(at: arr_AddIndex as! [IndexPath], with: .automatic)
                    
//                    let indexSet = IndexSet(integer: (sender as AnyObject).tag)
//                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: {
//                        self.tbl_Main.reloadSections(indexSet)
//                    })
                }
            }
        }else{
            let obj : VideoObject = arr_Main[(sender as AnyObject).tag] as! VideoObject
            if obj.arr_SaveVideos.count != 0 {
                tbl_reload_Number = IndexPath(row: obj.arr_SaveVideos.count, section: (sender as AnyObject).tag) as NSIndexPath!
                
                //Open Animation
                let arr_AddIndex = self.indexPaths(forSection: ((sender as AnyObject).tag), withNumberOfRows: obj.arr_SaveVideos.count)
                tbl_Main.insertRows(at: arr_AddIndex as! [IndexPath], with: .automatic)
                
//                let indexSet = IndexSet(integer: (sender as AnyObject).tag)
//                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: {
//                    self.tbl_Main.reloadSections(indexSet)
//                })
            }
        }
        
        tbl_Main.endUpdates()

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: {
            self.tbl_Main.reloadData()
        })
    }
    
    // MARK: - Get/Post Method -
    func Post_Video(str_Text : String){
        
//        tf_Search.endEditing(true)
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)getvideo"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "search" : str_Search,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "getvideo"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.indicatorShowOrHide = false
        webHelper.startDownload()

    }
    func Post_VideoWatch(str_Id : String){
        
        //        tf_Search.endEditing(true)
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)comman/rewardpoint"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "video_id" : str_Id,
            "type" : "1",
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "rewardpoint"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.indicatorShowOrHide = false
        webHelper.startDownload()
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}


//MARK: - Collection View Cell -
class VidoeTableviewCell : UITableViewCell{
    @IBOutlet weak var img_Seleted: UIImageView!
    @IBOutlet weak var img_Arrow: UIImageView!
    
    @IBOutlet weak var lbl_Title: UILabel!
    
    @IBOutlet weak var btn_Click: UIButton!
}


extension TrainingViewController : UITableViewDelegate,UITableViewDataSource{
    // MARK: - Table View -
    func numberOfSections(in tableView: UITableView) -> Int{
        
        return arr_Main.count;
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        //If search and result 0 than show no data cell
        if ((tbl_reload_Number) != nil) {
            if (tbl_reload_Number.section == section) {
                let obj : VideoObject = arr_Main[section] as! VideoObject
                return obj.arr_SaveVideos.count;
            }
        }
        return 0
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CGFloat(GlobalConstants.windowHeight * 0.3373313343)
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return 50
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        var cellIdentifier : String = "section"
        
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)as! VidoeTableviewCell
        
        if arr_Main.count != 0 {
            let obj : VideoObject = arr_Main[section] as! VideoObject
            
            cell.lbl_Title.text = obj.str_VideoCategory
            
            //Button Event
            cell.btn_Click.tag = section;
            cell.btn_Click.addTarget(self, action:#selector(btn_Section(_:)), for: .touchUpInside)
            
        }else{
            cell.lbl_Title.text = "No video available"
        }
        
        //Manage font
        cell.lbl_Title.font = UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFont(font: 16))
        
        cell.img_Arrow.image = UIImage(named:"icon_ArrowDownButton")
        if tbl_reload_Number != nil{
            if tbl_reload_Number.section == section{
                cell.img_Arrow.image = UIImage(named:"icon_ArrowUpButton")
            }
        }
        
        return cell;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cellIdentifier : String = "cell"
        
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for:indexPath as IndexPath) as! VidoeTableviewCell
        
        let obj : VideoObject = arr_Main[indexPath.section] as! VideoObject
        let obj2 : VideoObject = obj.arr_SaveVideos[indexPath.row] as! VideoObject
        
        
        cell.img_Seleted.sd_setImage(with: URL(string: (obj2.str_VideoImage)), placeholderImage: UIImage(named: "img_Demo"))
        
//        DispatchQueue.global().async {
//            let asset = AVAsset(url: URL(string: obj2.str_VideoURL)!)
//            let assetImgGenerate : AVAssetImageGenerator = AVAssetImageGenerator(asset: asset)
//            assetImgGenerate.appliesPreferredTrackTransform = true
//            let time = CMTimeMake(1, 2)
//            let img = try? assetImgGenerate.copyCGImage(at: time, actualTime: nil)
//            if img != nil {
//               cell.img_Seleted.image  = UIImage(cgImage: img!)
//                DispatchQueue.main.async(execute: {
//                    // assign your image to UIImageView
//                })
//            }
//        }
        
        return cell;
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let obj : VideoObject = arr_Main[indexPath.section] as! VideoObject
        let obj2 : VideoObject = obj.arr_SaveVideos[indexPath.row] as! VideoObject
        videoPlay = obj2
        
        let avPlayer = AVPlayer(url: URL(string: obj2.str_VideoURL)!)
        let player = AVPlayerViewController()
        player.player = avPlayer
        
        avPlayer.play()
        
        NotificationCenter.default.addObserver(self, selector: #selector(playerDidFinishPlaying(note:)),
                                               name: NSNotification.Name.AVPlayerItemDidPlayToEndTime, object: avPlayer.currentItem)
        
        self.present(player, animated: true, completion: nil)
    }
    
}

extension TrainingViewController : EmptyDataSetSource, EmptyDataSetDelegate
{
    func emptyDataSetShouldDisplay(_ scrollView: UIScrollView) -> Bool {
        
        if arr_Main.count == 0{
            return true
        }
        return false
    }
    
    //Header image show in list
    func image(forEmptyDataSet scrollView: UIScrollView) -> UIImage? {
        
        return UIImage.init(named: "img_PlaceHeader")
    }
    
    //Set button title
   
    //set tital in list
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        
        var text: String?
        var font: UIFont?
        var textColor: UIColor?
        
        textColor = UIColor.lightGray
        
        text = "No training video"
        
        font = UIFont(name: GlobalConstants.kFontRegular, size:GlobalConstants.kFontRatio*14.0)
        
        if text == nil {
            return nil
        }
        var attributes: [NSAttributedStringKey: Any] = [:]
        if font != nil {
            attributes[NSAttributedStringKey.font] = font!
        }
        if textColor != nil {
            attributes[NSAttributedStringKey.foregroundColor] = textColor
        }
        
        textColor = UIColor.clear
        
        return NSAttributedString.init(string: text!, attributes: attributes)
    }
}






extension TrainingViewController : UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
//        self.Post_Video(str_Text: textField.text!)
        
        return true
    }
    
    @objc func textFieldDidChange(textField: UITextField){
        if (textField.text?.count)! > 2{
            str_Search = tf_Search.text!
            NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(changeText), object: nil)
            self.perform(#selector(changeText), with: nil, afterDelay: 0.5)
        }
        else{
            if textField.text == ""{
                str_Search = tf_Search.text!
                NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(changeText), object: nil)
                self.perform(#selector(changeText), with: nil, afterDelay: 0.5)
            }
        }
    }
    
    @objc func changeText(){
        
        arr_Main = []
        self.Post_Video(str_Text: tf_Search.text!)
    }
}

//
//  ReminderNotificationViewController.swift
//  PooperPickerUpperKids
//
//  Created by Apple on 17/09/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import ActionSheetPicker_3_0

class ReminderNotificationViewController: UIViewController {

    @IBOutlet weak var lbl_Header : UILabel!
    @IBOutlet weak var lbl_Description : UILabel!
    @IBOutlet weak var lbl_RemainderTitle : UILabel!
    @IBOutlet weak var lbl_RemainderSelected : UILabel!
    
    var indexSave : Int = 0
    
    let arr_Data = ["5 Min","10 Min","1 Hours","2 Hours"]
    let arr_DataValue = ["5","10","60","120"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        lbl_Header.text = "Prospective Cusomer"
        
        let dict_Data = dict_Push["aps"] as! NSDictionary
        lbl_Description.text = dict_Data["alert"] as? String
        
        lbl_Header.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: 14)
        lbl_Description.font =  UIFont(name: GlobalConstants.kFontKarlaRegular, size: 14)
        lbl_RemainderTitle.font =  UIFont(name: GlobalConstants.kFontKarlaRegular, size: 14)
        lbl_RemainderSelected.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: 14)

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    //MARK: - Other Method -
    @IBAction func btn_Back(_ sender:Any){
        if lbl_RemainderSelected.text != "Select"{
            self.Post_UpdateCustomer(str_Min: arr_DataValue[indexSave])
        }else{
            self.dismiss(animated: true, completion: nil)
        }
    }
    @IBAction func btn_Dismiss(_ sender:Any){
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func btn_Select(_ sender:Any){
        
        let picker = ActionSheetStringPicker(title: "Select time to remind later", rows: arr_Data as [Any], initialSelection:selectedIndex(arr: arr_Data as NSArray, value: lbl_RemainderSelected.text as! NSString), doneBlock: { (picker, indexes, values) in
            
            self.indexSave = indexes
            self.lbl_RemainderSelected.text = values as! String
           
        }, cancel: {ActionSheetStringPicker in return}, origin: lbl_RemainderSelected)
        
        picker?.setDoneButton(UIBarButtonItem(title: "Select", style: .plain, target: nil, action: nil))
        picker?.setCancelButton(UIBarButtonItem(title: "Cancel", style: .plain, target: nil, action: nil))
        picker?.toolbarButtonsColor = UIColor.black
        
        picker?.show()
    }
    
    //MARK: - Get/Post -
    func Post_UpdateCustomer(str_Min : String){
        
        let dict_Data = dict_Push["aps"] as! NSDictionary
        let dict = dict_Data["data"] as? NSDictionary
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)customer/snooze"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "customer_id" : dict?.getStringForID(key: "id"),
            "minutes" : str_Min,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "snooze"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = true
        webHelper.serviceWithAlertErrorMessage = true
        webHelper.startDownload()
    }
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  RecentsViewController.swift
//  Communication
//
//  Created by Apple on 09/07/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import EmptyDataSet_Swift
import Contacts
import ContactsUI
import AddressBook
import AddressBookUI

class RecentsViewController: UIViewController {

    @IBOutlet weak var tbl_Main: UITableView!
    
    @IBOutlet weak var tf_Search: UITextField!
    
    var arr_Main : NSMutableArray = []
    var arr_Main_Store : NSMutableArray = []
    var arr_Contact : NSMutableArray = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()
        self.fetchContacts()
        // Do any additional setup after loading the view.
        
        let plivoVC: PlivoCallController? = (tabBarController?.viewControllers?[0] as? PlivoCallController)
        Phone.sharedInstance.setDelegate(plivoVC!)
    }
    override func viewWillAppear(_ animated: Bool) {
        self.CallHistoryAPI()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    // MARK: - Other Methods -
    func commanMethod(){
        tf_Search.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        
        tf_Search.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 17))
        
        tf_Search.attributedPlaceholder = NSAttributedString(string: "Search",
                                                             attributes: [NSAttributedStringKey.foregroundColor: UIColor.white])
        
        tbl_Main.emptyDataSetSource = self
        tbl_Main.emptyDataSetDelegate = self
        
//        arr_Main = []
//        //data
//        var obj = GlobalObject()
//        obj.str_Recent_Title = "Annie Hall"
//        obj.str_Recent_Descriptino = "Synth polaroid bitters chillwave pickled.  Synth polaroid bitters chillwave pickled. Synth polaroid bitters chillwave pickled. Synth polaroid bitters chillwave pickled. "
//        obj.str_Recent_Image = "img_Demo"
//        obj.str_Recent_Live = "1"
//        obj.str_Recent_Time = "07:12"
//        arr_Main.add(obj)
//
//        obj = GlobalObject()
//        obj.str_Recent_Title = "Annie Hall"
//        obj.str_Recent_Descriptino = "Synth polaroid bitters chillwave pickled. "
//        obj.str_Recent_Image = "img_Demo"
//        obj.str_Recent_Live = "1"
//        obj.str_Recent_Time = "06:23"
//        arr_Main.add(obj)
//
//        obj = GlobalObject()
//        obj.str_Recent_Title = "Carolyn James"
//        obj.str_Recent_Descriptino = "Speaking of which, Peter really wants "
//        obj.str_Recent_Image = "img_Demo"
//        obj.str_Recent_Live = "1"
//        obj.str_Recent_Time = "06:00"
//        arr_Main.add(obj)
//
//        obj = GlobalObject()
//        obj.str_Recent_Title = "Anna Phillips"
//        obj.str_Recent_Descriptino = "+91 2415 3587 12"
//        obj.str_Recent_Image = "img_Demo"
//        obj.str_Recent_Live = "1"
//        obj.str_Recent_Time = "02:01"
//        arr_Main.add(obj)
        
//        arr_Main_Store = NSMutableArray(array: arr_Main);
    }
    func fetchContacts()
    {
        arr_Main = []
        
        let toFetch = [CNContactGivenNameKey,CNContactMiddleNameKey, CNContactImageDataKey, CNContactFamilyNameKey, CNContactImageDataAvailableKey,CNContactPhoneNumbersKey,CNContactEmailAddressesKey,CNContactPostalAddressesKey]
        let request = CNContactFetchRequest(keysToFetch: toFetch as [CNKeyDescriptor])
        
        do{
            try contactStore.enumerateContacts(with: request) {
                contact, stop in
                print(contact.givenName)
                print(contact.familyName)
                print(contact.identifier)
                
                let dict : NSMutableDictionary = [:]
                
                var userImage : UIImage;
                // See if we can get image data
                if let imageData = contact.imageData {
                    //If so create the image
                    userImage = UIImage(data: imageData)!
                }
                else{
                    userImage = UIImage(named: "icon_AppMain")!
                }
                
                var arr_Number : NSMutableArray = []
                
                for ContctNumVar: CNLabeledValue in contact.phoneNumbers
                {
                    let MobNumVar  = (ContctNumVar.value as! CNPhoneNumber).value(forKey: "digits") as? String
                    arr_Number.add(MobNumVar!)
                }
                
                for i in 0..<arr_Number.count{
                    var str_Number = arr_Number[i] as! String
                    if str_Number != "" && str_Number.characters.count >= 9{
                        if (str_Number.characters.count == 9){
                            str_Number = ("1\(str_Number)")
                        }
                        
                        let dict : NSMutableDictionary = [:]
                        dict.setValue(contact.givenName == "" ? str_Number : "\(contact.givenName) \(contact.familyName)", forKey: "name")
                        dict.setValue(userImage, forKey: "image")
                        dict.setValue(str_Number, forKey: "number")
                        dict.setValue("0", forKey: "select")
                        self.arr_Contact.add(dict)
                    }
                }
            }
        } catch let err{
            print(err)
        }
        let sort = NSSortDescriptor(key: "name", ascending: true)
        let arr = self.arr_Contact.sortedArray(using: [sort])
        self.arr_Contact = NSMutableArray(array: arr)
        
    }
    
    func ContactMatch(str_Match : String) -> NSMutableDictionary{
        for count in 0..<arr_Contact.count {
            let dict : NSMutableDictionary = arr_Contact[count] as! NSMutableDictionary
            let str_Value : String = dict["number"] as! String
            
            if str_Match == str_Value{
                return dict
            }
        }
        return [:]
    }
    
    
    

    
    //MARK: - Get/Post Api -
    func CallHistoryAPI(){
//        //Declaration URL
//        let strURL = "\(GlobalConstants.BaseURLPlivo)Call/"
//
//        //Pass data in dictionary
//        var jsonData : NSDictionary =  NSDictionary()
//
//        var jsonHeader : NSDictionary =  NSDictionary()
//        jsonHeader = [
//            "Authorization" : "Basic TUFNREUyWVRBM04ySTBaVEEyTjI6Tm1ZeE0yTmtOR1kyTlRJNVlXSTBOekU0Wm1NNU5tTmhOR0k0WVdRMw==",
//            "Content-Type" : "application/x-www-form-urlencoded",
//        ]
//
//        //Create object for webservicehelper and start to call method
//        let webHelper = WebServiceHelper()
//        webHelper.strMethodName = "Call"
//        webHelper.methodType = "get"
//        webHelper.strURL = strURL
//        webHelper.dictType = jsonData
//        webHelper.dictHeader = jsonHeader
//        webHelper.delegateWeb = self
//        webHelper.serviceWithAlert = true
//        webHelper.callingWithXwwwFormURLEncoded = true
//        webHelper.startDownload()
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURLCalling)account/call"
        
        var jsonData : NSDictionary =  NSDictionary()
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "Call"
        webHelper.methodType = "get"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.serviceWithAlertErrorMessage = true
        webHelper.startDownload()
        
    }
    
    func CallAPICalling(toNumber: String,fromNumber : String){
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURLCalling)account/call"
        
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "to" : toNumber,
            "from" : fromNumber,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "calling"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = true
        webHelper.startDownload()
    }
    func postAddContact(arr_Temp : NSMutableArray){
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURLCalling)contacts/add"
        
        let arrAdd : NSMutableArray = []
        for i in 0..<arr_Temp.count{
            let dict = arr_Temp[i] as! NSMutableDictionary
            
            var jsonData : NSDictionary =  NSDictionary()
            jsonData = [
                "first_name" : dict["name"] as! String,
                "last_name" : "",
                "phone" : dict["number"] as! String,
                "email" : dict["email"] as! String,
                "address" : dict["address"] as! String,
            ]
            arrAdd.add(jsonData)
        }
        let string = notPrettyString(from : arrAdd)
        
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "contacts" : string,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "add2"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.startDownload()
    }
   
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}


// MARK: - Tableview Cell -
class RecentsViewControllerTableViewCell: MGSwipeTableCell {
    // MARK: - Table Cell -
    @IBOutlet var lbl_Tital: UILabel!
    @IBOutlet var lbl_Description: UILabel!
    @IBOutlet var lbl_Time: UILabel!
    
    @IBOutlet var img_Icon: UIImageView!
    @IBOutlet var img_Live: UIImageView!
}



// MARK: - Tableview Delegate -

extension RecentsViewController : UITableViewDataSource,UITableViewDelegate,MGSwipeTableCellDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr_Main.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    public func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 72
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let str_Identifier : String = "cell"
        
        var cell = tableView.dequeueReusableCell(withIdentifier: str_Identifier)as! RecentsViewControllerTableViewCell
        cell.delegate = self
        cell.tag = indexPath.row
        
        let obj = arr_Main[indexPath.row] as! GlobalObject
        
        let watch = StopWatch(totalSeconds: Int(obj.str_Recent_CallDuration)!)
        
        cell.lbl_Tital.text = obj.str_Recent_Title == "" ? (obj.str_Recent_To_Number) : (obj.str_Recent_Title)
        cell.lbl_Description.text =  getTimeBetweenCurrentDateTo(date:obj.str_Recent_Initiation_Time)
        cell.lbl_Time.text = watch.getFormate

        cell.img_Icon.image = obj.img_Recent_Image
        
        cell.img_Live.isHidden = true
        if obj.str_Recent_Live == "1"{
            cell.img_Live.isHidden = false
        }
        
        //Declare text in icon in tableview cell
        cell.lbl_Tital.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: 17)
        cell.lbl_Description.font =  UIFont(name: GlobalConstants.kFontRegular, size: 15)
        cell.lbl_Time.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: 12)
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
    func swipeTableCell(_ cell: MGSwipeTableCell, canSwipe direction: MGSwipeDirection) -> Bool {
        return true;
    }
    
    
    func swipeTableCell(_ cell: MGSwipeTableCell, swipeButtonsFor direction: MGSwipeDirection, swipeSettings: MGSwipeSettings, expansionSettings: MGSwipeExpansionSettings) -> [UIView]? {
        
        let obj = arr_Main[cell.tag] as! GlobalObject
        
        swipeSettings.transition = MGSwipeTransition.border;
        swipeSettings.enableSwipeBounces = false
        expansionSettings.buttonIndex = 0;
        
        
        if direction == MGSwipeDirection.rightToLeft {
            expansionSettings.fillOnTrigger = true;
            expansionSettings.threshold = 1.1;
            let padding = 15;
            let color1 = UIColor(red: 53.0/255.0, green: 48.0/255.0, blue: 222.0/255.0, alpha: 1.0);
            let color2 = UIColor.init(red:76.0/255.0, green:217.0/255.0, blue:100.0/255.0, alpha:1.0);
            
            let flag = MGSwipeButton(title: "Chat", backgroundColor: color2, padding: padding, callback: { (cell) -> Bool in
                let index : IndexPath = (self.tbl_Main.indexPath(for: cell)! as NSIndexPath) as IndexPath
                
                let obj = self.arr_Main[index.row] as! GlobalObject
                
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let sub = storyboard.instantiateViewController(withIdentifier: "NewMessageViewController") as! NewMessageViewController
                sub.str_SendMessage = obj.str_Recent_To_Number
                let navEditorViewController: UINavigationController = UINavigationController(rootViewController: sub)
                navEditorViewController.isNavigationBarHidden = true
                navEditorViewController.navigationBar.isHidden = true
                self.present(navEditorViewController, animated: true, completion: nil)
                
                return true;
            });
            
            let trash = MGSwipeButton(title: "Call", backgroundColor: color1, padding: padding, callback: { (cell) -> Bool in
                let index : IndexPath = (self.tbl_Main.indexPath(for: cell)! as NSIndexPath) as IndexPath
                
                let obj = self.arr_Main[index.row] as! GlobalObject
                
                vw_Call.strCall = obj.str_Recent_To_Number
                self.tabBarController?.selectedViewController = self.tabBarController?.viewControllers?[0]
//                self.CallAPICalling(toNumber: obj.str_Recent_To_Number, fromNumber: (objUser?.user_Phone)!)
                
                return true; //don't autohide to improve delete animation
            });
            
            if obj.str_Recent_Title == ""{
                let AddContact = MGSwipeButton(title: "Add", backgroundColor: color2, padding: padding, callback: { (cell) -> Bool in
                    let index : IndexPath = (self.tbl_Main.indexPath(for: cell)! as NSIndexPath) as IndexPath
                    
                    let obj = self.arr_Main[index.row] as! GlobalObject
                    
                    let pNewContact = CNMutableContact()
                    pNewContact.phoneNumbers = [CNLabeledValue(
                        label:CNLabelPhoneNumberMain,
                        value:CNPhoneNumber(stringValue:obj.str_Recent_To_Number))]
                    
                    let addContactVC = CNContactViewController(forNewContact: pNewContact)
                    addContactVC.delegate = self
                    let navController = UINavigationController(rootViewController: addContactVC)
                    self.present(navController, animated: false)
                    
                    return true;
                });
                
                return [flag,trash,AddContact];
            }else{
                
                return [flag,trash];
            }
            
        }
        
        return nil
    }
    
}


extension RecentsViewController : EmptyDataSetSource, EmptyDataSetDelegate
{
    func emptyDataSetShouldDisplay(_ scrollView: UIScrollView) -> Bool {

        if arr_Main.count == 0 {
            return true
        }
        return false
    }
    
    //    func image(forEmptyDataSet scrollView: UIScrollView) -> UIImage? {
    //
    //        return UIImage.init(named: "img_NoData1")
    //    }
    //
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        
        var text: String?
        var font: UIFont?
        var textColor: UIColor?
        
        textColor = UIColor.darkGray
        
        text = "No recent data availble"
        
        font = UIFont(name: GlobalConstants.kFontRegular, size:GlobalConstants.kFontRatio*18.0 )
        
        if text == nil {
            return nil
        }
        var attributes: [NSAttributedStringKey: Any] = [:]
        if font != nil {
            attributes[NSAttributedStringKey.font] = font!
        }
        if textColor != nil {
            attributes[NSAttributedStringKey.foregroundColor] = textColor
        }
        
        textColor = UIColor.clear
        
        return NSAttributedString.init(string: text!, attributes: attributes)
    }
}

extension RecentsViewController : UITextFieldDelegate{
    
    
    // MARK: - Scrollview Manage -
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if scrollView == tbl_Main {
            view.endEditing(true)
        }
    }
    // MARK: - TextField Manage -
    func textFieldDidBeginEditing(_ textField: UITextField) {
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        
        if tf_Search == textField && tf_Search.text == "" {
    
            //Time of end editing than check if no data so we set all data in tableview
            arr_Main = NSMutableArray(array: arr_Main_Store);
            tbl_Main.reloadData()
        }
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if tf_Search == textField {
            view.endEditing(true)

            if tf_Search.text != "" {
                arr_Main = []
                let arr_Count = arr_Main_Store
                for count in 0..<arr_Count.count {

                    let obj : GlobalObject = arr_Count[count] as! GlobalObject
                    let Str: String = obj.str_Recent_Title.lowercased()

                    let searchText : String = textField.text!

                    //Specific word with matching
                    if Str.lowercased().range(of:searchText) != nil{
                        self.arr_Main.add(obj)
                    }
                }

            }else{
                arr_Main = NSMutableArray(array: arr_Main_Store);
            }
        }
        tbl_Main.reloadData()
        
        return true
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        if touch?.phase == .began {
            view.endEditing(true)
        }
    }
    @objc func textFieldDidChange(textField: UITextField){
        if tf_Search.text != "" {
            arr_Main = []
            let arr_Count = arr_Main_Store
            for count in 0..<arr_Count.count {

                let obj : GlobalObject = arr_Count[count] as! GlobalObject
                let Str: String = obj.str_Recent_Title.lowercased()

                let searchText : String = textField.text!

                //Specific word with matching
                if Str.lowercased().range(of:searchText) != nil{
                    self.arr_Main.add(obj)
                }
            }
        }else{
            arr_Main = NSMutableArray(array: arr_Main_Store);
//            btn_CancelSearch.isHidden = true
        }

        tbl_Main.reloadData()
    }
    
}





extension RecentsViewController : CNContactViewControllerDelegate{
    func contactViewController(_ viewController: CNContactViewController, didCompleteWith contact: CNContact?) {
        if contact != nil{
            let arr_Temp : NSMutableArray = []
            
            print(contact?.givenName)
            print(contact?.familyName)
            print(contact?.identifier)
            
            let dict : NSMutableDictionary = [:]
            
            var userImage : UIImage;
            // See if we can get image data
            if let imageData = contact?.imageData {
                //If so create the image
                userImage = UIImage(data: imageData)!
            }else{
                userImage = UIImage(named: "icon_AppMain")!
            }
            
            var str_Number : String = ""
            var str_Email : String = ""
            var str_Address : String = ""
            
            for ContctNumVar: CNLabeledValue in (contact?.phoneNumbers)!
            {
                let MobNumVar  = (ContctNumVar.value as! CNPhoneNumber).value(forKey: "digits") as? String
                str_Number = MobNumVar!
                break
            }
            for ContctNumVar: CNLabeledValue in (contact?.emailAddresses)!
            {
                str_Email = ContctNumVar.value as String
                break
            }
            
            for ContctNumVar: CNLabeledValue in (contact?.postalAddresses)!
            {
                if let address = ContctNumVar.value as? CNPostalAddress {
                    if address.street != ""{
                        str_Address = address.street
                    }
                    
                    if address.city != ""{
                        if str_Address != ""{
                            str_Address = "\(str_Address), \(address.city)"
                        }else{
                            str_Address = address.city
                        }
                    }
                    
                    if address.state != ""{
                        if str_Address != ""{
                            str_Address = "\(str_Address), \(address.state)"
                        }else{
                            str_Address = address.state
                        }
                    }
                    
                    if address.postalCode != ""{
                        if str_Address != ""{
                            str_Address = "\(str_Address) - \(address.postalCode)"
                        }else{
                            str_Address = address.postalCode
                        }
                    }
                    
                    if address.country != ""{
                        if str_Address != ""{
                            str_Address = "\(str_Address) \n\(address.country)"
                        }else{
                            str_Address = address.country
                        }
                    }
                }
                break
            }
            
            if str_Number != "" && str_Number.characters.count >= 9{
                if (str_Number.characters.count == 9){
                    str_Number = ("1\(str_Number)")
                }
                
                dict.setValue(contact?.givenName == "" ? str_Number : "\(contact?.givenName) \(contact?.middleName)", forKey: "name")
                dict.setValue(userImage, forKey: "image")
                dict.setValue(str_Number, forKey: "number")
                dict.setValue("0", forKey: "select")
                dict.setValue(str_Email, forKey: "email")
                dict.setValue(str_Address, forKey: "address")
                arr_Temp.add(dict)
                self.postAddContact(arr_Temp: arr_Temp)
            }
            
        }
        viewController.dismiss(animated: true, completion: nil)
    }
}




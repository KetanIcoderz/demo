//
//  ContactsViewController.swift
//  Communication
//
//  Created by Apple on 06/07/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import Contacts
import ContactsUI
import EmptyDataSet_Swift
import Contacts
import ContactsUI
import AddressBook
import AddressBookUI

protocol AddContactDelegate: class {
    func selectContact(dict_Data: NSMutableDictionary)
}

class ContactsViewController: UIViewController {

    var contacts = [CNContact]()
    var arr_Main : NSMutableArray = []
    var arr_Selected : NSMutableArray = []
    
    @IBOutlet weak var tbl_Main: UITableView!
    
    @IBOutlet weak var tf_Search: UITextField!
    
    @IBOutlet weak var vw_Done: UIView!
    
    weak var delegate : AddContactDelegate? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()
        
        self.fetchContacts()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Other Methods -
    func commanMethod(){
        tf_Search.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        
        tf_Search.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 17))
        
        tf_Search.attributedPlaceholder = NSAttributedString(string: "Search",
                                                               attributes: [NSAttributedStringKey.foregroundColor: UIColor.white])
        
        tbl_Main.emptyDataSetSource = self
        tbl_Main.emptyDataSetDelegate = self
    }
    
    func didFetchContacts(contacts: [CNContact]) {
        for contact in contacts {
            self.contacts.append(contact)
        }
    }
    func fetchContacts()
    {
        arr_Main = []
        
        let toFetch = [CNContactGivenNameKey,CNContactMiddleNameKey, CNContactImageDataKey, CNContactFamilyNameKey, CNContactImageDataAvailableKey,CNContactPhoneNumbersKey,CNContactEmailAddressesKey,CNContactPostalAddressesKey]
        let request = CNContactFetchRequest(keysToFetch: toFetch as [CNKeyDescriptor])
        
        do{
            try contactStore.enumerateContacts(with: request) {
                contact, stop in
                print(contact.givenName)
                print(contact.familyName)
                print(contact.identifier)
                
                var userImage : UIImage;
                // See if we can get image data
                if let imageData = contact.imageData {
                    //If so create the image
                    userImage = UIImage(data: imageData)!
                }else{
                    userImage = UIImage(named: "icon_AppMain")!
                }

                var str_Email : String = ""
                var str_Address : String = ""
                var arr_Number : NSMutableArray = []
                
                for ContctNumVar: CNLabeledValue in contact.phoneNumbers
                {
                    let MobNumVar  = (ContctNumVar.value as! CNPhoneNumber).value(forKey: "digits") as? String
                    arr_Number.add(MobNumVar!)
//                    break
                }
                for ContctNumVar: CNLabeledValue in contact.emailAddresses
                {
                    str_Email = ContctNumVar.value as String
                    break
                }
                
                for ContctNumVar: CNLabeledValue in (contact.postalAddresses)
                {
                    if let address = ContctNumVar.value as? CNPostalAddress {
                        if address.street != ""{
                            str_Address = address.street
                        }
                        
                        if address.city != ""{
                            if str_Address != ""{
                                str_Address = "\(str_Address), \(address.city)"
                            }else{
                                str_Address = address.city
                            }
                        }
                        
                        if address.state != ""{
                            if str_Address != ""{
                                str_Address = "\(str_Address), \(address.state)"
                            }else{
                                str_Address = address.state
                            }
                        }
                        
                        if address.postalCode != ""{
                            if str_Address != ""{
                                str_Address = "\(str_Address) - \(address.postalCode)"
                            }else{
                                str_Address = address.postalCode
                            }
                        }
                        
                        if address.country != ""{
                            if str_Address != ""{
                                str_Address = "\(str_Address) \n\(address.country)"
                            }else{
                                str_Address = address.country
                            }
                        }
                    }
                    
                    break
                }
                
                for i in 0..<arr_Number.count{
                    var str_Number = arr_Number[i] as! String
                    if str_Number != "" && str_Number.characters.count >= 9{
                        if (str_Number.characters.count == 9){
                            str_Number = ("1\(str_Number)")
                        }
                        
                        let dict : NSMutableDictionary = [:]
                        dict.setValue(contact.givenName == "" ? str_Number : "\(contact.givenName) \(contact.familyName)", forKey: "name")
                        dict.setValue(userImage, forKey: "image")
                        dict.setValue(str_Number, forKey: "number")
                        dict.setValue("0", forKey: "select")
                        dict.setValue(str_Email, forKey: "email")
                        dict.setValue(str_Address, forKey: "address")
                        self.arr_Main.add(dict)
                    }
                }
            }
        } catch let err{
            print(err)
//            self.errorStatus()
        }

        
        var sort = NSSortDescriptor(key: "name", ascending: true)
        let arr = self.arr_Main.sortedArray(using: [sort])
        self.arr_Main = NSMutableArray(array: arr)
        
        tbl_Main.reloadData()
        
    }
  
    func ContactData() -> NSMutableDictionary{
        let dict_Temp : NSMutableDictionary = [:]
        for count in 0..<arr_Main.count {
            let dict : NSMutableDictionary = arr_Main[count] as! NSMutableDictionary
            let str_Value : String = dict["name"] as! String
            
            
            let lowerBound = String.Index(encodedOffset: 0)
            let upperBound = String.Index(encodedOffset: 1)
            let data = str_Value[lowerBound ..< upperBound]
            var firstLetter = String(data)
            firstLetter = firstLetter.capitalized
            
            var arrayForLetter : NSMutableArray = []
            if let val = dict_Temp[firstLetter] {
                arrayForLetter = val as! NSMutableArray
            }
            
            if tf_Search.text != ""{
                
                var bool_Match : Bool = false
                let dict : NSMutableDictionary = arr_Main[count] as! NSMutableDictionary
                let str = dict["name"] as! String
                if str.lowercased().range(of:(tf_Search.text as! String).lowercased()) != nil{
                    bool_Match = true
                }
                
                if bool_Match == true{
                    arrayForLetter.add(arr_Main[count])
                    dict_Temp[firstLetter] = arrayForLetter
                }
            }else{
                arrayForLetter.add(arr_Main[count])
                dict_Temp[firstLetter] = arrayForLetter
            }
        }
        return dict_Temp
    }
    
    
    // MARK: - Button Event -
    @IBAction func btn_Dismiss(_ sender:Any) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func btn_Done(_ sender:Any) {
        if vw_Done.alpha == 1.0{
            if arr_Selected.count != 0{
                self.postAddContact()
            }
        }
    }
    @IBAction func btn_AddContact(_ sender : Any){
        
        let addContactVC = CNContactViewController(forNewContact: nil)
        addContactVC.delegate = self
        let navController = UINavigationController(rootViewController: addContactVC)
        self.present(navController, animated: false)
        
    }
    
    
    // MARK: - Get/Post API -
    func CallAPICalling(toNumber: String,fromNumber : String){
        //Declaration URL
//        let strURL = "\(GlobalConstants.BaseURLPlivo)Call/"
        let strURL = "\(GlobalConstants.BaseURL)account/call"
        
//        //Pass data in dictionary
//        var jsonData : NSDictionary =  NSDictionary()
//        jsonData = [
//            "to" : toNumber,
//            "from" : fromNumber,
//            "answer_url" : "http://icoderzsolutions.com/mantis/answer_xml.xml",
//            "answer_method" : "GET",
//        ]
//        
//        var jsonHeader : NSDictionary =  NSDictionary()
//        jsonHeader = [
//            "Authorization" : "Basic TUFNREUyWVRBM04ySTBaVEEyTjI6Tm1ZeE0yTmtOR1kyTlRJNVlXSTBOekU0Wm1NNU5tTmhOR0k0WVdRMw==",
//            "Content-Type" : "application/x-www-form-urlencoded",
//        ]
        
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "to" : toNumber,
            "from" : fromNumber,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "Call"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = true
//        webHelper.callingWithXwwwFormURLEncoded = true
        webHelper.startDownload()
    }
    func postAddContact(){
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)contacts/add"
        
         let arrAdd : NSMutableArray = []
         for i in 0..<arr_Selected.count{
            let dict = arr_Selected[i] as! NSMutableDictionary
            
            var jsonData : NSDictionary =  NSDictionary()
            jsonData = [
                "first_name" : dict["name"] as! String,
                "last_name" : "",
                "phone" : dict["number"] as! String,
                "email" : dict["email"] as! String,
                "address" : dict["address"] as! String,
            ]
            arrAdd.add(jsonData)
        }
        let string = notPrettyString(from : arrAdd)
        
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "contacts" : string,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "add"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = true
        webHelper.startDownload()
    }
    func postAddContact(arr_Temp : NSMutableArray){
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)contacts/add"
        
        let arrAdd : NSMutableArray = []
        for i in 0..<arr_Temp.count{
            let dict = arr_Temp[i] as! NSMutableDictionary
            
            var jsonData : NSDictionary =  NSDictionary()
            jsonData = [
                "first_name" : dict["name"] as! String,
                "last_name" : "",
                "phone" : dict["number"] as! String,
                "email" : dict["email"] as! String,
                "address" : dict["address"] as! String,
            ]
            arrAdd.add(jsonData)
        }
        let string = notPrettyString(from : arrAdd)
        
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "contacts" : string,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "add2"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = true
        webHelper.startDownload()
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}



// MARK: - Tableview Cell -
class ContactsViewControllerTablecell: MGSwipeTableCell {
    // MARK: - Table Cell -
    @IBOutlet var lbl_Title: UILabel!
    @IBOutlet var lbl_Description: UILabel!
    
    @IBOutlet var img_Selectred: UIImageView!
}


// MARK: - Tableview Delegate -
func sorterForFileIDASC(this:String, that:String) -> Bool {
    return this > that
}
extension ContactsViewController : UITableViewDataSource,UITableViewDelegate,MGSwipeTableCellDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if arr_Selected.count != 0{
            vw_Done.alpha = 1.0
        }else{
            vw_Done.alpha = 0.5
        }
        
        let dict_Data : NSMutableDictionary  = self.ContactData()
        
        var sortedArray = dict_Data.allKeys as! NSArray
        var sortedArray2 = sortedArray.sorted { ($0 as AnyObject).localizedCaseInsensitiveCompare($1 as! String) == ComparisonResult.orderedAscending }

        var arr = dict_Data[sortedArray2[section]] as! NSMutableArray
        
        return arr.count // Crash here
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        let dict_Data : NSMutableDictionary  = self.ContactData()
        return dict_Data.count;
    }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return 30
        
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {

        let cellIdentifier : String = "section"

        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)as! ContactsViewControllerTablecell

        let dict_Data : NSMutableDictionary  = self.ContactData()
        var sortedArray = dict_Data.allKeys
        var sortedArray2 = sortedArray.sorted { ($0 as AnyObject).localizedCaseInsensitiveCompare($1 as! String) == ComparisonResult.orderedAscending }

        cell.lbl_Title.text = sortedArray2[section] as? String
        cell.lbl_Title.font =  UIFont(name: GlobalConstants.kFontMyriadProSemiBold, size: 17)
        
        return cell;
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var str_Identifier : String = "cell"
        
        let dict_Data : NSMutableDictionary  = self.ContactData()
        
        var sortedArray = dict_Data.allKeys
        var sortedArray2 = sortedArray.sorted { ($0 as AnyObject).localizedCaseInsensitiveCompare($1 as! String) == ComparisonResult.orderedAscending }

        let arr = dict_Data[sortedArray2[indexPath.section]] as! NSMutableArray
        let dict = arr[indexPath.row] as! NSMutableDictionary
       
        var cell = tableView.dequeueReusableCell(withIdentifier: str_Identifier)as! ContactsViewControllerTablecell
        cell.delegate = self;
        
        //Declare text in icon in tableview cell
        cell.lbl_Title.text = dict["name"] as? String
        cell.lbl_Description.text = dict["number"] as? String
        
        cell.lbl_Title.font =  UIFont(name: GlobalConstants.kFontMyriadProSemiBold, size: 17)
        cell.lbl_Description.font =  UIFont(name: GlobalConstants.kFontMyriadProSemiBold, size: 15)
        
        var bool_Match : Bool = false
        for i in 0..<arr_Selected.count{
            let dictTemp : NSMutableDictionary = arr_Selected[i] as! NSMutableDictionary
            
            if dict["number"] as! String == dictTemp["number"] as! String{
                if dict["name"] as! String == dictTemp["name"] as! String{
                    bool_Match = true
                    break
                }
            }
        }
        
        
        if bool_Match == false{
            cell.img_Selectred.image = UIImage(named: "icon_Unselected")
        }else{
            cell.img_Selectred.image = UIImage(named: "icon_Selected")
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        if delegate != nil{
            let dict_Data : NSMutableDictionary  = self.ContactData()

            var sortedArray = dict_Data.allKeys
            var sortedArray2 = sortedArray.sorted { ($0 as AnyObject).localizedCaseInsensitiveCompare($1 as! String) == ComparisonResult.orderedAscending }

            let arr = dict_Data[sortedArray2[indexPath.section]] as! NSMutableArray
            let dict = arr[indexPath.row] as! NSMutableDictionary
            
            var bool_Match : Bool = false
            for i in 0..<arr_Selected.count{
                let dictTemp : NSMutableDictionary = arr_Selected[i] as! NSMutableDictionary
                
                if dict["number"] as! String == dictTemp["number"] as! String{
                    if dict["name"] as! String == dictTemp["name"] as! String{
                        bool_Match = true
                        arr_Selected.removeObject(at: i)
                        break
                    }
                }
            }
            if bool_Match == true{
            }else{
               arr_Selected.add(dict)
            }
            self.tbl_Main.reloadData()
//        }
    }
    
    
    func swipeTableCell(_ cell: MGSwipeTableCell, canSwipe direction: MGSwipeDirection) -> Bool {
        if delegate == nil{
            return false;
        }
        
        return false;
    }
    
    
    func swipeTableCell(_ cell: MGSwipeTableCell, swipeButtonsFor direction: MGSwipeDirection, swipeSettings: MGSwipeSettings, expansionSettings: MGSwipeExpansionSettings) -> [UIView]? {
        
        swipeSettings.transition = MGSwipeTransition.border;
        swipeSettings.enableSwipeBounces = false
        expansionSettings.buttonIndex = 0;
        
        
        if direction == MGSwipeDirection.rightToLeft {
            expansionSettings.fillOnTrigger = true;
            expansionSettings.threshold = 1.1;
            let padding = 15;
            let color1 = UIColor(red: 53.0/255.0, green: 48.0/255.0, blue: 222.0/255.0, alpha: 1.0);
            let color2 = UIColor.init(red:76.0/255.0, green:217.0/255.0, blue:100.0/255.0, alpha:1.0);
            
            let flag = MGSwipeButton(title: "Chat", backgroundColor: color2, padding: padding, callback: { (cell) -> Bool in
                let index : IndexPath = (self.tbl_Main.indexPath(for: cell)! as NSIndexPath) as IndexPath
                
                let dict_Data : NSMutableDictionary  = self.ContactData()
                
                var sortedArray = dict_Data.allKeys
                var sortedArray2 = sortedArray.sorted { ($0 as AnyObject).localizedCaseInsensitiveCompare($1 as! String) == ComparisonResult.orderedAscending }

                let arr = dict_Data[sortedArray2[index.section]] as! NSMutableArray
                let dict = arr[index.row] as! NSMutableDictionary
                
                
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let sub = storyboard.instantiateViewController(withIdentifier: "NewMessageViewController") as! NewMessageViewController
                sub.str_SendMessage = dict["number"] as! String
                let navEditorViewController: UINavigationController = UINavigationController(rootViewController: sub)
                navEditorViewController.isNavigationBarHidden = true
                navEditorViewController.navigationBar.isHidden = true
                self.present(navEditorViewController, animated: true, completion: nil)
                
                //                let mail = self.mailForIndexPath(self.tableView.indexPath(for: cell)!);
                //                mail.flag = !mail.flag;
                //                self.updateCellIndicator(mail, cell: cell as! MailTableCell);
                //                cell.refreshContentView(); //needed to refresh cell contents while swipping
                return true; //autohide
            });
            
            let trash = MGSwipeButton(title: "Call", backgroundColor: color1, padding: padding, callback: { (cell) -> Bool in
                let index : IndexPath = (self.tbl_Main.indexPath(for: cell)! as NSIndexPath) as IndexPath
                
                let dict_Data : NSMutableDictionary  = self.ContactData()
                
                var sortedArray = dict_Data.allKeys
                var sortedArray2 = sortedArray.sorted { ($0 as AnyObject).localizedCaseInsensitiveCompare($1 as! String) == ComparisonResult.orderedAscending }

                let arr = dict_Data[sortedArray2[index.section]] as! NSMutableArray
                let dict = arr[index.row] as! NSMutableDictionary
                self.CallAPICalling(toNumber: dict["number"] as! String, fromNumber: (objUser?.user_Phone_Number)!)
                
//                self.deleteMail(self.tableView.indexPath(for: cell)!);
                return true; //don't autohide to improve delete animation
            });
            
            return [flag,trash];
        }
        
        return nil
    }
}


extension ContactsViewController : EmptyDataSetSource, EmptyDataSetDelegate
    
{
    func emptyDataSetShouldDisplay(_ scrollView: UIScrollView) -> Bool {
        let dict_Data : NSMutableDictionary  = self.ContactData()
        var sortedArray = dict_Data.allKeys
        var sortedArray2 = sortedArray.sorted { ($0 as AnyObject).localizedCaseInsensitiveCompare($1 as! String) == ComparisonResult.orderedAscending }
        
        if sortedArray2.count == 0 {
            return true
        }
        return false
    }
    
//    func image(forEmptyDataSet scrollView: UIScrollView) -> UIImage? {
//
//        return UIImage.init(named: "img_NoData1")
//    }
//
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        
        var text: String?
        var font: UIFont?
        var textColor: UIColor?
        
        textColor = UIColor.darkGray
        
        text = "No contact found"
        
        font = UIFont(name: GlobalConstants.kFontRegular, size:GlobalConstants.kFontRatio*18.0 )
        
        if text == nil {
            return nil
        }
        var attributes: [NSAttributedStringKey: Any] = [:]
        if font != nil {
            attributes[NSAttributedStringKey.font] = font!
        }
        if textColor != nil {
            attributes[NSAttributedStringKey.foregroundColor] = textColor
        }
        
        textColor = UIColor.clear
        
        return NSAttributedString.init(string: text!, attributes: attributes)
    }
}

extension ContactsViewController : UITextFieldDelegate{
    @objc func textFieldDidChange(textField: UITextField){
        self.tbl_Main.reloadData()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.tbl_Main.reloadData()
        return true
    }
}


extension ContactsViewController : CNContactViewControllerDelegate{
    func contactViewController(_ viewController: CNContactViewController, didCompleteWith contact: CNContact?) {
        if contact != nil{
            let arr_Temp : NSMutableArray = []
            
            print(contact?.givenName)
            print(contact?.familyName)
            print(contact?.identifier)
            
            let dict : NSMutableDictionary = [:]
            
            var userImage : UIImage;
            // See if we can get image data
            if let imageData = contact?.imageData {
                //If so create the image
                userImage = UIImage(data: imageData)!
            }else{
                userImage = UIImage(named: "icon_AppMain")!
            }
            
            var str_Number : String = ""
            var str_Email : String = ""
            var str_Address : String = ""
            
            for ContctNumVar: CNLabeledValue in (contact?.phoneNumbers)!
            {
                let MobNumVar  = (ContctNumVar.value as! CNPhoneNumber).value(forKey: "digits") as? String
                str_Number = MobNumVar!
                break
            }
            for ContctNumVar: CNLabeledValue in (contact?.emailAddresses)!
            {
                str_Email = ContctNumVar.value as String
                break
            }
            
            for ContctNumVar: CNLabeledValue in (contact?.postalAddresses)!
            {
                if let address = ContctNumVar.value as? CNPostalAddress {
                    if address.street != ""{
                        str_Address = address.street
                    }
                    
                    if address.city != ""{
                        if str_Address != ""{
                            str_Address = "\(str_Address), \(address.city)"
                        }else{
                            str_Address = address.city
                        }
                    }
                    
                    if address.state != ""{
                        if str_Address != ""{
                            str_Address = "\(str_Address), \(address.state)"
                        }else{
                            str_Address = address.state
                        }
                    }
                    
                    if address.postalCode != ""{
                        if str_Address != ""{
                            str_Address = "\(str_Address) - \(address.postalCode)"
                        }else{
                            str_Address = address.postalCode
                        }
                    }
                    
                    if address.country != ""{
                        if str_Address != ""{
                            str_Address = "\(str_Address) \n\(address.country)"
                        }else{
                            str_Address = address.country
                        }
                    }
                }
              
                break
            }
            
            if str_Number != "" && str_Number.characters.count >= 9{
                if (str_Number.characters.count == 9){
                    str_Number = ("1\(str_Number)")
                }
                
                dict.setValue(contact?.givenName == "" ? str_Number : "\(contact?.givenName as! String) \(contact?.middleName as! String)", forKey: "name")
                dict.setValue(userImage, forKey: "image")
                dict.setValue(str_Number, forKey: "number")
                dict.setValue("0", forKey: "select")
                dict.setValue(str_Email, forKey: "email")
                dict.setValue(str_Address, forKey: "address")
                arr_Temp.add(dict)
                self.postAddContact(arr_Temp: arr_Temp)
            }
            
        }
        viewController.dismiss(animated: true, completion: nil)
    }
}




//extension String {
//    subscript (bounds: CountableClosedRange<Int>) -> String {
//        let start = index(startIndex, offsetBy: bounds.lowerBound)
//        let end = index(startIndex, offsetBy: bounds.upperBound)
//        return String(self[start...end])
//    }
//    
//    subscript (bounds: CountableRange<Int>) -> String {
//        let start = index(startIndex, offsetBy: bounds.lowerBound)
//        let end = index(startIndex, offsetBy: bounds.upperBound)
//        return String(self[start..<end])
//    }
//}

//
//  ContactsListViewController.swift
//  Communication
//
//  Created by Apple on 06/07/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import Contacts
import ContactsUI
import EmptyDataSet_Swift


class ContactsListViewController: UIViewController {
    
    var contacts = [CNContact]()
    var arr_Main : NSMutableArray = []
    
    @IBOutlet weak var tbl_Main: UITableView!
    
    @IBOutlet weak var tf_Search: UITextField!
    
    weak var delegate : AddContactDelegate? = nil
    
    @IBOutlet weak var btn_Cancel: UIBarButtonItem!
    
    var book_Back : Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()
        
//        let plivoVC: PlivoCallController? = (tabBarController?.viewControllers?[0] as? PlivoCallController)
//        Phone.sharedInstance.setDelegate(plivoVC!)
    }
    override func viewWillAppear(_ animated: Bool) {
        self.GetContact()
        
        if book_Back == true{
            btn_Cancel.isEnabled = true
            btn_Cancel.tintColor = UIColor.white
        }else{
            btn_Cancel.isEnabled = false
            btn_Cancel.tintColor = UIColor(red: 57/255, green: 54/255, blue: 217/255, alpha: 1.0)
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Other Methods -
    func commanMethod(){
        tf_Search.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        
        tf_Search.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 17))
        
        tf_Search.attributedPlaceholder = NSAttributedString(string: "Search",
                                                             attributes: [NSAttributedStringKey.foregroundColor: UIColor.white])
        
        tbl_Main.emptyDataSetSource = self
        tbl_Main.emptyDataSetDelegate = self
    }
  
    func ContactData() -> NSMutableDictionary{
        let dict_Temp : NSMutableDictionary = [:]
        for count in 0..<arr_Main.count {
            let dict : NSMutableDictionary = arr_Main[count] as! NSMutableDictionary
            let str_Value : String = dict["name"] as! String
            
            let lowerBound = String.Index(encodedOffset: 0)
            let upperBound = String.Index(encodedOffset: 1)
            let data = str_Value[lowerBound ..< upperBound]
            var firstLetter = String(data)
            firstLetter = firstLetter.capitalized
            
            var arrayForLetter : NSMutableArray = []
            if let val = dict_Temp[firstLetter] {
                arrayForLetter = val as! NSMutableArray
            }
            
            if tf_Search.text != ""{
                
                var bool_Match : Bool = false
                let dict : NSMutableDictionary = arr_Main[count] as! NSMutableDictionary
                let str = dict["name"] as! String
                if str.lowercased().range(of:(tf_Search.text as! String).lowercased()) != nil{
                    bool_Match = true
                }
                
                if bool_Match == true{
                    arrayForLetter.add(arr_Main[count])
                    dict_Temp[firstLetter] = arrayForLetter
                }
            }else{
                arrayForLetter.add(arr_Main[count])
                dict_Temp[firstLetter] = arrayForLetter
            }
        }
        
        return dict_Temp
    }
   
    
    // MARK: - Button Event -
    @IBAction func btn_Dismiss(_ sender:Any) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func btn_Import(_ sender:Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let sub = storyboard.instantiateViewController(withIdentifier: "ContactsViewController") as! ContactsViewController
        let navEditorViewController: UINavigationController = UINavigationController(rootViewController: sub)
        navEditorViewController.isNavigationBarHidden = true
        navEditorViewController.navigationBar.isHidden = true
        self.present(navEditorViewController, animated: true, completion: nil)
    }
    
    // MARK: - Get/POST API -
    func GetContact(){
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURLCalling)contacts"
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "contacts"
        webHelper.methodType = "get"
        webHelper.strURL = strURL
        webHelper.dictType = NSDictionary()
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.serviceWithAlertErrorMessage = true
        webHelper.startDownload()
    }
    func CallAPICalling(toNumber: String,fromNumber : String){
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURLCalling)account/call"
        
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "to" : toNumber,
            "from" : fromNumber,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "Call"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = true
        webHelper.startDownload()
    }
    func PostDeleteContact(id : String){
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURLCalling)contact/delete"
        
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "contact_id" : id,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "contacts"
        if arr_Main.count == 1{
            webHelper.strMethodName = "delete"
        }
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = true
        webHelper.startDownload()
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}


// MARK: - Tableview Delegate -

extension ContactsListViewController : UITableViewDataSource,UITableViewDelegate,MGSwipeTableCellDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let dict_Data : NSMutableDictionary  = self.ContactData()
        
        var sortedArray = dict_Data.allKeys
        var sortedArray2 = sortedArray.sorted { ($0 as AnyObject).localizedCaseInsensitiveCompare($1 as! String) == ComparisonResult.orderedAscending }
        
        var arr = dict_Data[sortedArray2[section]] as! NSMutableArray
        
        return arr.count
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        let dict_Data : NSMutableDictionary  = self.ContactData()
        return dict_Data.count;
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return 30
        
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let cellIdentifier : String = "section"
        
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)as! ContactsViewControllerTablecell
        
        let dict_Data : NSMutableDictionary  = self.ContactData()
        var sortedArray = dict_Data.allKeys
        var sortedArray2 = sortedArray.sorted { ($0 as AnyObject).localizedCaseInsensitiveCompare($1 as! String) == ComparisonResult.orderedAscending }
      
        
        cell.lbl_Title.text = sortedArray2[section] as? String
        cell.lbl_Title.font =  UIFont(name: GlobalConstants.kFontMyriadProSemiBold, size: 17)
        
        return cell;
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let str_Identifier : String = "cell"
        
        let dict_Data : NSMutableDictionary  = self.ContactData()
        
        var sortedArray = dict_Data.allKeys
        var sortedArray2 = sortedArray.sorted { ($0 as AnyObject).localizedCaseInsensitiveCompare($1 as! String) == ComparisonResult.orderedAscending }

        let arr = dict_Data[sortedArray2[indexPath.section]] as! NSMutableArray
        let dict = arr[indexPath.row] as! NSMutableDictionary
        
        var cell = tableView.dequeueReusableCell(withIdentifier: str_Identifier)as! ContactsViewControllerTablecell
        cell.delegate = self;
        
        //Declare text in icon in tableview cell
        cell.lbl_Title.text = dict["name"] as? String
        cell.lbl_Description.text = dict["number"] as? String
        
        cell.lbl_Title.font =  UIFont(name: GlobalConstants.kFontMyriadProSemiBold, size: 17)
        cell.lbl_Description.font =  UIFont(name: GlobalConstants.kFontMyriadProSemiBold, size: 15)
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if delegate != nil{
            let dict_Data : NSMutableDictionary  = self.ContactData()
            
            var sortedArray = dict_Data.allKeys
            var sortedArray2 = sortedArray.sorted { ($0 as AnyObject).localizedCaseInsensitiveCompare($1 as! String) == ComparisonResult.orderedAscending }

            let arr = dict_Data[sortedArray2[indexPath.section]] as! NSMutableArray
            let dict = arr[indexPath.row] as! NSMutableDictionary
            
            self .dismiss(animated: true) {
                self.delegate?.selectContact(dict_Data: dict)
            }
        }
    }
    
    
    func swipeTableCell(_ cell: MGSwipeTableCell, canSwipe direction: MGSwipeDirection) -> Bool {
        if delegate == nil{
            return true;
        }
        
        return false;
    }
    
    
    func swipeTableCell(_ cell: MGSwipeTableCell, swipeButtonsFor direction: MGSwipeDirection, swipeSettings: MGSwipeSettings, expansionSettings: MGSwipeExpansionSettings) -> [UIView]? {
        
        swipeSettings.transition = MGSwipeTransition.border;
        swipeSettings.enableSwipeBounces = false
        expansionSettings.buttonIndex = 0;
        
        
        if direction == MGSwipeDirection.rightToLeft {
            expansionSettings.fillOnTrigger = true;
            expansionSettings.threshold = 1.1;
            let padding = 15;
            let color1 = UIColor(red: 53.0/255.0, green: 48.0/255.0, blue: 222.0/255.0, alpha: 1.0);
            let color2 = UIColor.init(red:76.0/255.0, green:217.0/255.0, blue:100.0/255.0, alpha:1.0);
            let color3 = UIColor.red
            
            let flag = MGSwipeButton(title: "Chat", backgroundColor: color2, padding: padding, callback: { (cell) -> Bool in
                let index : IndexPath = (self.tbl_Main.indexPath(for: cell)! as NSIndexPath) as IndexPath
                
                let dict_Data : NSMutableDictionary  = self.ContactData()
                
                var sortedArray = dict_Data.allKeys
                var sortedArray2 = sortedArray.sorted { ($0 as AnyObject).localizedCaseInsensitiveCompare($1 as! String) == ComparisonResult.orderedAscending }

                let arr = dict_Data[sortedArray2[index.section]] as! NSMutableArray
                let dict = arr[index.row] as! NSMutableDictionary
                
                
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let sub = storyboard.instantiateViewController(withIdentifier: "NewMessageViewController") as! NewMessageViewController
                sub.str_SendMessage = dict["number"] as! String
                let navEditorViewController: UINavigationController = UINavigationController(rootViewController: sub)
                navEditorViewController.isNavigationBarHidden = true
                navEditorViewController.navigationBar.isHidden = true
                self.present(navEditorViewController, animated: true, completion: nil)
                
                //                let mail = self.mailForIndexPath(self.tableView.indexPath(for: cell)!);
                //                mail.flag = !mail.flag;
                //                self.updateCellIndicator(mail, cell: cell as! MailTableCell);
                //                cell.refreshContentView(); //needed to refresh cell contents while swipping
                return true; //autohide
            });
            
            let trash = MGSwipeButton(title: "Call", backgroundColor: color1, padding: padding, callback: { (cell) -> Bool in
                let index : IndexPath = (self.tbl_Main.indexPath(for: cell)! as NSIndexPath) as IndexPath
                
                let dict_Data : NSMutableDictionary  = self.ContactData()
                
                var sortedArray = dict_Data.allKeys
                var sortedArray2 = sortedArray.sorted { ($0 as AnyObject).localizedCaseInsensitiveCompare($1 as! String) == ComparisonResult.orderedAscending }

                let arr = dict_Data[sortedArray2[index.section]] as! NSMutableArray
                let dict = arr[index.row] as! NSMutableDictionary
                
                vw_Call.strCall = dict["number"] as! String
                self.tabBarController?.selectedViewController = self.tabBarController?.viewControllers?[0]
                
//                self.CallAPICalling(toNumber: dict["number"] as! String, fromNumber: (objUser?.user_Phone)!)
                
                return true; //don't autohide to improve delete animation
            });
            
            let flag3 = MGSwipeButton(title: "Delete", backgroundColor: color3, padding: padding, callback: { (cell) -> Bool in
                let index : IndexPath = (self.tbl_Main.indexPath(for: cell)! as NSIndexPath) as IndexPath
                
                let dict_Data : NSMutableDictionary  = self.ContactData()
                
                var sortedArray = dict_Data.allKeys
                var sortedArray2 = sortedArray.sorted { ($0 as AnyObject).localizedCaseInsensitiveCompare($1 as! String) == ComparisonResult.orderedAscending }
                
                let arr = dict_Data[sortedArray2[index.section]] as! NSMutableArray
                let dict = arr[index.row] as! NSMutableDictionary
                
                self.PostDeleteContact(id: dict["contact_id"] as! String)
                
                return true; //autohide
            });
            
            return [flag,trash,flag3];
        }
        
        return nil
    }
    
    
}


extension ContactsListViewController : EmptyDataSetSource, EmptyDataSetDelegate
    
{
    func emptyDataSetShouldDisplay(_ scrollView: UIScrollView) -> Bool {
        let dict_Data : NSMutableDictionary  = self.ContactData()
        var sortedArray = dict_Data.allKeys
        var sortedArray2 = sortedArray.sorted { ($0 as AnyObject).localizedCaseInsensitiveCompare($1 as! String) == ComparisonResult.orderedAscending }

        if sortedArray2.count == 0 {
            return true
        }
        return false
    }
    
    //    func image(forEmptyDataSet scrollView: UIScrollView) -> UIImage? {
    //
    //        return UIImage.init(named: "img_NoData1")
    //    }
    //
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        
        var text: String?
        var font: UIFont?
        var textColor: UIColor?
        
        textColor = UIColor.darkGray
        
        text = "No contact found"
        
        font = UIFont(name: GlobalConstants.kFontRegular, size:GlobalConstants.kFontRatio*18.0 )
        
        if text == nil {
            return nil
        }
        var attributes: [NSAttributedStringKey: Any] = [:]
        if font != nil {
            attributes[NSAttributedStringKey.font] = font!
        }
        if textColor != nil {
            attributes[NSAttributedStringKey.foregroundColor] = textColor
        }
        
        textColor = UIColor.clear
        
        return NSAttributedString.init(string: text!, attributes: attributes)
    }
}

extension ContactsListViewController : UITextFieldDelegate{
    @objc func textFieldDidChange(textField: UITextField){
        self.tbl_Main.reloadData()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.tbl_Main.reloadData()
        return true
    }
}




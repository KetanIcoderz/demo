//
//  NewMessageViewController.swift
//  Communication
//
//  Created by Apple on 09/07/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import THContactPicker
import Contacts
import ContactsUI
import EmptyDataSet_Swift
import IQKeyboardManagerSwift
import SwiftMessages



class NewMessageViewController: UIViewController, AddContactDelegate {
    
    @IBOutlet var contactPickerView: THContactPickerView!
    
    @IBOutlet weak var tbl_Main: UITableView!
    
    @IBOutlet weak var tv_Main: UITextView!
    
    @IBOutlet weak var con_Bottom: NSLayoutConstraint!
    @IBOutlet weak var con_Bottom2: NSLayoutConstraint!
    
    
    
    var arr_Main : NSMutableArray = []
    
    var str_TextField : String = ""
    var str_SendMessage : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()
        self.fetchContacts()
    }
    override func viewWillAppear(_ animated: Bool) {
        IQKeyboardManager.sharedManager().enable = false
    }
    override func viewWillDisappear(_ animated: Bool) {
        IQKeyboardManager.sharedManager().enable = true
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - Add Contact Delegate -
    func selectContact(dict_Data: NSMutableDictionary) {
        contactPickerView.addContact(dict_Data["number"] as? String, withName: dict_Data["number"] as? String)
        
        tbl_Main.isHidden = true
        str_TextField = ""
        tbl_Main.reloadData()
    }
    
    // MARK: - NSNotificationCenter
    @objc func keyboardDidShow(_ notification: Notification?) {
        if let keyboardFrame: NSValue = notification?.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue {
            let keyboardRectangle = keyboardFrame.cgRectValue
            let keyboardHeight = keyboardRectangle.height
            //            let duration:TimeInterval = (notification.userInfo![UIKeyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0
            
            UIView.animate(withDuration: 0.0, delay: 0.0, options: .allowAnimatedContent, animations: {() -> Void in
                self.con_Bottom.constant = keyboardHeight
                self.con_Bottom2.constant = keyboardHeight
                
                self.view.layoutIfNeeded()
                // Ensures that all pending layout operations have been completed
            }, completion: {(_ finished: Bool) -> Void in
            })
        }
    }
    
    @objc func keyboardDidHide(_ notification: Notification?) {
        // Move the scroll view back into its original position.
        UIView.animate(withDuration: 0.01, delay: 0.0, options: .allowAnimatedContent, animations: {() -> Void in
             self.con_Bottom.constant = 0
            self.con_Bottom2.constant = 10
            
            self.view.layoutIfNeeded()
            // Ensures that all pending layout operations have been completed
        }, completion: {(_ finished: Bool) -> Void in
        })
    }

    
    //MARK : - Other Methods -
    func commanMethod(){
//        contactPickerView = THContactPickerView(frame: CGRect(x: 0, y: 200, width: view.frame.size.width, height: 100.0))
        contactPickerView.autoresizingMask = [.flexibleBottomMargin, .flexibleWidth]
        contactPickerView.delegate = self
        contactPickerView.setPlaceholderLabelText("Contact")
        contactPickerView.setPromptLabelText("To:")
        contactPickerView.backgroundColor = UIColor.clear
        contactPickerView.setPlaceholderLabelTextColor(UIColor.lightGray)
        contactPickerView.setPromptLabelTextColor(UIColor.white)
        contactPickerView.setPromptTintColor(UIColor.white)
        
        let obj = THContactViewStyle()
        obj.textColor = UIColor.white
        contactPickerView.setContactViewStyle(obj, selectedStyle: nil)
        //[self.contactPickerView setLimitToOne:YES];
        view.addSubview(contactPickerView)
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardDidShow(_:)), name: .UIKeyboardDidShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardDidHide(_:)), name: .UIKeyboardDidHide, object: nil)
        
        tv_Main.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 17))
        
        tv_Main.text = "Enter Message"
        tv_Main.textColor = UIColor.lightGray
        
        if str_SendMessage != ""{
            contactPickerView.addContact(str_SendMessage, withName: str_SendMessage)
        }

    }
    
    func fetchContacts()
    {
        arr_Main = []

        let toFetch = [CNContactGivenNameKey,CNContactMiddleNameKey, CNContactImageDataKey, CNContactFamilyNameKey, CNContactImageDataAvailableKey,CNContactPhoneNumbersKey]
        let request = CNContactFetchRequest(keysToFetch: toFetch as [CNKeyDescriptor])

        do{
            try contactStore.enumerateContacts(with: request) {
                contact, stop in
                print(contact.givenName)
                print(contact.familyName)
                print(contact.identifier)

                let dict : NSMutableDictionary = [:]

                var userImage : UIImage;
                // See if we can get image data
                if let imageData = contact.imageData {
                    //If so create the image
                    userImage = UIImage(data: imageData)!
                }else{
                    userImage = UIImage(named: "icon_AppMain")!
                }

                var arr_Number : NSMutableArray = []
                
                for ContctNumVar: CNLabeledValue in contact.phoneNumbers
                {
                    let MobNumVar  = (ContctNumVar.value as! CNPhoneNumber).value(forKey: "digits") as? String
                    arr_Number.add(MobNumVar!)
                }

                for i in 0..<arr_Number.count{
                    var str_Number = arr_Number[i] as! String
                    if str_Number != "" && str_Number.characters.count >= 9{
                        if (str_Number.characters.count == 9){
                            str_Number = ("1\(str_Number)")
                        }
                        
                        let dict : NSMutableDictionary = [:]
                        dict.setValue(contact.givenName == "" ? str_Number : "\(contact.givenName) \(contact.familyName)", forKey: "name")
                        dict.setValue(userImage, forKey: "image")
                        dict.setValue(str_Number, forKey: "number")
                        dict.setValue("0", forKey: "select")
                        self.arr_Main.add(dict)
                    }
                }
            }
        } catch let err{
            print(err)
            //            self.errorStatus()
        }

        var sort = NSSortDescriptor(key: "name", ascending: true)
        let arr = self.arr_Main.sortedArray(using: [sort])
        self.arr_Main = NSMutableArray(array: arr)

        tbl_Main.reloadData()

    }
    
    func ContactData() -> NSMutableDictionary{
        let dict_Temp : NSMutableDictionary = [:]
        for count in 0..<arr_Main.count {
            let dict : NSMutableDictionary = arr_Main[count] as! NSMutableDictionary
            let str_Value : String = dict["name"] as! String
            
            let lowerBound = String.Index(encodedOffset: 0)
            let upperBound = String.Index(encodedOffset: 1)
            let data = str_Value[lowerBound ..< upperBound]
            var firstLetter = String(data)
            firstLetter = firstLetter.capitalized
            
            var arrayForLetter : NSMutableArray = []
            if let val = dict_Temp[firstLetter] {
                arrayForLetter = val as! NSMutableArray
            }
            
            if str_TextField != ""{
                
                var bool_Match : Bool = false
                let dict : NSMutableDictionary = arr_Main[count] as! NSMutableDictionary
                let str = dict["name"] as! String
                if str.lowercased().range(of:(str_TextField as! String).lowercased()) != nil{
                    bool_Match = true
                }
                
                if bool_Match == true{
                    arrayForLetter.add(arr_Main[count])
                    dict_Temp[firstLetter] = arrayForLetter
                }
            }else{
                arrayForLetter.add(arr_Main[count])
                dict_Temp[firstLetter] = arrayForLetter
            }
            
        }
        
        return dict_Temp
    }
    
    // MARK: - Button Event -
    @IBAction func btn_Dismiss(_ sender:Any) {
//        let arr = contactPickerView.getAllContacts()
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btn_Send(_ sender:Any) {
        let arr = contactPickerView.getAllContacts() as! NSMutableArray

        if arr.count == 0 && GlobalConstants.developerTest == false{
            //Alert show for Header
            messageBar.MessageShow(title: "Please select to contact", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
            
        }else if((tv_Main.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please enter message first", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
            
        }else{
            var messageName : String = ""
            let arr = contactPickerView.getAllContacts() as! NSMutableArray
            for i in 0..<arr.count{
                if i == 0{
                    messageName = addCountryCode(str_Get: arr[i] as! String)
                }else{
                    messageName = "\(messageName)<\(addCountryCode(str_Get: arr[i] as! String))"
                }
            }
            self.CallAPIMessage(dst: messageName, src: (objUser?.user_Phone_Number)!, text: tv_Main.text)
        }
    }
    
    
    func CallAPIMessage(dst: String,src : String,text : String){
//        //Declaration URL
//        let strURL = "\(GlobalConstants.BaseURLPlivo)Message/"
//
//        //Pass data in dictionary
//        var jsonData : NSDictionary =  NSDictionary()
//        jsonData = [
//            "dst" : dst,
//            "src" : src,
//            "text" : text,
//        ]
//
//        var jsonHeader : NSDictionary =  NSDictionary()
//        jsonHeader = [
//            "Authorization" : "Basic TUFNREUyWVRBM04ySTBaVEEyTjI6Tm1ZeE0yTmtOR1kyTlRJNVlXSTBOekU0Wm1NNU5tTmhOR0k0WVdRMw==",
//            "Content-Type" : "application/x-www-form-urlencoded",
//        ]
//
//        //Create object for webservicehelper and start to call method
//        let webHelper = WebServiceHelper()
//        webHelper.strMethodName = "Message"
//        webHelper.methodType = "post"
//        webHelper.strURL = strURL
//        webHelper.dictType = jsonData
//        webHelper.dictHeader = jsonHeader
//        webHelper.delegateWeb = self
//        webHelper.serviceWithAlert = true
//        webHelper.callingWithXwwwFormURLEncoded = true
//        webHelper.startDownload()
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURLCalling)message/send"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "from" : src,
            "to" : dst,
            "text" : text,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "Message"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = true
        webHelper.startDownload()
        
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        if segue.identifier == "addcontact"{
            let view = segue.destination as! ContactsListViewController
            view.delegate = self
            view.book_Back = true
        }
    }
}

// MARK: - Tableview Delegate -

extension NewMessageViewController : UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let dict_Data : NSMutableDictionary  = self.ContactData()
        
        var sortedArray = dict_Data.allKeys
        var arr = dict_Data[sortedArray[section]] as! NSMutableArray
        
        return arr.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        let dict_Data : NSMutableDictionary  = self.ContactData()
        return dict_Data.count;
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return 0
        
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let cellIdentifier : String = "section"
        
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)as! ContactsViewControllerTablecell
        
        let dict_Data : NSMutableDictionary  = self.ContactData()
        var sortedArray = dict_Data.allKeys
        
        cell.lbl_Title.text = sortedArray[section] as? String
        cell.lbl_Title.font =  UIFont(name: GlobalConstants.kFontMyriadProSemiBold, size: 17)
        
        return cell;
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 45
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let str_Identifier : String = "cell"
        
        let dict_Data : NSMutableDictionary  = self.ContactData()
        
        var sortedArray = dict_Data.allKeys
        let arr = dict_Data[sortedArray[indexPath.section]] as! NSMutableArray
        let dict = arr[indexPath.row] as! NSMutableDictionary
        
        var cell = tableView.dequeueReusableCell(withIdentifier: str_Identifier)as! ContactsViewControllerTablecell
        
        //Declare text in icon in tableview cell
        cell.lbl_Title.text = dict["name"] as? String
        cell.lbl_Title.font =  UIFont(name: GlobalConstants.kFontMyriadProSemiBold, size: 17)
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let dict_Data : NSMutableDictionary  = self.ContactData()
        
        var sortedArray = dict_Data.allKeys
        let arr = dict_Data[sortedArray[indexPath.section]] as! NSMutableArray
        let dict = arr[indexPath.row] as! NSMutableDictionary
        
        contactPickerView.addContact(dict["number"] as? String, withName: dict["number"] as? String)
        
        tbl_Main.isHidden = true
        str_TextField = ""
        tbl_Main.reloadData()
    }
}



extension NewMessageViewController : THContactPickerDelegate{
    func contactPicker(_ contactPicker: THContactPickerView!, textFieldShouldReturn textField: UITextField!) -> Bool {
        if (textField.text?.characters.count)! > 0 {
            let contact = textField.text
            contactPickerView.addContact(contact, withName: textField.text)
            
            tbl_Main.isHidden = true
            str_TextField = ""
            tbl_Main.reloadData()
        }
        

        return true
    }
    
    func contactPicker(_ contactPicker: THContactPickerView!, textFieldDidChange textField: UITextField!) {
        if textField.text != ""{
            tbl_Main.isHidden = false
        }else{
            tbl_Main.isHidden = true
        }
        str_TextField = textField.text!
        tbl_Main.reloadData()
    }
}

extension NewMessageViewController : UITextViewDelegate{
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == UIColor.lightGray {
            textView.text = nil
            textView.textColor = UIColor.white
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = "Enter Message"
            textView.textColor = UIColor.lightGray
        }
    }
}

//
//  PhoneViewController.swift
//  Communication
//
//  Created by Apple on 06/07/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import SwiftMessages

class PhoneViewController: UIViewController {

    @IBOutlet var btn_KeyBoard : [UIButton]!
    @IBOutlet var btn_DailBack : UIButton!
    
    @IBOutlet var lbl_HeaderTital : UILabel!
    @IBOutlet var lbl_Phone : UILabel!
    @IBOutlet var tf_Phone : VSTextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let plivoVC: PlivoCallController? = (tabBarController?.viewControllers?[0] as? PlivoCallController)
        Phone.sharedInstance.setDelegate(plivoVC!)
        
        self.commanMethod()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - Other Files -
    func commanMethod(){
        btn_DailBack.isHidden = true
        
        tf_Phone.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 25))
        lbl_HeaderTital.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 34))

//        tf_Phone.setFormatting("##-##-##", replacementChar: "#")
        tf_Phone.formatting = .phoneNumber
        tf_Phone.minimumFontSize = 8
    }
    func manageBackArrow(){
        if lbl_Phone.text != ""{
            btn_DailBack.isHidden = false
        }else{
            btn_DailBack.isHidden = true
        }
    }
    
    // MARK: - Button Event -
    @IBAction func btn_AddContact(_ sender:Any) {
        
    }
    @IBAction func btn_Dail(_ sender:Any) {
        
        if (sender as AnyObject).tag == 10 {
            lbl_Phone.text = "\(lbl_Phone.text as! String)*"
        }else if (sender as AnyObject).tag == 11 {
            lbl_Phone.text = "\(lbl_Phone.text as! String)#"
        }else{
            var str = String((sender as AnyObject).tag as! Int)
            str = "\(lbl_Phone.text as! String)\(str)"
            lbl_Phone.text = str
        }
        
        tf_Phone.text = ""
        tf_Phone.text = lbl_Phone.text
        tf_Phone.reloadInputViews()
        self.manageBackArrow()
    }
    @IBAction func btn_DailCall(_ sender: UIButton) {
        if((tf_Phone.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please enter phone number", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
            
        }else{
            CallAPICalling(toNumber: lbl_Phone.text!, fromNumber: (objUser?.user_Phone_Number)!)
        }
    }
    @IBAction func btn_DailBack(_ sender: UIButton) {
        var str = lbl_Phone.text as! String
        str = String(str.dropLast())
        lbl_Phone.text = str
        
        tf_Phone.text = ""
        tf_Phone.text = str
        self.manageBackArrow()
    }
    
    
    func CallAPICalling(toNumber: String,fromNumber : String){
        //Declaration URL
//        let strURL = "\(GlobalConstants.BaseURLPlivo)Call/"
        let strURL = "\(GlobalConstants.BaseURL)account/call"
        
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "to" : toNumber,
            "from" : fromNumber,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "Call"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = true
//        webHelper.callingWithXwwwFormURLEncoded = true
        webHelper.startDownload()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension PhoneViewController : UITextFieldDelegate{
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return false
    }
    
}

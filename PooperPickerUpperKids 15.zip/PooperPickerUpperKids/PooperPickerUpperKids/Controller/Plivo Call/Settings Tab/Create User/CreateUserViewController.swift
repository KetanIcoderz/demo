//
//  CreateUserViewController.swift
//  Communication
//
//  Created by Apple on 06/07/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit
import SwiftMessages

class CreateUserViewController: UIViewController {

    //Declaration Button
    @IBOutlet weak var btn_Login: UIButton!
    
    @IBOutlet weak var tf_UserName: HoshiTextField!
    @IBOutlet weak var tf_Email: HoshiTextField!
    @IBOutlet weak var tf_PhoneNumber: HoshiTextField!
    @IBOutlet weak var tf_Password: HoshiTextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()

        self.navigationController?.setNavigationBarHidden(true, animated: false)
    }
    override func viewWillDisappear(_ animated: Bool) {
//        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - Other Files -
    func commanMethod(){
        
        btn_Login.titleLabel?.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 16))
        
        tf_UserName.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 20))
        tf_Email.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 20))
        tf_PhoneNumber.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 20))
        tf_Password.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 20))
    
    }
    
    
    func validationPassword(tf_Get : UITextField,condition : Bool) -> Bool{
        
        //Validation for 1 Capital 1 Number value and 8 Length
        var validation : Int = 0
        
        //1 8 character Validatiaon
        if (tf_Get.text!.characters.count >= 8) {
            validation = validation + 1;
        }
        
        //2 capital letter or not
        var output = ""
        let string : String = tf_Get.text!
        for chr in string.characters {
            let str = String(chr)
            if str.lowercased() != str {
                output += str
            }
        }
        if output != "" {
            validation = validation + 1
        }
        
        //3 Number
        let str = tf_Get.text!
        let intString = str.components(
            separatedBy: NSCharacterSet
                .decimalDigits
                .inverted)
            .joined(separator: "")
        if intString != "" {
            validation = validation + 1
        }
        
        if validation > 2 {
            return true
        }
        return false
    }
    
    
    // MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btn_Login(_ sender:Any) {
        
        var boolEmail : Bool = true
        var boolPassword : Bool = true
        
        var isValidEmail : Bool = false
        
        if((tf_UserName.text?.isEmpty)! && GlobalConstants.developerTest == false){
            
            messageBar.MessageShow(title: "Please enter user name", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
            boolPassword = false
            
        }else if((tf_Email.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please enter email address", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
            
            boolEmail = false
        }else if(isValidEmail ==  validateEmail(enteredEmail: tf_Email.text!) && GlobalConstants.developerTest == false){
            if isValidEmail == true {
                
            }else{
                //Alert show for Header
                messageBar.MessageShow(title: "Please enter valid email address", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
                
                boolEmail = false
            }
        }
        
        if boolEmail == true{
            
            if((tf_PhoneNumber.text?.isEmpty)! && GlobalConstants.developerTest == false){
                
                messageBar.MessageShow(title: "Please enter phone number", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
                boolPassword = false
                
            }else if((tf_Password.text?.isEmpty)! && GlobalConstants.developerTest == false){
                
                messageBar.MessageShow(title: "Please enter password", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
                boolPassword = false
                
            }
//            else if validationPassword(tf_Get : tf_Password,condition : true) == false && GlobalConstants.developerTest == false{
//                //Alert show for Header
//                messageBar.MessageShow(title: "Please enter password with 1 Capital,1 Number,8 minimum characters", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
//
//                boolPassword = false
//            }
        }
        
        if boolEmail == true && boolPassword == true{
            self.view.endEditing(true)
            
            self.Post_RegisterUser()
        }
    }

    
    // MARK: - Get/Post Method -
    func Post_RegisterUser(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURLCalling)subadmin/create"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "user_name" : tf_UserName.text ?? "",
            "email" : tf_Email.text ?? "",
            "phone" : tf_PhoneNumber.text ?? "",
            "password" : tf_Password.text ?? "",
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "create"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = true
        webHelper.startDownload()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

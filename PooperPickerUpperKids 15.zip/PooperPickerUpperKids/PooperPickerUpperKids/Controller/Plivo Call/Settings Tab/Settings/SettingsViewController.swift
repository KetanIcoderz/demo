//
//  SettingsViewController.swift
//  Communication
//
//  Created by Apple on 10/07/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {

     @IBOutlet weak var tbl_Main: UITableView!
    
     @IBOutlet weak var btn_AddMember: UIButton!
    
    @IBOutlet weak var vw_Admin: UIView!
    
    var arr_Main: NSMutableArray = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        vw_Admin.isHidden = false
        
//        if objUser?.user_Is_Admin == "1"{
            self.Post_adminList()
//            vw_Admin.isHidden = true
//        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Button Event -
    @IBAction func btn_LogOut(_ sender:Any) {
        let alert = UIAlertController(title: GlobalConstants.appName, message: "Are you sure you want to logout?", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Yes", style: UIAlertActionStyle.default, handler: { (action) in
            //Handle your yes please button action here
            UtilClass.makeToastActivity()
            let plivoVC: PlivoCallController? = self.tabBarController?.viewControllers?[0] as? PlivoCallController
            Phone.sharedInstance.setDelegate(plivoVC!)
            plivoVC?.unRegisterSIPEndpoit()
//            self.Post_Logout()
        }))
        alert.addAction(UIAlertAction(title: "No", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    @IBAction func btn_AddMember(_ sender : Any){
        
    }
    
    // MARK: - Get/Post Method -
    func Post_Logout(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURLCalling)logout"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "logout"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = true
        webHelper.startDownload()
    }
    
    func Post_adminList(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURLCalling)subadmin/list"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        
        var jsonHeader : NSDictionary =  NSDictionary()
        jsonHeader = [
            "Authorization" : "Basic TUFNREUyWVRBM04ySTBaVEEyTjI6Tm1ZeE0yTmtOR1kyTlRJNVlXSTBOekU0Wm1NNU5tTmhOR0k0WVdRMw==",
            "Content-Type" : "application/x-www-form-urlencoded",
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "subadmin"
        webHelper.methodType = "get"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = jsonHeader
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.startDownload()
    }
    
    func Post_Deleteuser(id: String){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURLCalling)user/delete"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "user_id" : id,
        ]
        
        var jsonHeader : NSDictionary =  NSDictionary()
        jsonHeader = [
            "Authorization" : "Basic TUFNREUyWVRBM04ySTBaVEEyTjI6Tm1ZeE0yTmtOR1kyTlRJNVlXSTBOekU0Wm1NNU5tTmhOR0k0WVdRMw==",
            "Content-Type" : "application/x-www-form-urlencoded",
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "delete"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = jsonHeader
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = true
        webHelper.startDownload()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}



// MARK: - Tableview Delegate -

extension SettingsViewController : UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        let intvalue = 1 + arr_Main.count
//        return intvalue
        if section == 0{
            return 1
        }
        return arr_Main.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
//        if objUser?.user_Is_Admin == "1"{
          return 2
//        }
//        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return 30
        
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let cellIdentifier : String = "section"
        
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)as! RecentsViewControllerTableViewCell
        
        if section == 0{
            cell.lbl_Tital.text = "Profile"
        }else{
            cell.lbl_Tital.text = "Member List"
        }
        
        cell.lbl_Tital.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: 17)
        
        return cell;
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    public func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 72
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var str_Identifier : String = "cell"
        if indexPath.section != 0{
            str_Identifier = "cell2"
        }
        var cell = tableView.dequeueReusableCell(withIdentifier: str_Identifier)as! RecentsViewControllerTableViewCell
        
         if indexPath.section == 0{
            cell.lbl_Tital.text = objUser?.user_First_Name
            cell.lbl_Description.text = objUser?.user_First_Name
            
            //Declare text in icon in tableview cell
            cell.lbl_Tital.font =  UIFont(name: GlobalConstants.kFontMyriadProSemiBold, size: 17)
            cell.lbl_Description.font =  UIFont(name: GlobalConstants.kFontRegular, size: 15)
        }else{
            let obj = arr_Main[indexPath.row] as! GlobalObject
            
            cell.lbl_Tital.text = obj.str_User_Name
            
            //Declare text in icon in tableview cell
            cell.lbl_Tital.font =  UIFont(name: GlobalConstants.kFontMyriadProSemiBold, size: 17)
        }
        
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool{
        if indexPath.section == 0{
            return false
        }
        return true
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath){
        
        if editingStyle == .delete {
             let obj = arr_Main[indexPath.row] as! GlobalObject
            self.Post_Deleteuser(id: obj.str_User_Id)
        }
    }
}


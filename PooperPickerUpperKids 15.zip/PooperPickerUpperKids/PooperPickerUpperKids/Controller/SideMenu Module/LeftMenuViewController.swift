//
//  LeftMenuViewController.swift
//
//  Created by      on 5/4/17.
//  Copyright © 2017   . All rights reserved.
//

import UIKit
//import SlideMenuControllerSwift
import SwiftMessages
import SDWebImage
import PlivoVoiceKit

enum LeftMenu: Int {
    case home = 0
    case setting
    case logout
}

protocol LeftMenuProtocol : class {
    func changeViewController(_ menu: LeftMenu)
}

class LeftMenuCell : UITableViewCell {
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var imgLogo: UIImageView!
    @IBOutlet weak var btnSwitch: UIButton!
    
    @IBOutlet weak var lbl_NotificationCount: UILabel!
    @IBOutlet weak var img_NotificationCount: UIImageView!
}

class LeftMenuViewController : UIViewController, LeftMenuProtocol , UIImagePickerControllerDelegate , UINavigationControllerDelegate{
    
    //Declaration
    @IBOutlet weak var tableView: UITableView!
    
    var selectedIndex: Int = -1;
    var selectedColorIndex: Int = -1
    
    //Declaration Images
    @IBOutlet weak var img_Profile: UIImageView!
    var arrColor:[UIColor] = []
    
    //
    @IBOutlet weak var viewSetGoal: UIView!
    @IBOutlet weak var viewSetColor: UIView!
    @IBOutlet weak var viewSelectSchool: UIView!
    @IBOutlet weak var vw_Header: UIView!
    //Manage array for ExskuderMenu controller
    
    var menus: [[String: String]] = [["name":"Home","image":"icon_Home"],["name":"My Customers","image":"icon_AddCustomer"],["name":"Notifications","image":"icon_Notification"],["name":"Messages","image":"icon_Messages"],["name":"Call","image":"icon_Call"],["name":"Contacts","image":"icon_Contact"],["name":"Setup Jobs","image":"icon_Tommorow"],["name":"Prospective Customers","image":"icon_Prospective"],["name":"Training","image":"icon_Training"],["name":"Log Out","image":"icon_Logout"]] // Tomorrow's jobs, Current Job ,//Add Customer
    
    //Label Declaration
    @IBOutlet var lbl_UserName : UILabel!
    @IBOutlet var lbl_Address : UILabel!
    @IBOutlet var lbl_Switch : UILabel!
    
    @IBOutlet var sw_Run : UISwitch!
    
    //Alloc init viewcontroller
    var TabBarViewController: UIViewController!
    var SettingsViewController: UIViewController!
    var FeedBackViewController: UIViewController!
    var LeftMenuSchoolViewController: UIViewController!
    
    //Declare Sidebar controller
    var leftMenuSize = SlideMenuOptions.leftViewWidth
    var size : SlideMenuController = SlideMenuController()
    
    //View Manage
    @IBOutlet var vw_Profile : UIView!
    
    //Constant ste
    @IBOutlet var con_vw_Top : NSLayoutConstraint!
    
//    required init?(coder aDecoder: NSCoder) {
//        super.init(coder: aDecoder)
//    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()
        
        vw_LeftMenu = self
        
        //Editing ModeaDecoder
        //        if objUser?.user_Type == "0"{
//        menus = [["name":"Home","image":"icon_Home"],["name":"Add Customer","image":"icon_AddCustomer"],["name":"Notifications","image":"icon_Notification"],["name":"Messages","image":"icon_Messages"],["name":"Contacts","image":"icon_Contact"],["name":"Tomorrow's jobs, Current Job","image":"icon_Tommorow"],["name":"Prospective Customers","image":"icon_Prospective"],["name":"Training","image":"icon_Training"],["name":"Log Out","image":"icon_Logout"]]
        
        //        vw_BaseView = self
        
        //Declaration number of view added in left view contoller
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        //1. Home controller
        let TabBarViewController = storyboard.instantiateViewController(withIdentifier: "PlivoCallController") as! PlivoCallController
        self.TabBarViewController = UINavigationController(rootViewController: TabBarViewController)
        
        //        //2. Setting Controller
        //        let SettingsViewController = storyboard.instantiateViewController(withIdentifier: "SettingsViewController") as! SettingsViewController
        //        self.SettingsViewController = UINavigationController(rootViewController: SettingsViewController)
        //         self.commanMethod()
        //
        //        //3. FeedBack controller
        //        let FeedBackViewController = storyboard.instantiateViewController(withIdentifier: "FeedbackViewController") as! FeedbackViewController
        //        self.FeedBackViewController = UINavigationController(rootViewController: FeedBackViewController)
        //
        //        //3. Student Left controller
        //        let LeftMenuSchoolViewController = storyboard.instantiateViewController(withIdentifier: "LeftMenuSchoolViewController") as! LeftMenuSchoolViewController
        //        self.LeftMenuSchoolViewController = UINavigationController(rootViewController: LeftMenuSchoolViewController)
        
        if objUser?.user_RunMode == "1"{
            sw_Run.isOn = true
        }else{
            sw_Run.isOn = false
        }
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
        self.navigationController?.isNavigationBarHidden = true
        
        //Reload data
        self.reloadViewData()
        tableView.reloadData()
        
        lbl_UserName.text = "\(objUser?.user_First_Name as! String) \(objUser?.user_Last_Name as! String)"
        lbl_Address.text = objUser?.user_Address
        
        img_Profile.sd_setImage(with: URL(string: (objUser?.user_Photo)!), placeholderImage: UIImage(named: GlobalConstants.placeHolder_User))
        
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
    }
    
    
    // MARK: - Other Files -
    //Method for change view with other screen calling
    func commanMethod() {
        arrColor.append(UIColor(red: 0/255, green: 201/255, blue: 55/255, alpha: 1.0))
        arrColor.append(UIColor(red: 76/255, green: 131/255, blue: 253/255, alpha: 1.0))
        arrColor.append(UIColor(red: 164/255, green: 83/255, blue: 251/255, alpha: 1.0))
        arrColor.append(UIColor(red: 249/255, green: 70/255, blue: 179/255, alpha: 1.0))
        arrColor.append(UIColor(red: 188/255, green: 180/255, blue: 2/255, alpha: 1.0))
        arrColor.append(UIColor(red: 242/255, green: 249/255, blue: 56/255, alpha: 1.0))
        arrColor.append(UIColor(red: 178/255, green: 236/255, blue: 2/255, alpha: 1.0))
        arrColor.append(UIColor(red: 51/255, green: 255/255, blue: 180/255, alpha: 1.0))
        arrColor.append(UIColor(red: 43/255, green: 255/255, blue: 43/255, alpha: 1.0))
        arrColor.append(UIColor(red: 255/255, green: 210/255, blue: 3/255, alpha: 1.0))
        arrColor.append(UIColor(red: 255/255, green: 164/255, blue: 2/255, alpha: 1.0))
        arrColor.append(UIColor(red: 255/255, green: 174/255, blue: 87/255, alpha: 1.0))
        arrColor.append(UIColor(red: 255/255, green: 73/255, blue: 1/255, alpha: 1.0))
        arrColor.append(UIColor(red: 151/255, green: 123/255, blue: 182/255, alpha: 1.0))
        arrColor.append(UIColor(red: 242/255, green: 143/255, blue: 185/255, alpha: 1.0))
        
        img_Profile.layer.cornerRadius = CGFloat(GlobalConstants.windowHeight * 0.04872563718)
        img_Profile.layer.masksToBounds = true
        
        lbl_UserName.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 17))
        lbl_Address.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 14))
        lbl_Switch.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFontHeight(font: 16))
        
        let vw = tableView.tableHeaderView
        vw?.frame = CGRect(x: 0, y: 0, width: GlobalConstants.windowWidth, height: GlobalConstants.windowHeight * 0.08245877061)
        tableView.tableHeaderView = vw
        
    }
    func callmethod(_int_Value : Int) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)

        switch _int_Value {
        case 0:
            str_Home_Present = "1"
            let view = storyboard.instantiateViewController(withIdentifier: "PlivoCallController") as! PlivoCallController
            let nav = UINavigationController(rootViewController: view)
            
            self.slideMenuController()?.changeMainViewController(nav, close: true)
            break
        case 1:
            let view = storyboard.instantiateViewController(withIdentifier: "CustomersListingViewController") as! CustomersListingViewController
            let nav = UINavigationController(rootViewController: view)
            
            self.slideMenuController()?.changeMainViewController(nav, close: true)
            break
           
        case 2:
            let view = storyboard.instantiateViewController(withIdentifier: "NotificationViewController") as! NotificationViewController
            let nav = UINavigationController(rootViewController: view)
            
            self.slideMenuController()?.changeMainViewController(nav, close: true)
            break
            
        case 3:
            let view = storyboard.instantiateViewController(withIdentifier: "MessagePlivoViewController") as! MessagePlivoViewController
            let nav = UINavigationController(rootViewController: view)
            
            self.slideMenuController()?.changeMainViewController(nav, close: true)
            break
            
        case 4:
            str_Home_Present = "0"
            let view = storyboard.instantiateViewController(withIdentifier: "PlivoCallController") as! PlivoCallController
            let nav = UINavigationController(rootViewController: view)
            
            self.slideMenuController()?.changeMainViewController(nav, close: true)
            break
            
        case 5:
            let view = storyboard.instantiateViewController(withIdentifier: "ContactListingViewController") as! ContactListingViewController
            let nav = UINavigationController(rootViewController: view)
            
            self.slideMenuController()?.changeMainViewController(nav, close: true)
            
        case 6:
            let view = storyboard.instantiateViewController(withIdentifier: "MyJobsViewController") as! MyJobsViewController
            let nav = UINavigationController(rootViewController: view)
            
            self.slideMenuController()?.changeMainViewController(nav, close: true)
            
        case 7:
            let view = storyboard.instantiateViewController(withIdentifier: "ProspectiveCustomersListingViewController") as! ProspectiveCustomersListingViewController
            let nav = UINavigationController(rootViewController: view)
            
            self.slideMenuController()?.changeMainViewController(nav, close: true)
            
            break
            
        case 8:
            let view = storyboard.instantiateViewController(withIdentifier: "TrainingViewController") as! TrainingViewController
            let nav = UINavigationController(rootViewController: view)
            
            self.slideMenuController()?.changeMainViewController(nav, close: true)
            
            break

        case 9:
            let alert = UIAlertController(title: GlobalConstants.appName, message: "Are you sure you want to logout?", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Yes", style: UIAlertActionStyle.default, handler: { (action) in
                
                self.Post_Logout()
  
                
//                //Store data nill value when user logout
//                let defaults = UserDefaults.standard
//                defaults.removeObject(forKey: "userobject")
//                defaults.synchronize()
//
//                //Move to home view in when app is launch
//                let appDelegate = UIApplication.shared.delegate as! AppDelegate
//                let nav: UINavigationController! = (appDelegate.window?.rootViewController as! UINavigationController)
//                nav.popToRootViewController(animated: true)
                
            }))
            alert.addAction(UIAlertAction(title: "No", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            break
            
        default:
            break
        }
    }
    func showDetailsView(_ index: Int) {
        self.slideMenuController()?.changeMainViewController(self.TabBarViewController, close: true)
        
        //        let when = DispatchTime.now() + 0.0 // change 2 to desired number of seconds
        //        DispatchQueue.main.asyncAfter(deadline: when) {
        //            vw_HomeView?.movingData(int_Value:index)
        //        }
    }
    func reloadViewData(){
        //Editing ModeaDecoder
        //        if objUser?.user_Type == "0"{
//        menus = [["name":"Home","image":"icon_Home"],["name":"Add Customer","image":"icon_PlaceHolderUser"],["name":"Notifications","image":"icon_Notification"],["name":"Messages","image":"icon_Messages"],["name":"Contacts","image":"icon_PlaceHolderUser"],["name":"Tomorrow's jobs, Current Job","image":"icon_Tommorow"],["name":"Prospective Customers","image":"icon_PlaceHolderUser"],["name":"Training","image":"icon_PlaceHolderUser"],["name":"Log Out","image":"icon_PlaceHolderUser"]]
        //        }else{
        //            menus = [["name":"Profile","image":"1"],["name":"Change Flashcard Color","image":"2"],["name":"Set Goal","image":"3"],["name":"Notifications","image":"4"],["name":"Feedback","image":"5"],["name":"My School","image":"6"],["name":"External Access","image":"7"],["name":"Sign Out","image":"8"]]
        //        }
        
        tableView.reloadData()
    }
    
    //For didselect method for present view controller
    func changeViewController(_ menu: LeftMenu) {
    }
    
    // MARK: - Button Event -
    @IBAction func btn_NavigationLeft(_ sender: Any) {
        //        toggleLeft()
        self.slideMenuController()?.changeMainViewController(self.TabBarViewController, close: true)
        
    }
    @IBAction func btn_SwitchRun(sender: UISwitch){
//        sender.isOn = !sender.isOn
        if sender.isOn{
            objUser?.user_RunMode = "1"
            Post_UpdateRunMode(str_Value: "1")
        }else{
            objUser?.user_RunMode = "0"
            Post_UpdateRunMode(str_Value: "0")
        }
        //Save User Object
        saveCustomObject(objUser!, key: "userobject");
        NaviationManager()
       
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            str_Home_Present = "1"
            let view = storyboard.instantiateViewController(withIdentifier: "PlivoCallController") as! PlivoCallController
            let nav = UINavigationController(rootViewController: view)
            
            self.slideMenuController()?.changeMainViewController(nav, close: true)
        })
        
        
//        if objUser?.user_RunMode == "1"{
//           let view = TabBarViewController as! UINavigationController
//           let views = view.topViewController as! PlivoCallController
//            views.navigationController?.navigationBar.setBackgroundImage(image(with:GlobalConstants.appColor),
//                                                                        for: .default)
//        }else{
//
//            let view = TabBarViewController as! UINavigationController
//            let views = view.topViewController as! PlivoCallController
//            views.navigationController?.navigationBar.setBackgroundImage(image(with:GlobalConstants.appColor2),
//                                                                         for: .default)
//        }
        
    }
    @IBAction func viewSetGoalHiddenClick(_ sender: Any) {
        viewSetGoal.isHidden = !viewSetGoal.isHidden
        
        self.view.endEditing(true)
    }
    
    @IBAction func setColorHiddenClick(_ sender: Any) {
        viewSetColor.isHidden = !viewSetColor.isHidden
    }
    
    @IBAction func schoolHiddenClick(_ sender: Any) {
        
        self.Post_RegistrationWithSutdent()
        
        //        objUser?.user_Type = "1"
        //        saveCustomObject(objUser!, key: "userobject");
        //        self.reloadViewData()
        //
        //        //Alert show for Header
        //        messageBar.MessageShow(title: "Please update Minnaz to get access to your school portal", alertType: MessageView.Layout.cardView, alertTheme: .success, TopBottom: true)
        //
        //        viewSelectSchool.isHidden = !viewSelectSchool.isHidden
        //
        //        //Logout when user apply for school portal
        //        GIDSignIn.sharedInstance().signOut()
        //
        //        //Move to home view in when app is launch
        //        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        //        let nav: UINavigationController! = (appDelegate.window?.rootViewController as! UINavigationController)
        //        nav.popToRootViewController(animated: true)
    }
    
    @IBAction func btn_Setting(_ sender: Any){
        //     self.slideMenuController()?.changeMainViewController(self.SettingsViewController, close: true)
        
        //        let when = DispatchTime.now() + 0.3 // change 2 to desired number of seconds
        //        DispatchQueue.main.asyncAfter(deadline: when) {
        //            vw_HomeView?.movingData(int_Value:0)
        //        }
    }
    @IBAction func btn_Profile(_ sender: Any){
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let view = storyboard.instantiateViewController(withIdentifier: "ProfileViewController") as! ProfileViewController
        let nav = UINavigationController(rootViewController: view)
        
        self.slideMenuController()?.changeMainViewController(nav, close: true)
    }
    
    // MARK: - Get/Post Method -
    func Post_Logout(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)customer/logout"
        
            //Pass data in dictionary
            var jsonData : NSDictionary =  NSDictionary()
            jsonData = [
                "devicetype" : GlobalConstants.deviceType,
                "devicetoken" :  UserDefaults.standard.value(forKey: "DeviceToken") == nil ? "123" : UserDefaults.standard.value(forKey: "DeviceToken")! as! String,
                "unique_id" : "",
            ]
    
            //Create object for webservicehelper and start to call method
            let webHelper = WebServiceHelper()
            webHelper.strMethodName = "logout"
            webHelper.methodType = "post"
            webHelper.strURL = strURL
            webHelper.dictType = jsonData
            webHelper.dictHeader = NSDictionary()
            webHelper.delegateWeb = self
            webHelper.serviceWithAlert = false
            webHelper.startDownload()
    }
    
    func Post_RegistrationWithSutdent(){
        
        //        //Declaration URL
        //        let strURL = "\(GlobalConstants.BaseURL)register_as_student"
        //
        //        //Pass data in dictionary
        //        var jsonData : NSDictionary =  NSDictionary()
        //        jsonData = [
        //            "user_id" : objUser?.user_UserID,
        //        ]
        //
        //        //Create object for webservicehelper and start to call method
        //        let webHelper = WebServiceHelper()
        //        webHelper.strMethodName = "register_as_student"
        //        webHelper.methodType = "post"
        //        webHelper.strURL = strURL
        //        webHelper.dictType = jsonData
        //        webHelper.dictHeader = NSDictionary()
        //        webHelper.delegateWeb = self
        //        webHelper.serviceWithAlert = true
        //        webHelper.startDownload()
    }
    
    func Post_UpdateRunMode(str_Value : String){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)comman/runmode"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "type" : str_Value,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "runmode"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.indicatorShowOrHide = false
        webHelper.startDownload()
    }
}


// MARK: - Tableview Delegate -

extension LeftMenuViewController : UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        //        return 80
//        if indexPath.row == 2{
//            return 0
//        }
        return CGFloat(GlobalConstants.windowHeight * 0.08245877061)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menus.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var str_Cell = "cell"
        if indexPath.row == 2 || indexPath.row == 3{
            str_Cell = "LeftMenuCell"
        }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: str_Cell, for:indexPath as IndexPath) as! LeftMenuCell
        
        //Declare text in icon in tableview cell
        cell.lblTitle.text = menus[indexPath.row]["name"]
        cell.imgLogo.image = UIImage(named:menus[indexPath.row]["image"]!)!
        
        //Manage font
        cell.lblTitle.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFont(font: 16))
        cell.lbl_NotificationCount.font =  UIFont(name: GlobalConstants.kFontOpenSansSemiBold, size: manageFont(font: 16))
        
        cell.lbl_NotificationCount.isHidden = true
        cell.img_NotificationCount.isHidden = true
        if indexPath.row == 2{
            if str_NotificationCount != "" && str_NotificationCount != "0"{
                cell.lbl_NotificationCount.isHidden = false
                cell.img_NotificationCount.isHidden = false
                cell.lbl_NotificationCount.text = str_NotificationCount
            }
        }else if indexPath.row == 3{
            if str_MessageCount != "" && str_MessageCount != "0"{
                cell.lbl_NotificationCount.isHidden = false
                cell.img_NotificationCount.isHidden = false
                cell.lbl_NotificationCount.text = str_MessageCount
            }
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        selectedIndex = indexPath.row
        self.callmethod(_int_Value: indexPath.row)
    }
    
    @objc func handleRegister(sender: UIButton){
        sender.isSelected = !sender.isSelected
        //...
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if self.tableView == scrollView {
            
        }
    }
}

//MARK: - Collection View -
extension LeftMenuViewController : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return arrColor.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell  = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        let viewColor : UIView = (cell.viewWithTag(100))!
        let viewBorder : UIView = (cell.viewWithTag(101))!
        viewColor.backgroundColor = arrColor[indexPath.row]
        viewColor.layer.cornerRadius = 5.0
        viewBorder.isHidden = false
        if indexPath.row == selectedIndex {
            viewBorder.isHidden = false
        }else {
            viewBorder.isHidden = true
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedIndex = indexPath.row
        collectionView.reloadData()
        //        cardDefaultColor = arrColor[indexPath.row]
    }
}



extension LeftMenuViewController : WebServiceHelperDelegate{
    //MARK: - Webservice Helper -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        if strRequest == "logout" || strRequest == "register_as_student"{

            let storyboard = UIStoryboard(name: "PlivoCall", bundle: nil)
            
//            str_Home_Present = "1"
//            let view = storyboard.instantiateViewController(withIdentifier: "PlivoCallController") as! PlivoCallController
//            let nav = UINavigationController(rootViewController: view)
//            self.slideMenuController()?.changeMainViewController(nav, close: false)
            
            UtilClass.makeToastActivity()
            Phone.sharedInstance.setDelegate(vw_Call)
            vw_Call.unRegisterSIPEndpoit()
        }else if strRequest == "runmode"{
            
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        print(error)
    }
    
}


//extension LeftMenuViewController : PlivoEndpointDelegate{
//    func onLogout() {
//
//        DispatchQueue.main.async(execute: {() -> Void in
//
//            UtilClass.setUserAuthenticationStatus(false)
//            UserDefaults.standard.removeObject(forKey: kUSERNAME)
//            UserDefaults.standard.removeObject(forKey: kPASSWORD)
//            UserDefaults.standard.synchronize()
//            indicatorHide()
//
//            //Store data nill value when user logout
//            let defaults = UserDefaults.standard
//            defaults.removeObject(forKey: "userobject")
//            defaults.synchronize()
//
//            //Move to home view in when app is launch
//            let appDelegate = UIApplication.shared.delegate as! AppDelegate
//            let nav: UINavigationController! = (appDelegate.window?.rootViewController as! UINavigationController)
//            let view : UIViewController = nav.viewControllers[0]
//            nav.popToViewController(view, animated: true)
//        })
//    }
//}
//




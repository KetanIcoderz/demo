
#define kUSERNAME  @"UserName"
#define kPASSWORD @"Password"
#define kAUTHENTICATIONSTATUS  @"AuthenticationStatus"
#define kCALLSINFO  @"CallsInfo"
#define kREACHABILITYURL "www.google.com"


#define DEVICE_HEIGHT [[UIScreen mainScreen] bounds].size.height
#define DEVICE_WIDTH  [UIScreen mainScreen].bounds.size.width
#define widthCalculate(w) (([[UIScreen mainScreen] bounds].size.width) * (w / 320.0))
#define heightCalculate(h) (([[UIScreen mainScreen] bounds].size.height) * (h / 568.0))

#define kLOGINMSG @"Trying to Login, please wait"
#define kLOGOUTMSG @"Trying to Logout, please wait"
#define kLOGINSUCCESS @"SIP registration done successfully"
#define kLOGOUTSUCCESS @"Logged Out Successfully"
#define kLOGINFAILTITLE @"Login failed"
#define kLOGINFAILMSG @"Login failed. Please check your username and password"
#define kINVALIDEMAIL @"Please login with plivo account"


#define kNOINTERNETTITLE @"No Internet"
#define kNOINTERNETMSG @"Please connect to internet"
#define kINVALIDENTRIESTITLE @"Invalid data"
#define kINVALIDENTRIESMSG @"Please enter SIP Endpoint Username and password"
#define kINVALIDSIPENDPOINTMSG @"Please enter SIP Endpoint or Phone numner"


#define kREQUESTFAILED @"Request failed"
#define kINCOMINGCALLREPORTFAILED @"Failed to report incoming call successfully"
#define kSTARTACTIONFAILED @"StartCallAction transaction request failed"
#define kENDACTIONFAILED @"EndCallAction transaction request failed"
//#define kENDPOINTURL @"@phone.test.plivo.com"
#define kENDPOINTURL @"@phone.plivo.com"


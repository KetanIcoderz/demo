//
//  UserDataObject.swift
//  HealthyBlackMen
//
//  Created by ketan_icoderz on 16/05/17.
//  Copyright © 2017 iCoderz. All rights reserved.
//

import UIKit

class UserDataObject: NSObject,NSCoding  {
    //NSCoding
    
    var user_UserID : String = ""
    var user_First_Name : String = ""
    var user_Last_Name : String = ""
    var user_Address : String = ""
    var user_Parent_Name_1 : String = ""
    var user_Parent_Name_2 : String = ""
    var user_Email : String = ""
    var user_Phone_Number: String = ""
    var user_Photo: String = ""
    var user_AccessToken: String = ""
    var user_RememberMe: String = ""
    var user_Lat: String = ""
    var user_Long: String = ""
    var user_RunMode: String = ""
    var user_Reward_Point: String = ""
    
    var user_PlivoUserName : String = ""
    var user_PlivoPassword : String = ""
    
    override init(){
        super.init()
    }
    
    init(user_UserID : String,user_First_Name : String,user_Last_Name : String,user_Address : String,user_Parent_Name_1 : String,user_Parent_Name_2 : String,user_Email : String,user_Phone_Number : String,user_Photo : String,user_AccessToken : String,user_RememberMe : String,user_Lat : String,user_Long : String, user_PlivoUserName : String,user_PlivoPassword : String,user_RunMode : String,user_Reward_Point : String) {
        
        self.user_UserID = user_UserID as String
        self.user_First_Name = user_First_Name as String
        self.user_Last_Name = user_Last_Name as String
        self.user_Address = user_Address as String
        self.user_Parent_Name_1 = user_Parent_Name_1 as String
        self.user_Parent_Name_2 = user_Parent_Name_2 as String
        self.user_Email = user_Email as String
        self.user_Phone_Number = user_Phone_Number as String
        self.user_Photo = user_Photo as String
        self.user_AccessToken = user_AccessToken as String
        self.user_RememberMe = user_RememberMe as String
        self.user_Lat = user_Lat as String
        self.user_Long = user_Long as String
        self.user_PlivoUserName = user_PlivoUserName as String
        self.user_PlivoPassword = user_PlivoPassword as String
        self.user_RunMode = user_RunMode as String
        self.user_Reward_Point = user_Reward_Point as String
       
    }
    
    required convenience init(coder aDecoder: NSCoder) {
        let user_UserID = aDecoder.decodeObject(forKey: "user_UserID") as! String
        let user_First_Name = aDecoder.decodeObject(forKey: "user_First_Name") as! String
        let user_Last_Name = aDecoder.decodeObject(forKey: "user_Last_Name") as! String
        let user_Address = aDecoder.decodeObject(forKey: "user_Address") as! String
        let user_Parent_Name_1 = aDecoder.decodeObject(forKey: "user_Parent_Name_1") as! String
        let user_Parent_Name_2 = aDecoder.decodeObject(forKey: "user_Parent_Name_2") as! String
        let user_Email = aDecoder.decodeObject(forKey: "user_Email") as! String
        let user_Phone_Number = aDecoder.decodeObject(forKey: "user_Phone_Number") as! String
        let user_Photo = aDecoder.decodeObject(forKey: "user_Photo") as! String
        let user_AccessToken = aDecoder.decodeObject(forKey: "user_AccessToken") as! String
        let user_RememberMe = aDecoder.decodeObject(forKey: "user_RememberMe") as! String
        let user_Lat = aDecoder.decodeObject(forKey: "user_Lat") as! String
        let user_Long = aDecoder.decodeObject(forKey: "user_Long") as! String
        let user_PlivoUserName = aDecoder.decodeObject(forKey: "user_PlivoUserName") as! String
        let user_PlivoPassword = aDecoder.decodeObject(forKey: "user_PlivoPassword") as! String
        let user_RunMode = aDecoder.decodeObject(forKey: "user_RunMode") as! String
        let user_Reward_Point = aDecoder.decodeObject(forKey: "user_Reward_Point") as! String
       
        self.init(user_UserID: user_UserID as String,
                  user_First_Name: user_First_Name as String,
                  user_Last_Name: user_Last_Name as String,
                  user_Address: user_Address as String,
                  user_Parent_Name_1: user_Parent_Name_1 as String,
                  user_Parent_Name_2: user_Parent_Name_2 as String,
                  user_Email: user_Email as String,
                  user_Phone_Number: user_Phone_Number as String,
                  user_Photo: user_Photo as String,
                  user_AccessToken: user_AccessToken as String,
                  user_RememberMe: user_RememberMe as String,
                  user_Lat: user_Lat as String,
                  user_Long: user_Long as String,
                  user_PlivoUserName: user_PlivoUserName as String,
                  user_PlivoPassword: user_PlivoPassword as String,
                  user_RunMode: user_RunMode as String,
                  user_Reward_Point: user_Reward_Point as String)
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(user_UserID, forKey: "user_UserID")
        aCoder.encode(user_First_Name, forKey: "user_First_Name")
        aCoder.encode(user_Last_Name, forKey: "user_Last_Name")
        aCoder.encode(user_Address, forKey: "user_Address")
        aCoder.encode(user_Parent_Name_1, forKey: "user_Parent_Name_1")
        aCoder.encode(user_Parent_Name_2, forKey: "user_Parent_Name_2")
        aCoder.encode(user_Email, forKey: "user_Email")
        aCoder.encode(user_Phone_Number, forKey: "user_Phone_Number")
        aCoder.encode(user_Photo, forKey: "user_Photo")
        aCoder.encode(user_AccessToken, forKey: "user_AccessToken")
        aCoder.encode(user_RememberMe, forKey: "user_RememberMe")
        aCoder.encode(user_Lat, forKey: "user_Lat")
        aCoder.encode(user_Long, forKey: "user_Long")
        aCoder.encode(user_PlivoUserName, forKey: "user_PlivoUserName")
        aCoder.encode(user_PlivoPassword, forKey: "user_PlivoPassword")
        aCoder.encode(user_RunMode, forKey: "user_RunMode")
        aCoder.encode(user_Reward_Point, forKey: "user_Reward_Point")
    }
    
}






//
//  Messages.swift
//  PooperPickerUpperKids
//
//  Created by Apple on 09/08/18.
//  Copyright © 2018 v. All rights reserved.
//

import UIKit

class ValidationMessages: NSObject {

    //SignInViewController
    static let SignInViewController_BlackEmail : String = "Please enter email address"
    static let SignInViewController_ValidEmail : String = "Please enter valid email address"
    static let SignInViewController_BlackPassword : String = "Please enter password"
    
    //ForgotPasswordViewController
    static let ForgotPasswordViewController_BlackEmail : String = "Please enter email address"
    static let ForgotPasswordViewController_ValidEmail : String = "Please enter valid email address"
    
    //AddCustomer
    static let AddCustomersViewController_Delete : String = "Are you sure to delete?"
    
    //Change Password
    static let ChangePasswordViewController_OldPassword : String = "Please enter old password"
    static let ChangePasswordViewController_NewPassword : String = "Please enter new password"
    static let ChangePasswordViewController_ConformPassword : String = "Please enter confirm password"
    static let ChangePasswordViewController_PasswordMatch : String = "Passwords do not match"
    
}

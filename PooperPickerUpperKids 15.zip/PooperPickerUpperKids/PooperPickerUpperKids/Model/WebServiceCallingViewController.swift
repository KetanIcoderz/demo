//
//  WebServiceCallingViewController.swift
//  iAudioo
//
//  Created by Apple on 18/05/18.
//  Copyright © 2018 iAudioo. All rights reserved.

import UIKit
import GoogleMaps

class WebServiceCallingViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}




extension ConfrimArrivalViewController : WebServiceHelperDelegate{
    //MARK: - ConfrimArrivalViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "mapRoute" {
            
            let routes = response["routes"] as! NSArray
            for i in (0..<routes.count)
            {
                let subDict = routes.object(at: i) as! NSDictionary
                let routeOverViewPolyline = subDict["overview_polyline"] as! NSDictionary
                let point = routeOverViewPolyline["points"]as? String ?? ""
                
                if (getPolygline == nil)
                {
                    getGMSPath = GMSPath.init(fromEncodedPath: point)
                    getPolygline = GMSPolyline.init(path: getGMSPath)
                    getPolygline.map = self.vw_MapGoogle
                }
                else {
                    getPolygline.map = nil
                    getPolygline = nil
                    getGMSPath = nil
                    getGMSPath = GMSPath.init(fromEncodedPath: point)
                    
                    getPolygline = GMSPolyline.init(path: getGMSPath)
                    getPolygline.map = self.vw_MapGoogle
                }
                
                getPolygline.strokeWidth = 5
                getPolygline.strokeColor = GlobalConstants.appColor
                
                vw_MapGoogle?.animate(with: GMSCameraUpdate.fit(GMSCoordinateBounds(path: getPolygline.path!), withPadding: CGFloat(50 * (GlobalConstants.windowHeight/667))))
            }
        }else if strRequest == "confirm" || strRequest == "complete"{
            self.navigationController?.popToRootViewController(animated: true)
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {

    }
}


extension SignInViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "login" {
            
            userObjectUpdate(dict_Get : response,remember: self.btn_RememberMe.isSelected == true ? "1" : "0")
//            manageTabBarandSideBar()
            
            self.Post_LoginWithPlivo()
            self.Post_DeviceTocken()
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}


extension ForgotPasswordViewController : WebServiceHelperDelegate{

    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "forget_password" {
            
           self.navigationController?.popViewController(animated: true)
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}


extension CustomersListingViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "customer" {

            let dict_Result = response["Result"] as! NSDictionary
            let arr_Result = dict_Result["data"] as! NSArray
            
            var arr_StoreTemp : NSMutableArray = []
            for i in 0..<arr_Result.count{
                let dict_Value = arr_Result[i] as! NSDictionary
                
                let obj = GlobalObject()
                obj.str_Customer_Id = dict_Value.getStringForID(key: "id")
                obj.str_Customer_Title = "\(dict_Value.getStringForID(key: "first_name") as! String) \(dict_Value.getStringForID(key: "last_name") as! String)"
                obj.str_Customer_FirstName = dict_Value.getStringForID(key: "first_name") as! String
                obj.str_Customer_LastName = (dict_Value.getStringForID(key: "last_name") as! String)
                obj.str_Customer_Lat = dict_Value.getStringForID(key: "lat")
                obj.str_Customer_Long = dict_Value.getStringForID(key: "longs")
                obj.str_Customer_Address = dict_Value.getStringForID(key: "address")
                obj.str_Customer_Interest = dict_Value.getStringForID(key: "interest")
                obj.str_Customer_Note = dict_Value.getStringForID(key: "note")
                obj.str_Customer_DogName = dict_Value.getStringForID(key: "dog_name")
                obj.str_Customer_PhoneNumber = dict_Value.getStringForID(key: "phone_number")
                
                obj.arr_Customer_ScheduleJob = []
                
                //Manage logic for day file with current time
//                var arr_Temp : NSArray = []
//                if dict_Value["schedule"] != nil{
                   let arr_Temp  = dict_Value["schedule"] as! NSArray
//                }
                
                
                for i in 0..<7{
                    var tenDaysfromNow: Date {
                        return (Calendar.current as NSCalendar).date(byAdding: .day, value: i+1, to: Date(), options: [])!
                    }
                    let obj2 = GlobalObject()
                    obj2.str_Customer_Name = localDateToStrignDate(date : tenDaysfromNow,type: 1)
                    obj2.str_Customer_Name2 = localDateToStrignDate(date : tenDaysfromNow,type: 2)
                    obj2.str_Customer_Month = localDateToStrignDate(date : tenDaysfromNow,type: 3)
                    obj2.str_Customer_DateOnly = localDateToStrignDate2(date : tenDaysfromNow)
                    
                    for i in 0..<arr_Temp.count{
                        let dict_Temp : NSDictionary = arr_Temp[i] as! NSDictionary
                        
                        if obj2.str_Customer_Name2 == dict_Temp.getStringForID(key: "day"){
                          
                            obj2.str_Customer_Name2 = dict_Temp.getStringForID(key: "day")
                            obj2.str_Customer_StartTime = dict_Temp.getStringForID(key: "start")
                            obj2.str_Customer_EndTime = dict_Temp.getStringForID(key: "end")
                            obj2.str_Customer_DateOnly = dict_Temp.getStringForID(key: "date")
                            break
                        }
                    }
                    obj.arr_Customer_ScheduleJob.add(obj2)
                }
                
                obj.str_Customer_ScheduleType = dict_Value.getStringForID(key: "schedule_type")
                
                arr_StoreTemp.add(obj)
            }
            
            //Refresh code
            if bool_ViewWill == true {
                arr_Main = []
                int_CountLoad = arr_StoreTemp.count
            }else{
                int_CountLoad = int_CountLoad + arr_StoreTemp.count
            }
            
            for i in (0...arr_StoreTemp.count-1){
                arr_Main.add(arr_StoreTemp[i])
            }
            
            //Load more data or not
            if GlobalConstants.int_LoadMax > arr_StoreTemp.count {
                //Bool Load more
                bool_SearchMore = false
            }
            else {
                //Bool Load more
                bool_SearchMore = true
            }
        }
        
        self.completedServiceCalling()
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        bool_SearchMore = false
        self.completedServiceCalling()
    }
}


extension AddCustomersViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "create" || strRequest == "update" || strRequest == "delete"
        {
            if str_Type == "contact"{
                self.navigationController?.popToRootViewController(animated: true)
            }else{
                self.navigationController?.popToRootViewController(animated: true)
            }
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}



extension ProspectiveCustomersListingViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        self.completedServiceCalling()
        
        let response = data as! NSDictionary
        if strRequest == "customer" {
            
            let dict_Result = response["Result"] as! NSDictionary
            let arr_Result = dict_Result["data"] as! NSArray
            
            var arr_StoreTemp : NSMutableArray = []
            for i in 0..<arr_Result.count{
                let dict_Value = arr_Result[i] as! NSDictionary
                
                let obj = GlobalObject()
                obj.str_Customer_Id = dict_Value.getStringForID(key: "id")
                obj.str_Customer_Title = "\(dict_Value.getStringForID(key: "first_name") as! String) \(dict_Value.getStringForID(key: "last_name") as! String)"
                obj.str_Customer_FirstName = dict_Value.getStringForID(key: "first_name") as! String
                obj.str_Customer_LastName = (dict_Value.getStringForID(key: "last_name") as! String)
                obj.str_Customer_Lat = dict_Value.getStringForID(key: "lat")
                obj.str_Customer_Long = dict_Value.getStringForID(key: "longs")
                obj.str_Customer_Address = dict_Value.getStringForID(key: "address")
                obj.str_Customer_Interest = dict_Value.getStringForID(key: "interest")
                obj.str_Customer_Note = dict_Value.getStringForID(key: "note")
                obj.str_Customer_DogName = dict_Value.getStringForID(key: "dog_name")
                obj.str_Customer_PhoneNumber = dict_Value.getStringForID(key: "phone_number")
                obj.str_Customer_ProspectDate = dict_Value.getStringForID(key: "pros_noty_date")
                obj.str_Customer_JobType = dict_Value.getStringForID(key: "pros_noty_date")
                
                arr_StoreTemp.add(obj)
            }
            
            //Refresh code
            if bool_ViewWill == true {
                arr_Main = []
                int_CountLoad = arr_StoreTemp.count
            }else{
                int_CountLoad = int_CountLoad + arr_StoreTemp.count
            }
            
            for i in (0...arr_StoreTemp.count-1){
                arr_Main.add(arr_StoreTemp[i])
            }
            
            //Load more data or not
            if GlobalConstants.int_LoadMax > arr_StoreTemp.count {
                //Bool Load more
                bool_SearchMore = false
            }
            else {
                //Bool Load more
                bool_SearchMore = true
            }
        }
        self.completedServiceCalling()
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        bool_SearchMore = false
        self.completedServiceCalling()
    }
}



extension AddProspectiveCustomersViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "create" || strRequest == "swap" || strRequest == "delete" || strRequest == "update"
        {
            if str_Type == "contact" || get_Data.str_Customer_Title != ""{
                self.navigationController?.popToRootViewController(animated: true)
            }else{
               self.navigationController?.popViewController(animated: true)
            }
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}



extension ChangePasswordViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "change_password"
        {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}


extension AddJobsViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "customer" {
            
            let dict_Result = response["Result"] as! NSDictionary
            let arr_Result = dict_Result["data"] as! NSArray
            
            arr_Customer = []
            for i in 0..<arr_Result.count{
                let dict_Value = arr_Result[i] as! NSDictionary
                
                let obj = GlobalObject()
                obj.str_Customer_Id = dict_Value.getStringForID(key: "id")
                obj.str_Customer_Title = "\(dict_Value.getStringForID(key: "first_name") as! String) \(dict_Value.getStringForID(key: "last_name") as! String)"
                obj.str_Customer_FirstName = dict_Value.getStringForID(key: "first_name") as! String
                obj.str_Customer_LastName = (dict_Value.getStringForID(key: "last_name") as! String)
                obj.str_Customer_Lat = dict_Value.getStringForID(key: "lat")
                obj.str_Customer_Long = dict_Value.getStringForID(key: "longs")
                obj.str_Customer_Address = dict_Value.getStringForID(key: "address")
                obj.str_Customer_Interest = dict_Value.getStringForID(key: "interest")
                obj.str_Customer_Note = dict_Value.getStringForID(key: "note")
                obj.str_Customer_DogName = dict_Value.getStringForID(key: "dog_name")
                
                arr_Customer.add(obj)
            }
            
//            self.tbl_Main.reloadData()
        }else if strRequest == "add"{
                self.navigationController?.popViewController(animated: true)
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
       
    }
}



extension ListMyScheduleJobsViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "schedule" {
            
            let dict_Result = response["Result"] as! NSDictionary
            let arr_Result = dict_Result["data"] as! NSArray
            
            let arr_StoreTemp : NSMutableArray = []
            for i in 0..<arr_Result.count{
                let dict_Value = arr_Result[i] as! NSDictionary
                let dict_Customer = dict_Value["customer"] as! NSDictionary
                let dict_Payment = dict_Value["payment"] as! NSDictionary
                
                let obj = GlobalObject()
                obj.str_Id = dict_Value.getStringForID(key: "id")
                obj.str_Customer_Id = dict_Value.getStringForID(key: "customer_id")
                obj.str_Customer_Address = dict_Value.getStringForID(key: "address")
                obj.str_Customer_Lat = dict_Value.getStringForID(key: "lat")
                obj.str_Customer_Long = dict_Value.getStringForID(key: "longs")
                obj.str_Customer_DogName = dict_Value.getStringForID(key: "dog_name")
                obj.str_Customer_Spouse_Name = dict_Value.getStringForID(key: "spouse_name")
                obj.str_Customer_Note = dict_Value.getStringForID(key: "note")
                obj.str_Customer_DateOnly = dict_Value.getStringForID(key: "job_date")
                obj.str_Customer_StartTime = dict_Value.getStringForID(key: "start_time")
                obj.str_Customer_EndTime = dict_Value.getStringForID(key: "end_time")
                obj.str_Customer_job_status_Text = dict_Value.getStringForID(key: "job_status_text")
                
                obj.str_Customer_Job_Amount = dict_Payment.getStringForID(key: "end_time")
                obj.str_Customer_Job_Payment_Method = dict_Payment.getStringForID(key: "end_time")
                obj.str_Customer_Job_Cheque_Num = dict_Payment.getStringForID(key: "end_time")
                
                obj.str_Customer_Title = "\(dict_Customer.getStringForID(key: "first_name") as! String) \(dict_Customer.getStringForID(key: "last_name") as! String)"
                
                arr_StoreTemp.add(obj)
            }
            
            //Refresh code
            if bool_ViewWill == true {
                arr_Main = []
                int_CountLoad = arr_StoreTemp.count
            }else{
                int_CountLoad = int_CountLoad + arr_StoreTemp.count
            }
            
            for i in (0...arr_StoreTemp.count-1){
                arr_Main.add(arr_StoreTemp[i])
            }
            
            //Load more data or not
            if GlobalConstants.int_LoadMax > arr_StoreTemp.count {
                //Bool Load more
                bool_SearchMore = false
            }
            else {
                //Bool Load more
                bool_SearchMore = true
            }
            
//            bool_ViewWill = false
//
//            self.tbl_Main.reloadData()
        }else if strRequest == "delete"{
            arr_Main = []
            tbl_Main.reloadData()
            
            int_CountLoad = GlobalConstants.int_LoadMax
            bool_ViewWill = true
            bool_SearchMore = true
            
            self.Post_JobsListing(count:int_CountLoad)
        }
        
        
        self.completedServiceCalling()
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        bool_SearchMore = false
        self.completedServiceCalling()
    }
    
    
}


extension ListMyCompletedJobsViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "schedule" {
            
            let dict_Result = response["Result"] as! NSDictionary
            let arr_Result = dict_Result["data"] as! NSArray
            
            var arr_StoreTemp : NSMutableArray = []
            for i in 0..<arr_Result.count{
                let dict_Value = arr_Result[i] as! NSDictionary
                let dict_Customer = dict_Value["customer"] as! NSDictionary
                let dict_Payment = dict_Value["payment"] as! NSDictionary
                
                let obj = GlobalObject()
                obj.str_Id = dict_Value.getStringForID(key: "id")
                obj.str_Customer_Id = dict_Value.getStringForID(key: "customer_id")
                obj.str_Customer_Address = dict_Value.getStringForID(key: "address")
                obj.str_Customer_Lat = dict_Value.getStringForID(key: "lat")
                obj.str_Customer_Long = dict_Value.getStringForID(key: "longs")
                obj.str_Customer_DogName = dict_Value.getStringForID(key: "dog_name")
                obj.str_Customer_Spouse_Name = dict_Value.getStringForID(key: "spouse_name")
                obj.str_Customer_Note = dict_Value.getStringForID(key: "note")
                obj.str_Customer_DateOnly = dict_Value.getStringForID(key: "job_date")
                obj.str_Customer_StartTime = dict_Value.getStringForID(key: "start_time")
                obj.str_Customer_EndTime = dict_Value.getStringForID(key: "end_time")
                
                obj.str_Customer_Job_Amount = dict_Payment.getStringForID(key: "amount")
                obj.str_Customer_Job_Payment_Method = dict_Payment.getStringForID(key: "payment_method")
                obj.str_Customer_Job_Cheque_Num = dict_Payment.getStringForID(key: "cheque_num")
                
                obj.str_Customer_Title = "\(dict_Customer.getStringForID(key: "first_name") as! String) \(dict_Customer.getStringForID(key: "last_name") as! String)"
                
                arr_StoreTemp.add(obj)
            }
            
            //Refresh code
            if bool_ViewWill == true {
                arr_Main = []
                int_CountLoad = arr_StoreTemp.count
            }else{
                int_CountLoad = int_CountLoad + arr_StoreTemp.count
            }
            
            for i in (0...arr_StoreTemp.count-1){
                arr_Main.add(arr_StoreTemp[i])
            }
            
            //Load more data or not
            if GlobalConstants.int_LoadMax > arr_StoreTemp.count {
                //Bool Load more
                bool_SearchMore = false
            }
            else {
                //Bool Load more
                bool_SearchMore = true
            }
            
//            bool_ViewWill = false
//            
//            self.tbl_Main.reloadData()
        }
        self.completedServiceCalling()
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        bool_SearchMore = false
        self.completedServiceCalling()
    }
}






extension PlaceViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "pushtoken" {
            
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
    }
}


extension ChangeProfileDetailViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "update_profile" {
            
            userObjectUpdate(dict_Get : response,remember: (objUser?.user_RememberMe)!)
            self.navigationController?.popViewController(animated: true)
            
        }else if strRequest == "upload_profile_img"{
             userObjectUpdate(dict_Get : response,remember: (objUser?.user_RememberMe)!)
            
            self.commanMethod()
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}



extension ListMyScheduleViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "schedule" {
            
            let dict_Result = response["Result"] as! NSDictionary
            let arr_Result = dict_Result["data"] as! NSArray
            
            var arr_StoreTemp : NSMutableArray = []
            for i in 0..<arr_Result.count{
                let dict_Value = arr_Result[i] as! NSDictionary
                let dict_Customer = dict_Value["customer"] as! NSDictionary
                
                let obj = GlobalObject()
                obj.str_Id = dict_Value.getStringForID(key: "id")
                obj.str_Customer_Id = dict_Value.getStringForID(key: "customer_id")
                obj.str_Customer_Address = dict_Value.getStringForID(key: "address")
                obj.str_Customer_Lat = dict_Value.getStringForID(key: "lat")
                obj.str_Customer_Long = dict_Value.getStringForID(key: "longs")
                obj.str_Customer_DogName = dict_Value.getStringForID(key: "dog_name")
                obj.str_Customer_Spouse_Name = dict_Value.getStringForID(key: "spouse_name")
                obj.str_Customer_Note = dict_Value.getStringForID(key: "note")
                obj.str_Customer_DateOnly = dict_Value.getStringForID(key: "job_date")
                obj.str_Customer_StartTime = dict_Value.getStringForID(key: "start_time")
                obj.str_Customer_EndTime = dict_Value.getStringForID(key: "end_time")
                obj.str_Customer_job_status = dict_Value.getStringForID(key: "job_status")
                obj.str_Customer_Confirm_Msg_Count = dict_Value.getStringForID(key: "confirm_msg_count")
                obj.str_Customer_job_status_Text = dict_Value.getStringForID(key: "job_status_text")
                
                obj.str_Customer_Title = "\(dict_Customer.getStringForID(key: "first_name") as! String) \(dict_Customer.getStringForID(key: "last_name") as! String)"
                
                arr_StoreTemp.add(obj)
            }
            
            //Refresh code
            if bool_ViewWill == true {
                arr_Main = []
                int_CountLoad = arr_StoreTemp.count
            }else{
                int_CountLoad = int_CountLoad + arr_StoreTemp.count
            }
            
            for i in (0...arr_StoreTemp.count-1){
                arr_Main.add(arr_StoreTemp[i])
            }
            
            //Load more data or not
            if GlobalConstants.int_LoadMax > arr_StoreTemp.count {
                //Bool Load more
                bool_SearchMore = false
            }
            else {
                //Bool Load more
                bool_SearchMore = true
            }
        }
        
        self.completedServiceCalling()
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        bool_SearchMore = false
        self.completedServiceCalling()
    }
}


extension MapMyScheduleViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "schedule" {
            
            let dict_Result = response["Result"] as! NSDictionary
            let arr_Result = dict_Result["data"] as! NSArray
            
            arr_Main = []
            for i in 0..<arr_Result.count{
                let dict_Value = arr_Result[i] as! NSDictionary
                let dict_Customer = dict_Value["customer"] as! NSDictionary
                
                let obj = GlobalObject()
                obj.str_Id = dict_Value.getStringForID(key: "id")
                obj.str_Customer_Id = dict_Value.getStringForID(key: "customer_id")
                obj.str_Customer_Address = dict_Value.getStringForID(key: "address")
                obj.str_Customer_Lat = dict_Value.getStringForID(key: "lat")
                obj.str_Customer_Long = dict_Value.getStringForID(key: "longs")
                obj.str_Customer_DogName = dict_Value.getStringForID(key: "dog_name")
                obj.str_Customer_Spouse_Name = dict_Value.getStringForID(key: "spouse_name")
                obj.str_Customer_Note = dict_Value.getStringForID(key: "note")
                obj.str_Customer_DateOnly = dict_Value.getStringForID(key: "job_date")
                obj.str_Customer_StartTime = dict_Value.getStringForID(key: "start_time")
                obj.str_Customer_EndTime = dict_Value.getStringForID(key: "end_time")
                obj.str_Customer_job_status = dict_Value.getStringForID(key: "job_status")
                obj.str_Customer_Confirm_Msg_Count = dict_Value.getStringForID(key: "confirm_msg_count")
                obj.str_Customer_job_status_Text = dict_Value.getStringForID(key: "job_status_text")
                
                obj.str_Customer_Title = "\(dict_Customer.getStringForID(key: "first_name") as! String) \(dict_Customer.getStringForID(key: "last_name") as! String)"
                
                arr_Main.add(obj)
            }
            
            vw_MapGoogle.clear()
            
            self.manageMapView()
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}

extension TrainingViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "getvideo" {
            
            let arr_Result = response["Result"] as! NSArray
            
            arr_Main = []
            for i in 0..<arr_Result.count{
                let obj = VideoObject()
                
                let dict_Value = arr_Result[i] as! NSDictionary
                let arr_Video = dict_Value["video"] as! NSArray
                
                obj.str_VideoCategory = dict_Value.getStringForID(key: "name")
                
                obj.arr_SaveVideos = []
                for j in 0..<arr_Video.count{
                    let dict_Save = arr_Video[j] as! NSDictionary
                    
                    let objSub = VideoObject()
                    objSub.str_VideoID = dict_Save.getStringForID(key: "id")
                    objSub.str_VideoURL = dict_Save.getStringForID(key: "video_url")
                    objSub.str_VideoImage = dict_Save.getStringForID(key: "thumb_url")
                    obj.arr_SaveVideos.add(objSub)
                }
                arr_Main.add(obj)
            }
            
            tbl_Main.reloadData()
        }else if strRequest == "rewardpoint" {
            
            let dict_Result = response["Result"] as! NSDictionary
            
            //Notification Count
            str_NotificationCount = dict_Result.getStringForID(key: "notification_unread")
            str_MessageCount = dict_Result.getStringForID(key: "message_unread")
            
            objUser?.user_RunMode = dict_Result.getStringForID(key: "run_mode")
            objUser?.user_Reward_Point = dict_Result.getStringForID(key: "reward_point")
            
            //Save User Object
            saveCustomObject(objUser!, key: "userobject");
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        arr_Main = []
        tbl_Main.reloadData()
    }
}



//MARK: - Plivo Call Controllers -

extension SettingsViewController : WebServiceHelperDelegate{
    
    //MARK: - SettingsViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "logout" {
            
            //Store data nill value when user logout
            let defaults = UserDefaults.standard
            defaults.removeObject(forKey: "userobject")
            defaults.synchronize()
            
            
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let nav: UINavigationController! = (appDelegate.window?.rootViewController as! UINavigationController)
            let view : UIViewController = nav.viewControllers[1]
            //                nav.popToRootViewController(animated: true)
            nav.popToViewController(view, animated: true)
        }else if strRequest == "subadmin" {
            let arr_responseLanguage = response["Result"] as! NSArray
            
            arr_Main = []
            for i in 0..<arr_responseLanguage.count{
                let dict_Temp : NSDictionary = arr_responseLanguage[i] as! NSDictionary
                
                let objSub = GlobalObject()
                objSub.str_User_Id =  dict_Temp.getStringForID(key: "user_id")
                objSub.str_User_Name =  dict_Temp.getStringForID(key: "user_name")
                objSub.str_User_AccessToken =  dict_Temp.getStringForID(key: "accessToken")
                objSub.str_User_Email =  dict_Temp.getStringForID(key: "email")
                objSub.str_User_Phone =  dict_Temp.getStringForID(key: "phone")
                
                arr_Main.add(objSub)
            }
            tbl_Main.reloadData()
        }else if strRequest == "delete" {
            self.Post_adminList()
        }
    }
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}


extension PlivoCallController : WebServiceHelperDelegate{
    
    //MARK: - PlivoCallController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "logout" {

            //Store data nill value when user logout
            let defaults = UserDefaults.standard
            defaults.removeObject(forKey: "userobject")
            defaults.synchronize()

            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let nav: UINavigationController! = (appDelegate.window?.rootViewController as! UINavigationController)
            let view : UIViewController = nav.viewControllers[0]
            //                nav.popToRootViewController(animated: true)
            nav.popToViewController(view, animated: true)
        }else if strRequest == "Call" {

        }else if strRequest == "xmlupdate"{
            self.manageCalling()
        }else if strRequest == "today" {

            let dict_Result = response["Result"] as! NSDictionary
            let arr_Result = dict_Result["data"] as! NSArray

            arr_Main = []
            for i in 0..<arr_Result.count{
                let dict_Value = arr_Result[i] as! NSDictionary
                let dict_Customer = dict_Value["customer"] as! NSDictionary

                let obj = GlobalObject()
                obj.str_Id = dict_Value.getStringForID(key: "id")
                obj.str_Customer_Id = dict_Value.getStringForID(key: "customer_id")
                obj.str_Customer_Address = dict_Value.getStringForID(key: "address")
                obj.str_Customer_Lat = dict_Value.getStringForID(key: "lat")
                obj.str_Customer_Long = dict_Value.getStringForID(key: "longs")
                obj.str_Customer_DogName = dict_Value.getStringForID(key: "dog_name")
                obj.str_Customer_Spouse_Name = dict_Value.getStringForID(key: "spouse_name")
                obj.str_Customer_Note = dict_Value.getStringForID(key: "note")
                obj.str_Customer_DateOnly = dict_Value.getStringForID(key: "job_date")
                obj.str_Customer_StartTime = dict_Value.getStringForID(key: "start_time")
                obj.str_Customer_EndTime = dict_Value.getStringForID(key: "end_time")

                obj.str_Customer_Title = "\(dict_Customer.getStringForID(key: "first_name") as! String) \(dict_Customer.getStringForID(key: "last_name") as! String)"

                arr_Main.add(obj)
            }

            vw_MapGoogle.clear()

            self.manageMapView()
        }else if strRequest == "banner" {

            let dict_Result = response["Result"] as! NSDictionary
            let arr_Result = dict_Result["data"] as! NSArray

            arr_Banner = []
            for i in 0..<arr_Result.count{
                let dict_Value = arr_Result[i] as! NSDictionary

                let obj = BannerObject()
                obj.str_BannerLink = dict_Value.getStringForID(key: "banner_link")
                obj.str_BannerImage = dict_Value.getStringForID(key: "banner_image")

                arr_Banner.add(obj)
            }
            cv_Header.reloadData()
        }else if strRequest == "comman" {

            let dict_Result = response["Result"] as! NSDictionary

            //Notification Count
            str_NotificationCount = dict_Result.getStringForID(key: "notification_unread")
            str_MessageCount = dict_Result.getStringForID(key: "message_unread")
            
            objUser?.user_RunMode = dict_Result.getStringForID(key: "run_mode")
            objUser?.user_Reward_Point = dict_Result.getStringForID(key: "reward_point")
            
            //Save User Object
            saveCustomObject(objUser!, key: "userobject");
        }
    }
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}


extension PhoneViewController : WebServiceHelperDelegate{
    
    //MARK: - PhoneViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "Call" {
            //            if response["error"] == nil{
            //                //Alert show for Header
            //                messageBar.MessageShow(title: "Calling successfully", alertType: MessageView.Layout.cardView, alertTheme: .success, TopBottom: true)
            //            }else{
            //                //Alert show for Header
            //                messageBar.MessageShow(title: "Somthing went to wrong", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
            //            }
        }
    }
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}

extension ContactsViewController : WebServiceHelperDelegate{
    
    //MARK: - ContactsViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "Call" {
            //            if response["error"] == nil{
            //                //Alert show for Header
            //                messageBar.MessageShow(title: "Calling successfully", alertType: MessageView.Layout.cardView, alertTheme: .success, TopBottom: true)
            //            }else{
            //                //Alert show for Header
            //                messageBar.MessageShow(title: "Somthing went to wrong", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
            //            }
        }else if strRequest == "add"{
            self.dismiss(animated: true, completion: nil)
        }else if strRequest == "add2"{
            self.fetchContacts()
            self.tbl_Main.reloadData()
        }
        
    }
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}

extension ContactsListViewController : WebServiceHelperDelegate{
    
    //MARK: - ContactsViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "contacts" {
            
            do {
                
                let arr_responseLanguage = response["Result"] as! NSArray
                
                self.arr_Main = []
                for i in 0..<arr_responseLanguage.count{
                    let dict_Data = arr_responseLanguage[i] as! NSDictionary
                    
                    let dict : NSMutableDictionary = [:]
                    dict.setValue("\(dict_Data.getStringForID(key: "first_name") as! String) \(dict_Data.getStringForID(key: "last_name") as! String)", forKey: "name")
                    dict.setValue(dict_Data.getStringForID(key: "email"), forKey: "image")
                    dict.setValue(dict_Data.getStringForID(key: "phone"), forKey: "number")
                    dict.setValue(dict_Data.getStringForID(key: "contact_id"), forKey: "contact_id")
                    dict.setValue(dict_Data.getStringForID(key: "address"), forKey: "address")
                    dict.setValue(dict_Data.getStringForID(key: "contact_id"), forKey: "contact_id")
                    self.arr_Main.add(dict)
                }
            } catch {
            }
            self.tbl_Main.reloadData()
        }else if strRequest == "delete"{
            self.GetContact()
        }
    }
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}


extension NewMessageViewController : WebServiceHelperDelegate{
    
    //MARK: - NewMessageViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "Message" {
            //            if response["error"] == nil{
            //                self.dismiss(animated: true, completion: nil)
            //
            //                //Alert show for Header
            //                messageBar.MessageShow(title: "Message send successfully", alertType: MessageView.Layout.cardView, alertTheme: .success, TopBottom: true)
            //            }else{
            //                //Alert show for Header
            //                messageBar.MessageShow(title: "Somthing went to wrong", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
            //            }
            
            self.dismiss(animated: true, completion: nil)
        }
    }
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}


extension CreateUserViewController : WebServiceHelperDelegate{
    
    //MARK: - CreateUserViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "create" {
            self.navigationController?.popViewController(animated: true)
        }
    }
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}



extension RecentsViewController : WebServiceHelperDelegate{
    
    //MARK: - RecentsViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "Call" {
            let response2 = response["Result"] as! NSDictionary
            let arr_responseLanguage : NSArray = response2["objects"] as! NSArray
            //            let arr_responseLanguage = response["objects"] as! NSArray
            arr_Main = []
            for i in 0..<arr_responseLanguage.count{
                let dict_Temp : NSDictionary = arr_responseLanguage[i] as! NSDictionary
                
                let objSub = GlobalObject()
                objSub.str_Recent_To_Number =  dict_Temp.getStringForID(key: "to_number")
                objSub.str_Recent_CallDirection =  dict_Temp.getStringForID(key: "call_direction")
                objSub.str_Recent_CallDuration =  dict_Temp.getStringForID(key: "call_duration")
                objSub.str_Recent_Callstate =  dict_Temp.getStringForID(key: "call_state")
                objSub.str_Recent_Initiation_Time =  dict_Temp.getStringForID(key: "initiation_time")
                objSub.str_Recent_Total_Amount =  dict_Temp.getStringForID(key: "total_amount")
                objSub.str_Recent_Title =  dict_Temp.getStringForID(key: "to_name")
                objSub.str_Recent_From_Title =  dict_Temp.getStringForID(key: "from_name")
                objSub.img_Recent_Image = UIImage(named: "icon_AppMain")!
                
                
                //Contact Detail
                objSub.str_MessageTo_FirstName =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageTo_LastName =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageTo_Email =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageTo_Phone =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageTo_ContatId =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageTo_Address =  dict_Temp.getStringForID(key: "from_name")
                
                objSub.str_MessageFrom_FirstName =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageFrom_LastName =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageFrom_Email =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageFrom_Phone =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageFrom_ContatId =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageFrom_Address =  dict_Temp.getStringForID(key: "from_name")
                
                
                
                //Use code for get contact detail name from my phone
                //                let dict = self.ContactMatch(str_Match: dict_Temp.getStringForID(key: "to_number"))
                //                if dict.count != 0{
                //                    objSub.str_Recent_Title = dict["name"] as! String
                //                    objSub.img_Recent_Image = dict["image"] as! UIImage
                //                }else{
                //                    objSub.img_Recent_Image = UIImage(named: "icon_AppMain")!
                //                }
                
                arr_Main.add(objSub)
            }
            arr_Main_Store = NSMutableArray(array: arr_Main);
            tbl_Main.reloadData()
        }else if strRequest == "calling" {
            
        }else if strRequest == "add2" {
            self.CallHistoryAPI()
        }
    }
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}


extension RecentsMessageViewController : WebServiceHelperDelegate{
    
    //MARK: - RecentsViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "Message" {
            let response2 = response["Result"] as! NSDictionary
            let arr_responseLanguage : NSArray = response2["objects"] as! NSArray
            
            arr_Main = []
            for i in 0..<arr_responseLanguage.count{
                let dict_Temp : NSDictionary = arr_responseLanguage[i] as! NSDictionary
                
                let objSub = GlobalObject()
                objSub.str_Message = dict_Temp.getStringForID(key: "message_text")
                //                objSub.str_Message_Tital = dict_Temp.getStringForID(key: "to_number")
                objSub.str_Message_Error_code =  dict_Temp.getStringForID(key: "error_code")
                objSub.str_Message_From_Number =  dict_Temp.getStringForID(key: "from_number")
                objSub.img_Message_Direction =  dict_Temp.getStringForID(key: "message_direction")
                objSub.str_Message_State =  dict_Temp.getStringForID(key: "message_state")
                objSub.str_Message_Time =  dict_Temp.getStringForID(key: "message_time")
                objSub.str_Message_Type =  dict_Temp.getStringForID(key: "message_type")
                objSub.str_Message_UIID =  dict_Temp.getStringForID(key: "message_uuid")
                objSub.str_Message_URI =  dict_Temp.getStringForID(key: "resource_uri")
                objSub.str_Message_To_Number =  dict_Temp.getStringForID(key: "to_number")
                objSub.str_Message_Total_Amount =  dict_Temp.getStringForID(key: "total_amount")
                objSub.str_Message_Total_Rate =  dict_Temp.getStringForID(key: "total_rate")
                objSub.str_Message_Unit =  dict_Temp.getStringForID(key: "units")
                objSub.str_Message_Tital =  dict_Temp.getStringForID(key: "to_name")
                objSub.str_Message_From_Tital =  dict_Temp.getStringForID(key: "from_name")
                objSub.img_Recent_Image = UIImage(named: "icon_AppMain")!
                
                //Contact Detail
                objSub.str_MessageTo_FirstName =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageTo_LastName =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageTo_Email =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageTo_Phone =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageTo_ContatId =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageTo_Address =  dict_Temp.getStringForID(key: "from_name")
                
                objSub.str_MessageFrom_FirstName =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageFrom_LastName =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageFrom_Email =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageFrom_Phone =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageFrom_ContatId =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageFrom_Address =  dict_Temp.getStringForID(key: "from_name")
                
                //User code for get contact name from my contact list
                //                let dict = self.ContactMatch(str_Match: dict_Temp.getStringForID(key: "to_number"))
                //                if dict.count != 0{
                //                    objSub.str_Message_Tital = dict["name"] as! String
                //                    objSub.img_Recent_Image = dict["image"] as! UIImage
                //                }else{
                //                    objSub.img_Recent_Image = UIImage(named: "icon_AppMain")!
                //                }
                
                arr_Main.add(objSub)
            }
            arr_Main_Store = NSMutableArray(array: arr_Main);
            tbl_Main.reloadData()
        }else if strRequest == "calling" {
            
        }else if strRequest == "add2" {
            self.CallHistoryAPI()
        }
    }
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}




extension ContactListingViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "customer" {
            
            let dict_Result = response["Result"] as! NSDictionary
            let arr_Result = dict_Result["data"] as! NSArray
            
            var arr_StoreTemp : NSMutableArray = []
            for i in 0..<arr_Result.count{
                let dict_Value = arr_Result[i] as! NSDictionary
                
                let obj = GlobalObject()
                obj.str_Customer_Id = dict_Value.getStringForID(key: "id")
                obj.str_Customer_Title = "\(dict_Value.getStringForID(key: "first_name") as! String) \(dict_Value.getStringForID(key: "last_name") as! String)"
                obj.str_Customer_FirstName = dict_Value.getStringForID(key: "first_name") as! String
                obj.str_Customer_LastName = (dict_Value.getStringForID(key: "last_name") as! String)
                obj.str_Customer_Lat = dict_Value.getStringForID(key: "lat")
                obj.str_Customer_Long = dict_Value.getStringForID(key: "longs")
                obj.str_Customer_Address = dict_Value.getStringForID(key: "address")
                obj.str_Customer_Interest = dict_Value.getStringForID(key: "interest")
                obj.str_Customer_Note = dict_Value.getStringForID(key: "note")
                obj.str_Customer_DogName = dict_Value.getStringForID(key: "dog_name")
                obj.str_Customer_PhoneNumber = dict_Value.getStringForID(key: "phone_number")
                obj.str_Customer_JobType = dict_Value.getStringForID(key: "type")
                obj.str_Customer_ProspectDate = dict_Value.getStringForID(key: "pros_noty_date")
                
                obj.arr_Customer_ScheduleJob = []
                
                //Manage logic for day file with current time
                let arr_Temp : NSArray  = dict_Value["schedule"] as! NSArray
                
                for i in 0..<7{
                    var tenDaysfromNow: Date {
                        return (Calendar.current as NSCalendar).date(byAdding: .day, value: i+1, to: Date(), options: [])!
                    }
                    let obj2 = GlobalObject()
                    obj2.str_Customer_Name = localDateToStrignDate(date : tenDaysfromNow,type: 1)
                    obj2.str_Customer_Name2 = localDateToStrignDate(date : tenDaysfromNow,type: 2)
                    obj2.str_Customer_Month = localDateToStrignDate(date : tenDaysfromNow,type: 3)
                    obj2.str_Customer_DateOnly = localDateToStrignDate2(date : tenDaysfromNow)
                    
                    for i in 0..<arr_Temp.count{
                        let dict_Temp : NSDictionary = arr_Temp[i] as! NSDictionary
                        
                        if obj2.str_Customer_Name2 == dict_Temp.getStringForID(key: "day"){
                            
                            obj2.str_Customer_Name2 = dict_Temp.getStringForID(key: "day")
                            obj2.str_Customer_StartTime = dict_Temp.getStringForID(key: "start")
                            obj2.str_Customer_EndTime = dict_Temp.getStringForID(key: "end")
                            obj2.str_Customer_DateOnly = dict_Temp.getStringForID(key: "date")
                            break
                        }
                    }
                    obj.arr_Customer_ScheduleJob.add(obj2)
                }
                
                obj.str_Customer_ScheduleType = dict_Value.getStringForID(key: "schedule_type")
                
                arr_StoreTemp.add(obj)
            }
            
            //Refresh code
            if bool_ViewWill == true {
                arr_Main = []
                int_CountLoad = arr_StoreTemp.count
            }else{
                int_CountLoad = int_CountLoad + arr_StoreTemp.count
            }
            
            for i in (0...arr_StoreTemp.count-1){
                arr_Main.add(arr_StoreTemp[i])
            }
            
            //Load more data or not
            if GlobalConstants.int_LoadMax > arr_StoreTemp.count {
                //Bool Load more
                bool_SearchMore = false
            }
            else {
                //Bool Load more
                bool_SearchMore = true
            }
        }
        
        self.completedServiceCalling()
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        bool_SearchMore = false
        self.completedServiceCalling()
    }
}



extension AddContactViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "create" || strRequest == "update" || strRequest == "delete"
        {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}



extension MyJobPaymentTypeViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "payment" {
            self.navigationController?.popToRootViewController(animated: true)
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
    }
}


extension ReminderNotificationViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "snooze" {
           self.dismiss(animated: true, completion: nil)
            
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
    }
}



extension HomeSearchViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "search" {
            
            let dict_Result = response["Result"] as! NSDictionary
            let arr_Result = dict_Result["data"] as! NSArray
            
            var arr_StoreTemp : NSMutableArray = []
            for i in 0..<arr_Result.count{
                let dict_Value = arr_Result[i] as! NSDictionary
                
                let obj = GlobalObject()
                obj.str_Customer_Id = dict_Value.getStringForID(key: "id")
                obj.str_Customer_Title = "\(dict_Value.getStringForID(key: "first_name") as! String) \(dict_Value.getStringForID(key: "last_name") as! String)"
                obj.str_Customer_FirstName = dict_Value.getStringForID(key: "first_name") as! String
                obj.str_Customer_LastName = (dict_Value.getStringForID(key: "last_name") as! String)
                obj.str_Customer_Lat = dict_Value.getStringForID(key: "lat")
                obj.str_Customer_Long = dict_Value.getStringForID(key: "longs")
                obj.str_Customer_Address = dict_Value.getStringForID(key: "address")
                obj.str_Customer_Interest = dict_Value.getStringForID(key: "interest")
                obj.str_Customer_Note = dict_Value.getStringForID(key: "note")
                obj.str_Customer_DogName = dict_Value.getStringForID(key: "dog_name")
                obj.str_Customer_PhoneNumber = dict_Value.getStringForID(key: "phone_number")
                obj.str_Customer_JobType = dict_Value.getStringForID(key: "type")
                
                obj.arr_Customer_ScheduleJob = []
                
                //                //Manage logic for day file with current time
                //                let arr_Temp : NSArray  = dict_Value["schedule"] as! NSArray
                //
                //                for i in 0..<7{
                //                    var tenDaysfromNow: Date {
                //                        return (Calendar.current as NSCalendar).date(byAdding: .day, value: i, to: Date(), options: [])!
                //                    }
                //                    let obj2 = GlobalObject()
                //                    obj2.str_Customer_Name = localDateToStrignDate(date : tenDaysfromNow,type: 1)
                //                    obj2.str_Customer_Name2 = localDateToStrignDate(date : tenDaysfromNow,type: 2)
                //                    obj2.str_Customer_Month = localDateToStrignDate(date : tenDaysfromNow,type: 3)
                //                    obj2.str_Customer_DateOnly = localDateToStrignDate2(date : tenDaysfromNow)
                //
                //                    for i in 0..<arr_Temp.count{
                //                        let dict_Temp : NSDictionary = arr_Temp[i] as! NSDictionary
                //
                //                        if obj2.str_Customer_Name2 == dict_Temp.getStringForID(key: "day"){
                //
                //                            obj2.str_Customer_Name2 = dict_Temp.getStringForID(key: "day")
                //                            obj2.str_Customer_StartTime = dict_Temp.getStringForID(key: "start")
                //                            obj2.str_Customer_EndTime = dict_Temp.getStringForID(key: "end")
                //                            obj2.str_Customer_DateOnly = dict_Temp.getStringForID(key: "date")
                //                            break
                //                        }
                //                    }
                //                    obj.arr_Customer_ScheduleJob.add(obj2)
                //                }
                
                obj.str_Customer_ScheduleType = dict_Value.getStringForID(key: "schedule_type")
                
                arr_StoreTemp.add(obj)
            }
            
            //Refresh code
            if bool_ViewWill == true {
                arr_Main = []
                int_CountLoad = arr_StoreTemp.count
            }else{
                int_CountLoad = int_CountLoad + arr_StoreTemp.count
            }
            
            for i in (0...arr_StoreTemp.count-1){
                arr_Main.add(arr_StoreTemp[i])
            }
            
            //Load more data or not
            if GlobalConstants.int_LoadMax > arr_StoreTemp.count {
                //Bool Load more
                bool_SearchMore = false
            }
            else {
                //Bool Load more
                bool_SearchMore = true
            }
        }
        
        self.completedServiceCalling()
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        bool_SearchMore = false
        self.completedServiceCalling()
    }
}




extension SendMessageViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "Message" {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}



extension MessagePlivoViewController : WebServiceHelperDelegate{
    
    //MARK: - RecentsViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "Message" {
            let response2 = response["Result"] as! NSDictionary
            let arr_responseLanguage : NSArray = response2["objects"] as! NSArray
            
            arr_Main = []
            for i in 0..<arr_responseLanguage.count{
                let dict_Temp : NSDictionary = arr_responseLanguage[i] as! NSDictionary
                
                let objSub = GlobalObject()
                objSub.str_Message = dict_Temp.getStringForID(key: "message_text")
                //                objSub.str_Message_Tital = dict_Temp.getStringForID(key: "to_number")
                objSub.str_Message_Error_code =  dict_Temp.getStringForID(key: "error_code")
                objSub.str_Message_From_Number =  dict_Temp.getStringForID(key: "from_number")
                objSub.img_Message_Direction =  dict_Temp.getStringForID(key: "message_direction")
                objSub.str_Message_State =  dict_Temp.getStringForID(key: "message_state")
                objSub.str_Message_Time =  dict_Temp.getStringForID(key: "message_time")
                objSub.str_Message_Type =  dict_Temp.getStringForID(key: "message_type")
                objSub.str_Message_UIID =  dict_Temp.getStringForID(key: "message_uuid")
                objSub.str_Message_URI =  dict_Temp.getStringForID(key: "resource_uri")
                objSub.str_Message_To_Number =  dict_Temp.getStringForID(key: "to_number")
                objSub.str_Message_Total_Amount =  dict_Temp.getStringForID(key: "total_amount")
                objSub.str_Message_Total_Rate =  dict_Temp.getStringForID(key: "total_rate")
                objSub.str_Message_Unit =  dict_Temp.getStringForID(key: "units")
                objSub.str_Message_Tital =  dict_Temp.getStringForID(key: "to_name")
                objSub.str_Message_From_Tital =  dict_Temp.getStringForID(key: "from_name")
                objSub.img_Recent_Image = dict_Temp.getStringForID(key: "message_direction") == "inbound" ? UIImage(named: "icon_IncomingCall")! : UIImage(named: "icon_OutGoingCall")!
                
                //Contact Detail
                objSub.str_MessageTo_FirstName =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageTo_LastName =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageTo_Email =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageTo_Phone =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageTo_ContatId =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageTo_Address =  dict_Temp.getStringForID(key: "from_name")
                
                objSub.str_MessageFrom_FirstName =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageFrom_LastName =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageFrom_Email =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageFrom_Phone =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageFrom_ContatId =  dict_Temp.getStringForID(key: "from_name")
                objSub.str_MessageFrom_Address =  dict_Temp.getStringForID(key: "from_name")
                
                arr_Main.add(objSub)
            }
        }
        str_MessageCount = "0"
        self.completedServiceCalling()
    }
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}



extension NotificationViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "notification" {
            
            let dict_Result = response["Result"] as! NSDictionary
            let arr_Result = dict_Result["data"] as! NSArray
            
            var arr_StoreTemp : NSMutableArray = []
            for i in 0..<arr_Result.count{
                let dict_Value = arr_Result[i] as! NSDictionary
                
                let obj = GlobalObject()
                obj.str_Notification_Id = dict_Value.getStringForID(key: "id")
                obj.str_Notification_User_Id = dict_Value.getStringForID(key: "user_id")
                obj.str_Notification_Text = dict_Value.getStringForID(key: "text")
                obj.str_Notification_Type = dict_Value.getStringForID(key: "type")
                obj.str_Notification_Is_Read = dict_Value.getStringForID(key: "is_read")
                obj.str_Notification_Time = dict_Value.getStringForID(key: "created_at")
                
                arr_StoreTemp.add(obj)
            }
            
            //Refresh code
            if bool_ViewWill == true {
                arr_Main = []
                int_CountLoad = arr_StoreTemp.count
            }else{
                int_CountLoad = int_CountLoad + arr_StoreTemp.count
            }
            
            for i in (0...arr_StoreTemp.count-1){
                arr_Main.add(arr_StoreTemp[i])
            }
            
            //Load more data or not
            if GlobalConstants.int_LoadMax > arr_StoreTemp.count {
                //Bool Load more
                bool_SearchMore = false
            }
            else {
                //Bool Load more
                bool_SearchMore = true
            }
            str_NotificationCount = "0"
        }else if strRequest == "delete" {
            
            arr_Main = []
            tbl_Main.reloadData()
        }
        
        self.completedServiceCalling()
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        bool_SearchMore = false
        self.completedServiceCalling()
    }
}



extension AppDelegate : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "notification" {
            let dict_Result = response["Result"] as! NSDictionary
            
            //Notification Count
            str_NotificationCount = dict_Result.getStringForID(key: "notification_unread")
            str_MessageCount = dict_Result.getStringForID(key: "message_unread")
        }else if strRequest == "update"{
            
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}




extension PurchaseHistoryViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "notification" {
            
            let dict_Result = response["Result"] as! NSDictionary
            let arr_Result = dict_Result["data"] as! NSArray
            
            var arr_StoreTemp : NSMutableArray = []
            for i in 0..<arr_Result.count{
                let dict_Value = arr_Result[i] as! NSDictionary
                
                let obj = GlobalObject()
                obj.str_Notification_Id = dict_Value.getStringForID(key: "id")
                obj.str_Notification_User_Id = dict_Value.getStringForID(key: "user_id")
                obj.str_Notification_Text = dict_Value.getStringForID(key: "text")
                obj.str_Notification_Type = dict_Value.getStringForID(key: "type")
                obj.str_Notification_Is_Read = dict_Value.getStringForID(key: "is_read")
                obj.str_Notification_Time = dict_Value.getStringForID(key: "created_at")
                
                arr_StoreTemp.add(obj)
            }
            
            //Refresh code
            if bool_ViewWill == true {
                arr_Main = []
                int_CountLoad = arr_StoreTemp.count
            }else{
                int_CountLoad = int_CountLoad + arr_StoreTemp.count
            }
            
            for i in (0...arr_StoreTemp.count-1){
                arr_Main.add(arr_StoreTemp[i])
            }
            
            //Load more data or not
            if GlobalConstants.int_LoadMax > arr_StoreTemp.count {
                //Bool Load more
                bool_SearchMore = false
            }
            else {
                //Bool Load more
                bool_SearchMore = true
            }
            str_NotificationCount = "0"
        }
        
        self.completedServiceCalling()
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        bool_SearchMore = false
        self.completedServiceCalling()
    }
}



extension ListCanceledJobsViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "schedule" {
            
            let dict_Result = response["Result"] as! NSDictionary
            let arr_Result = dict_Result["data"] as! NSArray
            
            let arr_StoreTemp : NSMutableArray = []
            for i in 0..<arr_Result.count{
                let dict_Value = arr_Result[i] as! NSDictionary
                let dict_Customer = dict_Value["customer"] as! NSDictionary
                let dict_Payment = dict_Value["payment"] as! NSDictionary
                
                let obj = GlobalObject()
                obj.str_Id = dict_Value.getStringForID(key: "id")
                obj.str_Customer_Id = dict_Value.getStringForID(key: "customer_id")
                obj.str_Customer_Address = dict_Value.getStringForID(key: "address")
                obj.str_Customer_Lat = dict_Value.getStringForID(key: "lat")
                obj.str_Customer_Long = dict_Value.getStringForID(key: "longs")
                obj.str_Customer_DogName = dict_Value.getStringForID(key: "dog_name")
                obj.str_Customer_Spouse_Name = dict_Value.getStringForID(key: "spouse_name")
                obj.str_Customer_Note = dict_Value.getStringForID(key: "note")
                obj.str_Customer_DateOnly = dict_Value.getStringForID(key: "job_date")
                obj.str_Customer_StartTime = dict_Value.getStringForID(key: "start_time")
                obj.str_Customer_EndTime = dict_Value.getStringForID(key: "end_time")
                obj.str_Customer_job_status_Text = dict_Value.getStringForID(key: "job_status_text")
                
                obj.str_Customer_Job_Amount = dict_Payment.getStringForID(key: "end_time")
                obj.str_Customer_Job_Payment_Method = dict_Payment.getStringForID(key: "end_time")
                obj.str_Customer_Job_Cheque_Num = dict_Payment.getStringForID(key: "end_time")
                
                obj.str_Customer_Title = "\(dict_Customer.getStringForID(key: "first_name") as! String) \(dict_Customer.getStringForID(key: "last_name") as! String)"
                
                arr_StoreTemp.add(obj)
            }
            
            //Refresh code
            if bool_ViewWill == true {
                arr_Main = []
                int_CountLoad = arr_StoreTemp.count
            }else{
                int_CountLoad = int_CountLoad + arr_StoreTemp.count
            }
            
            for i in (0...arr_StoreTemp.count-1){
                arr_Main.add(arr_StoreTemp[i])
            }
            
            //Load more data or not
            if GlobalConstants.int_LoadMax > arr_StoreTemp.count {
                //Bool Load more
                bool_SearchMore = false
            }
            else {
                //Bool Load more
                bool_SearchMore = true
            }
            
            //            bool_ViewWill = false
            //
            //            self.tbl_Main.reloadData()
        }else if strRequest == "delete"{
            arr_Main = []
            tbl_Main.reloadData()
            
            int_CountLoad = GlobalConstants.int_LoadMax
            bool_ViewWill = true
            bool_SearchMore = true
            
            self.Post_JobsListing(count:int_CountLoad)
        }
        
        
        self.completedServiceCalling()
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        bool_SearchMore = false
        self.completedServiceCalling()
    }
}


extension PointViewController : WebServiceHelperDelegate{
    
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "point" {
            
            let dict_Result = response["Result"] as! NSDictionary
            let arr_Result = dict_Result["data"] as! NSArray
            
            let arr_StoreTemp : NSMutableArray = []
            for i in 0..<arr_Result.count{
                let dict_Value = arr_Result[i] as! NSDictionary
                let obj = GlobalObject()
                
                obj.str_Message_Tital = dict_Value.getStringForID(key: "text")
                obj.str_Message_Discription = dict_Value.getStringForID(key: "point")
                obj.str_Id = dict_Value.getStringForID(key: "id")
                
                arr_StoreTemp.add(obj)
            }
            
            //Refresh code
            if bool_ViewWill == true {
                arr_Main = []
                int_CountLoad = arr_StoreTemp.count
            }else{
                int_CountLoad = int_CountLoad + arr_StoreTemp.count
            }
            
            for i in (0...arr_StoreTemp.count-1){
                arr_Main.add(arr_StoreTemp[i])
            }
            
            //Load more data or not
            if GlobalConstants.int_LoadMax > arr_StoreTemp.count {
                //Bool Load more
                bool_SearchMore = false
            }
            else {
                //Bool Load more
                bool_SearchMore = true
            }
        }
        
        self.completedServiceCalling()
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        bool_SearchMore = false
        self.completedServiceCalling()
    }
}

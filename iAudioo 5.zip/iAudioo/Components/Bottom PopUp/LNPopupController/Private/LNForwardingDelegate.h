//
//  LNForwardingDelegate.h
//  LNPopupController
//
//  Created by Leo Natan (Wix) on 15/07/2017.
//  Copyright © 2017 Leo Natan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LNForwardingDelegate : NSObject

@property (nonatomic, weak) id forwardedDelegate;

@end

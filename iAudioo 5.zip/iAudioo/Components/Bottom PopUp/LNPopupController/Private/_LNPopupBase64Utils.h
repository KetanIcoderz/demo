//
//  _LNPopupBase64Utils.h
//  LNPopupController
//
//  Created by Leo Natan (Wix) on 1/14/18.
//  Copyright © 2018 Leo Natan. All rights reserved.
//

#import <Foundation/Foundation.h>

NSString* _LNPopupDecodeBase64String(NSString* base64String);

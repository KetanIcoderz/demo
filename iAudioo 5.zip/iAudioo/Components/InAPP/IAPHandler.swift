//
//  IAPHandler.swift
//  Vana
//
//  Created by Apple on 10/04/18.
//  Copyright © 2018 Apple. All rights reserved.
//

import Foundation
import StoreKit
import SwiftyReceiptValidator

enum IAPHandlerAlertType{
    case disabled
    case restored
    case purchased
    
    func message() -> String{
        switch self {
        case .disabled: return "Purchases are disabled in your device!"
        case .restored: return "You've successfully restored your purchase!"
        case .purchased: return "You've successfully bought this purchase!"
        }
    }
}
    class IAPHandler: NSObject {
        static let shared = IAPHandler()
        
        let CONSUMABLE_PURCHASE_PRODUCT_ID = "com.houstonmitchell.iaudioo1"
        let CONSUMABLE_PURCHASE_PRODUCT_ID2 = "com.houstonmitchell.iaudioo2"
//        let NON_CONSUMABLE_PURCHASE_PRODUCT_ID = "non.consumable"
        
        fileprivate var productID = ""
        fileprivate var productsRequest = SKProductsRequest()
        fileprivate var iapProducts = [SKProduct]()
        
        var purchaseStatusBlock: ((IAPHandlerAlertType) -> Void)?
        
        // MARK: - MAKE PURCHASE OF A PRODUCT
        func canMakePurchases() -> Bool {  return SKPaymentQueue.canMakePayments()  }
        
        func purchaseMyProduct(index: Int){
            if iapProducts.count == 0 { return }
            
            if self.canMakePurchases() {
                var bool_Match : Bool = false
                for product in iapProducts{
                    if product.productIdentifier == CONSUMABLE_PURCHASE_PRODUCT_ID && index == 0{
                        bool_Match = true
                    }else if product.productIdentifier == CONSUMABLE_PURCHASE_PRODUCT_ID2 && index == 1{
                        bool_Match = true
                    }
                }
                
                if bool_Match == true{
                    let product = iapProducts[index]
                    let payment = SKPayment(product: product)
                    SKPaymentQueue.default().add(self)
                    SKPaymentQueue.default().add(payment)
                    
                    print("PRODUCT TO PURCHASE: \(product.productIdentifier)")
                    productID = product.productIdentifier
                    
                    indicatorShow()
                }
            } else {
                purchaseStatusBlock?(.disabled)
            }
        }
        
        // MARK: - RESTORE PURCHASE
        func restorePurchase(){
            SKPaymentQueue.default().add(self)
            SKPaymentQueue.default().restoreCompletedTransactions()
        }
        
        
        // MARK: - FETCH AVAILABLE IAP PRODUCTS
        func fetchAvailableProducts(){
            
            // Put here your IAP Products ID's
            let productIdentifiers = NSSet(objects:
                CONSUMABLE_PURCHASE_PRODUCT_ID,
                CONSUMABLE_PURCHASE_PRODUCT_ID2
            )
            /* Multiple product id
            let productIdentifiers = NSSet(objects: CONSUMABLE_PURCHASE_PRODUCT_ID,NON_CONSUMABLE_PURCHASE_PRODUCT_ID
            )
            */
            productsRequest = SKProductsRequest(productIdentifiers: productIdentifiers as! Set<String>)
            productsRequest.delegate = self
            productsRequest.start()
        }
        
        // MARK: - Get/Post Method -
        func Post_AddSubscription(str_SubscrptionID : String,str_SubscriptionDate : String,type : String,name : String){
            
            //Declaration URL
            let strURL = "\(GlobalConstants.BaseURL)add_subscription"
            
            //Pass data in dictionary
            var jsonData : NSDictionary =  NSDictionary()
            jsonData = [
                "code" : str_SubscrptionID,
                "expiry_date" : str_SubscriptionDate,
                "type" : name,
            ]
            
            //Create object for webservicehelper and start to call method
            let webHelper = WebServiceHelper()
            webHelper.strMethodName = "add_subscription"
            webHelper.methodType = "post"
            webHelper.strURL = strURL
            webHelper.dictType = jsonData
            webHelper.dictHeader = NSDictionary()
            webHelper.delegateWeb = self
            webHelper.serviceWithAlert = true
            webHelper.startDownload()
        }
    }
    
    extension IAPHandler: SKProductsRequestDelegate, SKPaymentTransactionObserver{
        // MARK: - REQUEST IAP PRODUCTS
        func productsRequest (_ request:SKProductsRequest, didReceive response:SKProductsResponse) {
            
            if (response.products.count > 0) {
                iapProducts = response.products
                for product in iapProducts{
                    let numberFormatter = NumberFormatter()
                    numberFormatter.formatterBehavior = .behavior10_4
                    numberFormatter.numberStyle = .currency
                    numberFormatter.locale = product.priceLocale
                    let price1Str = numberFormatter.string(from: product.price)
                    print(product.localizedDescription + "\nfor just \(price1Str!)")
                }
            }
        }
        
        func paymentQueueRestoreCompletedTransactionsFinished(_ queue: SKPaymentQueue) {
            purchaseStatusBlock?(.restored)
        }
        
        // MARK:- IAP PAYMENT QUEUE
        func paymentQueue(_ queue: SKPaymentQueue, updatedTransactions transactions: [SKPaymentTransaction]) {
            for transaction:AnyObject in transactions {
                if let trans = transaction as? SKPaymentTransaction {
                    switch trans.transactionState {
                    case .purchased:
                        print("purchased")
                        SKPaymentQueue.default().finishTransaction(transaction as! SKPaymentTransaction)
                        purchaseStatusBlock?(.purchased)
                        
                        let value =  transaction as! SKPaymentTransaction
                        self.purchaseInfo(transaction : value.payment.productIdentifier)
                        queue.finishTransaction(transaction as! SKPaymentTransaction)
                        
                        break
                        
                    case .failed:
                        print("failed")
                        indicatorHide()
                        SKPaymentQueue.default().finishTransaction(transaction as! SKPaymentTransaction)
                        break
                    case .restored:
                        print("restored")
                        SKPaymentQueue.default().finishTransaction(transaction as! SKPaymentTransaction)
                        
                        let value =  transaction as! SKPaymentTransaction
                        self.purchaseInfo(transaction : value.payment.productIdentifier)
                        queue.finishTransaction(transaction as! SKPaymentTransaction)
                        
                        break
                        
                    default: break
                    }}}
        }
}

extension IAPHandler{
    func purchaseInfo(transaction : String){

        SwiftyReceiptValidator.validate(forIdentifier: transaction, sharedSecret: "8c3970776baa4931b8e55b50058adaaa") { (success, response) in
            indicatorHide()
            
            if success {
                // example 2 (auto-renewable subscriptions)
                let receiptInfoFieldKey = SwiftyReceiptValidator.ResponseKey.receipt.rawValue
                if let receipt = response![receiptInfoFieldKey] {
                    
                    // example 2
                    let inAppKey = SwiftyReceiptValidator.InfoKey.in_app.rawValue
                    if let inApp = receipt[inAppKey] as? [AnyObject] {
                        
                        if inApp.count != 0{
                            let dict_detail = inApp[inApp.count - 1] as! NSDictionary
                            let traslation_Id = dict_detail["transaction_id"] as! String
                            let traslation_ExpiredDate = dict_detail["expires_date_ms"] as! String
                            let product_id = dict_detail["product_id"] as! String
                            //1527530583000
                            //1527531432000
                            //1527531990000
                            
                            print(traslation_Id)
                            print(traslation_ExpiredDate)
                            self.Post_AddSubscription(str_SubscrptionID: traslation_Id, str_SubscriptionDate: traslation_ExpiredDate, type: "1",name : product_id)
                        }
                    }
                }
            } else {
                /// maybe show alert here
            }
        }
    }
}




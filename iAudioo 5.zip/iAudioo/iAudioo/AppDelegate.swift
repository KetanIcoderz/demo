//
//  AppDelegate.swift
//  iAudioo
//
//  Created by Apple on 19/04/18.
//  Copyright © 2018 iAudioo. All rights reserved.
//

import UIKit
import AVFoundation
import IQKeyboardManagerSwift
import SwiftMessages
import GoogleMobileAds
import FBSDKCoreKit
import FBSDKLoginKit
import Instabug
import Firebase

//Global Declaration
var messageBar = MessageBarController()
var vw_TabBarController: TabBarViewController?
var act_indicator = ActivityIndicatorViewController()
var objUser : UserDataObject?

var str_PresentView = "0"
var arr_Voice : NSMutableArray = []
var arr_Languages : NSMutableArray = []
var arr_Subscription : NSMutableArray = []

var str_PickerText = ""
var str_PresentPlayer = ""
var obj_Player = GlobalObject()
var obj_PlayerSave = GlobalObject()
var img_PlayerImage = UIImage()
var str_PlayerType : String = ""
var str_AddPresentCount = "0"
var str_SubscriptionLink = ""

var Progress_Save: UIProgressView!

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate,GADBannerViewDelegate,GADInterstitialDelegate {

    var window: UIWindow?

    var Ad_con_Bottom: NSLayoutConstraint!
    var Ad_View: UIViewController!
    var interstitial: GADInterstitial!
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        //Text editing manager
        IQKeyboardManager.sharedManager().enable = true
        IQKeyboardManager.sharedManager().enableAutoToolbar = true
        IQKeyboardManager.sharedManager().shouldShowTextFieldPlaceholder = true
        IQKeyboardManager.sharedManager().keyboardDistanceFromTextField = 20.0
        
        navigationSet(type : "0")
        self.manageUserDefualt()
        
//        GADMobileAds.configure(withApplicationID: "ca-app-pub-3940256099942544~1458002511")
        GADMobileAds.configure(withApplicationID: GlobalConstants.googleAdUnit)
        self.googleIntestrialAds()
        
        //Facebook Compusary method
        FBSDKApplicationDelegate.sharedInstance().application(application, didFinishLaunchingWithOptions: launchOptions)
        
        //Instabug
        Instabug.start(withToken: "6415e4e82455ab0fb5ce16372aeba986", invocationEvent: .shake)
        
//        for family: String in UIFont.familyNames
//        {
//            print("\(family)")
//            for names: String in UIFont.fontNames(forFamilyName: family)
//            {
//                print("== \(names)")
//            }
//        }
        
        if GlobalConstants.appLive == true{
            FirebaseApp.configure()
        }
        
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
    // MARK: - Google Banner Ads -
    func googleBannerAds(view : UIViewController,constant : NSLayoutConstraint,frame : CGRect){
        var bannerView: GADBannerView!
        
        if self.adValidation() == false{
            
            var bool_Check : Bool = false
            for view in view.view.subviews{
                if view.tag == 1000{
                    bool_Check = true
                }
            }
            
            if bool_Check == false{
                Ad_con_Bottom = constant
                Ad_View = view
                
                let request: GADRequest = GADRequest()
                request.testDevices = [kGADSimulatorID,"35ebdbdd2fa379d21153116a9a3cae3c","36090febc4372277c1d1c6c093c98c78"]
                
                // In this case, we instantiate the banner with desired ad size.
                bannerView = GADBannerView(adSize: kGADAdSizeBanner)
//                bannerView.adUnitID = "ca-app-pub-3940256099942544/2934735716"
                bannerView.adUnitID = GlobalConstants.googleBannerAd
                bannerView.rootViewController = view
                bannerView.delegate = self
                bannerView.load(request)
                bannerView.frame = frame
                bannerView.tag = 1000
                view.view.addSubview(bannerView)
                bannerView.isUserInteractionEnabled = false
            }
        }else{
            constant.constant = 0
            
            for view in view.view.subviews{
                if view.tag == 1000{
                    view.removeFromSuperview()
                }
            }
        }
    }
    
    func addBannerViewToView(_ bannerView: GADBannerView,view : UIViewController) {
        bannerView.translatesAutoresizingMaskIntoConstraints = false
        view.view.addSubview(bannerView)
      }

    
    /// Tells the delegate an ad request loaded an ad.
    func adViewDidReceiveAd(_ bannerView: GADBannerView) {
        print("adViewDidReceiveAd")
        
        bannerView.isUserInteractionEnabled = true
        UIView.animate(withDuration: 0.5, animations: {
            self.Ad_con_Bottom.constant = 50
        }, completion: { (finished) in
        })
    }
    
    /// Tells the delegate an ad request failed.
    func adView(_ bannerView: GADBannerView,
                didFailToReceiveAdWithError error: GADRequestError) {
        print("adView:didFailToReceiveAdWithError: \(error.localizedDescription)")
    }
    
    /// Tells the delegate that a full-screen view will be presented in response
    /// to the user clicking on an ad.
    func adViewWillPresentScreen(_ bannerView: GADBannerView) {
        print("adViewWillPresentScreen")
    }
    
    /// Tells the delegate that the full-screen view will be dismissed.
    func adViewWillDismissScreen(_ bannerView: GADBannerView) {
        print("adViewWillDismissScreen")
    }
    
    /// Tells the delegate that the full-screen view has been dismissed.
    func adViewDidDismissScreen(_ bannerView: GADBannerView) {
        print("adViewDidDismissScreen")
    }
    
    /// Tells the delegate that a user click will open another app (such as
    /// the App Store), backgrounding the current app.
    func adViewWillLeaveApplication(_ bannerView: GADBannerView) {
        print("adViewWillLeaveApplication")
    }
    func adValidation() -> Bool{
        for i in 0..<arr_Subscription.count{
            let objSub = arr_Subscription[i] as! GlobalObject
            
            if objSub.str_Sub_Type == "com.houstonmitchell.iaudioo1" && objSub.str_Sub_Active == "1"{
                return true
            }else if objSub.str_Sub_Type == "com.houstonmitchell.iaudioo2" && objSub.str_Sub_Active == "1"{
                return true
            }
        }
        return false
    }
    
    
    // MARK: - Google Intestrial Ads -
    func googleIntestrialAds(){
        
        let request: GADRequest = GADRequest()
//        request.testDevices = [kGADSimulatorID,"35ebdbdd2fa379d21153116a9a3cae3c","36090febc4372277c1d1c6c093c98c78"]
        
        interstitial = GADInterstitial()
//        interstitial = GADInterstitial(adUnitID: "ca-app-pub-3940256099942544/4411468910")
        interstitial = GADInterstitial(adUnitID: GlobalConstants.googleBannerInt)
        interstitial.delegate = self
        interstitial.load(request)
        
    }
    func presentFullScreenAds() -> Bool{
        if self.adValidation() == false{
            if interstitial.isReady {
                
                interstitial.present(fromRootViewController: (GlobalConstants.appDelegate?.window?.rootViewController)!)
                return true
            } else {
                print("Failed to receive Ad.")
            }
        }
        
//        let alert = UIAlertController(title: GlobalConstants.appName, message: "Failed to receive Ad.", preferredStyle: UIAlertControllerStyle.alert)
//        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: { (action) in
//
//        }))
//        self.window?.rootViewController?.present(alert, animated: true, completion: nil)
        
        return false
    }
    
    func presentFullScreenAdsCheck() -> Bool{
        if self.adValidation() == false{
            if interstitial.isReady {
                return true
            }
        }
        return false

    }
    
    func manageUserDefualt(){
        if GlobalConstants.AddPresent == nil{
            str_AddPresentCount = "0"
            UserDefaults.standard.setString(string: "0", forKey: "AddPresent")
        }else{
            str_AddPresentCount = GlobalConstants.AddPresent as! String
        }
    }
    
    /// Tells the delegate an ad request succeeded.
    func interstitialDidReceiveAd(_ ad: GADInterstitial) {
        print("interstitialDidReceiveAd")
    }
    
    /// Tells the delegate an ad request failed.
    func interstitial(_ ad: GADInterstitial, didFailToReceiveAdWithError error: GADRequestError) {
        print("interstitial:didFailToReceiveAdWithError: \(error.localizedDescription)")
    }
    
    /// Tells the delegate that an interstitial will be presented.
    func interstitialWillPresentScreen(_ ad: GADInterstitial) {
        print("interstitialWillPresentScreen")
    }
    
    /// Tells the delegate the interstitial is to be animated off the screen.
    func interstitialWillDismissScreen(_ ad: GADInterstitial) {
        self.googleIntestrialAds()
        print("interstitialWillDismissScreen")
    }
    
    /// Tells the delegate the interstitial had been animated off the screen.
    func interstitialDidDismissScreen(_ ad: GADInterstitial) {
        print("interstitialDidDismissScreen")
    }
    
    /// Tells the delegate that a user click will open another app
    /// (such as the App Store), backgrounding the current app.
    func interstitialWillLeaveApplication(_ ad: GADInterstitial) {
        print("interstitialWillLeaveApplication")
    }
    
    
    
//    func application(_ application: UIApplication, open url: URL, sourceApplication: String?, annotation: Any) -> Bool {
//        if url.scheme == "fb235317900356700" {
//            return FBSDKApplicationDelegate.sharedInstance().application(application, open: url, sourceApplication: sourceApplication, annotation: annotation)
//        }
//        return true
//    }
    
    func application(_ application: UIApplication, open url: URL, options: [UIApplicationOpenURLOptionsKey : Any] = [:]) -> Bool {
        let handled: Bool = FBSDKApplicationDelegate.sharedInstance().application(application, open: url, sourceApplication: options[.sourceApplication] as? String, annotation: options[.annotation])
        // Add any custom logic here.
        return handled
    }

    
    func application(_ application: UIApplication, open url: URL, sourceApplication: String?, annotation: Any) -> Bool {
        let handled: Bool = FBSDKApplicationDelegate.sharedInstance().application(application, open: url, sourceApplication: sourceApplication, annotation: annotation)
        // Add any custom logic here.
        return handled
    }

}


// MARK: - Navigation Manager -
func navigationSet(type : String) {
    UIBarButtonItem.appearance().setBackButtonBackgroundImage(UIImage(named: "btn_Back"), for: .normal, barMetrics: .default)
     UIBarButtonItem.appearance().setBackButtonTitlePositionAdjustment(UIOffsetMake(0, -500), for: .default)
    
    if type == "0"{
        UINavigationBar.appearance().setBackgroundImage(imageWithColor(with:UIColor.white), for: .default)
    }else{
        UINavigationBar.appearance().setBackgroundImage(imageWithColor(with:UIColor.clear), for: .default)
    }
    
    UINavigationBar.appearance().titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.black, NSAttributedStringKey.font: UIFont(name:  GlobalConstants.kFontSemiBold, size: 17.0)!]
    //        UINavigationBar.appearance().shadowImage = UIImage(named: "img_Shadow")
    UINavigationBar.appearance().shadowImage = UIImage()
    UIApplication.shared.statusBarStyle = UIStatusBarStyle.default
    
}


//Device Identifier
func deviceIdentifier() -> String{
    switch UIScreen.main.nativeBounds.height {
    case 1136:
        return "iPhone 5 or 5S or 5C"
    case 1334:
        return "iPhone 6/6S/7/8"
    case 1920, 2208:
        return "iPhone iPhone 6+/6S+/7+/8+"
    case 2436:
        return "iPhone X"
    default:
        return "unknown"
    }
}


//MARK: -- Inicator --
func indicatorShow(){
    let size = CGSize(width: 30, height: 30)
    
    act_indicator.startAnimating(size, message: "", type: NVActivityIndicatorType(rawValue:5)!)
}
func indicatorHide(){
    act_indicator.stopAnimating()
}



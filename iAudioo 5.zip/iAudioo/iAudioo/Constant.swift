//
//  Constant.swift
//
//  Created by iAudioo on 11/09/17.
//  Copyright © 2017 iAudioo. All rights reserved.


import Foundation
import UIKit
import AVFoundation
import MediaPlayer
import SwiftMessages
import IQKeyboardManagerSwift

struct GlobalConstants
{
    // Constant define here.
    static let developerTest : Bool = false
    static let appLive : Bool = true
  
    //Implementation View height
    static let screenHeightDeveloper : Double = 667
    static let screenWidthDeveloper : Double = 375
    
    //Base URL
    static let BaseURL = "http://ec2-54-71-230-176.us-west-2.compute.amazonaws.com/Development/iaudioo/api/v1/"
    
    //Name And Appdelegate Object
    static let appName: String = "iAudioo"
    static let appDelegate = (UIApplication.shared.delegate as? AppDelegate)
    static let kFontRatio =  (UIScreen.main.bounds.size.width/375)
  
    //System width height
    static let windowWidth: Double = Double(UIScreen.main.bounds.size.width)
    static let windowHeight: Double = Double(UIScreen.main.bounds.size.height)
    
    //Font
    static let kFontRegular = "OpenSans"
    static let kFontLight = "OpenSans-Light"
    static let kFontItalic = "OpenSans-Italic"
    static let kFontBold = "OpenSans-Bold"
    static let kFontSemiBold = "OpenSans-Semibold"
    
    //Google Api forKey
    static let apiKeyGoogle = "AIzaSyCuuATFaZqxiN-7tvSkEvEN41G1GP_M3uE"
    
    //Loading data pagination
    static let int_LoadMax = 6
    static let int_LoadMaxCollection = 12
    
    //Google AnalityKey
    static let apiKeyGoogleAnality = "UA-105722820-1"
    
    //Device Token
    static let DeviceToken = UserDefaults.standard.object(forKey: "DeviceToken")
    static let AddPresent = UserDefaults.standard.object(forKey: "AddPresent")
    
    //Place holder
    static let placeHolder_User = "icon_PlaceHolderUser"
    static let placeHolder_Comman = "icon_PlaceHolderSquare"
    
    //App Color
    static let appColor = UIColor(red: 0/255, green: 102/255, blue: 203/255, alpha: 1.0)
    static let appGreenColor = UIColor(red: 0/255, green: 207/255, blue: 255/255, alpha: 1.0)
    static let appPopupBackgroundColor = UIColor(red: 232/255, green: 232/255, blue: 232/255, alpha: 1.0)
    
    //Google Search
    static let googleImageSearch = "AIzaSyBd0vpZ05n2frDI2dUoTA_HSiFB4xa8Euw"
    
    //tempIMage232
    static let img_Temp = "https://hellodotcom.hello.com/img_/hello_logo_hero.png"
    
    //Google Admob
    static let googleAdUnit = "ca-app-pub-6983061144638658~4416741091"
    static let googleBannerAd = "ca-app-pub-6983061144638658/8139954566"
    static let googleBannerInt = "ca-app-pub-6983061144638658/4619921075"
    
    //Registration
    static let deviceType = "iphone"
    
    //Player Controller
    static let playerWordPerPlaySecond = 0.073
}


// MARK: - User Object Updatet -
func userObjectUpdate(dict_Get : NSDictionary){
    
    let dict_result = dict_Get["user_detail"] as! NSDictionary
    
    //Store data in object
    let obj = UserDataObject(user_UserID : dict_result.getStringForID(key: "id"),
                             user_Name : dict_result.getStringForID(key: "name"),
                             user_Email : dict_result.getStringForID(key: "email"),
                             user_Image : dict_result.getStringForID(key: "image"),
                             user_Account_Type : dict_result.getStringForID(key: "account_type"),
                             user_Socialid : dict_result.getStringForID(key: "social_id"),
                             user_isActive : dict_result.getStringForID(key: "is_active"),
                             user_Access_token : dict_result.getStringForID(key: "access_token"),
                             user_Language_id : dict_result.getStringForID(key: "language_id"),
                             user_Voice_id : dict_result.getStringForID(key: "voice_id"),
                             user_Created_at : dict_result.getStringForID(key: "created_at"),
                             user_Updated_at : dict_result.getStringForID(key: "updated_at"),
                             plyer_DisplayType : "0",
                             user_Profile_image : dict_result.getStringForID(key: "profile_image"))
    
    //Save User Object
    saveCustomObject(obj, key: "userobject");
    
    //Save Object In global variable
    objUser = obj
}



func removeSpecialCharsFromString(text: String) -> String {

    let charsToRemove: Set<Character> = Set("[{}\\[\\]+:?,\"\'".characters)
    let newNumberCharacters = String(text.characters.filter { !charsToRemove.contains($0) })
    print(newNumberCharacters) //prints 1 832 8316486
     return newNumberCharacters
}


//MARK: - Manage Font -
func manageFontHeight(font : Double) -> CGFloat{
    let cal : Double = GlobalConstants.windowHeight * font
    
    return CGFloat(cal / GlobalConstants.screenHeightDeveloper)
}

func manageFont(font : Double) -> CGFloat{
    let cal : Double = GlobalConstants.windowWidth * font
    
    return CGFloat(cal / GlobalConstants.screenWidthDeveloper)
}


// MARK: - Make Image with Color -
func imageWithColor(with color: UIColor) -> UIImage {
    let rect = CGRect(x: CGFloat(0.0), y: CGFloat(0.0), width: CGFloat(1.0), height: CGFloat(1.0))
    UIGraphicsBeginImageContext(rect.size)
    let context: CGContext? = UIGraphicsGetCurrentContext()
    context?.setFillColor(color.cgColor)
    context?.fill(rect)
    let image: UIImage? = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    
    return image!
}

////MARK: -- Inicator --
//func indicatorShow() {
//    let size = CGSize(width: 30, height: 30)
//
//    act_indicator.startAnimating(size, message: "Loading", type: NVActivityIndicatorType(rawValue:2)!)
//}
//func indicatorHide() {
//    act_indicator.stopAnimating()
//}

//MARK: -- Email Validation --
func validateEmail(enteredEmail:String) -> Bool {
    
    let emailFormat = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
    let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailFormat)
    return emailPredicate.evaluate(with: enteredEmail)
}

func validatePhoneNumber(value: String) -> Bool {
    let charcterSet  = NSCharacterSet(charactersIn: "+0123456789").inverted
    let inputString = value.components(separatedBy: charcterSet)
    let filtered = inputString.joined(separator: "")
    return  value == filtered
}

//MARK: - Manage function for value save -
extension NSDictionary {
    func getStringForID(key: String) -> String! {
        
        var strKeyValue : String = ""
        if self[key] != nil {
            if (self[key] as? Int) != nil {
                strKeyValue = String(self[key] as? Int ?? 0)
            } else if (self[key] as? String) != nil {
                strKeyValue = self[key] as? String ?? ""
            }else if (self[key] as? Double) != nil {
                strKeyValue = String(self[key] as? Double ?? 0)
            }else if (self[key] as? Float) != nil {
                strKeyValue = String(self[key] as? Float ?? 0)
            }else if (self[key] as? Bool) != nil {
                let bool_Get = self[key] as? Bool ?? false
                if bool_Get == true{
                    strKeyValue = "1"
                }else{
                    strKeyValue = "0"
                }
            }
        }
        return strKeyValue
    }
    
    func getArrayVarification(key: String) -> NSArray {
        
        var strKeyValue : NSArray = []
        if self[key] != nil {
            if (self[key] as? NSArray) != nil {
                strKeyValue = self[key] as? NSArray ?? []
            }
        }
        return strKeyValue
    }
}

//MARK: --User Object--
func saveCustomObject(_ object: UserDataObject, key: String) {
    let encodedObject = NSKeyedArchiver.archivedData(withRootObject: object)
    let defaults = UserDefaults.standard
    defaults.set(encodedObject, forKey: key)
    defaults.synchronize()
}

func loadCustomObject(withKey key: String) -> UserDataObject? {
    let defaults = UserDefaults.standard
    let encodedObject: Data? = defaults.object(forKey: key) as! Data?
    if encodedObject != nil {
        let object: UserDataObject? = NSKeyedUnarchiver.unarchiveObject(with: encodedObject!) as! UserDataObject?
        return object!
    }
    return nil
}


//MARK: - Calculate widht or height of string -
extension String {
    
    func widthOfString(usingFont font: UIFont) -> CGFloat {
        let fontAttributes = [NSAttributedStringKey.font: font]
        let size = self.size(withAttributes: fontAttributes)
        return size.width
    }
    
    func heightOfString(usingFont font: UIFont) -> CGFloat {
        let fontAttributes = [NSAttributedStringKey.font: font]
        let size = self.size(withAttributes: fontAttributes)
        return size.height
    }
    
    func height(withConstrainedWidth width: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: width, height: .greatestFiniteMagnitude)
        let boundingBox = self.boundingRect(with: constraintRect, options: .usesLineFragmentOrigin, attributes: [NSAttributedStringKey.font: font], context: nil)
        
        return ceil(boundingBox.height)
    }
    
    func width(withConstrainedHeight height: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: .greatestFiniteMagnitude, height: height)
        let boundingBox = self.boundingRect(with: constraintRect, options: .usesLineFragmentOrigin, attributes: [NSAttributedStringKey.font: font], context: nil)
        
        return ceil(boundingBox.width)
    }
}



//MARK: -- Selected Index --
func selectedIndex(arr : NSArray, value : NSString) -> Int{
    for (index, element) in arr.enumerated() {
        if value as String == arr[index] as! String {
            return index
        }
    }
    return 0
}
extension UserDefaults {
    func setString(string:String, forKey:String) {
        set(string, forKey: forKey)
    }
    func setDate(date:NSDate, forKey:String) {
        set(date, forKey: forKey)
    }
    //  func dateForKey(string:String) -> NSDate? {
    //    return objectForKey(string) as? NSDate
    //  }
}


func TabbarManager(view : UIViewController){
//    let titlesArray = ["Style \"Scale From Big\"",
//                               "Style \"Slide Above\"",
//                               "Style \"Slide Below\"",
//                               "Style \"Scale From Little\"",
//                               "Blurred root view cover",
//                               "Blurred side views covers",
//                               "Blurred side views backgrounds",
//                               "Landscape always visible",
//                               "Status bar always visible",
//                               "Gesture area full screen",
//                               "Editable table view",
//                               "Custom style"]
    
    let viewController : UIViewController = TabBarViewController()
    
    let storyboard = UIStoryboard(name: "Main", bundle: nil)
    let navigationController = storyboard.instantiateViewController(withIdentifier: "NavigationController") as! UINavigationController
    
    navigationController.setViewControllers([storyboard.instantiateViewController(withIdentifier: "TabBarViewController")], animated: false)
    
    let mainViewController = storyboard.instantiateViewController(withIdentifier: "MainViewController") as! MainViewController
    mainViewController.rootViewController = navigationController
    mainViewController.setup(type: UInt(0))
    
    let window = UIApplication.shared.delegate!.window!!
//    window.rootViewController = mainViewController
    view.navigationController?.pushViewController(mainViewController, animated: true)
    
    UIView.transition(with: window, duration: 0.3, options: [.transitionCrossDissolve], animations: nil, completion: nil)
    
    
}



// MARK: - All Object -
class SideMenuModuleObject : NSObject {
    var str_Title: String = ""
    var str_Selected: String = ""
    var str_Image: String = ""
}

class GlobalObject : NSObject {
    //Library
    var str_Library_Title: String = ""
    var str_Library_NumberOfNot: String = ""
    var str_Library_RemingTime: String = ""
    var str_Library_ProgressPer: String = ""
    var str_Library_Image: String = ""
    
    //Libaray
    var str_Lib_Id: String = ""
    var str_Lib_User_Id: String = ""
    var str_Lib_Title: String = ""
    var str_Lib_Text: String = ""
    var str_Lib_Type: String = ""
    var str_Lib_Image: String = ""
    var str_Lib_Progress: String = ""
    var str_Lib_Status: String = ""
    var str_Lib_Created_At: String = ""
    var str_Lib_Updated_At: String = ""
    var str_Lib_Deleted_At: String = ""
    var str_Lib_Note_Count: String = ""
    var str_Lib_Total_Time: String = ""
    var str_Lib_PassType: String = ""
    
    var arr_JustCreated: NSMutableArray = []
    var arr_ContinueReading: NSMutableArray = []
    var arr_InProgress: NSMutableArray = []
    var arr_Completed: NSMutableArray = []
    
    //Language
    var str_Lan_Id: String = ""
    var str_Lan_Name: String = ""
    var str_Lan_Code: String = ""
    var str_Lan_Active: String = ""
    
    //Voice
    var str_Voice_Id: String = ""
    var str_Voice_Name: String = ""
    var str_Voice_Code: String = ""
    var str_Voice_Active: String = ""
    
    //Note
    var str_Note_Id: String = ""
    var str_Note_Title: String = ""
    var str_Note_Description: String = ""
    var str_Note_Library_Id: String = ""
    var str_Note_Created_At: String = ""
    var str_Note_Updated_At: String = ""
    
    //Subscription
    var str_Sub_Id: String = ""
    var str_Sub_Code: String = ""
    var str_Sub_Expiry_date: String = ""
    var str_Sub_Type: String = ""
    var str_Sub_Active: String = ""
    
}

//MARK: - Array To string convertion -
func notPrettyString(from object: Any) -> String? {
    if let objectData = try? JSONSerialization.data(withJSONObject: object, options: JSONSerialization.WritingOptions(rawValue: 0)) {
        let objectString = String(data: objectData, encoding: .utf8)
        return objectString
    }
    return nil
}


//Player Controller
func playerControllerPresent(obj : GlobalObject,image : UIImage,str_Type : String){
    //Player controler Bottom Popup
    UIApplication.shared.beginIgnoringInteractionEvents()
    
    let storyboard = UIStoryboard(name: "Main", bundle: nil)
    
    vw_TabBarController?.popupContentView.popupCloseButton.accessibilityLabel = NSLocalizedString("Dismiss Now Playing Screen", comment: "")
    let popupContentController = storyboard.instantiateViewController(withIdentifier: "PlayerViewController") as! PlayerViewController
    popupContentController.songTitle = obj.str_Lib_Title
    popupContentController.albumTitle = ""
    popupContentController.obj_Get = obj
    popupContentController.img_Load = image
    popupContentController.str_TypePlay = str_Type
    popupContentController.popupBar.accessibilityNavigationStyle = .separate
    
    popupContentController.popupItem.accessibilityHint = NSLocalizedString("Double Tap to Expand the Mini Player", comment: "")
    vw_TabBarController?.popupContentView.popupCloseButton.accessibilityLabel = NSLocalizedString("Dismiss Now Playing Screen", comment: "")
    vw_TabBarController?.popupContentView.popupCloseButtonStyle = LNPopupCloseButtonStyle.none
    
    if vw_TabBarController?.popupBar.isHidden == false {
        indicatorShow()
        
        let popupContentController = vw_TabBarController?.popupContent as! PlayerViewController
        popupContentController.speechSynthesizer.stopSpeaking(at: AVSpeechBoundary.immediate)
        popupContentController.speechSynthesizer = AVSpeechSynthesizer()
        popupContentController.playerClose()
        obj_PlayerSave = obj
        img_PlayerImage = image
        str_PlayerType = str_Type
        
    }else{
        
        str_PresentPlayer = "0"
        vw_TabBarController?.presentPopupBar(withContentViewController: popupContentController, animated: true, completion: nil)
        //            vw_TabBarController?.presentPopupBar(withContentViewController: popupContentController, openPopup: true, animated: true, completion: nil)

        vw_TabBarController?.popupBar.tintColor = UIColor(white: 38.0 / 255.0, alpha: 1.0)
        vw_TabBarController?.popupBar.imageView.layer.cornerRadius = 5
    
        let when = DispatchTime.now() + 0.5
        DispatchQueue.main.asyncAfter(deadline: when) {
            vw_TabBarController?.updatePopupBarAppearance()
            str_PresentPlayer = "1"
            vw_TabBarController?.openPopup(animated: true, completion: nil)
            UIApplication.shared.endIgnoringInteractionEvents()
        }
    }
}
func playerControllerContinue(){
    let obj = obj_PlayerSave
    let image = img_PlayerImage
    let str_Type = str_PlayerType
    
    let storyboard = UIStoryboard(name: "Main", bundle: nil)

    let popupContentController = storyboard.instantiateViewController(withIdentifier: "PlayerViewController") as! PlayerViewController
    popupContentController.songTitle = obj.str_Lib_Title
    popupContentController.albumTitle = ""
    popupContentController.obj_Get = obj
    popupContentController.img_Load = image
    popupContentController.popupBar.accessibilityNavigationStyle = .separate
    popupContentController.str_TypePlay = str_Type
    
    popupContentController.popupItem.accessibilityHint = NSLocalizedString("Double Tap to Expand the Mini Player", comment: "")
    vw_TabBarController?.popupContentView.popupCloseButton.accessibilityLabel = NSLocalizedString("Dismiss Now Playing Screen", comment: "")
    
    vw_TabBarController?.popupContentView.popupCloseButtonStyle = LNPopupCloseButtonStyle.none
    
    
    vw_TabBarController?.presentPopupBar(withContentViewController: popupContentController, animated: true, completion: nil)
    //            vw_TabBarController?.presentPopupBar(withContentViewController: popupContentController, openPopup: true, animated: true, completion: nil)
    
    vw_TabBarController?.popupBar.tintColor = UIColor(white: 38.0 / 255.0, alpha: 1.0)
    vw_TabBarController?.popupBar.imageView.layer.cornerRadius = 5
    
    let when = DispatchTime.now() + 0.7
    DispatchQueue.main.asyncAfter(deadline: when) {
//        vw_TabBarController?.popupBar.reloadInputViews()
        vw_TabBarController?.updatePopupBarAppearance()
        
        str_PresentPlayer = "1"
        vw_TabBarController?.openPopup(animated: true, completion: nil)
        indicatorHide()
        UIApplication.shared.endIgnoringInteractionEvents()
    }
}

func PlayerControllerOn(alert : Bool) -> Bool{
    if vw_TabBarController?.popupBar.isHidden == false{
        if alert == true{
            //Alert show for Header
            messageBar.MessageShow(title: "Player controller is working. Please use after finish playing", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }
        return true
    }else{
        return false
    }
}


func removeNewLineToSpace(str_Value : String) -> String{
    let newString = str_Value.replacingOccurrences(of: "\n", with: " ")
    
    return newString
}

func keyboardActivityEnableorDisable(show : Bool){
    if show == true{
        IQKeyboardManager.sharedManager().enable = true
        IQKeyboardManager.sharedManager().enableAutoToolbar = true
        IQKeyboardManager.sharedManager().shouldShowTextFieldPlaceholder = true
        IQKeyboardManager.sharedManager().keyboardDistanceFromTextField = 20.0
    }else{
        IQKeyboardManager.sharedManager().enable = false
        IQKeyboardManager.sharedManager().enableAutoToolbar = true
        IQKeyboardManager.sharedManager().shouldShowTextFieldPlaceholder = false
        IQKeyboardManager.sharedManager().keyboardDistanceFromTextField = 20.0
    }
}

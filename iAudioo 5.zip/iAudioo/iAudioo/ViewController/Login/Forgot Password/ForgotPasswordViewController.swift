//
//  ForgotPasswordViewController.swift
//  iAudioo
//
//  Created by Apple on 20/04/18.
//  Copyright © 2018 iAudioo. All rights reserved.

import UIKit
import SwiftMessages

class ForgotPasswordViewController: UIViewController {

    //Declaration UIVIew
    @IBOutlet weak var vw_Bottom: UIView!
    
    //Declaratino Label
    @IBOutlet weak var lbl_Temp: UILabel!
    @IBOutlet weak var lbl_Temp2: UILabel!
    
    //Declaration Button
    @IBOutlet weak var btn_ForgotPassword: UIButton!
    
    @IBOutlet weak var tf_Email: HoshiTextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Other Files -
    func commanMethod(){
        
        btn_ForgotPassword.titleLabel?.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 16))
        
        tf_Email.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 18))
        
        lbl_Temp.font = UIFont(name: GlobalConstants.kFontSemiBold, size: manageFontHeight(font: 20))
        lbl_Temp2.font = UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 17))
    }
    
    
    // MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any){
        self .dismiss(animated: true) {
        }        
    }
    
    @IBAction func btn_ForgotPassword(_ sender:Any) {
        var boolEmail : Bool = true
        
        var isValidEmail : Bool = false
        
        if(isValidEmail ==  validateEmail(enteredEmail: tf_Email.text!) && GlobalConstants.developerTest == false){
            if isValidEmail == true {
                
            }else{
                //Alert show for Header
                messageBar.MessageShow(title: "Please enter valid email address", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
                
                boolEmail = false
            }
        }
        
        if boolEmail == true{
            self.view.endEditing(true)
            
            self.Post_ForgotPassword()
        }
    }
    
    
    // MARK: - Get/Post Method -
    func Post_ForgotPassword(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)forget"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "email" : tf_Email.text ?? "",
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "forget"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = true
        webHelper.startDownload()
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

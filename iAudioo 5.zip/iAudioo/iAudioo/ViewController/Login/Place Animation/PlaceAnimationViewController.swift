//
//  PlaceAnimationViewController.swift
//  iAudioo
//
//  Created by Apple on 19/04/18.
//  Copyright © 2018 iAudioo. All rights reserved.
//

import UIKit

class PlaceAnimationViewController: UIViewController {

    @IBOutlet weak var con_Bottom: NSLayoutConstraint!
    
    @IBOutlet weak var img_Logo: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.viewSetup()
    }
    override func viewWillAppear(_ animated: Bool) {
        img_Logo.alpha = 1.0
        self.con_Bottom.constant = 0
        
        if self.alredyLoginOrNot() == false{
            self.moveView()
        }else{
            let Delay = DispatchTime.now() + 1.0
            DispatchQueue.main.asyncAfter(deadline: Delay) {
                TabbarManager(view : self)
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    func moveView(){
        img_Logo.alpha = 1.0
        UIView.animate(withDuration: 1.0, animations: {
            self.con_Bottom.constant = CGFloat((GlobalConstants.windowHeight * 257)/GlobalConstants.screenHeightDeveloper)
            self.img_Logo.alpha = 0.5
            
            self.view.layoutIfNeeded()
        }, completion: { (finished) in
            self.performSegue(withIdentifier: "place", sender: self)
        })
    }
    func viewSetup(){
        IAPHandler.shared.fetchAvailableProducts()
        IAPHandler.shared.purchaseStatusBlock = {[weak self] (type) in
            guard let strongSelf = self else {
                return
            }
            if type == .purchased {
//                let alertView = UIAlertController(title: "", message: type.message(), preferredStyle: .alert)
//                let action = UIAlertAction(title: "OK", style: .default, handler: { (alert) in
//
//                })
//                alertView.addAction(action)
//                strongSelf.present(alertView, animated: true, completion: nil)
            }
        }
    }
    func alredyLoginOrNot() -> Bool{
        if ((loadCustomObject(withKey: "userobject")) != nil){
            var objUserTemp : UserDataObject = loadCustomObject(withKey: "userobject")!
            
            //Condition get data from userdefault
            if objUserTemp.user_UserID.characters.count != 0 {
                
                objUser = objUserTemp
                return true
            }
        }
        
        return false
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

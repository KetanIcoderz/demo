//
//  PlaceViewController.swift
//  iAudioo
//
//  Created by Apple on 19/04/18.
//  Copyright © 2018 iAudioo. All rights reserved.

import UIKit
import SwiftMessages
import FBSDKCoreKit
import FBSDKLoginKit

class PlaceViewController: UIViewController {

    //Declaration Button
    @IBOutlet weak var btn_SignUpFB: UIButton!
    @IBOutlet weak var btn_SignUpEmail: UIButton!
    @IBOutlet weak var btn_SignUpLogIn: UIButton!
    
    //Declaration Label
    @IBOutlet weak var lbl_SignIn: UILabel!
    
    //Declaration UIVIew
    @IBOutlet weak var vw_Bottom: UIView!
    
    @IBOutlet weak var con_BottomViewHeight: NSLayoutConstraint!
    @IBOutlet weak var con_BottomEyecenter: NSLayoutConstraint!
    
    @IBOutlet weak var img_Header: UIImageView!
    @IBOutlet weak var img_HeaderCenter: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.commanMethod()
        
        let Delay = DispatchTime.now() + 0.5
        DispatchQueue.main.asyncAfter(deadline: Delay) {
            self.alredyLoginOrNot()
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        self.img_Header.image = UIImage(named:"img_PlaceBG")
        self.con_BottomViewHeight.constant = 0
        self.con_BottomEyecenter.constant = 0
        
        vw_Bottom.alpha = 0.0
        UIView.animate(withDuration: 0.5, animations: {
            self.vw_Bottom.alpha = 1.0
        }, completion: { (finished) in
        })
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - Other Files -
    func commanMethod(){
        
        //Manage font
        lbl_SignIn.font = UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 16))
        
        btn_SignUpFB.titleLabel?.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 18))
        btn_SignUpEmail.titleLabel?.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 16))
        btn_SignUpLogIn.titleLabel?.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 16))
        
        vw_Bottom.alpha = 0.0
        UIView.animate(withDuration: 0.5, animations: {
            self.vw_Bottom.alpha = 1.0

        }, completion: { (finished) in
        })
        
        img_HeaderCenter.alpha = 0.0
        UIView.animate(withDuration: 0.5, animations: {
            self.img_HeaderCenter.alpha = 1.0
            
        }, completion: { (finished) in
        })
        
    }
    func alredyLoginOrNot() -> Bool{
        if ((loadCustomObject(withKey: "userobject")) != nil){
            var objUserTemp : UserDataObject = loadCustomObject(withKey: "userobject")!
            
            //Condition get data from userdefault
            if objUserTemp.user_UserID.characters.count != 0 {
                
                objUser = objUserTemp
                TabbarManager(view : self)
                return true
            }
        }
        
        return false
    }
    
    
    // MARK: - Button Event -
    @IBAction func btn_SignUpFB(_ sender:Any){
        let login = FBSDKLoginManager()
        login.logOut()
        //ESSENTIAL LINE OF CODE
        login.loginBehavior = FBSDKLoginBehavior.browser
        
        login.logIn(withReadPermissions: ["public_profile","email"], handler: { (result, error) -> Void in
            
            if (error == nil){
                let fbloginresult : FBSDKLoginManagerLoginResult = result!
                
                if(fbloginresult.isCancelled) {
                    //Show Cancel alert
                } else {
                    
                    if (FBSDKAccessToken.current() != nil) {
                        indicatorShow()
                        
                        FBSDKGraphRequest(graphPath: "me", parameters: ["fields": "email,first_name,last_name,id,picture.type(large), age_range"]).start(completionHandler: { (connection, result, error) -> Void in
                            if (error == nil){
                                print(result ?? 0)
                                let dict_Data : NSDictionary = result as! NSDictionary
                                let dictPicture : NSDictionary = dict_Data["picture"] as! NSDictionary
                                let dictPictureSub : NSDictionary = dictPicture["data"] as! NSDictionary
                                
                                let dict_Dave : Dictionary = ["email" : ((dict_Data["email"] as? String) != nil) ? (dict_Data["email"] as? String) : "",
                                                              "firstname" : ((dict_Data["first_name"] as? String) != nil) ? (dict_Data["first_name"] as? String) : "",
                                                              "lastname" : ((dict_Data["last_name"] as? String) != nil) ? (dict_Data["last_name"] as? String) : "",
                                                              "id" : ((dict_Data["id"] as? String) != nil) ? (dict_Data["id"] as? String) : "",
                                                              "image" : ((dictPictureSub["url"] as? String) != nil) ? (dictPictureSub["url"] as? String) : "",
                                                              "zip" : ((dict_Data["zip"] as? String) != nil) ? (dict_Data["zip"] as? String) : ""]
                                
                               
                                
//                                TabbarManager(view : self)
                                self.Post_FBGmail(flag: "FB", NSDictionary: dict_Dave as NSDictionary)
                                indicatorHide()
                            }else{
                                messageBar.MessageShow(title: (error?.localizedDescription)! as NSString, alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
                                indicatorHide()
                            }
                            
                        })
                    }
                }
            }else{
                messageBar.MessageShow(title: (error?.localizedDescription)! as NSString, alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
            }
        })
    }
    
    @IBAction func btn_SignUpEmail(_ sender:Any){
        
        self.img_Header.alpha = 1.0
        UIView.animate(withDuration: 0.35, animations: {
            self.img_Header.alpha = 0.2
            self.view.layoutIfNeeded()
        }, completion: { (finished) in
            self.img_Header.image = UIImage(named:"img_LoginBG")
            UIView.animate(withDuration: 0.35, animations: {
                self.img_Header.alpha = 1.0
                self.view.layoutIfNeeded()
            }, completion: { (finished) in
            })
        })
        
        //img_LoginBG
        vw_Bottom.alpha = 1.0
        UIView.animate(withDuration: 0.7, animations: {
            self.vw_Bottom.alpha = 0.0
            self.con_BottomViewHeight.constant = -CGFloat((GlobalConstants.windowHeight * 118)/GlobalConstants.screenHeightDeveloper)
            self.con_BottomEyecenter.constant = -CGFloat((GlobalConstants.windowHeight * 29)/GlobalConstants.screenHeightDeveloper)
            self.view.layoutIfNeeded()
        }, completion: { (finished) in
            self.performSegue(withIdentifier: "signup", sender: self)
        })
        
    }
    
    @IBAction func btn_SignUpLogIn(_ sender:Any){
        
        self.img_Header.alpha = 1.0
        UIView.animate(withDuration: 0.35, animations: {
            self.img_Header.alpha = 0.2
            self.view.layoutIfNeeded()
        }, completion: { (finished) in
            self.img_Header.image = UIImage(named:"img_LoginBG")
            UIView.animate(withDuration: 0.35, animations: {
                self.img_Header.alpha = 1.0
                self.view.layoutIfNeeded()
            }, completion: { (finished) in
            })
        })
        
        //img_LoginBG
        vw_Bottom.alpha = 1.0
        UIView.animate(withDuration: 0.7, animations: {
            self.vw_Bottom.alpha = 0.0
            self.con_BottomViewHeight.constant = -CGFloat((GlobalConstants.windowHeight * 118)/GlobalConstants.screenHeightDeveloper)
            self.con_BottomEyecenter.constant = -CGFloat((GlobalConstants.windowHeight * 29)/GlobalConstants.screenHeightDeveloper)
            self.view.layoutIfNeeded()
        }, completion: { (finished) in
            self.performSegue(withIdentifier: "login", sender: self)
        })
        
    }
    
    
    // MARK: - Get/Post Method -
    func Post_FBGmail(flag : String , NSDictionary : NSDictionary){
        
        if NSDictionary["email"] as! String == "" {
            messageBar.MessageShow(title:"We not getting your email address with login. Please try login with use of another id.", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }else{
            
            let url = URL(string: NSDictionary["image"] as! String)
            let data = try? Data(contentsOf: url!) //make sure your image in this url does exist, otherwise unwrap in a if let check / try-catch
            let image_Save : UIImage = UIImage(data: data!)!
            
            //Declaration URL
            let strURL = "\(GlobalConstants.BaseURL)register"
            
            //Pass data in dictionary
            var jsonData : NSDictionary =  NSDictionary
            jsonData = [
                "name" : "\(NSDictionary["firstname"] as! String) \(NSDictionary["lastname"] as! String)",
                "email" : NSDictionary["email"] as! String,
                "account_type" :  flag,
                "social_id" :  NSDictionary["id"] as! String,
                "password" : "",
                "devicetoken" :  UserDefaults.standard.value(forKey: "DeviceToken") == nil ? NSDictionary["email"] as! String : UserDefaults.standard.value(forKey: "DeviceToken")! as! String,
                "device_type" : GlobalConstants.deviceType,
                "image" : "",
            ]
            var jsonData2 : NSDictionary =  NSDictionary
            
            
            //Create object for webservicehelper and start to call method
            let webHelper = WebServiceHelper()
            webHelper.strMethodName = "register"
            webHelper.methodType = "post"
            webHelper.strURL = strURL
            webHelper.dictType = jsonData
//            webHelper.dictHeader = jsonData2
            webHelper.delegateWeb = self
            webHelper.serviceWithAlert = true
            webHelper.imageUpload = (image_Save != nil) ? (image_Save) : (UIImage())
            webHelper.imageUploadName = "profile_image"
            webHelper.startDownloadWithImage()
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

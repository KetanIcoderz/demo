//
//  SignUpViewController.swift
//  iAudioo
//
//  Created by Apple on 19/04/18.
//  Copyright © 2018 iAudioo. All rights reserved.

import UIKit
import SwiftMessages

class SignUpViewController: UIViewController,UINavigationControllerDelegate {

    //Declaration UIVIew
    @IBOutlet weak var vw_Bottom: UIView!
    
    @IBOutlet weak var con_BottomViewHeight: NSLayoutConstraint!
    @IBOutlet weak var con_BottomEyecenter: NSLayoutConstraint!
    
    @IBOutlet weak var img_Header: UIImageView!
    @IBOutlet weak var img_HeaderLogo: UIImageView!
    @IBOutlet weak var img_SelectPhoto: UIImageView!
    
    //Declaration Button
    @IBOutlet weak var btn_SignUp: UIButton!
    
    @IBOutlet weak var tf_Email: HoshiTextField!
    @IBOutlet weak var tf_Password: HoshiTextField!
    @IBOutlet weak var tf_Name: HoshiTextField!
    
    //Comman Declaration
    var isValidEmail : Bool = false
    let picker = UIImagePickerController()
    var isEditMode : Bool = false
    var isImage :Bool = false
    
    //Layout Constant
    @IBOutlet weak var con_BottomTableView: NSLayoutConstraint!
    @IBOutlet weak var con_TopTableView: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()
        
        // Do any additional setup after loading the view.
    }

    override func viewWillAppear(_ animated: Bool) {
        self.img_Header.image = UIImage(named:"img_LoginBG")
        self.vw_Bottom.alpha = 1.0
        self.con_BottomViewHeight.constant = 0
        self.con_BottomEyecenter.constant = -CGFloat((GlobalConstants.windowHeight * 29)/GlobalConstants.screenHeightDeveloper)
        
        keyboardActivityEnableorDisable(show : false)
    }
    override func viewWillDisappear(_ animated: Bool) {
        keyboardActivityEnableorDisable(show : true)
    }
    
    override func viewWillLayoutSubviews() {
        self.img_SelectPhoto.layer.cornerRadius = self.img_SelectPhoto.frame.size.height/2
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //Custome class keyboard handler method
    @objc func myKeyboardWillHideHandler(_ notification: NSNotification) {
        view.layoutIfNeeded()
        UIView.animate(withDuration: 0.2, delay: 0.0, options: [.allowAnimatedContent], animations: {
            self.con_BottomTableView.constant = 0
            self.con_TopTableView.constant = 0
            self.view .layoutIfNeeded()
        }, completion: nil)
    }
    @objc func myKeyboardWillShow(_ notification: NSNotification) {
        let userInfo:NSDictionary = notification.userInfo! as NSDictionary
        let keyboardFrame:NSValue = userInfo.value(forKey: UIKeyboardFrameEndUserInfoKey) as! NSValue
        let keyboardRectangle = keyboardFrame.cgRectValue
        let keyboardHeight = keyboardRectangle.height - CGFloat(GlobalConstants.windowHeight * 0.15)
        
        self.view .layoutIfNeeded()
        
        //Scrollview animation when keyboard open
        UIView.animate(withDuration: 0.2, delay: 0.0, options: [.allowAnimatedContent], animations: {
            //Set constant with screen size
            self.con_BottomTableView.constant = keyboardHeight
            self.con_TopTableView.constant = -keyboardHeight
            //            self.tbl_Main.contentOffset = CGPoint(x: 0, y: CGFloat(keyboardHeight - CGFloat(GlobalConstants.windowHeight * 0.2)))
            
            self.view .layoutIfNeeded()
        }, completion: nil)
    }
    
    
    // MARK: - Other Files -
    func commanMethod(){
        
        btn_SignUp.titleLabel?.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 16))
        
        tf_Name.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 18))
        tf_Email.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 18))
        tf_Password.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 18))
        
        vw_Bottom.alpha = 0.0
        UIView.animate(withDuration: 0.5, animations: {
            self.vw_Bottom.alpha = 1.0
            
        }, completion: { (finished) in
        })
        
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(myKeyboardWillHideHandler),
            name: .UIKeyboardWillHide,
            object: nil)
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(myKeyboardWillShow),
            name: .UIKeyboardWillShow,
            object: nil)
    }
    func validationPassword(tf_Get : UITextField,condition : Bool) -> Bool{
        
        //Validation for 1 Capital 1 Number value and 8 Length
        var validation : Int = 0
        
        //1 8 character Validatiaon
        if (tf_Get.text!.characters.count >= 8) {
            validation = validation + 1;
        }
        
        //2 capital letter or not
        var output = ""
        let string : String = tf_Get.text!
        for chr in string.characters {
            let str = String(chr)
            if str.lowercased() != str {
                output += str
            }
        }
        if output != "" {
            validation = validation + 1
        }
        
        //3 Number
        let str = tf_Get.text!
        let intString = str.components(
            separatedBy: NSCharacterSet
                .decimalDigits
                .inverted)
            .joined(separator: "")
        if intString != "" {
            validation = validation + 1
        }
        
        if validation > 2 {
            return true
        }
        return false
    }
    
    // MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any){
        
        self.img_Header.alpha = 1.0
        UIView.animate(withDuration: 0.35, animations: {
            self.img_Header.alpha = 0.2
            self.view.layoutIfNeeded()
        }, completion: { (finished) in
            self.img_Header.image = UIImage(named:"img_PlaceBG")
            UIView.animate(withDuration: 0.35, animations: {
                self.img_Header.alpha = 1.0
                self.view.layoutIfNeeded()
            }, completion: { (finished) in
            })
        })
        
        vw_Bottom.alpha = 1.0
        UIView.animate(withDuration: 0.7, animations: {
            self.vw_Bottom.alpha = 0.0
            self.con_BottomViewHeight.constant = CGFloat((GlobalConstants.windowHeight * 118)/GlobalConstants.screenHeightDeveloper)
            self.con_BottomEyecenter.constant = 0
            self.view.layoutIfNeeded()
        }, completion: { (finished) in
            self.navigationController?.popViewController(animated: false)
        })
        
    }
    @IBAction func btn_SignUp(_ sender:Any) {
        var boolEmail : Bool = true
        var boolPassword : Bool = true
        
        var isValidEmail : Bool = false
        
        if((tf_Name.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please enter name", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
            
            boolEmail = false
        }
        else if((tf_Email.text?.isEmpty)! && GlobalConstants.developerTest == false){
            //Alert show for Header
            messageBar.MessageShow(title: "Please enter email address", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
            
            boolEmail = false
        }else if(isValidEmail ==  validateEmail(enteredEmail: tf_Email.text!) && GlobalConstants.developerTest == false){
            if isValidEmail == true {
                
            }else{
                //Alert show for Header
                messageBar.MessageShow(title: "Please enter valid email address", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
                
                boolEmail = false
            }
        }
        
        if boolEmail == true{
            
            if((tf_Password.text?.isEmpty)! && GlobalConstants.developerTest == false){
                
                messageBar.MessageShow(title: "Please enter password", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
                boolPassword = false
                
            }else if validationPassword(tf_Get : tf_Password,condition : true) == false && GlobalConstants.developerTest == false{
                //Alert show for Header
                messageBar.MessageShow(title: "Please enter password with 1 Capital,1 Number,8 minimum characters", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
                
                boolPassword = false
            }
        }
        
        if boolEmail == true && boolPassword == true{
            self.view.endEditing(true)
            self.Post_Reistration()
        }
    }
    
    @IBAction func btn_ForgotPassword(_ sender:Any) {
        
    }
    
    @IBAction func btn_SelectPhoto(_ sender:Any) {
        let alert = UIAlertController(title: GlobalConstants.appName, message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: UIAlertActionStyle.default, handler: { (action) in
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera)
            {
                self.picker.sourceType = .camera
                self.picker.allowsEditing = true
                self.picker.delegate = self
                self.present(self.picker, animated: true, completion: nil)
            }
        }))
        alert.addAction(UIAlertAction(title: "Gallery", style: UIAlertActionStyle.default, handler: { (action) in
            self.picker.allowsEditing = true
            self.picker.sourceType = .photoLibrary
            self.picker.delegate = self
            self.present(self.picker, animated: true, completion: nil)
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    // MARK: - Get/Post Method -
    func Post_Reistration(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)register"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "name" : tf_Name.text ?? "",
            "email" : tf_Email.text ?? "",
            "account_type" :  "EMAIL",
            "social_id" : "",
            "password" : tf_Password.text ?? "",
            "devicetoken" :  UserDefaults.standard.value(forKey: "DeviceToken") == nil ? tf_Email.text ?? "" : UserDefaults.standard.value(forKey: "DeviceToken")! as! String,
            "device_type" : GlobalConstants.deviceType,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "register"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = true
        webHelper.imageUpload = (isImage == true) ? (img_SelectPhoto.image) : (UIImage())
        webHelper.imageUploadName = "profile_image"
        webHelper.startDownloadWithImage()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}


extension SignUpViewController : UIImagePickerControllerDelegate{
    //MARK: - Imagepicker Delegates
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        let chosenImage = info[UIImagePickerControllerEditedImage] as! UIImage
        isImage = true
        img_SelectPhoto.image = chosenImage
        img_HeaderLogo.isHidden = true
        dismiss(animated:true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}


extension SignUpViewController : UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    
}

//
//  LeftSideMenuViewController.swift
//  iAudioo
//
//  Created by Apple on 20/04/18.
//  Copyright © 2018 iAudioo. All rights reserved.

import UIKit

class LeftSideMenuViewController: UIViewController {

    var arr_Main : NSMutableArray = []
    
    var selectedIndex : Int = 0
    
    @IBOutlet var tbl_Main : UITableView!
    
    @IBOutlet var con_TblY : NSLayoutConstraint!
    
    @IBOutlet var lbl_UserName : UILabel!
    @IBOutlet var img_Profile : UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.commanMethod()
        
        NotificationCenter.default.removeObserver("reloadsidemenu")
        NotificationCenter.default.addObserver(self, selector: #selector(reloadData), name: NSNotification.Name(rawValue: "reloadsidemenu"), object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        lbl_UserName.text = objUser?.user_Name
        img_Profile.sd_setImage(with: URL(string: (objUser?.user_Profile_image)!), placeholderImage: UIImage(named:"icon_Avtar"))
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Comman Method -
    func commanMethod(){
        var obj = SideMenuModuleObject()
        obj.str_Title = "Profile"
        obj.str_Image = "icon_Profile"
        arr_Main.add(obj)
        
        var obj2 = SideMenuModuleObject()
        obj2.str_Title = "Subscription"
        obj2.str_Image = "img_Subscription"
        arr_Main.add(obj2)
        
        var obj3 = SideMenuModuleObject()
        obj3.str_Title = "Logout"
        obj3.str_Image = "icon_LogOut"
        arr_Main.add(obj3)
        
        con_TblY.constant = CGFloat((GlobalConstants.windowHeight * 55)/GlobalConstants.screenHeightDeveloper)
        
        img_Profile.layer.cornerRadius = CGFloat((GlobalConstants.windowHeight * 45.25)/GlobalConstants.screenHeightDeveloper)
        img_Profile.layer.masksToBounds = true
    }
    @objc func reloadData(){
        lbl_UserName.text = objUser?.user_Name
        img_Profile.sd_setImage(with: URL(string: (objUser?.user_Profile_image)!), placeholderImage: UIImage(named:"img_Demo"))
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}



// MARK: - Tableview Cell -
class SideMenuModule: UITableViewCell {
    // MARK: - Table Cell -
    @IBOutlet var lbl_Title: UILabel!
    
    @IBOutlet var img_Icon: UIImageView!
}


// MARK: - Tableview Delegate -

extension LeftSideMenuViewController : UITableViewDataSource,UITableViewDelegate {
  
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr_Main.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CGFloat(GlobalConstants.windowHeight * 0.09595202399)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for:indexPath as IndexPath) as! SideMenuModule
        
        let obj = arr_Main[indexPath.row] as! SideMenuModuleObject
       
        //Declare text in icon in tableview cell
        cell.lbl_Title.text = obj.str_Title
        
        if selectedIndex == indexPath.row{
            cell.lbl_Title.textColor = GlobalConstants.appColor
            cell.img_Icon.image = UIImage(named:"\(obj.str_Image)_Sel")!
            cell.backgroundColor = UIColor.white
        }else{
            cell.lbl_Title.textColor = UIColor.white
            cell.img_Icon.image = UIImage(named:"\(obj.str_Image)")!
            cell.backgroundColor = UIColor.clear
        }
        
        cell.lbl_Title.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 15))
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.row == 2{
            let alert = UIAlertController(title: GlobalConstants.appName, message: "Are you sure you want to logout?", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Yes", style: UIAlertActionStyle.default, handler: { (action) in
                
                self.Post_Logout()
                
            }))
            alert.addAction(UIAlertAction(title: "No", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else if indexPath.row == 1{
            let mainViewController = sideMenuController!
            
            
            let viewController = self.storyboard?.instantiateViewController(withIdentifier: "SubscriptionListViewController") as! SubscriptionListViewController
            
            let nav : UINavigationController
            vw_TabBarController?.navigationController?.pushViewController(viewController, animated: true)
            mainViewController.hideLeftView(animated: true, completionHandler: nil)
        }else if indexPath.row == 0{
            let mainViewController = sideMenuController!
            
            let viewController = self.storyboard?.instantiateViewController(withIdentifier: "ProfileViewViewController") as! ProfileViewViewController
            
            let nav : UINavigationController
            vw_TabBarController?.navigationController?.pushViewController(viewController, animated: true)
            mainViewController.hideLeftView(animated: true, completionHandler: nil)
        }
        
        selectedIndex = indexPath.row
        tbl_Main.reloadData()
    }
    
    
    // MARK: - Get/Post Method -
    func Post_Logout(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)logout"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "logout"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = true
        webHelper.startDownload()
    }
    
}



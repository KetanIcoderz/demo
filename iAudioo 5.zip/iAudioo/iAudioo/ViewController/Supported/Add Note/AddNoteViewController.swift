//
//  AddNoteViewController.swift
//  iAudioo
//
//  Created by Apple on 27/04/18.
//  Copyright © 2018 iAudioo. All rights reserved.

import UIKit
import IQKeyboardManagerSwift
import Speech

protocol DismissNotePickerDelegate: class {
    func NoteOption(str_Tital: String,str_Description: String)
}


class AddNoteViewController: UIViewController, SFSpeechRecognizerDelegate {

    @IBOutlet weak var tf_Title: HoshiTextField!
    
    @IBOutlet weak var lbl_PlayTitle: UILabel!
    
    @IBOutlet weak var tv_Descriptin: UITextView!
    
    @IBOutlet weak var btn_Done: UIBarButtonItem!
    @IBOutlet weak var btn_Speak: UIButton!
    
    @IBOutlet weak var con_ViewHeight: NSLayoutConstraint!
    
    weak var delegate : DismissNotePickerDelegate? = nil
    
    var tv_Active: UITextView!
    var str_KeyboardHeight: Int = 0
    
    private let speechRecognizer = SFSpeechRecognizer(locale: Locale.init(identifier: "en-US"))!
    
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()
    
    var str_EventId : String = ""
    
    var str_Id : String = ""
    var str_Tital : String = ""
    var str_Description : String = ""
    var str_DescriptionSave : String = ""
    
    var str_TypeGoing : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()
        
        // Do any additional setup after loading the view.
    }

    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        
        self.navigationController!.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
        self.navigationController!.navigationBar.setBackgroundImage(imageWithColor(with:GlobalConstants.appColor), for: .default)
                
        IQKeyboardManager.sharedManager().enable = false
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        
        IQKeyboardManager.sharedManager().enable = true
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    // MARK: - Other Files -
    func commanMethod(){
        
        tf_Title.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 19))
        tv_Descriptin.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 16))
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWillShow), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWillHide), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
        con_ViewHeight.constant = CGFloat(GlobalConstants.windowHeight * 0.72)
        
        tf_Title.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        tf_Title.addTarget(self, action: #selector(textFieldDidBeginEditing(textField:)), for: .editingDidBegin)
        tf_Title.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingDidEnd)
        
        self.manageDoneButton(tv:tv_Descriptin.text)
        
        
        btn_Speak.isEnabled = false
        speechRecognizer.delegate = self
        
        SFSpeechRecognizer.requestAuthorization { (authStatus) in
            
            var isButtonEnabled = false
            
            switch authStatus {
            case .authorized:
                isButtonEnabled = true
                
            case .denied:
                isButtonEnabled = false
                print("User denied access to speech recognition")
                
            case .restricted:
                isButtonEnabled = false
                print("Speech recognition restricted on this device")
                
            case .notDetermined:
                isButtonEnabled = false
                print("Speech recognition not yet authorized")
            }
            
            OperationQueue.main.addOperation() {
                self.btn_Speak.isEnabled = isButtonEnabled
            }
        }
        
        //Editing or not
        if str_Id != ""{
            tf_Title.text = str_Tital
            tv_Descriptin.text = str_Description
            tv_Descriptin.textColor = UIColor.black
            self.manageDoneButton(tv: tv_Descriptin.text)
        }
        
        let longGesture = UILongPressGestureRecognizer(target: self, action: #selector(longTap(sender:)))
        btn_Speak.addGestureRecognizer(longGesture)
    }
    func manageDoneButton(tv : String){
        btn_Done.isEnabled = false
        
        if tf_Title.text != "" && tv != "" && tv != "Please enter description" && tv != "Say something, I'm listening!"{
            btn_Done.isEnabled = true
        }
    }
    @objc func keyboardWillShow(notification: NSNotification) {
        if ((notification.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue) != nil {
            let keyboardSize = (notification.userInfo![UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.size
            str_KeyboardHeight = Int(keyboardSize.height)
            if let activeFieldPresent =  tv_Active
            {
                con_ViewHeight.constant = CGFloat(GlobalConstants.windowHeight - Double(keyboardSize.height) - 50)
            }
        }
    }
    @objc func keyboardWillHide(notification: NSNotification) {
        if ((notification.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue) != nil {
            if let activeFieldPresent =  tv_Active
            {
                con_ViewHeight.constant = CGFloat(GlobalConstants.windowHeight * 0.72)
            }
        }
    }
    func startRecording() {
        
        if recognitionTask != nil {  //1
            recognitionTask?.cancel()
            recognitionTask = nil
        }
        
        let audioSession = AVAudioSession.sharedInstance()  //2
        do {
            try audioSession.setCategory(AVAudioSessionCategoryRecord)
            try audioSession.setMode(AVAudioSessionModeMeasurement)
            try audioSession.setActive(true, with: .notifyOthersOnDeactivation)
        } catch {
            print("audioSession properties weren't set because of an error.")
        }
        
        if #available(iOS 10.0, *) {
            recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
            
            let inputNode = audioEngine.inputNode
            
            //                {
            //                fatalError("Audio engine has no input node")
            //            }  //4
            
            guard let recognitionRequest = recognitionRequest else {
                fatalError("Unable to create an SFSpeechAudioBufferRecognitionRequest object")
            } //5
            
            recognitionRequest.shouldReportPartialResults = true  //6
            
            recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest, resultHandler: { (result, error) in  //7
                
                var isFinal = false  //8
                
                if result != nil {
                    
                    let str = result?.bestTranscription.formattedString
                    self.tv_Descriptin.text = "\(self.str_DescriptionSave) \(str as! String)"  //9
                    self.tv_Descriptin.textColor = UIColor.black
                    
                    isFinal = (result?.isFinal)!
                    self.manageDoneButton(tv: self.tv_Descriptin.text)
                }
                
                if error != nil || isFinal {  //10
                    self.audioEngine.stop()
                    inputNode.removeTap(onBus: 0)
                    
                    self.recognitionRequest = nil
                    self.recognitionTask = nil
                    
                    self.btn_Speak.isEnabled = true
                }
            })
            
            let recordingFormat = inputNode.outputFormat(forBus: 0)  //11
            inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer, when) in
                self.recognitionRequest?.append(buffer)
            }
            
            audioEngine.prepare()  //12
            
            do {
                try audioEngine.start()
            } catch {
                print("audioEngine couldn't start because of an error.")
            }
            
            if tv_Descriptin.text == "" || tv_Descriptin.text == "Please enter description"{
                tv_Descriptin.text = "Say something, I'm listening!"
                str_DescriptionSave = ""
                self.tv_Descriptin.textColor = UIColor.lightGray
            }
            
            self.manageDoneButton(tv: tv_Descriptin.text)
            
        } else {
            // Fallback on earlier versions
        }  //3
    }
    
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        if available {
            btn_Speak.isEnabled = true
        } else {
            btn_Speak.isEnabled = false
        }
    }
    
    
     @IBAction func textDidChange(_ sender: HoshiTextField) {
        print("call")
    }
    
    
    //MARK: - Button Event -
    
    @IBAction func btn_Back(_ sender:Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btn_Done(_ sender:Any) {
        //Editing or not
        if str_Id == ""{
            self.Post_AddNote(index : str_EventId)
        }else{
            self.Post_UpdateNote()
        }
    }
    @IBAction func btn_Speak(_ sender: AnyObject) {
        if PlayerControllerOn(alert: true) == false{
            if audioEngine.isRunning {
                audioEngine.stop()
                recognitionRequest?.endAudio()
                
                btn_Speak.isEnabled = false
                btn_Speak.isSelected = false
                lbl_PlayTitle.isHidden = true
                
                btn_Speak.setTitle("Start Recording", for: .normal)
            } else {
                str_DescriptionSave = tv_Descriptin.text
                startRecording()
                btn_Speak.setTitle("Stop Recording", for: .normal)
                btn_Speak.isSelected = true
                lbl_PlayTitle.isHidden = false
            }
        }
    }
    @objc func longTap(sender : UIGestureRecognizer){
//        print("Long tap")
//        if sender.state == .began {
//            print("UIGestureRecognizerStateEnded")
//            startRecording()
//            
//            btn_Speak.setTitle("Stop Recording", for: .normal)
//        }
//        else if sender.state == .ended {
//            print("UIGestureRecognizerStateBegan.")
//            
//            audioEngine.stop()
//            recognitionRequest?.endAudio()
//            btn_Speak.isEnabled = false
//            btn_Speak.setTitle("Start Recording", for: .normal)
//        }
    }
    
    
    // MARK: - Get/Post Method -
    func Post_AddNote(index : String){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)library/\(index)/add_note"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "title" : tf_Title.text,
            "description" : tv_Descriptin.text,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "add_note"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.showLogForCallingAPI = false
        webHelper.startDownload()
        
    }
    
    func Post_UpdateNote(){
        
        //Declaration URL
        var strURL = "\(GlobalConstants.BaseURL)library/\(str_EventId)/update_note/\(str_Id)"
        
        if str_TypeGoing == "main"{
            strURL = "\(GlobalConstants.BaseURL)update_user_note/\(str_Id)"
        }else if str_TypeGoing == "submain"{
            strURL = "\(GlobalConstants.BaseURL)update_user_note/\(str_Id)"
        }else if str_TypeGoing == "mainedit"{
            strURL = "\(GlobalConstants.BaseURL)update_library/\(str_Id)"
        }
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "title" : tf_Title.text,
            "description" : tv_Descriptin.text,
        ]
        
        if str_TypeGoing == "mainedit"{
            jsonData = [
                "title" : tf_Title.text,
                "text" : tv_Descriptin.text,
            ]
        }
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "update_note"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.startDownload()
    }

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}

extension AddNoteViewController : UITextViewDelegate{
    func textViewDidBeginEditing(_ textView: UITextView) {
        tv_Active = textView
        if textView.text == "Please enter description" {
            textView.text = nil
            textView.textColor = UIColor.black
        }
        
        if str_KeyboardHeight != 0{
            con_ViewHeight.constant = CGFloat(GlobalConstants.windowHeight - Double(str_KeyboardHeight) - 50)
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        tv_Active = nil
        if textView.text.isEmpty {
            textView.text = "Please enter description"
            textView.textColor = UIColor.lightGray
        }
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        let newLength = textView.text.utf16.count + text.utf16.count - range.length
        if newLength > 0 // have text, so don't show the placeholder
        {
            self.manageDoneButton(tv : "1")
        }else{
            self.manageDoneButton(tv : "")
        }
        
        return true
    }

    
}

extension AddNoteViewController : UITextFieldDelegate{
    
    @objc func textFieldDidChange(textField: UITextField){
        if textField.text == ""{
            tf_Title.placeholder = "Enter Title…"
        }else{
            tf_Title.placeholder = "Title"
        }
        self.manageDoneButton(tv : tv_Descriptin.text)
    }
    
    @objc func textFieldDidBeginEditing(textField: UITextField) {
        tf_Title.placeholder = "Title"
    }
}


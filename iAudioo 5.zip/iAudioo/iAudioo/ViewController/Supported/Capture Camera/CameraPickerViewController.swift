//
//  CameraPickerViewController.swift
//  iAudioo
//
//  Created by Apple on 01/05/18.
//  Copyright © 2018 iAudioo. All rights reserved.

import UIKit
import AVFoundation
import SwiftMessages

protocol DismissCameraPickerDelegate: class {
    func CaptureImagesOption(arr: NSMutableArray)
}


class CameraPickerViewController: UIViewController {

    @IBOutlet weak var vw_Camera: UIView!
    
    @IBOutlet weak var btn_Capture: UIButton!
    
    @IBOutlet weak var btn_DoneCheck: UIButton!
    
    @IBOutlet weak var cv_Main: UICollectionView!
    
    var arr_Main : NSMutableArray = []
    
    weak var delegate : DismissCameraPickerDelegate? = nil
    
    var session: AVCaptureSession?
    var stillImageOutput: AVCaptureStillImageOutput?
    var videoPreviewLayer: AVCaptureVideoPreviewLayer?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()
        
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
         videoPreviewLayer!.frame = self.view.bounds
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - Other Files -
    func commanMethod(){
        session = AVCaptureSession()
        session!.sessionPreset = AVCaptureSession.Preset.photo

        let backCamera =  AVCaptureDevice.default(for: AVMediaType.video)
        var error: NSError?
        var input: AVCaptureDeviceInput!
        do {
            input = try AVCaptureDeviceInput(device: backCamera!)
        } catch let error1 as NSError {
            error = error1
            input = nil
//            print(error!.localizedDescription)
        }
        if error == nil && session!.canAddInput(input) {
            session!.addInput(input)
            stillImageOutput = AVCaptureStillImageOutput()
            stillImageOutput?.outputSettings = [AVVideoCodecKey: AVVideoCodecJPEG]
            if session!.canAddOutput(stillImageOutput!) {
                session!.addOutput(stillImageOutput!)
                videoPreviewLayer = AVCaptureVideoPreviewLayer(session: session!)
                videoPreviewLayer!.videoGravity = AVLayerVideoGravity.resizeAspectFill
                videoPreviewLayer!.connection?.videoOrientation = self.orintationSet()
                vw_Camera.layer.addSublayer(videoPreviewLayer!)
                session!.startRunning()
                // ...
                // Configure the Live Preview here...
            }
            // ...
            // The remainder of the session setup will go here...
        }
    }
    
    func orintationSet() -> AVCaptureVideoOrientation{
        switch UIDevice.current.orientation {
        case .landscapeLeft:
           return AVCaptureVideoOrientation.landscapeRight
        case .landscapeRight:
           return  AVCaptureVideoOrientation.landscapeLeft
        case .portrait:
           return AVCaptureVideoOrientation.portrait
        case .portraitUpsideDown:
            return AVCaptureVideoOrientation.portraitUpsideDown
        default:
            return AVCaptureVideoOrientation.portrait
        }
    }
    
    //MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any) {
        dismiss(animated: true) {
        }
    }
    @IBAction func btn_Capture(_ sender: AnyObject) {
        if arr_Main.count < 10{
            let videoConnection = stillImageOutput!.connection(with: AVMediaType.video)
            if(videoConnection != nil) {
                stillImageOutput?.captureStillImageAsynchronously(from: videoConnection!, completionHandler: { (sampleBuffer, error) -> Void in
                    if sampleBuffer != nil {
                        let imageData = AVCaptureStillImageOutput.jpegStillImageNSDataRepresentation(sampleBuffer!)
                        let dataProvider = CGDataProvider(data: imageData as! CFData)
                        let cgImageRef = CGImage.init(jpegDataProviderSource: dataProvider!, decode: nil, shouldInterpolate: true, intent: CGColorRenderingIntent.relativeColorimetric)
                        
                        let image = UIImage(cgImage: cgImageRef!, scale: 0.2, orientation: UIImageOrientation.right)
//                        let images = fixOrientationOfImage(image: image)
                        self.arr_Main.add(image)
                        self.cv_Main.reloadData()
                    }
                })
            }
        }else{
            //Alert show for Header
            messageBar.MessageShow(title: "Max Photos limit reached", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }
    }
    @IBAction func btn_DoneCheck(_ sender: AnyObject) {
        self.dismiss(animated: true) {
            self.delegate?.CaptureImagesOption(arr: self.arr_Main)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}


class CameraPickerCellViewController : UICollectionViewCell {
    
    @IBOutlet var img_Capture: UIImageView!
    
}

func fixOrientationOfImage(image: UIImage) -> UIImage? {
    if image.imageOrientation == .up {
        return image
    }
    
    // We need to calculate the proper transformation to make the image upright.
    // We do it in 2 steps: Rotate if Left/Right/Down, and then flip if Mirrored.
    var transform = CGAffineTransform.identity
    
    switch image.imageOrientation {
    case .down, .downMirrored:
        transform = transform.translatedBy(x: image.size.width, y: image.size.height)
        transform = transform.rotated(by: CGFloat(Double.pi))
    case .left, .leftMirrored:
        transform = transform.translatedBy(x: image.size.width, y: 0)
        transform = transform.rotated(by:  CGFloat(Double.pi / 2))
    case .right, .rightMirrored:
        transform = transform.translatedBy(x: 0, y: image.size.height)
        transform = transform.rotated(by:  -CGFloat(Double.pi / 2))
    default:
        break
    }
    
    switch image.imageOrientation {
    case .upMirrored, .downMirrored:
        transform = transform.translatedBy(x: image.size.width, y: 0)
        transform = transform.scaledBy(x: -1, y: 1)
    case .leftMirrored, .rightMirrored:
        transform = transform.translatedBy(x: image.size.height, y: 0)
        transform = transform.scaledBy(x: -1, y: 1)
    default:
        break
    }
    
    // Now we draw the underlying CGImage into a new context, applying the transform
    // calculated above.
    guard let context = CGContext(data: nil, width: Int(image.size.width), height: Int(image.size.height), bitsPerComponent: image.cgImage!.bitsPerComponent, bytesPerRow: 0, space: image.cgImage!.colorSpace!, bitmapInfo: image.cgImage!.bitmapInfo.rawValue) else {
        return nil
    }
    
    context.concatenate(transform)
    
    switch image.imageOrientation {
    case .left, .leftMirrored, .right, .rightMirrored:
        context.draw(image.cgImage!, in: CGRect(x: 0, y: 0, width: image.size.height, height: image.size.width))
    default:
        context.draw(image.cgImage!, in: CGRect(origin: .zero, size: image.size))
    }
    
    // And now we just create a new UIImage from the drawing context
    guard let CGImage = context.makeImage() else {
        return nil
    }
    
    return UIImage(cgImage: CGImage)
}



//MARK: - Collection View -
extension CameraPickerViewController : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        btn_DoneCheck.isHidden = true
        if arr_Main.count != 0{
            btn_DoneCheck.isHidden = false
        }
        return arr_Main.count
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        
        return CGSize(width: collectionView.frame.size.height, height: collectionView.frame.size.height)
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        var str_Identifier : String = "cell"

        let cell  = collectionView.dequeueReusableCell(withReuseIdentifier: str_Identifier, for: indexPath) as! CameraPickerCellViewController
     
        cell.img_Capture.image = arr_Main[indexPath.row] as! UIImage
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
    }
}


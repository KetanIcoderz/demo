//
//  EditTextPlayerViewController.swift
//  iAudioo
//
//  Created by Apple on 11/06/18.
//  Copyright © 2018 iAudioo. All rights reserved.

import UIKit

class EditTextPlayerViewController: UIViewController {

    @IBOutlet weak var tv_Descriptin: UITextView!
    
    var tv_Active: UITextView!
    
    let str_EventId : String = ""
    let str_Text : String = ""
    
    @IBOutlet weak var btn_Done: UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        
        self.navigationController!.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
        self.navigationController!.navigationBar.setBackgroundImage(imageWithColor(with:GlobalConstants.appColor), for: .default)
        
        tv_Descriptin.text = str_Text
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(true, animated: true)

    }
    
    // MARK: - Other Files -
    func commanMethod(){
        
        tv_Descriptin.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 16))
    }
   
    func manageDoneButton(tv : String){
        btn_Done.isEnabled = false
        
        if tv != "" && tv != "Please enter description"{
            btn_Done.isEnabled = true
        }
    }
    
    // MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btn_Done(_ sender:Any) {
        self.Post_AddNote(index : str_EventId)
        
    }
    
    // MARK: - Get/Post Method -
    func Post_AddNote(index : String){
        
//        //Declaration URL
//        let strURL = "\(GlobalConstants.BaseURL)library/\(index)/add_note"
//
//        //Pass data in dictionary
//        var jsonData : NSDictionary =  NSDictionary()
//        jsonData = [
//            "description" : tv_Descriptin.text,
//        ]
//
//        //Create object for webservicehelper and start to call method
//        let webHelper = WebServiceHelper()
//        webHelper.strMethodName = "add_note"
//        webHelper.methodType = "post"
//        webHelper.strURL = strURL
//        webHelper.dictType = jsonData
//        webHelper.dictHeader = NSDictionary()
//        webHelper.delegateWeb = self
//        webHelper.serviceWithAlert = false
//        webHelper.showLogForCallingAPI = false
//        webHelper.startDownload()
        
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}


extension EditTextPlayerViewController : UITextViewDelegate{
    func textViewDidBeginEditing(_ textView: UITextView) {
        tv_Active = textView
        if textView.text == "Please enter description" {
            textView.text = nil
            textView.textColor = UIColor.black
        }
        
        
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        tv_Active = nil
        if textView.text.isEmpty {
            textView.text = "Please enter description"
            textView.textColor = UIColor.lightGray
        }
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        let newLength = textView.text.utf16.count + text.utf16.count - range.length
        if newLength > 0 // have text, so don't show the placeholder
        {
            self.manageDoneButton(tv : "1")
        }else{
            self.manageDoneButton(tv : "")
        }
        
        return true
    }
}


extension EditTextPlayerViewController : UITextFieldDelegate{
    
    @objc func textFieldDidChange(textField: UITextField){
        
        self.manageDoneButton(tv : tv_Descriptin.text)
        
    }
}



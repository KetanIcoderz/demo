//
//  GotoSettingPageViewController.swift
//
//  Created by iAudioo on 02/08/17.
//  Copyright © 2017 iAudioo123. All rights reserved.

import UIKit

class GotoSettingPageViewController: UIViewController {

    //photo,video,microPhone
    var str_TypeofValidation : NSString = "photo"
    
    @IBOutlet var lbl_Title : UILabel!
    @IBOutlet var lbl_SubTitle : UILabel!
    
    @IBOutlet var img_Icon : UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if str_TypeofValidation == "photo" {
            
            lbl_Title.text = "Please Allow Photos Access"
            lbl_SubTitle.text = "We need your permission to access your photo library. This will enable you to upload photos you're previously taken to \(GlobalConstants.appName)."
            
        }else if str_TypeofValidation == "video" {
            
            lbl_Title.text = "Please Allow Video Access"
            lbl_SubTitle.text = "We need your permission to access your video recording. This will enable you to upload video you're previously record to \(GlobalConstants.appName)."
            
        }else if str_TypeofValidation == "microPhone" {
            
            lbl_Title.text = "Please Allow Microphone Access"
            lbl_SubTitle.text = "We need your permission to access your MicroPhone access."
            
        }
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    //MARK: - Button Event -
    @IBAction func btn_Back(_ sender: Any) {
        dismiss(animated: true) {
        }
    }
    @IBAction func btn_GoingToSetting(_ sender: Any) {
        if UIApplicationOpenSettingsURLString != nil {
            var appSettings = URL(string: UIApplicationOpenSettingsURLString)
            UIApplication.shared.openURL(appSettings!)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

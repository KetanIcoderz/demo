//
//  NoteListingViewController.swift
//  iAudioo
//
//  Created by Apple on 25/05/18.
//  Copyright © 2018 iAudioo. All rights reserved.
//

import UIKit
import EmptyDataSet_Swift

class NoteListingViewController: UIViewController {

    var str_LibraryId : String = ""
    var str_TitleNav : String = ""
    
    var arr_Main : NSMutableArray = []
    
    @IBOutlet weak var tbl_Main : UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
     
        self.navigationItem.title = str_TitleNav
        
        tbl_Main.emptyDataSetSource = self
        tbl_Main.emptyDataSetDelegate = self
        
    }

    override func viewWillAppear(_ animated: Bool) {
        self.navigationController!.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
        self.navigationController!.navigationBar.setBackgroundImage(imageWithColor(with:GlobalConstants.appColor), for: .default)
        
        self.Get_NoteListing()
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Get/Post Method -
    func Get_NoteListing(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)library/\(str_LibraryId)/list_notes"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "list_notes"
        webHelper.methodType = "get"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.startDownload()
    }
    
    // MARK: - Get/Post Method -
    @IBAction func btn_Back (_ sender : Any){
        self.navigationController?.popViewController(animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}


// MARK: - Tableview Cell -
class NoteListingTablecell: UITableViewCell {
    // MARK: - Table Cell -
    @IBOutlet var lbl_Title: UILabel!
    @IBOutlet var lbl_Decription: UILabel!
}


// MARK: - Tableview Delegate -

extension NoteListingViewController : UITableViewDataSource,UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr_Main.count
    }
  
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    public func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 50
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let str_Identifier : String = "cell"
        
        let obj = arr_Main[indexPath.row] as! GlobalObject
      
        let cell = tableView.dequeueReusableCell(withIdentifier: str_Identifier, for:indexPath as IndexPath) as! NoteListingTablecell
        
        //Declare text in icon in tableview cell
        cell.lbl_Title.text = obj.str_Note_Title
        cell.lbl_Decription.text = obj.str_Note_Description
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let obj = arr_Main[indexPath.row] as! GlobalObject

        let view = self.storyboard?.instantiateViewController(withIdentifier: "AddNoteViewController") as! AddNoteViewController
        view.str_EventId = str_LibraryId
        view.str_Id = obj.str_Note_Id
        view.str_Tital = obj.str_Note_Title
        view.str_Description = obj.str_Note_Description
        vw_TabBarController?.navigationController?.pushViewController(view, animated: true)
        
    }
    
}


extension NoteListingViewController : EmptyDataSetSource, EmptyDataSetDelegate
    
{
    func emptyDataSetShouldDisplay(_ scrollView: UIScrollView) -> Bool {
        if arr_Main.count == 0{
            return true
        }
        return false
    }
    
    func image(forEmptyDataSet scrollView: UIScrollView) -> UIImage? {
        
        return UIImage.init(named: "img_NoData1")
    }
    
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        
        var text: String?
        var font: UIFont?
        var textColor: UIColor?
        
        textColor = UIColor.darkGray
        
        text = "No note found"
        
        font = UIFont(name: GlobalConstants.kFontRegular, size:GlobalConstants.kFontRatio*18.0 )
        
        if text == nil {
            return nil
        }
        var attributes: [NSAttributedStringKey: Any] = [:]
        if font != nil {
            attributes[NSAttributedStringKey.font] = font!
        }
        if textColor != nil {
            attributes[NSAttributedStringKey.foregroundColor] = textColor
        }
        
        textColor = UIColor.clear
        
        return NSAttributedString.init(string: text!, attributes: attributes)
    }
}




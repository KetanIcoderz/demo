//
//  PlayerViewController.swift
//  iAudioo
//
//  Created by Apple on 30/04/18.
//  Copyright © 2018 iAudioo. All rights reserved.

import UIKit
import ActionSheetPicker_3_0
import QuartzCore
import AVFoundation
import MediaPlayer

class PlayerViewController: UIViewController, AVAudioPlayerDelegate, DismissNotePickerDelegate {

    @IBOutlet weak var tv_Main: UITextView!
    
    @IBOutlet weak var lbl_StartTimer: UILabel!
    @IBOutlet weak var lbl_EndTimer: UILabel!
    @IBOutlet weak var lbl_TextShow : UILabel!
    @IBOutlet weak var lbl_HeaderTitle : UILabel!
    
    @IBOutlet weak var btn_PlayPause: UIButton!
    @IBOutlet weak var btn_15Back: UIButton!
    @IBOutlet weak var btn_15Forward: UIButton!
    
    @IBOutlet weak var slider_Main: UISlider!
    
    @IBOutlet weak var vw_TextField : UIView!
    
    @IBOutlet weak var vw_Sound : UIView!
    
    @IBOutlet weak var slider: MJSlider!
    
    //Player controller declaration object
    var speechSynthesizer = AVSpeechSynthesizer()
    
    var rate: Float!
    
    var pitch: Float!
    
    var volume: Float!
    
    var totalUtterances: Int! = 0
    
    var currentUtterance: Int! = 0
    
    var totalTextLength: Int = 0
    
    var spokenTextLengths: Int = 0
    
    var preferredVoiceLanguageCode: String!
    
    var previousSelectedRange: NSRange!
    
    //5 -
    var songPlayer = AVAudioPlayer()
    //15 -
    var hasBeenPaused = false
    var bool_Close = false
    var bool_Appear = false
    
    var obj_Get = GlobalObject()
    
    var img_Load : UIImage!
    var str_SelectedLanguageCode : String = "en-US"
    var str_SelectedLanguageTitle : String = ""
    var str_TypePlay : String = ""
    
    var str_VoiceManage : String = "English (United States)"
    
    var presentAds : Bool = true
    
    let accessibilityDateComponentsFormatter = DateComponentsFormatter()
    
    var alert = UIAlertController()
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        let pause = UIBarButtonItem(image: UIImage(named: "pause"), style: .plain, target: self, action: #selector(btn_PlayPause(_:)))
        pause.accessibilityLabel = NSLocalizedString("Pause", comment: "")
        
        let next = UIBarButtonItem(image: UIImage(named: "nextFwd"), style: .plain, target: self, action: #selector(btn_PlayPause(_:)))
        next.accessibilityLabel = NSLocalizedString("Next Track", comment: "")
        
        popupItem.rightBarButtonItems = [ pause, next ]
        
        accessibilityDateComponentsFormatter.unitsStyle = .spellOut
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = obj_Get.str_Lib_Title
        lbl_HeaderTitle.text = obj_Get.str_Lib_Title
        tv_Main.text = removeNewLineToSpace(str_Value: obj_Get.str_Lib_Text)
        
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = false

    }

    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        bool_Close = false
        bool_Appear = true

        if str_PresentPlayer != "1" && !speechSynthesizer.isSpeaking{
                self.commanMethod()
                if obj_Get.str_Lib_Progress != "0" && obj_Get.str_Lib_Progress != "1"{
                    slider_Main.value = Float(obj_Get.str_Lib_Progress)!
                    self.StartToMiddle()
                }else{
                    self.commanMethod()
                    self.btn_PlayPause(btn_PlayPause)
                }
            presentAds = false
        }
        str_PresentPlayer = ""
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        
        bool_Appear = false
        alert.dismiss(animated: true, completion: nil)
        
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        //Once the view has loaded then we can register to begin recieving controls and we can become the first responder
        UIApplication.shared.beginReceivingRemoteControlEvents()
        becomeFirstResponder()
    }
    override func viewDidDisappear(_ animated: Bool) {

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var songTitle: String = "" {
        didSet {
            popupItem.title = songTitle
        }
    }
    var albumTitle: String = "" {
        didSet {
            if ProcessInfo.processInfo.operatingSystemVersion.majorVersion <= 9 {
                popupItem.subtitle = albumTitle
            }
        }
    }
    
    // MARK: - Delegate Call -
    func NoteOption(str_Tital: String,str_Description: String){
        obj_Get.str_Lib_Title = str_Tital
        obj_Get.str_Lib_Text = str_Description
        
        self.tv_Main.text = removeNewLineToSpace(str_Value: self.obj_Get.str_Lib_Text)

        self.slider_Main.value = 0.0
        self.sliderChangeSound()
    }
    
    // MARK: - Other Files -
    func commanMethod(){
        
        slider_Main.addTarget(self, action: #selector(onSliderValChanged(slider:event:)), for: .valueChanged)
        
        lbl_StartTimer.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 12))
        lbl_EndTimer.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 12))
        lbl_TextShow.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 16))
        lbl_HeaderTitle.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 16))
        
        tv_Main.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 16))
        
        //Geasture
        let longGust = UILongPressGestureRecognizer(target: self, action: #selector(longPressed(sender:)))
        vw_TextField.addGestureRecognizer(longGust)
        
        //Player Controller SetUp
        prepareSongAndSession()
        songPlayer.delegate = self
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.appDidEnterBackground), name: .UIApplicationDidEnterBackground, object: nil)
        
        
        UIApplication.shared.beginReceivingRemoteControlEvents()
        let commandCenter = MPRemoteCommandCenter.shared()
        
        commandCenter.pauseCommand.addTarget { (event) -> MPRemoteCommandHandlerStatus in
            //Update your button here for the pause command
            return .success
        }
        
        commandCenter.playCommand.addTarget { (event) -> MPRemoteCommandHandlerStatus in
            //Update your button here for the play command
            return .success
        }
        
        // Make the progress view invisible and set is initial progress to zero.
        slider_Main.value = 0.0
        
        if !loadSettings() {
            registerDefaultSettings()
        }
        
        speechSynthesizer.delegate = self
        
        setInitialFontAttribute()
        
        tv_Main.isHidden = true
        lbl_TextShow.isHidden = true
        if objUser?.plyer_DisplayType == "0"{
            tv_Main.isHidden = false
        }else{
            lbl_TextShow.isHidden = false
        }
        
        // add a slider
        slider.backgroundColor = UIColor.black
        slider.tintColor = UIColor.white
        slider.cornerRadius = 10
        slider.value = (rate == nil) ? 1 : rate
        slider.transparency = 1.0
    }
    func restarView(){
        speechSynthesizer.stopSpeaking(at: AVSpeechBoundary.immediate)
        speechSynthesizer = AVSpeechSynthesizer()
        speechSynthesizer.delegate = self
        
        btn_PlayPause.isSelected = false
        
        self.tv_Main.textColor = UIColor.black
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4, execute: {
            self.commanMethod()
        })
    }
    func StartToMiddle(){
        
        if tv_Main.text.count > 0{
            let int_Sec = Double(tv_Main.text.count) * GlobalConstants.playerWordPerPlaySecond
            var int_Sec_Sub = (Double(slider_Main.value * 100) * int_Sec) / 100
            
            var textParagraphs = tv_Main.text.components(separatedBy: "\n")
            
            // Logic
            let doublePer = (int_Sec_Sub * 100) / int_Sec // Get persentage for start index
            let notGetText = (Double(doublePer) * Double(tv_Main.text.count)) / 100 // start text index
            
            let string1 = tv_Main.text as! String
            let result = String(string1.characters.dropFirst(Int(notGetText)))
            
            textParagraphs =  result.components(separatedBy: "\n")
            spokenTextLengths = Int(notGetText)
            
            totalUtterances = 0
            currentUtterance = 0
            totalTextLength = 0
            
            for pieceOfText in textParagraphs {
                let speechUtterance = AVSpeechUtterance(string: pieceOfText)
                speechUtterance.rate = (rate == nil) ? 1 : rate
                speechUtterance.pitchMultiplier = (pitch == nil) ? 1.0 : pitch
                speechUtterance.volume = volume
                speechUtterance.postUtteranceDelay = 0.005
                
                //                if let voiceLanguageCode = preferredVoiceLanguageCode {
                let voice = AVSpeechSynthesisVoice(language: self.str_SelectedLanguageCode)
                speechUtterance.voice = voice
                //                }
                
                totalTextLength = totalTextLength + pieceOfText.characters.count
                
                if pieceOfText != ""{
                    totalUtterances = totalUtterances + 1
                }
                
                speechSynthesizer.speak(speechUtterance)
                songPlayer.play()
            }
            
            animateActionButtonAppearance(shouldHideSpeakButton: true)
            
            let pause = UIBarButtonItem(image: UIImage(named: "pause"), style: .plain, target: self, action: #selector(btn_PlayPause(_:)))
            pause.accessibilityLabel = NSLocalizedString("Pause", comment: "")
            popupItem.rightBarButtonItems = [ pause]
        }
    }
    @objc func longPressed(sender: UILongPressGestureRecognizer)
    {
        print("long guasure")
        
        if sender.state == UIGestureRecognizerState.began{
            if objUser?.plyer_DisplayType == "0"{
                objUser?.plyer_DisplayType = "1"
            }else{
                objUser?.plyer_DisplayType = "0"
            }
            
            //Save User Object
            saveCustomObject(objUser!, key: "userobject");
            
            tv_Main.isHidden = true
            lbl_TextShow.isHidden = true
            if objUser?.plyer_DisplayType == "0"{
                tv_Main.isHidden = false
            }else{
                lbl_TextShow.isHidden = false
            }
        }
        
    }
    func prepareSongAndSession() {
        do {
            //7 - Insert the song from our Bundle into our AVAudioPlayer
            songPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "DemoSound", ofType: "mp3")!))
            
            //8 - Prepare the song to be played
//            songPlayer.numberOfLoops = -1
            songPlayer.delegate = self
            songPlayer.prepareToPlay()
            
            //9 - Create an audio session
            let audioSession = AVAudioSession.sharedInstance()
            do {
                //10 - Set our session category to playback music
                try audioSession.setCategory(AVAudioSessionCategoryPlayback)
                try AVAudioSession.sharedInstance().setActive(true)
                //11 -
            } catch let sessionError {
                
                print(sessionError)
            }
            //12 -
        } catch let songPlayerError {
            print(songPlayerError)
        }
    }
    func loadSettings() -> Bool {
        let userDefaults = UserDefaults.standard as UserDefaults
        
        if let theRate: Float = userDefaults.value(forKey: "rate") as? Float {
            rate = userDefaults.value(forKey: "rate") as? Float
            pitch = userDefaults.value(forKey: "pitch") as! Float
            volume = userDefaults.value(forKey: "volume") as! Float
            
            return true
        }
        
        return false
    }
    func registerDefaultSettings() {
        rate = 0.5
        pitch = 1.0
        volume = 1.0
        
        let defaultSpeechSettings: Dictionary<NSObject, AnyObject> = ["rate" as NSObject: rate as AnyObject, "pitch" as NSObject: pitch as AnyObject, "volume" as NSObject: volume as AnyObject]
        
        UserDefaults.standard.register(defaults: defaultSpeechSettings as! [String : Any])
    }
    @objc func appDidEnterBackground() {
        if speechSynthesizer.isPaused {
            songPlayer.pause()
        }else{
            songPlayer.play()
        }
        self.callGetLockScreenPlayDetail()
    }
    
    func callGetLockScreenPlayDetail() {

        let commandCenter = MPRemoteCommandCenter.shared()
        commandCenter.skipForwardCommand.isEnabled = true
        commandCenter.skipForwardCommand.addTarget(self, action:#selector(skip15SecondPlayer))
        commandCenter.skipBackwardCommand.isEnabled = true
        commandCenter.skipBackwardCommand.addTarget(self, action:#selector(backword15SecondPlayer))
        commandCenter.changePlaybackPositionCommand.isEnabled = true
        commandCenter.changePlaybackPositionCommand.addTarget(self, action: #selector(PlayerViewController.changedThumbSlider(onLockScreen:)))

        
        let int_Sec = Double(tv_Main.text.count) * GlobalConstants.playerWordPerPlaySecond
        var int_Sec_Sub = (Double(slider_Main.value * 100) * int_Sec) / 100
        
        obj_Get.str_Lib_Title = "dsfsdf\nsdfsdf\ndfsdf"
        let test = String(obj_Get.str_Lib_Title.filter { !" \n\t\r".contains($0) })
        //MPMediaItemPropertyAlbumTitle: "",
        let nowPlaying = [MPMediaItemPropertyArtist: test,
                          MPMediaItemPropertyPlaybackDuration: int_Sec,
                          MPNowPlayingInfoPropertyPlaybackRate: 1.0,
                          MPNowPlayingInfoPropertyElapsedPlaybackTime: int_Sec_Sub,
                          MPMediaItemPropertyArtwork: MPMediaItemArtwork(image: img_Load!)] as [String : Any]
        
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nowPlaying
    }
    override var canBecomeFirstResponder: Bool {
        return true
    }
    override func remoteControlReceived(with event: UIEvent?) {
        
        //if it is a remote control event handle it correctly
        if event?.type == .remoteControl {
            if event?.subtype == .remoteControlPlay {
                songPlayer.play()
                self.btn_PlayPause(btn_PlayPause)
            } else if event?.subtype == .remoteControlPause {
                songPlayer.pause()
                speechSynthesizer.pauseSpeaking(at: AVSpeechBoundary.immediate)
                animateActionButtonAppearance(shouldHideSpeakButton: false)
            } else if event?.subtype == .remoteControlTogglePlayPause {
                songPlayer.pause()
                speechSynthesizer.pauseSpeaking(at: AVSpeechBoundary.immediate)
                animateActionButtonAppearance(shouldHideSpeakButton: false)
            } else if event?.subtype == .remoteControlPreviousTrack {
                songPlayer.stop()
                speechSynthesizer.stopSpeaking(at: AVSpeechBoundary.immediate)
                speechSynthesizer = AVSpeechSynthesizer()
                speechSynthesizer.delegate = self
                
                animateActionButtonAppearance(shouldHideSpeakButton: false)
            } else if event?.subtype == .remoteControlNextTrack {
                songPlayer.stop()
                speechSynthesizer.stopSpeaking(at: AVSpeechBoundary.immediate)
                speechSynthesizer = AVSpeechSynthesizer()
                speechSynthesizer.delegate = self
                
                animateActionButtonAppearance(shouldHideSpeakButton: false)
            }else if event?.subtype == .remoteControlEndSeekingBackward {
                songPlayer.stop()
                speechSynthesizer.stopSpeaking(at: AVSpeechBoundary.immediate)
                speechSynthesizer = AVSpeechSynthesizer()
                speechSynthesizer.delegate = self
                
                animateActionButtonAppearance(shouldHideSpeakButton: false)
            }
        }
    }
    @objc func backword15SecondPlayer(){
        speechSynthesizer.stopSpeaking(at: AVSpeechBoundary.immediate)
        speechSynthesizer = AVSpeechSynthesizer()
        speechSynthesizer.delegate = self
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: {
            self.manage15SecondUpDown(type: 0)
        })
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: {
            self.callGetLockScreenPlayDetail()
        })
    }
    @objc func skip15SecondPlayer(){
        speechSynthesizer.stopSpeaking(at: AVSpeechBoundary.immediate)
        speechSynthesizer = AVSpeechSynthesizer()
        speechSynthesizer.delegate = self
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: {
            self.manage15SecondUpDown(type: 1)
        })
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: {
            self.callGetLockScreenPlayDetail()
        })
    }
    @objc func changedThumbSlider(onLockScreen event: MPChangePlaybackPositionCommandEvent?) -> MPRemoteCommandHandlerStatus {
        
        
        speechSynthesizer.stopSpeaking(at: AVSpeechBoundary.immediate)
        speechSynthesizer = AVSpeechSynthesizer()
        speechSynthesizer.delegate = self
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: {
            // change position
            let time = event?.positionTime ?? 0.0
            print(time)
            
            let int_Sec = Double(self.tv_Main.text.count) * GlobalConstants.playerWordPerPlaySecond
            let doubleNew = (time * 100) / int_Sec
                
            self.slider_Main.value = Float(doubleNew/100)
            
            let int_Sec_Sub = (Double(self.slider_Main.value * 100) * int_Sec) / 100
            
            var textParagraphs = self.tv_Main.text.components(separatedBy: "\n")
            
            // Logic
            let doublePer = (int_Sec_Sub * 100) / int_Sec // Get persentage for start index
            let notGetText = (Double(doublePer) * Double(self.tv_Main.text.count)) / 100 // start text index
            
            let string1 = self.tv_Main.text as! String
            let result = String(string1.characters.dropFirst(Int(notGetText)))
            
            textParagraphs =  result.components(separatedBy: "\n")
            self.spokenTextLengths = Int(notGetText)
            
            self.totalUtterances = 0
            self.currentUtterance = 0
            self.totalTextLength = 0
            
            for pieceOfText in textParagraphs {
                let speechUtterance = AVSpeechUtterance(string: pieceOfText)
                speechUtterance.rate = self.rate
                speechUtterance.pitchMultiplier = self.pitch
                speechUtterance.volume = self.volume
                speechUtterance.postUtteranceDelay = 0.005
                
//                if let voiceLanguageCode = self.preferredVoiceLanguageCode {
                    let voice = AVSpeechSynthesisVoice(language: self.str_SelectedLanguageCode)
                    speechUtterance.voice = voice
//                }
                
                self.totalTextLength = self.totalTextLength + pieceOfText.characters.count
                
                if pieceOfText != ""{
                    self.totalUtterances = self.totalUtterances + 1
                }
                
                self.speechSynthesizer.speak(speechUtterance)
                
                self.songPlayer.play()
            }
            
            self.animateActionButtonAppearance(shouldHideSpeakButton: true)
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: {
                self.callGetLockScreenPlayDetail()
            })
         })
        
        return .noSuchContent
    }

    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool){
        songPlayer.stop()
        speechSynthesizer.stopSpeaking(at: AVSpeechBoundary.immediate)
        speechSynthesizer = AVSpeechSynthesizer()
        speechSynthesizer.delegate = self
        
        animateActionButtonAppearance(shouldHideSpeakButton: false)
    }
    
    func handleSwipeDownGesture(gestureRecognizer: UISwipeGestureRecognizer) {
        tv_Main.resignFirstResponder()
    }
    
    func animateActionButtonAppearance(shouldHideSpeakButton: Bool) {
        
        if shouldHideSpeakButton {
           btn_PlayPause.isSelected = true
        }else{
            btn_PlayPause.isSelected = false
        }
    }
    
    func setInitialFontAttribute() {
    }
    func unselectLastWord() {
        if let selectedRange = previousSelectedRange {
            // Get the attributes of tv_Main last selected attributed word.
            let currentAttributes = tv_Main.attributedText.attributes(at: selectedRange.location, effectiveRange: nil)
            // Keep the font attribute.
            let fontAttribute: AnyObject? = currentAttributes[NSAttributedStringKey.font] as AnyObject
            
            // Create a new mutable attributed string using the last selected word.
            let attributedWord = NSMutableAttributedString(string: tv_Main.attributedText.attributedSubstring(from: selectedRange).string)
            
            // Set the previous font attribute, and make the foreground color black.
            attributedWord.addAttribute(NSAttributedStringKey.foregroundColor, value: UIColor.black, range: NSMakeRange(0, attributedWord.length))
            attributedWord.addAttribute(NSAttributedStringKey.font, value: fontAttribute!, range: NSMakeRange(0, attributedWord.length))
            
            // Update the text storage property and replace the last selected word with the new attributed string.
            tv_Main.textStorage.beginEditing()
            tv_Main.textStorage.replaceCharacters(in: selectedRange, with: attributedWord)
            tv_Main.textStorage.endEditing()
        }
    }
    func manageTimerSetting(){
        //0.073
        
        let int_Sec = Double(tv_Main.text.count) * GlobalConstants.playerWordPerPlaySecond
        lbl_EndTimer.text = String(secondsToHoursMinutesSeconds(seconds: Int(int_Sec)))
        
        if slider_Main.value == 0.0{
            lbl_StartTimer.text = "00:00"
        }else{
            let int_Sec_Sub = (Double(slider_Main.value * 100) * int_Sec) / 100
            lbl_StartTimer.text = String(secondsToHoursMinutesSeconds(seconds: Int(int_Sec_Sub)))
        }
        
        obj_Player.str_Lib_Progress = String(slider_Main.value)
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "librayreloadtableview"), object: nil)
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "notereloadtableview"), object: nil)
        
        print(slider_Main.value)

    }
    func secondsToHoursMinutesSeconds (seconds : Int) -> String {
        return "\((seconds % 3600) / 60):\((seconds % 3600) % 60)"
    }
    func manage15SecondUpDown(type : Int){//type = 0 - backword , 1 - forward
//        speechSynthesizer.stopSpeaking(at: AVSpeechBoundary.immediate)
        
        if type == 0{
            let int_Sec = Double(tv_Main.text.count) * GlobalConstants.playerWordPerPlaySecond
            var int_Sec_Sub = (Double(slider_Main.value * 100) * int_Sec) / 100
            
            var textParagraphs = tv_Main.text.components(separatedBy: "\n")
            if int_Sec_Sub < 15{
                spokenTextLengths = 0
                textParagraphs = tv_Main.text.components(separatedBy: "\n")
            }else{
                // Logic
                int_Sec_Sub = int_Sec_Sub - 15 //Subscibe 15 second for current second
                let doublePer = (int_Sec_Sub * 100) / int_Sec // Get persentage for start index
                let notGetText = (Double(doublePer) * Double(tv_Main.text.count)) / 100 // start text index
                
                let string1 = tv_Main.text as! String
                let result = String(string1.characters.dropFirst(Int(notGetText)))
                    
                textParagraphs =  result.components(separatedBy: "\n")
                spokenTextLengths = Int(notGetText)
            }
            
            totalUtterances = 0
            currentUtterance = 0
            totalTextLength = 0
            
            for pieceOfText in textParagraphs {
                let speechUtterance = AVSpeechUtterance(string: pieceOfText)
                speechUtterance.rate = (rate == nil) ? 1 : rate
                speechUtterance.pitchMultiplier = pitch
                speechUtterance.volume = volume
                speechUtterance.postUtteranceDelay = 0.005
                
//                if let voiceLanguageCode = preferredVoiceLanguageCode {
                    let voice = AVSpeechSynthesisVoice(language: self.str_SelectedLanguageCode)
                    speechUtterance.voice = voice
//                }
                
                totalTextLength = totalTextLength + pieceOfText.characters.count
                if pieceOfText != ""{
                    totalUtterances = totalUtterances + 1
                }
                
                speechSynthesizer.speak(speechUtterance)
                songPlayer.play()
            }
        }else  if type == 1{
            let int_Sec = Double(tv_Main.text.count) * GlobalConstants.playerWordPerPlaySecond
            var int_Sec_Sub = (Double(slider_Main.value * 100) * int_Sec) / 100
            int_Sec_Sub = int_Sec_Sub + 15
            
            var textParagraphs = tv_Main.text.components(separatedBy: "\n")
            if int_Sec_Sub > int_Sec{
                int_Sec_Sub = int_Sec

                slider_Main.value = 0.0
                bool_Close = true
                if bool_Appear == false{
                    self.Post_UpdateLibraryStatus(progressValue: "1", status: "Completed",serviceCall: "update_library3")
                }else{
                    self.Post_UpdateLibraryStatus(progressValue: "1", status: "Completed",serviceCall: "update_library")
                }
            }
            
            
            let doublePer = (int_Sec_Sub * 100) / int_Sec // Get persentage for start index
            let notGetText = (Double(doublePer) * Double(tv_Main.text.count)) / 100 // start text index
            
            let string1 = tv_Main.text as! String
            let result = String(string1.characters.dropFirst(Int(notGetText)))
            
            textParagraphs =  result.components(separatedBy: "\n")
            spokenTextLengths = Int(notGetText)
            
            totalUtterances = 0
            currentUtterance = 0
            totalTextLength = 0
            
            for pieceOfText in textParagraphs {
                let speechUtterance = AVSpeechUtterance(string: pieceOfText)
                speechUtterance.rate = (rate == nil) ? 1 : rate
                speechUtterance.pitchMultiplier = pitch
                speechUtterance.volume = volume
                speechUtterance.postUtteranceDelay = 0.005
                
//                if let voiceLanguageCode = preferredVoiceLanguageCode {
                    let voice = AVSpeechSynthesisVoice(language: self.str_SelectedLanguageCode)
                    speechUtterance.voice = voice
//                }
                
                totalTextLength = totalTextLength + pieceOfText.characters.count
                
                if pieceOfText != ""{
                    totalUtterances = totalUtterances + 1
                }
                
                speechSynthesizer.speak(speechUtterance)
                songPlayer.play()
            }
        }
        
        animateActionButtonAppearance(shouldHideSpeakButton: true)
    }
    func playerClose(){
        str_PresentPlayer = ""
        self.Post_UpdateLibraryStatus(progressValue: String(slider_Main.value), status: "Continue Reading",serviceCall: "update_library2")
    }
    
    // MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any) {
        if songPlayer.isPlaying == false{
            self.Post_UpdateLibraryStatus(progressValue: "1", status: "Completed",serviceCall: "update_library3")
        }else{
            vw_TabBarController?.closePopup(animated: true, completion: nil)
        }
    }
    @IBAction func btn_More(_ sender:Any) {
        alert = UIAlertController(title: nil, message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        alert.addAction(UIAlertAction(title: "English Voice", style: UIAlertActionStyle.default, handler: { (action) in
            
            let arr_Get : NSMutableArray = []
            for i in 0..<arr_Voice.count{
                let obj : GlobalObject = arr_Voice[i] as! GlobalObject
                arr_Get.add(obj.str_Voice_Name)
            }
            
//            var arr_Get : Array = ["US Female","US Male (HD)","US Female (HD)","Britesh Male (HD)"]
            let picker = ActionSheetStringPicker(title: "English Voice", rows: arr_Get as! [Any], initialSelection:selectedIndex(arr: arr_Get as NSArray, value: self.str_VoiceManage as NSString), doneBlock: { (picker, indexes, values) in
                //Get selected object and set code and voice string
                let obj : GlobalObject = arr_Voice[indexes] as! GlobalObject
                self.str_SelectedLanguageCode = obj.str_Voice_Code
                
                self.str_VoiceManage = obj.str_Voice_Name
                
                //Restart player
                self.restarView()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: {
                    self.tv_Main.text = ""
                    self.tv_Main.text = removeNewLineToSpace(str_Value: self.obj_Get.str_Lib_Text)
                })
                
            }, cancel: {ActionSheetStringPicker in return}, origin: sender)
            
            picker?.setDoneButton(UIBarButtonItem(title: "DONE", style: .plain, target: nil, action: nil))
            picker?.toolbarButtonsColor = UIColor.black
            picker?.show()
            
        }))
        alert.addAction(UIAlertAction(title: "Translate", style: UIAlertActionStyle.default, handler: { (action) in
//            var arr_Get : Array = ["Spanish","French","Chinese","Portuguese Male","Portuguese Female","Dutch Male","Dutch FeMale","Hindi","Arabian"]
            let arr_Get : NSMutableArray = []
            for i in 0..<arr_Languages.count{
                let obj : GlobalObject = arr_Languages[i] as! GlobalObject
                arr_Get.add(obj.str_Lan_Name)
            }
            
            let picker = ActionSheetStringPicker(title: "Translate", rows: arr_Get as! [Any], initialSelection:selectedIndex(arr: arr_Get, value: self.str_SelectedLanguageTitle as NSString), doneBlock: { (picker, indexes, values) in
                
                let obj : GlobalObject = arr_Languages[indexes] as! GlobalObject
                self.str_SelectedLanguageCode = obj.str_Lan_Code
                self.Post_GetTraslation(str_Id : obj.str_Lan_Code)
                
                self.str_SelectedLanguageTitle = obj.str_Lan_Name
                
            }, cancel: {ActionSheetStringPicker in return}, origin: sender)
            
            picker?.setDoneButton(UIBarButtonItem(title: "DONE", style: .plain, target: nil, action: nil))
            picker?.toolbarButtonsColor = UIColor.black
            picker?.show()
        }))
        
        alert.addAction(UIAlertAction(title: "Edit", style: UIAlertActionStyle.default, handler: { (action) in
            self.speechSynthesizer.stopSpeaking(at: AVSpeechBoundary.immediate)
            self.speechSynthesizer = AVSpeechSynthesizer()
            self.speechSynthesizer.delegate = self

            if self.str_TypePlay == "note"{
                let view = self.storyboard?.instantiateViewController(withIdentifier: "AddNoteViewController") as! AddNoteViewController
                view.str_Id = self.obj_Get.str_Lib_Id
                view.str_Tital = self.obj_Get.str_Lib_Title

                view.str_Description = removeNewLineToSpace(str_Value: self.obj_Get.str_Lib_Text)
                view.str_TypeGoing = "submain"
                view.delegate = self
                vw_TabBarController?.navigationController?.pushViewController(view, animated: true)
            }else{
                let view = self.storyboard?.instantiateViewController(withIdentifier: "AddNoteViewController") as! AddNoteViewController
                view.str_Id = self.obj_Get.str_Lib_Id
                view.str_Tital = self.obj_Get.str_Lib_Title

                 view.str_Description = removeNewLineToSpace(str_Value: self.obj_Get.str_Lib_Text)
                view.str_TypeGoing = "mainedit"
                view.delegate = self
                vw_TabBarController?.navigationController?.pushViewController(view, animated: true)
            }


        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
        
    }
    @IBAction func btn_PlayPause (_ sender: UIButton){
        if btn_PlayPause.isSelected == false{
            if !speechSynthesizer.isSpeaking {
                
                let textParagraphs = tv_Main.text.components(separatedBy: "\n")
                
                totalUtterances = 0
                currentUtterance = 0
                totalTextLength = 0
                spokenTextLengths = 0
                
                for pieceOfText in textParagraphs {
                    let speechUtterance = AVSpeechUtterance(string: pieceOfText)
                    speechUtterance.rate = (rate == nil) ? 0.5 : rate
                    speechUtterance.pitchMultiplier = (pitch == nil) ? 1.0 : pitch
                    speechUtterance.volume = (volume == nil) ? 1.0 : volume
                    speechUtterance.postUtteranceDelay = 0.005
                    
//                    if let voiceLanguageCode = preferredVoiceLanguageCode {
                        let voice = AVSpeechSynthesisVoice(language: self.str_SelectedLanguageCode)
                        speechUtterance.voice = voice
//                    }
                    
                    totalTextLength = totalTextLength + pieceOfText.characters.count
                    
                    if pieceOfText != ""{
                        totalUtterances = totalUtterances + 1
                    }
                    
                    speechSynthesizer.speak(speechUtterance)
                    songPlayer.play()
                }
            }
            else{
                speechSynthesizer.continueSpeaking()
            }
            
            animateActionButtonAppearance(shouldHideSpeakButton: true)
            
            let pause = UIBarButtonItem(image: UIImage(named: "pause"), style: .plain, target: self, action: #selector(btn_PlayPause(_:)))
            pause.accessibilityLabel = NSLocalizedString("Pause", comment: "")
            popupItem.rightBarButtonItems = [ pause]
        }else{
            speechSynthesizer.pauseSpeaking(at: AVSpeechBoundary.immediate)
            animateActionButtonAppearance(shouldHideSpeakButton: false)
            
            let pause = UIBarButtonItem(image: UIImage(named: "play"), style: .plain, target: self, action: #selector(btn_PlayPause(_:)))
            pause.accessibilityLabel = NSLocalizedString("Pause", comment: "")
            popupItem.rightBarButtonItems = [ pause]
        }
    }
    @IBAction func btn_15Back (_ sender: UIButton){
        speechSynthesizer.stopSpeaking(at: AVSpeechBoundary.immediate)
        speechSynthesizer = AVSpeechSynthesizer()
        speechSynthesizer.delegate = self
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: {
            self.manage15SecondUpDown(type: 0)
        })
    }
    @IBAction func btn_15Forward (_ sender: UIButton){
        speechSynthesizer.stopSpeaking(at: AVSpeechBoundary.immediate)
        speechSynthesizer = AVSpeechSynthesizer()
        speechSynthesizer.delegate = self
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: {
            self.manage15SecondUpDown(type: 1)
        })
    }

    @objc func onSliderValChanged(slider: UISlider, event: UIEvent) {
        var bool_Match : Bool = false
        if let touchEvent = event.allTouches?.first {
            switch touchEvent.phase {
            case .began: break
            // handle drag began
            case .moved: break
            // handle drag moved
            case .ended:
            bool_Match = true
                break
            default:
                break
            }
        }
        
        
        if bool_Match == true{
            speechSynthesizer.stopSpeaking(at: AVSpeechBoundary.immediate)
            speechSynthesizer = AVSpeechSynthesizer()
            speechSynthesizer.delegate = self
            
            let int_Sec = Double(tv_Main.text.count) * GlobalConstants.playerWordPerPlaySecond
            var int_Sec_Sub = (Double(slider_Main.value * 100) * int_Sec) / 100
            
            var textParagraphs = tv_Main.text.components(separatedBy: "\n")
            
            // Logic
            let doublePer = (int_Sec_Sub * 100) / int_Sec // Get persentage for start index
            let notGetText = (Double(doublePer) * Double(tv_Main.text.count)) / 100 // start text index
            
            let string1 = tv_Main.text as! String
            let result = String(string1.characters.dropFirst(Int(notGetText)))
            
            textParagraphs =  result.components(separatedBy: "\n")
            spokenTextLengths = Int(notGetText)
            
            totalUtterances = 0
            currentUtterance = 0
            totalTextLength = 0
            
            for pieceOfText in textParagraphs {
                let speechUtterance = AVSpeechUtterance(string: pieceOfText)
                speechUtterance.rate = (rate == nil) ? 1 : rate
                speechUtterance.pitchMultiplier = (pitch == nil) ? 1.0 : pitch
                speechUtterance.volume = volume
                speechUtterance.postUtteranceDelay = 0.005
                
//                if let voiceLanguageCode = preferredVoiceLanguageCode {
                    let voice = AVSpeechSynthesisVoice(language: self.str_SelectedLanguageCode)
                    speechUtterance.voice = voice
//                }
                
                totalTextLength = totalTextLength + pieceOfText.characters.count
                
                if pieceOfText != ""{
                    totalUtterances = totalUtterances + 1
                }
                
                speechSynthesizer.speak(speechUtterance)
                songPlayer.play()
            }
            
            animateActionButtonAppearance(shouldHideSpeakButton: true)
        }
    }
    func sliderChangeSound() {
        speechSynthesizer.stopSpeaking(at: AVSpeechBoundary.immediate)
        speechSynthesizer = AVSpeechSynthesizer()
        speechSynthesizer.delegate = self
        
        let int_Sec = Double(tv_Main.text.count) * GlobalConstants.playerWordPerPlaySecond
        var int_Sec_Sub = (Double(slider_Main.value * 100) * int_Sec) / 100
        
        var textParagraphs = tv_Main.text.components(separatedBy: "\n")
        
        // Logic
        let doublePer = (int_Sec_Sub * 100) / int_Sec // Get persentage for start index
        let notGetText = (Double(doublePer) * Double(tv_Main.text.count)) / 100 // start text index
        
        let string1 = tv_Main.text as! String
        let result = String(string1.characters.dropFirst(Int(notGetText)))
        
        textParagraphs =  result.components(separatedBy: "\n")
        spokenTextLengths = Int(notGetText)
        
        totalUtterances = 0
        currentUtterance = 0
        totalTextLength = 0
        
        for pieceOfText in textParagraphs {
            let speechUtterance = AVSpeechUtterance(string: pieceOfText)
            speechUtterance.rate = (rate == nil) ? 1 : rate
            speechUtterance.pitchMultiplier = (pitch == nil) ? 1.0 : pitch
            speechUtterance.volume = volume
            speechUtterance.postUtteranceDelay = 0.005
            
            //                if let voiceLanguageCode = preferredVoiceLanguageCode {
            let voice = AVSpeechSynthesisVoice(language: self.str_SelectedLanguageCode)
            speechUtterance.voice = voice
            //                }
            
            totalTextLength = totalTextLength + pieceOfText.characters.count
            
            if pieceOfText != ""{
                totalUtterances = totalUtterances + 1
            }
            
            speechSynthesizer.speak(speechUtterance)
            songPlayer.play()
        }
        
        animateActionButtonAppearance(shouldHideSpeakButton: true)
    }
    
    
    @IBAction func btn_Sound (_ sender: UIButton){
        if vw_Sound.isHidden == false{
           vw_Sound.isHidden = true
        }else{
            vw_Sound.isHidden = false
        }
    }
    @IBAction func btn_SliderAction(_ sender: MJSlider) {
        print(sender.value)
        
        rate = sender.value
        let defaultSpeechSettings: Dictionary<NSObject, AnyObject> = ["rate" as NSObject: sender.value as AnyObject]
        
        UserDefaults.standard.register(defaults: defaultSpeechSettings as! [String : Any])

        self.sliderChangeSound()
    
    }
    
    
    // MARK: - Get/Post Method -
    func Post_GetTraslation(str_Id : String){
        
        //Declaration URL
        var strURL = "\(GlobalConstants.BaseURL)translate"
        
        if obj_Player.str_Lib_PassType == "note"{
            strURL = "\(GlobalConstants.BaseURL)usernote_translate"
        }
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "library_id" : obj_Get.str_Lib_Id,
            "iso_code" :str_Id,
        ]
        
        if obj_Player.str_Lib_PassType == "note"{
            jsonData = [
                "note_id" : obj_Get.str_Lib_Id,
                "iso_code" :str_Id,
            ]
        }
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "translate"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.startDownload()
    }
    func Post_UpdateLibraryStatus(progressValue : String,status : String,serviceCall : String){
        
        //--Nubmer of Flag--
        //Just Created
        //Continue Reading
        //In Progress
        //Completed
        
        //User Flag 1. Continue Reading 2. Completed
        
        //Declaration URL
        var strURL = "\(GlobalConstants.BaseURL)update_library_status/\(obj_Get.str_Lib_Id)"
        if str_TypePlay == "note"{
            strURL = "\(GlobalConstants.BaseURL)update_user_lib_note/\(obj_Get.str_Lib_Id)"
        }
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "status" : status,
            "progress" :progressValue,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = serviceCall
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.startDownload()
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}


extension PlayerViewController : AVSpeechSynthesizerDelegate{
    // MARK: AVSpeechSynthesizerDelegate method implementation
    
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        spokenTextLengths = spokenTextLengths + utterance.speechString.characters.count + 1
        
        if currentUtterance == totalUtterances {
            songPlayer.stop()
            MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
            
            animateActionButtonAppearance(shouldHideSpeakButton: false)
            
            unselectLastWord()
            previousSelectedRange = nil
            
//            if bool_Close == false{
                slider_Main.value = 0.0
                bool_Close = true
                if bool_Appear == false{
                    self.Post_UpdateLibraryStatus(progressValue: "1", status: "Completed",serviceCall: "update_library3")
                }else{
                    self.Post_UpdateLibraryStatus(progressValue: "1", status: "Completed",serviceCall: "update_library")
                }
//            }
        }
    }
    
    
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didStart utterance: AVSpeechUtterance) {
        utterance.rate = (rate == nil) ? 1 : rate
        currentUtterance = currentUtterance + 1
    }
    
    
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, willSpeakRangeOfSpeechString characterRange: NSRange, utterance: AVSpeechUtterance) {
        utterance.rate = (rate == nil) ? 1 : rate
        
        tv_Main.textColor = UIColor.black
        
        let progress: Float = Float(spokenTextLengths + characterRange.location) * 100 / Float(tv_Main.text.count)
        slider_Main.value = progress / 100
        
        // Determine the current range in the whole text (all utterances), not just the current one.
        //        let rangeInTotalText = NSMakeRange(spokenTextLengths + characterRange.location, characterRange.length)
        let rangeInTotalText = NSMakeRange(spokenTextLengths + characterRange.location, characterRange.length)
        
        // Select the specified range in the textfield.
        tv_Main.selectedRange = rangeInTotalText
        
        if rangeInTotalText.location + rangeInTotalText.length <  tv_Main.text.count{

            // Store temporarily the current font attribute of the selected text.
            let currentAttributes = tv_Main.attributedText.attributes(at: rangeInTotalText.location, effectiveRange: nil)
            let fontAttribute: AnyObject? = currentAttributes[NSAttributedStringKey.font] as AnyObject
        
            // Assign the selected text to a mutable attributed string.
            let attributedString = NSMutableAttributedString(string: tv_Main.attributedText.attributedSubstring(from: rangeInTotalText).string)
            
            // Make the text of the selected area orange by specifying a new attribute.
            attributedString.addAttribute(NSAttributedStringKey.foregroundColor, value: UIColor.orange, range: NSMakeRange(0, attributedString.length))
            
            // Make sure that the text will keep the original font by setting it as an attribute.
            attributedString.addAttribute(NSAttributedStringKey.font, value: fontAttribute!, range: NSMakeRange(0, attributedString.string.characters.count))
            
            // In case the selected word is not visible scroll a bit to fix this.
            tv_Main.scrollRangeToVisible(rangeInTotalText)
            
            // Begin editing the text storage.
            tv_Main.textStorage.beginEditing()
            
            let string1 = tv_Main.text as! String
            let result = String(string1.characters.dropFirst(Int(rangeInTotalText.location)))
            let arr_Space = result.components(separatedBy: " ")
            if arr_Space.count != 0{
                lbl_TextShow.text = arr_Space[0] as! String
            }
            
            tv_Main.textStorage.replaceCharacters(in: rangeInTotalText, with: attributedString)
            
            // If there was another highlighted word previously (orange text color), then do exactly the same things as above and change the foreground color to black.
            if let previousRange = previousSelectedRange {
                if (previousRange.location + previousRange.length) < tv_Main.text.count{
                    do {
                        print(tv_Main.attributedText.attributedSubstring(from: previousRange))
                        print(tv_Main.attributedText.attributedSubstring(from: previousRange).string)
                        
                        let previousAttributedText = NSMutableAttributedString(string: tv_Main.attributedText.attributedSubstring(from: previousRange).string)
                        previousAttributedText.addAttribute(NSAttributedStringKey.foregroundColor, value: UIColor.black, range: NSMakeRange(0, previousAttributedText.length))
                        previousAttributedText.addAttribute(NSAttributedStringKey.font, value: fontAttribute!, range: NSMakeRange(0, previousAttributedText.length))
                        
                        tv_Main.textStorage.replaceCharacters(in: previousRange, with: previousAttributedText)
                        
                    } catch {
                       print("crash")
                    }
                }
            }
            
            // End editing the text storage.
            tv_Main.textStorage.endEditing()
            
            // Keep the currently selected range so as to remove the orange text color next.
            previousSelectedRange = rangeInTotalText
            
            self.manageTimerSetting()
        }
    }
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
            return false
    }
}



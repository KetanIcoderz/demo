//
//  ProfileViewViewController.swift
//  iAudioo
//
//  Created by Apple on 06/06/18.
//  Copyright © 2018 iAudioo. All rights reserved.
//

import UIKit

class ProfileViewViewController: UIViewController,UINavigationControllerDelegate {

    @IBOutlet weak var img_SelectPhoto: UIImageView!
    
    @IBOutlet weak var lbl_UserName: UILabel!
    @IBOutlet weak var lbl_Subscription: UILabel!
    @IBOutlet weak var lbl_SubscriptionState: UILabel!
    @IBOutlet weak var lbl_Subscription2: UILabel!
    @IBOutlet weak var lbl_SubscriptionState2: UILabel!
    
    @IBOutlet weak var vw_Bottom: UIView!
    
     @IBOutlet weak var con_Month: NSLayoutConstraint!
    
    //Comman Declaration
    var isValidEmail : Bool = false
    let picker = UIImagePickerController()
    var isEditMode : Bool = false
    var isImage :Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        lbl_UserName.text = objUser?.user_Name
        img_SelectPhoto.sd_setImage(with: URL(string: (objUser?.user_Profile_image)!), placeholderImage: UIImage(named:"img_Demo"))
        
        NotificationCenter.default.removeObserver("reloadSubscription2")
        NotificationCenter.default.addObserver(self, selector: #selector(commanMethod), name: NSNotification.Name(rawValue: "reloadSubscription2"), object: nil)
    }
    override func viewWillAppear(_ animated: Bool) {
        self.commanMethod()
    }
    
    override func viewWillLayoutSubviews() {
        self.img_SelectPhoto.layer.cornerRadius = self.img_SelectPhoto.frame.size.height/2
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARk: - Other Files -
    @objc func commanMethod(){
        
        
        var bool_Purchase : Bool = false
        var bool_Purchase2 : Bool = false
        for i in 0..<arr_Subscription.count{
            let objSub = arr_Subscription[i] as! GlobalObject
            
            if objSub.str_Sub_Type == "com.houstonmitchell.iaudioo1" && objSub.str_Sub_Active == "1"{
                bool_Purchase = true
            }else if objSub.str_Sub_Type == "com.houstonmitchell.iaudioo2" && objSub.str_Sub_Active == "1"{
                bool_Purchase2 = true
            }
            
        }
        
        con_Month.constant = 50
        
        if bool_Purchase == false && bool_Purchase2 == false {
            lbl_Subscription.text = "Subscription $4.99 a month"
            lbl_SubscriptionState.text = "Subscribe Now"
        }else{
            if bool_Purchase2 == true{
                con_Month.constant = 0
            }
            lbl_Subscription.text = "Subscription $4.99 a month"
            lbl_SubscriptionState.text = "Paid"
        }
        
        if bool_Purchase2 == false{
            lbl_Subscription2.text = "Subscription $47.99 a year"
            lbl_SubscriptionState2.text = "Subscribe Now"
        }else{
            lbl_Subscription2.text = "Subscription $47.99 a year"
            lbl_SubscriptionState2.text = "Paid"
        }
    }
    
    //MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btn_Purchase(_ sender: Any) {
        if lbl_SubscriptionState.text == "Subscribe Now"{
             IAPHandler.shared.purchaseMyProduct(index: 0)
        }
    }
    @IBAction func btn_Purchase2(_ sender: Any) {
        if lbl_SubscriptionState.text == "Subscribe Now"{
            IAPHandler.shared.purchaseMyProduct(index: 1)
        }
    }
    
    @IBAction func btn_Save(_ sender: Any) {
        self.Post_UpdateProfile()
    }
    
    @IBAction func btn_SelectPhoto(_ sender:Any) {
        let alert = UIAlertController(title: GlobalConstants.appName, message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: UIAlertActionStyle.default, handler: { (action) in
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera)
            {
                self.picker.sourceType = .camera
                self.picker.allowsEditing = true
                self.picker.delegate = self
                self.present(self.picker, animated: true, completion: nil)
            }
        }))
        alert.addAction(UIAlertAction(title: "Gallery", style: UIAlertActionStyle.default, handler: { (action) in
            self.picker.allowsEditing = true
            self.picker.sourceType = .photoLibrary
            self.picker.delegate = self
            self.present(self.picker, animated: true, completion: nil)
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    
    // MARK: - Get/Post Method -
    func Post_UpdateProfile(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)update_profile_image"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "update_profile_image"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = true
        webHelper.imageUpload = (isImage == true) ? (img_SelectPhoto.image) : (UIImage())
        webHelper.imageUploadName = "profile_image"
        webHelper.startDownloadWithImage()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension ProfileViewViewController : UIImagePickerControllerDelegate{
    //MARK: - Imagepicker Delegates
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        let chosenImage = info[UIImagePickerControllerEditedImage] as! UIImage
        isImage = true
        img_SelectPhoto.image = chosenImage
        vw_Bottom.isHidden = false
        dismiss(animated:true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}



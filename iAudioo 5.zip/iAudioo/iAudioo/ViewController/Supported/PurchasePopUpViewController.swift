//
//  PurchasePopUpViewController.swift
//  iAudioo
//
//  Created by Apple on 27/04/18.
//  Copyright © 2018 iAudioo. All rights reserved.

import UIKit

class PurchasePopUpViewController: UIViewController {

    @IBOutlet weak var lbl_Opps: UILabel!
    @IBOutlet weak var lbl_OppsDetail: UILabel!
    @IBOutlet weak var lbl_MothTitle: UILabel!
    @IBOutlet weak var lbl_PurchaseTitle: UILabel!
    
    @IBOutlet weak var btn_Month: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    // MARK: - Other Files -
    func commanMethod(){
        
        btn_Month.titleLabel?.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 16))
        
        lbl_Opps.font =  UIFont(name: GlobalConstants.kFontLight, size: manageFontHeight(font: 30))
        lbl_OppsDetail.font =  UIFont(name: GlobalConstants.kFontLight, size: manageFontHeight(font: 18))
        lbl_MothTitle.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 13))
        lbl_PurchaseTitle.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 16))
        
    }
    
    
    // MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any){
        self.dismiss(animated: true) {
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  SubscriptionListViewController.swift
//  iAudioo
//
//  Created by Apple on 30/04/18.
//  Copyright © 2018 iAudioo. All rights reserved.

import UIKit
import SwiftyReceiptValidator


class SubscriptionListViewController: UIViewController {

    @IBOutlet weak var tbl_Main : UITableView!
    
    @IBOutlet weak var btn_Subscription : UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.removeObserver("reloadSubscription")
        NotificationCenter.default.addObserver(self, selector: #selector(reloadData), name: NSNotification.Name(rawValue: "reloadSubscription"), object: nil)
        // Do any additional setup after loading the view.
        
        if str_SubscriptionLink == ""{
            btn_Subscription.isHidden = true
        }else{
            btn_Subscription.isHidden = false
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
        
        self.navigationController!.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
        self.navigationController!.navigationBar.setBackgroundImage(imageWithColor(with:GlobalConstants.appColor), for: .default)
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
        
        self.navigationController!.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.black]
        self.navigationController!.navigationBar.setBackgroundImage(imageWithColor(with:UIColor.white), for: .default)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    //MARk: - Other Files -
    func commanMethod(){
        
    }
    @objc func reloadData(){
        //load data here
        self.tbl_Main.reloadData()
    }
    
    
    //MARK: - Button Event -
    @IBAction func btn_Back(_ sender:Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btn_Purchase1Month(_ sender: Any) {
        IAPHandler.shared.purchaseMyProduct(index: 0)
    }
    @IBAction func btn_Purchase2Month(_ sender: Any) {
        IAPHandler.shared.purchaseMyProduct(index: 1)
    }
    
    @IBAction func btn_PurchaseFree(_ sender : Any){
        
    }
    @IBAction func btn_Subscription(_ sender : Any){
        guard let url = URL(string: str_SubscriptionLink) else {
            return //be safe
        }
        
        if #available(iOS 10.0, *) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        } else {
            UIApplication.shared.openURL(url)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}


// MARK: - Tableview Cell -
class SubcriptionTablecell: UITableViewCell {
    // MARK: - Table Cell -
    @IBOutlet var lbl_Title: UILabel!
    @IBOutlet var lbl_Description: UILabel!
    
    @IBOutlet var btn_Click: UIButton!
}


// MARK: - Tableview Delegate -

extension SubscriptionListViewController : UITableViewDataSource,UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        //Hide month tab when already purchase for year subscription
        if indexPath.row == 1{
            var bool_Purchase : Bool = false
            for i in 0..<arr_Subscription.count{
                let objSub = arr_Subscription[i] as! GlobalObject
                
                if objSub.str_Sub_Type == "com.houstonmitchell.iaudioo2" && objSub.str_Sub_Active == "1"{
                    bool_Purchase = true
                }
            }
            
            if bool_Purchase == true{
                return 0
            }
        }
        if str_SubscriptionLink == ""{
            return CGFloat(GlobalConstants.windowHeight * 0.2848575712)
        }else{
             return CGFloat(GlobalConstants.windowHeight * 0.26)
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var str_Identifier : String = "cell"
        
        if indexPath.row == 1{
            str_Identifier = "cell2"
        }else  if indexPath.row == 2{
            str_Identifier = "cell3"
        }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: str_Identifier, for:indexPath as IndexPath) as! SubcriptionTablecell
        
     
            
        cell.lbl_Title.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 25))
        cell.lbl_Description.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 14))
       
        cell.btn_Click.tag = indexPath.row
        cell.btn_Click.titleLabel?.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 15))
        

        var bool_Purchase : Bool = false
        if indexPath.row == 0{
            cell.btn_Click.addTarget(self, action: #selector(btn_PurchaseFree(_:)), for: UIControlEvents.touchUpInside)
            
            for i in 0..<arr_Subscription.count{
                let objSub = arr_Subscription[i] as! GlobalObject
                
                if objSub.str_Sub_Type == "com.houstonmitchell.iaudioo1" && objSub.str_Sub_Active == "1"{
                    bool_Purchase = true
                }else if objSub.str_Sub_Type == "com.houstonmitchell.iaudioo2" && objSub.str_Sub_Active == "1"{
                    bool_Purchase = true
                }
            }
            
            cell.btn_Click .setTitle("Active", for: UIControlState.normal)
            cell.btn_Click.backgroundColor = UIColor.red
          
        }else if indexPath.row == 1{
            
            for i in 0..<arr_Subscription.count{
                let objSub = arr_Subscription[i] as! GlobalObject
                
                if objSub.str_Sub_Type == "com.houstonmitchell.iaudioo1" && objSub.str_Sub_Active == "1"{
                    bool_Purchase = true
                }else if objSub.str_Sub_Type == "com.houstonmitchell.iaudioo2" && objSub.str_Sub_Active == "1"{
                    bool_Purchase = true
                }
            }
            
            if bool_Purchase == true{
                cell.btn_Click .setTitle("Active", for: UIControlState.normal)
                cell.btn_Click.backgroundColor = UIColor.red
            }else{
                cell.btn_Click.addTarget(self, action: #selector(btn_Purchase1Month(_:)), for: UIControlEvents.touchUpInside)

                cell.btn_Click .setTitle("Subscribe", for: UIControlState.normal)
                cell.btn_Click.backgroundColor = GlobalConstants.appColor
            }
        }else if indexPath.row == 2{
            
            for i in 0..<arr_Subscription.count{
                let objSub = arr_Subscription[i] as! GlobalObject
                
                if objSub.str_Sub_Type == "com.houstonmitchell.iaudioo2" && objSub.str_Sub_Active == "1"{
                    bool_Purchase = true
                }
            }
            
            if bool_Purchase == true{
                cell.btn_Click .setTitle("Active", for: UIControlState.normal)
                cell.btn_Click.backgroundColor = UIColor.red
            }else{
                cell.btn_Click.addTarget(self, action: #selector(btn_Purchase2Month(_:)), for: UIControlEvents.touchUpInside)

                cell.btn_Click .setTitle("Subscribe", for: UIControlState.normal)
                cell.btn_Click.backgroundColor = GlobalConstants.appColor
            }
        }
        
       
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
    }
}






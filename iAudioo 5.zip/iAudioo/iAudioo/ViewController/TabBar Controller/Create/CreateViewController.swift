//
//  CreateViewController.swift
//  iAudioo
//
//  Created by Apple on 20/04/18.
//  Copyright © 2018 iAudioo. All rights reserved.

import UIKit
import DKImagePickerController
import Photos
import AVFoundation
import FileProvider
import UIKit
import SwiftMessages

class CreateViewController: UIViewController, DismissCameraPickerDelegate {

    @IBOutlet weak var lbl_TakeAPhoto: UILabel!
    @IBOutlet weak var lbl_CameraRoll: UILabel!
    @IBOutlet weak var lbl_Files: UILabel!
    @IBOutlet weak var lbl_CopyText: UILabel!

    //Ad Module
    @IBOutlet weak var con_Ads: NSLayoutConstraint!
    @IBOutlet weak var img_Ads: UIImageView!
    
    var objAssest: [DKAsset]?
    
    var arr_Get : NSMutableArray = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.commanMethod()
        str_PresentView = "2"

        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0, execute: {
            if deviceIdentifier() == "iPhone X"{
                GlobalConstants.appDelegate?.googleBannerAds(view: self,constant : self.con_Ads,frame : CGRect(x: 0, y: Int(self.img_Ads.frame.origin.y), width: Int(GlobalConstants.windowWidth), height: 50))
            }else{
                GlobalConstants.appDelegate?.googleBannerAds(view: self,constant : self.con_Ads,frame : CGRect(x: 0, y: Int(self.img_Ads.frame.origin.y), width: Int(GlobalConstants.windowWidth), height: 50))
            }
        })
        
        NotificationCenter.default.removeObserver("reloadAds2")
        NotificationCenter.default.addObserver(self, selector: #selector(reloadData), name: NSNotification.Name(rawValue: "reloadAds2"), object: nil)
        
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        
        if str_PickerText != ""{
            self.Post_Addvalue(type: "document", value : [])
            str_PickerText = ""
        }
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Delegate method for capture image -
    func CaptureImagesOption(arr: NSMutableArray){
        arr_Get = arr
        self.Post_Addvalue(type:"camera",value : [])
    }

    // MARK: - Other Files -
    func commanMethod(){
        
        lbl_TakeAPhoto.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 16))
        lbl_CameraRoll.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 16))
        lbl_Files.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 16))
        lbl_CopyText.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 16))
    }
    @objc func reloadData(){
        if deviceIdentifier() == "iPhone X"{
            GlobalConstants.appDelegate?.googleBannerAds(view: self,constant : con_Ads,frame : CGRect(x: 0, y: Int(img_Ads.frame.origin.y), width: Int(GlobalConstants.windowWidth), height: 50))
        }else{
            GlobalConstants.appDelegate?.googleBannerAds(view: self,constant : con_Ads,frame : CGRect(x: 0, y: Int(img_Ads.frame.origin.y), width: Int(GlobalConstants.windowWidth), height: 50))
        }
    }
    
    func openGallery(){
        let pickerController = DKImagePickerController()
        pickerController.sourceType = .photo
        pickerController.maxSelectableCount = 10
        
        pickerController.didSelectAssets = { (assets: [DKAsset]) in

            self.objAssest = assets
            
             let arr_Data : NSMutableArray = []
            if assets.count != 0 {
                var int_Count = 0
                var str_String : String = ""
                for each in self.objAssest!{
                    each.fetchOriginalImageWithCompleteBlock({ (image, info) in
                        var binaryImageData: String = self.base64EncodeImage(image!)
                        
                        //Save data in dictionary
                        let dict_Store : NSDictionary = [
                            "text" : binaryImageData,
                            ]
                        arr_Data.add(dict_Store)
 
                        if int_Count + 1 == self.objAssest!.count{
                            self.Post_Addvalue(type:"image",value : arr_Data)
                        }else{
                            int_Count = int_Count + 1
                        }
                    })
                }
            }
        }
        self.present(pickerController, animated: false) {}
    }

    func takeVideo(){
        let view = self.storyboard?.instantiateViewController(withIdentifier: "CameraPickerViewController") as! CameraPickerViewController
        view.delegate = self
        present(view, animated: true)
    }
    
    func permissionForGallery(){
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let view = storyboard.instantiateViewController(withIdentifier: "GotoSettingPageViewController") as! GotoSettingPageViewController
        view.str_TypeofValidation = "photo"
        self.present(view, animated: true, completion: nil)
    }
    func permissionForMicroPhone(){
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let view = storyboard.instantiateViewController(withIdentifier: "GotoSettingPageViewController") as! GotoSettingPageViewController
        view.str_TypeofValidation = "microPhone"
        self.present(view, animated: true, completion: nil)
    }
    func permissionForVideo(){
        let when = DispatchTime.now() + 1
        DispatchQueue.main.asyncAfter(deadline: when) {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let view = storyboard.instantiateViewController(withIdentifier: "GotoSettingPageViewController") as! GotoSettingPageViewController
            view.str_TypeofValidation = "video"
            self.present(view, animated: true, completion: nil)
        }
    }
    // MARK: - OCR Method -
    func base64EncodeImage(_ image: UIImage) -> String {
        var image = image
        
        if var imagedata = image.jpeg(.lowest) {
//            var imagedata: NSData? = UIImagePNGRepresentation(image) as NSData?
            
            // Resize the image if it exceeds the 2MB API limit
            if imagedata.count as! Int > 2097152 {
                let oldSize: CGSize = image.size
                imagedata = UIImagePNGRepresentation(image) as? NSData as! Data
            }
            
            let base64String = imagedata.base64EncodedString(options: .endLineWithCarriageReturn)
            return base64String ?? ""
        }
        
       return ""
    }
    func resize(_ image: UIImage, to newSize: CGSize) -> UIImage {
        UIGraphicsBeginImageContext(newSize)
        image.draw(in: CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height))
        let newImage: UIImage? = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage ?? UIImage()
    }
    
    //MARK: - Button Event -
    @IBAction func btn_NavLeft(_ sender:Any) {
        sideMenuController?.showLeftView(animated: true, completionHandler: nil)
    }
    @IBAction func btn_CameraRoll(_ sender: Any) {
        // Get the current authorization state.
        let status = PHPhotoLibrary.authorizationStatus()
        
        if (status == PHAuthorizationStatus.authorized) {
            // Access has been granted.
            self.openGallery()
            
        }else if (status == PHAuthorizationStatus.denied) {
            
            self.permissionForGallery()
        }else if (status == PHAuthorizationStatus.notDetermined) {
            
            // Access has not been determined.
            PHPhotoLibrary.requestAuthorization({ (newStatus) in
                
                if (newStatus == PHAuthorizationStatus.authorized) {
                    self.openGallery()
                }
            })
        }
        else if (status == PHAuthorizationStatus.restricted) {
            self.openGallery()
        }
    }
    @IBAction func btn_TakeAPhoto(_ sender:Any) {
        //Get authanitication for video
        if AVCaptureDevice.authorizationStatus(for: AVMediaType.video) ==  AVAuthorizationStatus.authorized {
            
            //Microphone Accepted or not
            if AVCaptureDevice.authorizationStatus(for: AVMediaType.audio) ==  AVAuthorizationStatus.authorized {
                self.takeVideo()
            } else {
                AVCaptureDevice.requestAccess(for: AVMediaType.audio, completionHandler: { (granted: Bool) -> Void in
                    if granted == true {
                        // User granted
                        self.takeVideo()
                    } else {
                        self.permissionForMicroPhone()
                    }
                })
            }
        } else {
            AVCaptureDevice.requestAccess(for: AVMediaType.video, completionHandler: { (granted: Bool) -> Void in
                if granted == true {
                    
                    //Microphone Accepted or not
                    if AVCaptureDevice.authorizationStatus(for: AVMediaType.audio) ==  AVAuthorizationStatus.authorized {
                        self.takeVideo()
                    } else {
                        AVCaptureDevice.requestAccess(for: AVMediaType.audio, completionHandler: { (granted: Bool) -> Void in
                            if granted == true {
                                // User granted
                                self.takeVideo()
                            } else {
                                self.permissionForMicroPhone()
                            }
                        })
                    }
                }else{
                    self.permissionForVideo()
                }
            })
        }
    }
    @IBAction func btn_Files(_ sender:Any) {
        if #available(iOS 11.0, *) {
            self.navigationController?.isNavigationBarHidden = true
            let view = DocumentBrowserViewController(forOpeningFilesWithContentTypes: ["public.plain-text"])
            present(view, animated: true)
//            self.navigationController?.pushViewController(view, animated: true)
        } else {
            // Fallback on earlier versions
        }
    }
    @IBAction func btn_CopyText(_ sender:Any) {

        let pasteboardString: String? = UIPasteboard.general.string
        if let theString = pasteboardString {
            
            self.Post_Addvalue(type: "copy", value : [])
        }else{
            messageBar.MessageShow(title: "No text copy", alertType: MessageView.Layout.cardView, alertTheme: .error, TopBottom: true)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
 
    // MARK: - Get/Post Method -
    func Post_Addvalue(type : String,value : NSMutableArray){
        
        var arr_Data : NSMutableArray = []
        
        if type == "image"{
            arr_Data = value
        }else if type == "copy"{
            let pasteboardString: String? = UIPasteboard.general.string
            if let theString = pasteboardString {
                
                //Save data in dictionary
                let dict_Store : NSDictionary = [
                    "text" : theString,
                    ]
                arr_Data.add(dict_Store)
            }
        }else if type == "camera"{
            for i in 0..<arr_Get.count{
                var image : UIImage = arr_Get[i] as! UIImage
                
                var binaryImageData: String = self.base64EncodeImage(image)
                
                //Save data in dictionary
                let dict_Store : NSDictionary = [
                    "text" : binaryImageData,
                    ]
                arr_Data.add(dict_Store)
                
            }
        }else if type == "document"{
            //Save data in dictionary
            let dict_Store : NSDictionary = [
                "text" : str_PickerText,
                ]
            arr_Data.add(dict_Store)
        }
        
        //Convert array in string
        let string = notPrettyString(from : arr_Data)
        
        //Sevice calling
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)add_library"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "text" : string,
            "type" : type,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "add_library"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = true
        webHelper.showLogForCallingAPI = false
        webHelper.startDownload()
    }
    
}

extension UIImage {
    enum JPEGQuality: CGFloat {
        case lowest  = 0
        case low     = 0.25
        case medium  = 0.5
        case high    = 0.75
        case highest = 1
    }
    
    /// Returns the data for the specified image in JPEG format.
    /// If the image object’s underlying image data has been purged, calling this function forces that data to be reloaded into memory.
    /// - returns: A data object containing the JPEG data, or nil if there was a problem generating the data. This function may return nil if the image has no data or if the underlying CGImageRef contains data in an unsupported bitmap format.
    func jpeg(_ quality: JPEGQuality) -> Data? {
        return UIImageJPEGRepresentation(self, quality.rawValue)
    }
}



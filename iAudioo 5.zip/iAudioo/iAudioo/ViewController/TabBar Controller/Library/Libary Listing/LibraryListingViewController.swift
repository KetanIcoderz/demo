//
//  LibraryListingViewController.swift
//  iAudioo
//
//  Created by Apple on 25/05/18.
//  Copyright © 2018 iAudioo. All rights reserved.

import UIKit
import PopOverMenu
import SDWebImage
import EmptyDataSet_Swift

class LibraryListingViewController: UIViewController, UINavigationControllerDelegate {

    @IBOutlet weak var tbl_Main: UITableView!
    
    var arr_Main : NSMutableArray = []
    
    var obj_Main = GlobalObject()
    
    //Comman Declaration
    var isValidEmail : Bool = false
    let picker = UIImagePickerController()
    var isEditMode : Bool = false
    var isImage :Bool = false
    
    var bool_Load: Bool = false
    
    var objMore = GlobalObject()
    
    var indexSave = NSIndexPath(row: -1, section: 0)
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tbl_Main.emptyDataSetSource = self
        tbl_Main.emptyDataSetDelegate = self
        // Do any additional setup after loading the view.
        
        NotificationCenter.default.removeObserver("librayreload")
        NotificationCenter.default.addObserver(self, selector: #selector(librayreload), name: NSNotification.Name(rawValue: "librayreload"), object: nil)
        
        NotificationCenter.default.removeObserver("librayreloadtableview")
        NotificationCenter.default.addObserver(self, selector: #selector(librayreloadtableview), name: NSNotification.Name(rawValue: "librayreloadtableview"), object: nil)
    }

    override func viewWillAppear(_ animated: Bool) {
        
        if str_PresentView == "1"{
            self.Get_ListLibrary()
        }
        
        //Addpresent
        if indexSave.row != -1{
            self.tableView(tbl_Main, didSelectRowAt: indexSave as IndexPath)
            indexSave = NSIndexPath(row: -1, section: 0)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - Other Method -
    func commanMethod(){
    }
    @objc func librayreload(){
        self.Get_ListLibrary()
    }
    @objc func librayreloadtableview(){
        if vw_TabBarController?.popupBar.isHidden == false && obj_Player.str_Lib_PassType == "lib"{
            
            //Find cell is available or not
            var boolGet : Bool = false
            let nSections: Int = tbl_Main.numberOfSections
            for j in 0..<nSections {
                let nRows: Int = tbl_Main.numberOfRows(inSection: j)
                if j == 0 && nRows == 1{
                    boolGet = true
                }
            }

            //iF cell is not availble then reload other wise only reload with cell
            if boolGet == false{
                self.tbl_Main.reloadData()
            }else{
                let indexPath = IndexPath(item: 0, section: 0)
                if let visibleIndexPaths = tbl_Main.indexPathsForVisibleRows?.index(of: indexPath as IndexPath) {
                    if visibleIndexPaths != NSNotFound {
                        Progress_Save.progress = Float(obj_Player.str_Lib_Progress)!
                    }
                }
            }
        }
    }
    
    func moreOption(index : NSIndexPath,tag : Int){
        
        objMore = GlobalObject()
        
        switch index.section {
        case 1:
            objMore = obj_Main.arr_JustCreated[tag] as! GlobalObject
            break
        case 2:
            objMore = obj_Main.arr_ContinueReading[tag] as! GlobalObject
            break
        case 3:
            objMore = obj_Main.arr_InProgress[tag] as! GlobalObject
            break
        case 4:
            objMore = obj_Main.arr_Completed[tag] as! GlobalObject
            break
        default:
            break
        }
        
        let rectOfCell = tbl_Main.rectForRow(at: index as IndexPath)
        let rectOfCellInSuperview = tbl_Main.convert(rectOfCell, to: tbl_Main.superview)
        let frameGet : CGRect = CGRect(x: rectOfCellInSuperview.origin.x + rectOfCellInSuperview.size.width - (rectOfCellInSuperview.size.width * 0.06), y: rectOfCellInSuperview.origin.y + (rectOfCellInSuperview.size.height * 0.70), width: 1, height: 1)
        
        let ArrayTemp  : NSArray = ["Rename File","Add Note","Delete","Edit Picture","Edit Library"]
        let titles:Array<String> = ArrayTemp as NSArray as! [String]
        
        for var view in self.view.subviews{
            if view.tag == 1000{
                view.removeFromSuperview()
            }
        }
        
        var view = UIView()
        view.frame  = frameGet
        view.tag = 1000
        self.view.addSubview(view)
        view.isHidden = true
        
        //Custome popup show
        let popOverViewController = PopOverViewController.instantiate()
        popOverViewController.setTitles(titles)
        popOverViewController.preferredContentSize = CGSize(width: 200, height:Int(225))
        popOverViewController.presentationController?.delegate = self
        popOverViewController.popoverPresentationController?.sourceView = view
        popOverViewController.completionHandler = { selectRow in
            if selectRow == 1{
                let view = self.storyboard?.instantiateViewController(withIdentifier: "AddNoteViewController") as! AddNoteViewController
                view.str_EventId = self.objMore.str_Lib_Id
                vw_TabBarController?.navigationController?.pushViewController(view, animated: true)
            }else if selectRow == 2{
                let alert = UIAlertController(title: GlobalConstants.appName, message: "Are you sure you want delete this file?", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Delete", style: UIAlertActionStyle.default, handler: { (action) in
                    
                    self.Post_DeleteIndex(index: self.objMore.str_Lib_Id)
                }))
                alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }else if selectRow == 0{
                let alert = UIAlertController(title: "Rename Book", message: nil, preferredStyle: UIAlertControllerStyle.alert)
                
                alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.default, handler: nil))
                
                let action = UIAlertAction(title: "OK", style: .default) { (alertAction) in
                    let textField = alert.textFields![0] as UITextField
                    
                    if textField.text != ""{
                        self.Post_RenameIndex(index: self.objMore.str_Lib_Id,title: textField.text!)
                    }
                }
                alert.addTextField { (textField) in
                    textField.placeholder = "Rename Book"
                    textField.text = self.objMore.str_Lib_Title
                }
                alert.addAction(action)
                
                self.present(alert, animated: true, completion: nil)
            }else if selectRow == 3{
                
                let alert = UIAlertController(title: GlobalConstants.appName, message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
                alert.addAction(UIAlertAction(title: "Camera", style: UIAlertActionStyle.default, handler: { (action) in
                    if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera)
                    {
                        self.picker.sourceType = .camera
                        self.picker.allowsEditing = true
                        self.picker.delegate = self
                        self.present(self.picker, animated: true, completion: nil)
                    }
                }))
                alert.addAction(UIAlertAction(title: "Gallery", style: UIAlertActionStyle.default, handler: { (action) in
                    self.picker.allowsEditing = true
                    self.picker.sourceType = .photoLibrary
                    self.picker.delegate = self
                    self.present(self.picker, animated: true, completion: nil)
                }))
                
                alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }else if selectRow == 4{
                var obj = GlobalObject()
                
                switch index.section {
                case 0:
                    obj = obj_Player
                    break
                case 1:
                    obj = self.obj_Main.arr_JustCreated[index.row] as! GlobalObject
                    break
                case 2:
                    obj = self.obj_Main.arr_ContinueReading[index.row] as! GlobalObject
                    break
                case 3:
                    obj = self.obj_Main.arr_InProgress[index.row] as! GlobalObject
                    break
                case 4:
                    obj = self.obj_Main.arr_Completed[index.row] as! GlobalObject
                    break
                default:
                    break
                }
                
                let view = self.storyboard?.instantiateViewController(withIdentifier: "AddNoteViewController") as! AddNoteViewController
                view.str_Id = obj.str_Lib_Id
                view.str_Tital = obj.str_Lib_Title
                // view.str_Description = self.obj_Get.str_Lib_Text
                
                view.str_Description = removeNewLineToSpace(str_Value: obj.str_Lib_Text)
                view.str_TypeGoing = "mainedit"
//                view.delegate = self
                vw_TabBarController?.navigationController?.pushViewController(view, animated: true)
            }
        };
        present(popOverViewController, animated: true, completion: nil)
    }
    
    func noteDetail(index : NSIndexPath,tag : Int){
        
        var obj = GlobalObject()
        
        switch index.section {
        case 1:
            obj = obj_Main.arr_JustCreated[tag] as! GlobalObject
            break
        case 2:
            obj = obj_Main.arr_ContinueReading[tag] as! GlobalObject
            break
        case 3:
            obj = obj_Main.arr_InProgress[tag] as! GlobalObject
            break
        case 4:
            obj = obj_Main.arr_Completed[tag] as! GlobalObject
            break
        default:
            break
        }
        
        let view = self.storyboard?.instantiateViewController(withIdentifier: "NoteListingViewController") as! NoteListingViewController
        view.str_LibraryId = obj.str_Lib_Id
        view.str_TitleNav = obj.str_Lib_Title
        self.navigationController?.pushViewController(view, animated: true)
    }
    
    //MARK: - Button Event -
    @IBAction func btn_NavLeft(_ sender:Any) {
        sideMenuController?.showLeftView(animated: true, completionHandler: nil)
    }
    @IBAction func btn_MoreIn(_ sender:Any) {
        let touchPoint = (sender as AnyObject).convert(CGPoint.zero, to: self.tbl_Main)
        var clickedButtonIndexPath = tbl_Main.indexPathForRow(at: touchPoint)
        
        if clickedButtonIndexPath != nil{
            let index : NSIndexPath = NSIndexPath(row: (clickedButtonIndexPath?.row)!, section: (clickedButtonIndexPath?.section)!)
            self.moreOption(index: index, tag: (sender as AnyObject).tag)
        }
    }
   
    @IBAction func btn_Note(_ sender:Any) {
        let touchPoint = (sender as AnyObject).convert(CGPoint.zero, to: self.tbl_Main)
        var clickedButtonIndexPath = tbl_Main.indexPathForRow(at: touchPoint)
        
        let index : NSIndexPath = NSIndexPath(row: (clickedButtonIndexPath?.row)!, section: (clickedButtonIndexPath?.section)!)
        self.noteDetail(index: index, tag: (sender as AnyObject).tag)
    }

    
    
    // MARK: - Get/Post Method -
    func Get_ListLibrary(){
        
        bool_Load = true
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)list_libraries"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "list_libraries"
        webHelper.methodType = "get"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.startDownload()
    }
    
    func Post_DeleteIndex(index : String){
        
        bool_Load = true
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)delete_library/\(index)"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "delete_library"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.startDownload()
        
    }
    
    func Post_RenameIndex(index : String,title : String){
        
        bool_Load = true
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)library/\(index)/update_title"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()
        jsonData = [
            "title" : title,
        ]
        
        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "update_title"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.startDownload()
        
    }
    
    func Post_PictureCell(index : String,image : UIImage){
        
        bool_Load = true
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)library/\(index)/update_image"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()

        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "update_image"
        webHelper.methodType = "post"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.imageUpload = image
        webHelper.imageUploadName = "image"
        webHelper.startDownloadWithImage()
        
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}


extension LibraryListingViewController : UIAdaptivePresentationControllerDelegate{
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        return UIModalPresentationStyle.none
    }
    
    func adaptivePresentationStyle(for controller: UIPresentationController, traitCollection: UITraitCollection) -> UIModalPresentationStyle {
        return UIModalPresentationStyle.none
    }
}



// MARK: - Tableview Cell -
class CollectionsTablecell: UITableViewCell {
    // MARK: - Table Cell -
    @IBOutlet var lbl_Title: UILabel!
    @IBOutlet var lbl_NumberOfNot: UILabel!
    @IBOutlet var lbl_ReaminingTime: UILabel!
    @IBOutlet var lbl_FinishedTitle: UILabel!
    
    @IBOutlet var Progress_Main: UIProgressView!
    
    @IBOutlet var img_Icon: UIImageView!
    
    @IBOutlet var btn_More: UIButton!
    
    @IBOutlet var btn_Note: UIButton!
}


// MARK: - Tableview Delegate -
extension LibraryListingViewController : UITableViewDataSource,UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            if vw_TabBarController?.popupBar.isHidden == false && obj_Player.str_Lib_PassType == "lib"{
                return 1
            }
            return 0
        case 1:
            return obj_Main.arr_JustCreated.count
        case 2:
            return obj_Main.arr_ContinueReading.count
        case 3:
            return obj_Main.arr_InProgress.count
        case 4:
            return obj_Main.arr_Completed.count
        default:
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        switch section {
        case 0:
             if vw_TabBarController?.popupBar.isHidden == false && obj_Player.str_Lib_PassType == "lib"{
                return 30
            }
        case 1:
            if obj_Main.arr_JustCreated.count != 0{
                return 30
            }
        case 2:
            if obj_Main.arr_ContinueReading.count != 0{
                return 30
            }
        case 3:
            if obj_Main.arr_InProgress.count != 0{
                return 30
            }
        case 4:
            if obj_Main.arr_Completed.count != 0{
                return 30
            }
        default:
            return 0
        }
        
        return 0
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        var cellIdentifier : String = "section"
        
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)as! CollectionsTablecell
        
        switch section {
        case 0:
            cell.lbl_Title.text = "Now Playing"
            break
        case 1:
            cell.lbl_Title.text = "Just Added"
            break
        case 2:
            cell.lbl_Title.text = "Continue Reading"
            break
        case 3:
            cell.lbl_Title.text = "In Progress"
            break
        case 4:
            cell.lbl_Title.text = "Completed"
            break
        default:
            break
        }
        
        return cell;
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CGFloat(GlobalConstants.windowHeight * 0.107946027)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var str_Identifier : String = "cell"
        
        var obj = GlobalObject()
        
        switch indexPath.section {
        case 0:
            obj = obj_Player
            break
        case 1:
            obj = obj_Main.arr_JustCreated[indexPath.row] as! GlobalObject
            break
        case 2:
            obj = obj_Main.arr_ContinueReading[indexPath.row] as! GlobalObject
            break
        case 3:
            obj = obj_Main.arr_InProgress[indexPath.row] as! GlobalObject
            break
        case 4:
            obj = obj_Main.arr_Completed[indexPath.row] as! GlobalObject
            break
        default:
            break
        }
        
        if indexPath.section == 2 || indexPath.section == 3{
            str_Identifier = "cell2"
        }else if indexPath.section == 0 {
            str_Identifier = "cell3"
        }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: str_Identifier, for:indexPath as IndexPath) as! CollectionsTablecell
        
        //Declare text in icon in tableview cell
        cell.lbl_Title.text = obj.str_Lib_Title
        cell.img_Icon.sd_setImage(with: URL(string: (obj.str_Lib_Image)), placeholderImage: UIImage(named:"img_PlaceHolder"))
        cell.lbl_NumberOfNot.text = "\(obj.str_Lib_Note_Count) Note"
        
        if indexPath.section == 1{
            cell.lbl_FinishedTitle.text = "Just Added"
            
            cell.lbl_FinishedTitle.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 12))
        }else if indexPath.section == 4{
            cell.lbl_FinishedTitle.text = "Finished"
            
            cell.lbl_FinishedTitle.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 12))
        }else{
            
            let int_Sec = Double(obj.str_Lib_Text.count) * GlobalConstants.playerWordPerPlaySecond
            let int_Sec2 = Double(Double(obj.str_Lib_Text.count) * Double((1.0 - Float(obj.str_Lib_Progress)!) * 100)) / 100
            let int_Sec3 = Double(int_Sec2) * GlobalConstants.playerWordPerPlaySecond
            
            if int_Sec3 < 60{
                cell.lbl_ReaminingTime.text = "\(Int(int_Sec3)) sec remain"
            }else{
                cell.lbl_ReaminingTime.text = "\(Int(int_Sec3/60)) min remain"
            }
            
            cell.Progress_Main.progress = Float(obj.str_Lib_Progress)!
            if indexPath.section == 0{
                Progress_Save = cell.Progress_Main
            }
            cell.lbl_NumberOfNot.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 12))
            cell.lbl_ReaminingTime.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 12))
        }
        
        cell.lbl_Title.font =  UIFont(name: GlobalConstants.kFontRegular, size: manageFontHeight(font: 14))
        
        cell.btn_More.tag = indexPath.row
        cell.btn_More.addTarget(self, action: #selector(btn_MoreIn(_:)), for: UIControlEvents.touchUpInside)

        
        cell.btn_More.tag = indexPath.row
        cell.btn_Note.addTarget(self, action: #selector(btn_Note(_:)), for: UIControlEvents.touchUpInside)

        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        var boolValidation : Bool = false
        if indexSave.row == -1{
//            indexSave = indexPath as NSIndexPath
            if GlobalConstants.appDelegate?.presentFullScreenAds() == true{
                boolValidation = true
                indexSave = indexPath as NSIndexPath
            }
        }
        if boolValidation == false{
            if let cell = tableView.cellForRow(at: indexPath) as? CollectionsTablecell {
                var obj = GlobalObject()

                switch indexPath.section {
                case 0:
                    vw_TabBarController?.openPopup(animated: true, completion: nil)
                    break
                case 1:
                    obj = obj_Main.arr_JustCreated[indexPath.row] as! GlobalObject
                    obj_Main.arr_JustCreated.removeObject(at: indexPath.row)
                    break
                case 2:
                    obj = obj_Main.arr_ContinueReading[indexPath.row] as! GlobalObject
                    obj_Main.arr_ContinueReading.removeObject(at: indexPath.row)
                    break
                case 3:
                    obj = obj_Main.arr_InProgress[indexPath.row] as! GlobalObject
                    obj_Main.arr_InProgress.removeObject(at: indexPath.row)
                    break
                case 4:
                    obj = obj_Main.arr_Completed[indexPath.row] as! GlobalObject
                    obj_Main.arr_Completed.removeObject(at: indexPath.row)
                    break
                default:
                    break
                }

                if indexPath.section != 0{
                    obj_Player = obj
                    obj_Player.str_Lib_PassType = "lib"
                    
                    playerControllerPresent(obj : obj,image : cell.img_Icon.image!,str_Type: "")
                }
            }
        }
    }
    
}


extension LibraryListingViewController : EmptyDataSetSource, EmptyDataSetDelegate
    
{
    func emptyDataSetShouldDisplay(_ scrollView: UIScrollView) -> Bool {
        if arr_Main.count == 0 && bool_Load == false{
            return true
        }
        return false
    }
    
    func image(forEmptyDataSet scrollView: UIScrollView) -> UIImage? {
        
        return UIImage.init(named: "img_NoData1")
    }
    
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        
        var text: String?
        var font: UIFont?
        var textColor: UIColor?
        
        textColor = UIColor.darkGray
        
        
        text = "Please first add libaray using with \nphotos/camera/copy text"
        
        font = UIFont(name: GlobalConstants.kFontRegular, size:GlobalConstants.kFontRatio*18.0 )
        //        textColor = GlobalConstants.noDataColor
        
        if text == nil {
            return nil
        }
        var attributes: [NSAttributedStringKey: Any] = [:]
        if font != nil {
            attributes[NSAttributedStringKey.font] = font!
        }
        if textColor != nil {
            attributes[NSAttributedStringKey.foregroundColor] = textColor
        }
        
        textColor = UIColor.clear
        
        return NSAttributedString.init(string: text!, attributes: attributes)
    }
}


extension LibraryListingViewController : UIImagePickerControllerDelegate{
    //MARK: - Imagepicker Delegates
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        let chosenImage = info[UIImagePickerControllerEditedImage] as! UIImage
        dismiss(animated:true, completion: nil)
        
        self.Post_PictureCell(index: self.objMore.str_Lib_Id,image: chosenImage)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}



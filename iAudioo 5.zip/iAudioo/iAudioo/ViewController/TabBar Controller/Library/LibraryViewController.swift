//
//  LibraryViewController.swift
//  iAudioo
//
//  Created by Apple on 20/04/18.
//  Copyright © 2018 iAudioo. All rights reserved.

import UIKit
import PopOverMenu
import SDWebImage

class LibraryViewController: UIViewController {

    //Ad Module
    @IBOutlet weak var con_Ads: NSLayoutConstraint!
    @IBOutlet weak var img_Ads: UIImageView!
    
    //Collectionview declaration
    @IBOutlet weak var cv_HeaderSelection : UICollectionView!
    
    //Other
    var indexpath_Header : NSIndexPath = NSIndexPath(row: 0, section: 0)
    var arr_Header = ["Libaray","Notes"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.commanMethod()
        str_PresentView = "1"
        
        NotificationCenter.default.removeObserver("reloadAds3")
        NotificationCenter.default.addObserver(self, selector: #selector(reloadData), name: NSNotification.Name(rawValue: "reloadAds3"), object: nil)
    }

    override func viewWillAppear(_ animated: Bool) {
        self.navigationController!.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
        self.navigationController!.navigationBar.setBackgroundImage(imageWithColor(with:GlobalConstants.appColor), for: .default)
        
        if deviceIdentifier() == "iPhone X"{
            GlobalConstants.appDelegate?.googleBannerAds(view: self,constant : con_Ads,frame : CGRect(x: 0, y: Int(img_Ads.frame.origin.y) + 23, width: Int(GlobalConstants.windowWidth), height: 50))
        }else{
            GlobalConstants.appDelegate?.googleBannerAds(view: self,constant : con_Ads,frame : CGRect(x: 0, y: Int(img_Ads.frame.origin.y), width: Int(GlobalConstants.windowWidth), height: 50))
        }
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController!.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.black]
        self.navigationController!.navigationBar.setBackgroundImage(imageWithColor(with:UIColor.white), for: .default)
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    //MARK: - Page view controller -
    var LibarayPageViewController: LibarayPageViewController? {
        didSet {
            LibarayPageViewController?.tutorialDelegate = self
        }
    }
    
    
    //MARK : - Other Method -
    func commanMethod(){
  
    }
    @objc func reloadData(){
        if deviceIdentifier() == "iPhone X"{
            GlobalConstants.appDelegate?.googleBannerAds(view: self,constant : con_Ads,frame : CGRect(x: 0, y: Int(img_Ads.frame.origin.y) + 23, width: Int(GlobalConstants.windowWidth), height: 50))
        }else{
            GlobalConstants.appDelegate?.googleBannerAds(view: self,constant : con_Ads,frame : CGRect(x: 0, y: Int(img_Ads.frame.origin.y), width: Int(GlobalConstants.windowWidth), height: 50))
        }
    }
    
    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let LibarayPageViewController = segue.destination as? LibarayPageViewController {
            self.LibarayPageViewController = LibarayPageViewController
        }
    }
    
}

//MARK: - Collection View Cell -
class LibarayViewCollectioncell : UICollectionViewCell{
    //Cell for tabbar
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var img_Seleted: UIImageView!
    
}

//MARK: - Collection View -
extension LibraryViewController : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arr_Header.count
       
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let userAttributes = [NSAttributedStringKey.font: UIFont(name: GlobalConstants.kFontBold, size:13), NSAttributedStringKey.foregroundColor: UIColor.black]
        let text: String = arr_Header[indexPath.row] as! String
        
        //Find out widht of text with depend of font size and font name
        var textSize: CGSize = (text as NSString).size(withAttributes: userAttributes)
        textSize.height = collectionView.frame.size.height
        textSize.width = textSize.width + 14
        
        return textSize
      
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        var str_Identifier : String = "cell"
        
        let cell  = collectionView.dequeueReusableCell(withReuseIdentifier: str_Identifier, for: indexPath) as! LibarayViewCollectioncell
        
            //Set text in label
            cell.lblTitle.text = arr_Header[indexPath.row] as! String
            
            //Seleted Image always false only selected state they show
            cell.img_Seleted.isHidden = true
            
            if indexpath_Header.row == indexPath.row {
                cell.img_Seleted.isHidden = false
            }
            
            //Set font size and font name in title
            cell.lblTitle.font = UIFont(name: GlobalConstants.kFontBold, size: 13)
            
            //Current logic
            if indexpath_Header.row == indexPath.row {
                cell.img_Seleted.isHidden = false
            }else{
                cell.img_Seleted.isHidden = true
            }
            
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        LibarayPageViewController?.scrollToPreviewsViewController(indexCall:indexPath.row)
        indexpath_Header = indexPath as NSIndexPath

        cv_HeaderSelection.reloadData()
    }
}


//MARK: - Page Viewcontroller Deleagte -
extension LibraryViewController: LibarayPageViewControllerDelegate {
    
    func LibarayPageViewController(_ LibarayPageViewController: LibarayPageViewController, didUpdatePageCount count: Int) {
        
    }
    func LibarayPageViewController(_ LibarayPageViewController: LibarayPageViewController,
                                didUpdatePageIndex index: Int) {
        indexpath_Header = NSIndexPath(row: index, section: 0)
        cv_HeaderSelection.reloadData()
    }
    
}

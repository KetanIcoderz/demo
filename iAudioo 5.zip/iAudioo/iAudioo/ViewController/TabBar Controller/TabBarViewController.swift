//
//  TabBarViewController.swift
//  iAudioo
//
//  Created by Apple on 20/04/18.
//  Copyright © 2018 iAudioo. All rights reserved.
//

import UIKit
import SwiftyReceiptValidator

class TabBarViewController: UIViewController {

    @IBOutlet var contentView : UIView!
    
    @IBOutlet var button : [UIButton]!
    
    var LibraryViewController : UINavigationController!
    var CreateViewController : UINavigationController!
    var CollectionsViewController : UINavigationController!
    
    var viewControllers: [UINavigationController]!
    
    var selectedIndex: Int = 2
    
    @IBOutlet weak var con_ViewHeight: NSLayoutConstraint!
    
    var arr_PurchaseInfo : NSMutableArray = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.Get_CommanMethod()
        
        view.backgroundColor = .white
        
        self.navigationController?.isNavigationBarHidden = true
        navigationSet(type : "0")
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(named:"icon_LeftBlue"), style: .plain, target: self, action: #selector(btn_NavLeft(_:)))
        
        vw_TabBarController = self
        
        //Manage array for navigation controller
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        CollectionsViewController = storyboard.instantiateViewController(withIdentifier: "nav1") as! UINavigationController
        CreateViewController = storyboard.instantiateViewController(withIdentifier: "nav2") as! UINavigationController
        LibraryViewController = storyboard.instantiateViewController(withIdentifier: "nav3") as! UINavigationController
        viewControllers = [CollectionsViewController,LibraryViewController,CreateViewController]
        
        //Select first tab bar
        button[selectedIndex].isSelected = true
        self.btn_Tab(button[selectedIndex])
        
        con_ViewHeight.constant = CGFloat(GlobalConstants.windowHeight * 0.0644678)
        
        self.purchaseInfo(transaction: "com.houstonmitchell.iaudioo1")
        self.purchaseInfo(transaction: "com.houstonmitchell.iaudioo2")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    //MARK: - Tabbar Manage -
    func tabbarManage(str_ID : String,str_Type : String){
        let btn_Button : UIButton = UIButton()
        btn_Button.tag = Int(str_ID)!
        self.btn_Tab(btn_Button)
    }
    func hideTabBar(){
        UIView.animate(withDuration: 0.3, animations: {
            self.con_ViewHeight.constant = 0
            self.view.layoutIfNeeded()
        }, completion: { (finished) in
        })
        
    }
    func showTabBar(){
        UIView.animate(withDuration: 0.3, animations: {
            self.con_ViewHeight.constant = CGFloat(GlobalConstants.windowHeight * 0.0644678)
            self.view.layoutIfNeeded()
        }, completion: { (finished) in
        })
    }
    
    //MARK: - Button Event -
    @IBAction func btn_NavLeft(_ sender:Any) {
        sideMenuController?.showLeftView(animated: true, completionHandler: nil)
    }
    
    @IBAction func btn_NavRight(_ sender:Any) {
        sideMenuController?.showRightView(animated: true, completionHandler: nil)
    }
    
    @IBAction func btn_Tab(_ sender: UIButton) {
        str_PresentView = "\(sender.tag)"
        
        if str_PresentView == "2"{
            var int_Value = Int(str_AddPresentCount)
            int_Value = int_Value! + 1
            if int_Value! >= 3{
                str_AddPresentCount = "0"
                UserDefaults.standard.set("0", forKey: "AddPresent")
                GlobalConstants.appDelegate?.presentFullScreenAds()
            }else{
                str_AddPresentCount = String(int_Value!)
                UserDefaults.standard.set(String(int_Value!), forKey: "AddPresent")
            }
        }
        
        //Previous selected tab deselected
        button[selectedIndex].isSelected = false
        button[sender.tag].isSelected = true
        
        //Save current index
        selectedIndex = sender.tag
        
        //Get previous controller and remove from super view
        let previousVC = viewControllers[sender.tag]
        previousVC.willMove(toParentViewController: nil)
        previousVC.view.removeFromSuperview()
        previousVC.removeFromParentViewController()
        
        //Selected controller set in present view
        let vc = viewControllers[sender.tag]
        addChildViewController(vc)
        vc.view.frame = contentView.bounds
        contentView.addSubview(vc.view)
        vc.didMove(toParentViewController: self)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    // MARK: - Get/Post Method -
    func Get_CommanMethod(){
        
        //Declaration URL
        let strURL = "\(GlobalConstants.BaseURL)commonApi"
        
        //Pass data in dictionary
        var jsonData : NSDictionary =  NSDictionary()

        //Create object for webservicehelper and start to call method
        let webHelper = WebServiceHelper()
        webHelper.strMethodName = "commonApi"
        webHelper.methodType = "get"
        webHelper.strURL = strURL
        webHelper.dictType = jsonData
        webHelper.dictHeader = NSDictionary()
        webHelper.delegateWeb = self
        webHelper.serviceWithAlert = false
        webHelper.startDownload()
    }
    func Post_UpdateSubscription(arr_Subscription : NSMutableArray){
        
        let arr_Code : NSMutableArray = []
        let arr_ExpireDate : NSMutableArray = []
        
        for i in 0..<arr_Subscription.count{
            if (arr_Subscription[i] as? NSDictionary) != nil {
                let dict_Temp = arr_Subscription[i] as! NSDictionary
                
                let traslation_Id = dict_Temp["transaction_id"] as! String
                let traslation_ExpiredDate = dict_Temp["expires_date_ms"] as! String
                
                //Save data in dictionary
                let dict_Store : NSDictionary = [
                    "code" : traslation_Id,
                    ]
                arr_Code.add(dict_Store)
                
                //Save data in dictionary
                let dict_Store2 : NSDictionary = [
                    "expiry_date" : traslation_ExpiredDate,
                    ]
                arr_ExpireDate.add(dict_Store2)
            }
        }
    
        if arr_Code.count != 0{
            //Convert array in string
            let string = notPrettyString(from : arr_Code)
            let string2 = notPrettyString(from : arr_ExpireDate)
        
            //Declaration URL
            let strURL = "\(GlobalConstants.BaseURL)update_subscriptions"
            
            //Pass data in dictionary
            var jsonData : NSDictionary =  NSDictionary()
            jsonData = [
                "code" : string,
                "expiry_date" : string2,
            ]
            
            //Create object for webservicehelper and start to call method
            let webHelper = WebServiceHelper()
            webHelper.strMethodName = "update_subscriptions"
            webHelper.methodType = "post"
            webHelper.strURL = strURL
            webHelper.dictType = jsonData
            webHelper.dictHeader = NSDictionary()
            webHelper.delegateWeb = self
            webHelper.serviceWithAlert = false
            webHelper.indicatorShowOrHide = false
            webHelper.startDownload()
        }
    }
    
    func purchaseInfo(transaction : String){
        
        SwiftyReceiptValidator.validate(forIdentifier: transaction, sharedSecret: "8c3970776baa4931b8e55b50058adaaa") { (success, response) in
            indicatorHide()
            //indicatorHide()
            if success {
                // example 2 (auto-renewable subscriptions)
                let receiptInfoFieldKey = SwiftyReceiptValidator.ResponseKey.receipt.rawValue
                if let receipt = response![receiptInfoFieldKey] {
                    
                    // example 2
                    let inAppKey = SwiftyReceiptValidator.InfoKey.in_app.rawValue
                    if let inApp = receipt[inAppKey] as? [AnyObject] {
                        
                        if inApp.count != 0{
                            let dict_detail = inApp[inApp.count - 1] as! NSDictionary
                            let traslation_Id = dict_detail["transaction_id"] as! String
                            let traslation_ExpiredDate = dict_detail["expires_date_ms"] as! String
                            let product_id = dict_detail["product_id"] as! String
                            //1527530583000
                            //1527531432000
                            //1527531990000
                            
                            print(traslation_Id)
                            print(traslation_ExpiredDate)
                            self.arr_PurchaseInfo.add(dict_detail)
                        }
                    }else{
                        self.arr_PurchaseInfo.add("")
                    }
                }
            } else {
                self.arr_PurchaseInfo.add("")
            }
            //Number of in-app purchase found
            if self.arr_PurchaseInfo.count == 1{
                self.Post_UpdateSubscription(arr_Subscription: self.arr_PurchaseInfo)
            }
        }
    }
}

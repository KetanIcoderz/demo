//
//  UserDataObject.swift
//
//  Created by iAudioo on 16/05/17.
//  Copyright © 2017 iAudioo. All rights reserved.
//

import UIKit

class UserDataObject: NSObject,NSCoding  {
    //NSCoding
    
    var user_UserID : String = ""
    var user_Name : String = ""
    var user_Email : String = ""
    var user_Image : String = ""
    var user_Account_Type : String = ""
    var user_Socialid : String = ""
    var user_isActive : String = ""
    var user_Access_token : String = ""
    var user_Language_id : String = ""
    var user_Voice_id : String = ""
    var user_Created_at : String = ""
    var user_Updated_at : String = ""
    var user_Profile_image : String = ""
    
    
    //Player Controller
    var plyer_DisplayType : String = ""
    
    override init(){
        super.init()
    }
    
    init(user_UserID : String,user_Name : String,user_Email : String,user_Image : String,user_Account_Type : String,user_Socialid : String, user_isActive : String,user_Access_token : String,user_Language_id : String,user_Voice_id : String,user_Created_at : String,user_Updated_at : String,plyer_DisplayType : String,user_Profile_image : String) {
        
        self.user_UserID = user_UserID as String
        self.user_Name = user_Name as String
        self.user_Email = user_Email as String
        self.user_Image = user_Image as String
        self.user_Account_Type = user_Account_Type as String
        self.user_Socialid = user_Socialid as String
        self.user_isActive = user_isActive as String
        self.user_Access_token = user_Access_token as String
        self.user_Language_id = user_Language_id as String
        self.user_Voice_id = user_Voice_id as String
        self.user_Created_at = user_Created_at as String
        self.user_Updated_at = user_Updated_at as String
        self.plyer_DisplayType = plyer_DisplayType as String
        self.user_Profile_image = user_Profile_image as String
        
    }
    
    required convenience init(coder aDecoder: NSCoder) {
        let user_UserID = aDecoder.decodeObject(forKey: "user_UserID") as! String
        let user_Name = aDecoder.decodeObject(forKey: "user_Name") as! String
        let user_Email = aDecoder.decodeObject(forKey: "user_Email") as! String
        let user_Image = aDecoder.decodeObject(forKey: "user_Image") as! String
        let user_Account_Type = aDecoder.decodeObject(forKey: "user_Account_Type") as! String
        let user_Socialid = aDecoder.decodeObject(forKey: "user_Socialid") as! String
        let user_isActive = aDecoder.decodeObject(forKey: "user_isActive") as! String
        let user_Access_token = aDecoder.decodeObject(forKey: "user_Access_token") as! String
        let user_Language_id = aDecoder.decodeObject(forKey: "user_Language_id") as! String
        let user_Voice_id = aDecoder.decodeObject(forKey: "user_Voice_id") as! String
        let user_Created_at = aDecoder.decodeObject(forKey: "user_Created_at") as! String
        let user_Updated_at = aDecoder.decodeObject(forKey: "user_Updated_at") as! String
        let plyer_DisplayType = aDecoder.decodeObject(forKey: "plyer_DisplayType") as! String
        let user_Profile_image = aDecoder.decodeObject(forKey: "user_Profile_image") as! String
        
        self.init(user_UserID: user_UserID as String,
                  user_Name: user_Name as String,
                  user_Email: user_Email as String,
                  user_Image: user_Image as String,
                  user_Account_Type: user_Account_Type as String,
                  user_Socialid: user_Socialid as String,
                  user_isActive: user_isActive as String,
                  user_Access_token: user_Access_token as String,
                  user_Language_id: user_Language_id as String,
                  user_Voice_id: user_Voice_id as String,
                  user_Created_at: user_Created_at as String,
                  user_Updated_at: user_Updated_at as String,
                  plyer_DisplayType: plyer_DisplayType as String,
                  user_Profile_image: user_Profile_image as String)
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(user_UserID, forKey: "user_UserID")
        aCoder.encode(user_Name, forKey: "user_Name")
        aCoder.encode(user_Email, forKey: "user_Email")
        aCoder.encode(user_Image, forKey: "user_Image")
        aCoder.encode(user_Account_Type, forKey: "user_Account_Type")
        aCoder.encode(user_Socialid, forKey: "user_Socialid")
        aCoder.encode(user_isActive, forKey: "user_isActive")
        aCoder.encode(user_Access_token, forKey: "user_Access_token")
        aCoder.encode(user_Language_id, forKey: "user_Language_id")
        aCoder.encode(user_Voice_id, forKey: "user_Voice_id")
        aCoder.encode(user_Created_at, forKey: "user_Created_at")
        aCoder.encode(user_Updated_at, forKey: "user_Updated_at")
        aCoder.encode(plyer_DisplayType, forKey: "plyer_DisplayType")
        aCoder.encode(user_Profile_image, forKey: "user_Profile_image")
    }
    
}






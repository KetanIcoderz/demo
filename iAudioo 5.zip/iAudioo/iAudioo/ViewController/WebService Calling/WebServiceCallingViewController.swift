//
//  WebServiceCallingViewController.swift
//  iAudioo
//
//  Created by Apple on 18/05/18.
//  Copyright © 2018 iAudioo. All rights reserved.

import UIKit

class WebServiceCallingViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension TabBarViewController : WebServiceHelperDelegate{
    //MARK: - TabBarViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "commonApi" {
         
            let arr_responseLanguage = response["languages"] as! NSArray
            let arr_responseVoices = response["voices"] as! NSArray
            let arr_responseSubscription = response["subscriptions"] as! NSArray
            str_SubscriptionLink = response["subscription_terms"] as! String
            
            arr_Languages = []
            for i in 0..<arr_responseLanguage.count{
                let dict_Temp : NSDictionary = arr_responseLanguage[i] as! NSDictionary
                
                let objSub = GlobalObject()
                objSub.str_Lan_Id =  dict_Temp.getStringForID(key: "id")
                objSub.str_Lan_Name =  dict_Temp.getStringForID(key: "name")
                objSub.str_Lan_Code =  dict_Temp.getStringForID(key: "iso_code")
                objSub.str_Lan_Active =  dict_Temp.getStringForID(key: "active")
                
                arr_Languages.add(objSub)
            }
            
            arr_Voice = []
            for i in 0..<arr_responseVoices.count{
                let dict_Temp : NSDictionary = arr_responseVoices[i] as! NSDictionary
                
                let objSub = GlobalObject()
                objSub.str_Voice_Id =  dict_Temp.getStringForID(key: "id")
                objSub.str_Voice_Name =  dict_Temp.getStringForID(key: "name")
                objSub.str_Voice_Code =  dict_Temp.getStringForID(key: "code")
                objSub.str_Voice_Active =  dict_Temp.getStringForID(key: "active")
                
                arr_Voice.add(objSub)
            }
            
            arr_Subscription = []
            for i in 0..<arr_responseSubscription.count{
                let dict_Temp : NSDictionary = arr_responseSubscription[i] as! NSDictionary
                
                let objSub = GlobalObject()
                objSub.str_Sub_Id =  dict_Temp.getStringForID(key: "id")
                objSub.str_Sub_Code =  dict_Temp.getStringForID(key: "code")
                objSub.str_Sub_Expiry_date =  dict_Temp.getStringForID(key: "expiry_date")
                objSub.str_Sub_Type =  dict_Temp.getStringForID(key: "type")
                objSub.str_Sub_Active =  dict_Temp.getStringForID(key: "active")
                
                arr_Subscription.add(objSub)
            }
            
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadSubscription"), object: nil)
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadSubscription2"), object: nil)
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadAds1"), object: nil)
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadAds2"), object: nil)
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadAds3"), object: nil)
        }else if strRequest == "update_subscriptions"{
            
            let arr_responseLanguage = response["languages"] as! NSArray
            let arr_responseVoices = response["voices"] as! NSArray
            let arr_responseSubscription = response["subscriptions"] as! NSArray
            
            arr_Languages = []
            for i in 0..<arr_responseLanguage.count{
                let dict_Temp : NSDictionary = arr_responseLanguage[i] as! NSDictionary
                
                let objSub = GlobalObject()
                objSub.str_Lan_Id =  dict_Temp.getStringForID(key: "id")
                objSub.str_Lan_Name =  dict_Temp.getStringForID(key: "name")
                objSub.str_Lan_Code =  dict_Temp.getStringForID(key: "iso_code")
                objSub.str_Lan_Active =  dict_Temp.getStringForID(key: "active")
                
                arr_Languages.add(objSub)
            }
            
            arr_Voice = []
            for i in 0..<arr_responseVoices.count{
                let dict_Temp : NSDictionary = arr_responseVoices[i] as! NSDictionary
                
                let objSub = GlobalObject()
                objSub.str_Voice_Id =  dict_Temp.getStringForID(key: "id")
                objSub.str_Voice_Name =  dict_Temp.getStringForID(key: "name")
                objSub.str_Voice_Code =  dict_Temp.getStringForID(key: "code")
                objSub.str_Voice_Active =  dict_Temp.getStringForID(key: "active")
                
                arr_Voice.add(objSub)
            }
            
            arr_Subscription = []
            for i in 0..<arr_responseSubscription.count{
                let dict_Temp : NSDictionary = arr_responseSubscription[i] as! NSDictionary
                
                let objSub = GlobalObject()
                objSub.str_Sub_Id =  dict_Temp.getStringForID(key: "id")
                objSub.str_Sub_Code =  dict_Temp.getStringForID(key: "code")
                objSub.str_Sub_Expiry_date =  dict_Temp.getStringForID(key: "expiry_date")
                objSub.str_Sub_Type =  dict_Temp.getStringForID(key: "type")
                objSub.str_Sub_Active =  dict_Temp.getStringForID(key: "active")
                
                arr_Subscription.add(objSub)
            }
            
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadSubscription"), object: nil)
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadSubscription2"), object: nil)
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadAds1"), object: nil)
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadAds2"), object: nil)
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadAds3"), object: nil)
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}



extension SignUpViewController : WebServiceHelperDelegate{
    //MARK: - SignUpViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "register" {
            
            userObjectUpdate(dict_Get : response)
            TabbarManager(view : self)
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {

    }
}


extension SignInViewController : WebServiceHelperDelegate{
    //MARK: - SignInViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "login" {
           
            userObjectUpdate(dict_Get : response)
            TabbarManager(view : self)
        }else if strRequest == "register" {
            
            userObjectUpdate(dict_Get : response)
            TabbarManager(view : self)
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
 
    }
}


extension PlaceViewController : WebServiceHelperDelegate{
    //MARK: - PlaceViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "register" {
            
            userObjectUpdate(dict_Get : response)
            TabbarManager(view : self)
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {

    }
}

extension ForgotPasswordViewController : WebServiceHelperDelegate{
    //MARK: - ForgotPasswordViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "forget" {
            
            self .dismiss(animated: true) {
            }
            
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {

    }
}


extension LeftSideMenuViewController : WebServiceHelperDelegate{
    //MARK: - LeftSideMenuViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "logout" {
            
            //Store data nill value when user logout
            let defaults = UserDefaults.standard
            defaults.removeObject(forKey: "userobject")
            defaults.synchronize()
            
            
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let nav: UINavigationController! = (appDelegate.window?.rootViewController as! UINavigationController)
            let view : UIViewController = nav.viewControllers[0]
            //                nav.popToRootViewController(animated: true)
            nav.popToViewController(view, animated: true)
            
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}


extension CreateViewController : WebServiceHelperDelegate{
    //MARK: - CreateViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "add_library" {
            vw_TabBarController?.tabbarManage(str_ID: "1", str_Type: "")
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}


extension LibraryListingViewController : WebServiceHelperDelegate{
    //MARK: - LibraryListingViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        bool_Load = false
        let response = data as! NSDictionary
        if strRequest == "list_libraries" ||  strRequest == "delete_library" || strRequest == "update_title" || strRequest == "update_image"{
            
            let dict_responseData = response["libraries"] as! NSDictionary
            
            let arr_JustAdded = dict_responseData.getArrayVarification(key:"Just Created")
            let arr_Recent = dict_responseData.getArrayVarification(key:"Continue Reading")
            let arr_Complted = dict_responseData.getArrayVarification(key:"In Progress")
            let arr_NotAdded = dict_responseData.getArrayVarification(key:"Completed")
            
            obj_Main = GlobalObject()
            
            obj_Main.arr_JustCreated = []
            obj_Main.arr_ContinueReading = []
            obj_Main.arr_InProgress = []
            obj_Main.arr_Completed = []
            
            for count in 0..<arr_JustAdded.count {
                let dict_Temp = arr_JustAdded[count] as! NSDictionary
                
                let objSub = GlobalObject()
                objSub.str_Lib_Id =  dict_Temp.getStringForID(key: "id")
                objSub.str_Lib_User_Id =  dict_Temp.getStringForID(key: "user_id")
                objSub.str_Lib_Title =  dict_Temp.getStringForID(key: "title")
                objSub.str_Lib_Text =  dict_Temp.getStringForID(key: "text")
                objSub.str_Lib_Type =  dict_Temp.getStringForID(key: "type")
                objSub.str_Lib_Image =  dict_Temp.getStringForID(key: "image")
                objSub.str_Lib_Progress =  dict_Temp.getStringForID(key: "progress")
                objSub.str_Lib_Status =  dict_Temp.getStringForID(key: "status")
                objSub.str_Lib_Created_At =  dict_Temp.getStringForID(key: "created_at")
                objSub.str_Lib_Updated_At =  dict_Temp.getStringForID(key: "updated_at")
                objSub.str_Lib_Deleted_At =  dict_Temp.getStringForID(key: "deleted_at")
                objSub.str_Lib_Note_Count =  dict_Temp.getStringForID(key: "note_count")
                objSub.str_Lib_Total_Time =  dict_Temp.getStringForID(key: "total_time")
                
                
                
                if vw_TabBarController?.popupBar.isHidden == false && obj_Player.str_Lib_Id == objSub.str_Lib_Id{
                }else{
                    obj_Main.arr_JustCreated.add(objSub)
                }
            }
            
            for count in 0..<arr_Recent.count {
                let dict_Temp = arr_Recent[count] as! NSDictionary
                
                let objSub = GlobalObject()
                objSub.str_Lib_Id =  dict_Temp.getStringForID(key: "id")
                objSub.str_Lib_User_Id =  dict_Temp.getStringForID(key: "user_id")
                objSub.str_Lib_Title =  dict_Temp.getStringForID(key: "title")
                objSub.str_Lib_Text =  dict_Temp.getStringForID(key: "text")
                objSub.str_Lib_Type =  dict_Temp.getStringForID(key: "type")
                objSub.str_Lib_Image =  dict_Temp.getStringForID(key: "image")
                objSub.str_Lib_Progress =  dict_Temp.getStringForID(key: "progress")
                objSub.str_Lib_Status =  dict_Temp.getStringForID(key: "status")
                objSub.str_Lib_Created_At =  dict_Temp.getStringForID(key: "created_at")
                objSub.str_Lib_Updated_At =  dict_Temp.getStringForID(key: "updated_at")
                objSub.str_Lib_Deleted_At =  dict_Temp.getStringForID(key: "deleted_at")
                objSub.str_Lib_Note_Count =  dict_Temp.getStringForID(key: "note_count")
                objSub.str_Lib_Total_Time =  dict_Temp.getStringForID(key: "total_time")
                
                if vw_TabBarController?.popupBar.isHidden == false && obj_Player.str_Lib_Id == objSub.str_Lib_Id{
                }else{
                    obj_Main.arr_ContinueReading.add(objSub)
                }
            }
            
            for count in 0..<arr_Complted.count {
                let dict_Temp = arr_Complted[count] as! NSDictionary
                
                let objSub = GlobalObject()
                objSub.str_Lib_Id =  dict_Temp.getStringForID(key: "id")
                objSub.str_Lib_User_Id =  dict_Temp.getStringForID(key: "user_id")
                objSub.str_Lib_Title =  dict_Temp.getStringForID(key: "title")
                objSub.str_Lib_Text =  dict_Temp.getStringForID(key: "text")
                objSub.str_Lib_Type =  dict_Temp.getStringForID(key: "type")
                objSub.str_Lib_Image =  dict_Temp.getStringForID(key: "image")
                objSub.str_Lib_Progress =  dict_Temp.getStringForID(key: "progress")
                objSub.str_Lib_Status =  dict_Temp.getStringForID(key: "status")
                objSub.str_Lib_Created_At =  dict_Temp.getStringForID(key: "created_at")
                objSub.str_Lib_Updated_At =  dict_Temp.getStringForID(key: "updated_at")
                objSub.str_Lib_Deleted_At =  dict_Temp.getStringForID(key: "deleted_at")
                objSub.str_Lib_Note_Count =  dict_Temp.getStringForID(key: "note_count")
                objSub.str_Lib_Total_Time =  dict_Temp.getStringForID(key: "total_time")
                
                if vw_TabBarController?.popupBar.isHidden == false && obj_Player.str_Lib_Id == objSub.str_Lib_Id{
                }else{
                    obj_Main.arr_InProgress.add(objSub)
                }
            }
            
            for count in 0..<arr_NotAdded.count {
                let dict_Temp = arr_NotAdded[count] as! NSDictionary
                
                let objSub = GlobalObject()
                objSub.str_Lib_Id =  dict_Temp.getStringForID(key: "id")
                objSub.str_Lib_User_Id =  dict_Temp.getStringForID(key: "user_id")
                objSub.str_Lib_Title =  dict_Temp.getStringForID(key: "title")
                objSub.str_Lib_Text =  dict_Temp.getStringForID(key: "text")
                objSub.str_Lib_Type =  dict_Temp.getStringForID(key: "type")
                objSub.str_Lib_Image =  dict_Temp.getStringForID(key: "image")
                objSub.str_Lib_Progress =  dict_Temp.getStringForID(key: "progress")
                objSub.str_Lib_Status =  dict_Temp.getStringForID(key: "status")
                objSub.str_Lib_Created_At =  dict_Temp.getStringForID(key: "created_at")
                objSub.str_Lib_Updated_At =  dict_Temp.getStringForID(key: "updated_at")
                objSub.str_Lib_Deleted_At =  dict_Temp.getStringForID(key: "deleted_at")
                objSub.str_Lib_Note_Count =  dict_Temp.getStringForID(key: "note_count")
                objSub.str_Lib_Total_Time =  dict_Temp.getStringForID(key: "total_time")
                
                if vw_TabBarController?.popupBar.isHidden == false && obj_Player.str_Lib_Id == objSub.str_Lib_Id{
                }else{
                    obj_Main.arr_Completed.add(objSub)
                }
            }
            
            tbl_Main.reloadData()
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        bool_Load = false
        arr_Main = []
        tbl_Main.reloadData()
    }
}

extension AddNoteViewController : WebServiceHelperDelegate{
    //MARK: - LibraryViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "add_note"{
            self.navigationController?.popViewController(animated: true)
        }else if strRequest == "update_note"{
            self.navigationController?.popViewController(animated: true)
            self.delegate?.NoteOption(str_Tital: tf_Title.text!,str_Description: tv_Descriptin.text)
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}

extension CollectionsViewController : WebServiceHelperDelegate{
    //MARK: - CollectionsViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "add_user_note"{
            tf_Title.text = ""
            tf_Title.placeholder = "Enter Title…"
            
            tv_Descriptin.text = "Please enter description"
            tv_Descriptin.textColor = UIColor.lightGray
            self.manageDoneButton(tv: tv_Descriptin.text)
            
            vw_TabBarController?.tabbarManage(str_ID: "1", str_Type: "")
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}


extension PlayerViewController : WebServiceHelperDelegate{
    //MARK: - TabBarViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "translate" {
            
            let str_Data = response["translated_text"] as! String
            
            self.restarView()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: {
                self.tv_Main.text = ""
                self.tv_Main.text = str_Data
            })
        }else if strRequest == "update_library"{
//            self.navigationController?.popViewController(animated: true)
//            vw_TabBarController?.dismissPopupBar(animated: true, completion: {
//                GlobalConstants.appDelegate?.presentFullScreenAds()
                
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "librayreload"), object: nil)
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "notereload"), object: nil)
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "librayreloadtableview"), object: nil)
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "notereloadtableview"), object: nil)
//            })
        }else if strRequest == "update_library2"{
                
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "librayreload"), object: nil)
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "notereload"), object: nil)
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "librayreloadtableview"), object: nil)
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "notereloadtableview"), object: nil)
            
            playerControllerContinue()
            
        }else if strRequest == "update_library3"{
            vw_TabBarController?.dismissPopupBar(animated: true, completion: {
                GlobalConstants.appDelegate?.presentFullScreenAds()
                
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "librayreload"), object: nil)
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "notereload"), object: nil)
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "librayreloadtableview"), object: nil)
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "notereloadtableview"), object: nil)
            })
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        UIApplication.shared.endIgnoringInteractionEvents()
    }
}


extension NoteListingViewController : WebServiceHelperDelegate{
    //MARK: - NoteListingViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "list_notes"{
            
            let arr_Notes = response.getArrayVarification(key:"notes")
            
            arr_Main = []
            
            for count in 0..<arr_Notes.count {
                let dict_Temp = arr_Notes[count] as! NSDictionary
                
                let objSub = GlobalObject()
                
                objSub.str_Note_Id =  dict_Temp.getStringForID(key: "id")
                objSub.str_Note_Title =  dict_Temp.getStringForID(key: "title")
                objSub.str_Note_Description =  dict_Temp.getStringForID(key: "description")
                objSub.str_Note_Library_Id =  dict_Temp.getStringForID(key: "library_id")
                objSub.str_Note_Created_At =  dict_Temp.getStringForID(key: "created_at")
                objSub.str_Note_Updated_At =  dict_Temp.getStringForID(key: "updated_at")
                
                arr_Main.add(objSub)
            }
            
            tbl_Main.reloadData()
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}

extension NoteAppListingViewController : WebServiceHelperDelegate{
    //MARK: - NoteAppListingViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        bool_Load = false
        
        let response = data as! NSDictionary
        if strRequest == "list_user_notes" ||  strRequest == "delete_library" || strRequest == "update_title" || strRequest == "update_image"{
            
            let dict_responseData = response["notes"] as! NSDictionary
            
            let arr_JustAdded = dict_responseData.getArrayVarification(key:"Just Created")
            let arr_Recent = dict_responseData.getArrayVarification(key:"Continue Reading")
            let arr_Complted = dict_responseData.getArrayVarification(key:"In Progress")
            let arr_NotAdded = dict_responseData.getArrayVarification(key:"Completed")
            
            obj_Main = GlobalObject()
            
            obj_Main.arr_JustCreated = []
            obj_Main.arr_ContinueReading = []
            obj_Main.arr_InProgress = []
            obj_Main.arr_Completed = []
            
            for count in 0..<arr_JustAdded.count {
                let dict_Temp = arr_JustAdded[count] as! NSDictionary
                
                let objSub = GlobalObject()
                objSub.str_Lib_Id =  dict_Temp.getStringForID(key: "id")
                objSub.str_Lib_User_Id =  dict_Temp.getStringForID(key: "user_id")
                objSub.str_Lib_Title =  dict_Temp.getStringForID(key: "title")
                objSub.str_Lib_Text =  dict_Temp.getStringForID(key: "text")
                objSub.str_Lib_Type =  dict_Temp.getStringForID(key: "type")
                objSub.str_Lib_Image =  dict_Temp.getStringForID(key: "image")
                objSub.str_Lib_Progress =  dict_Temp.getStringForID(key: "progress")
                objSub.str_Lib_Status =  dict_Temp.getStringForID(key: "status")
                objSub.str_Lib_Created_At =  dict_Temp.getStringForID(key: "created_at")
                objSub.str_Lib_Updated_At =  dict_Temp.getStringForID(key: "updated_at")
                objSub.str_Lib_Deleted_At =  dict_Temp.getStringForID(key: "deleted_at")
                objSub.str_Lib_Note_Count =  dict_Temp.getStringForID(key: "note_count")
                objSub.str_Lib_Total_Time =  dict_Temp.getStringForID(key: "total_time")
                
                if vw_TabBarController?.popupBar.isHidden == false && obj_Player.str_Lib_Id == objSub.str_Lib_Id{
                }else{
                    obj_Main.arr_JustCreated.add(objSub)
                }
            }
            
            for count in 0..<arr_Recent.count {
                let dict_Temp = arr_Recent[count] as! NSDictionary
                
                let objSub = GlobalObject()
                objSub.str_Lib_Id =  dict_Temp.getStringForID(key: "id")
                objSub.str_Lib_User_Id =  dict_Temp.getStringForID(key: "user_id")
                objSub.str_Lib_Title =  dict_Temp.getStringForID(key: "title")
                objSub.str_Lib_Text =  dict_Temp.getStringForID(key: "text")
                objSub.str_Lib_Type =  dict_Temp.getStringForID(key: "type")
                objSub.str_Lib_Image =  dict_Temp.getStringForID(key: "image")
                objSub.str_Lib_Progress =  dict_Temp.getStringForID(key: "progress")
                objSub.str_Lib_Status =  dict_Temp.getStringForID(key: "status")
                objSub.str_Lib_Created_At =  dict_Temp.getStringForID(key: "created_at")
                objSub.str_Lib_Updated_At =  dict_Temp.getStringForID(key: "updated_at")
                objSub.str_Lib_Deleted_At =  dict_Temp.getStringForID(key: "deleted_at")
                objSub.str_Lib_Note_Count =  dict_Temp.getStringForID(key: "note_count")
                objSub.str_Lib_Total_Time =  dict_Temp.getStringForID(key: "total_time")
                
                if vw_TabBarController?.popupBar.isHidden == false && obj_Player.str_Lib_Id == objSub.str_Lib_Id{
                }else{
                    obj_Main.arr_ContinueReading.add(objSub)
                }
            }
            
            for count in 0..<arr_Complted.count {
                let dict_Temp = arr_Complted[count] as! NSDictionary
                
                let objSub = GlobalObject()
                objSub.str_Lib_Id =  dict_Temp.getStringForID(key: "id")
                objSub.str_Lib_User_Id =  dict_Temp.getStringForID(key: "user_id")
                objSub.str_Lib_Title =  dict_Temp.getStringForID(key: "title")
                objSub.str_Lib_Text =  dict_Temp.getStringForID(key: "text")
                objSub.str_Lib_Type =  dict_Temp.getStringForID(key: "type")
                objSub.str_Lib_Image =  dict_Temp.getStringForID(key: "image")
                objSub.str_Lib_Progress =  dict_Temp.getStringForID(key: "progress")
                objSub.str_Lib_Status =  dict_Temp.getStringForID(key: "status")
                objSub.str_Lib_Created_At =  dict_Temp.getStringForID(key: "created_at")
                objSub.str_Lib_Updated_At =  dict_Temp.getStringForID(key: "updated_at")
                objSub.str_Lib_Deleted_At =  dict_Temp.getStringForID(key: "deleted_at")
                objSub.str_Lib_Note_Count =  dict_Temp.getStringForID(key: "note_count")
                objSub.str_Lib_Total_Time =  dict_Temp.getStringForID(key: "total_time")
                
                if vw_TabBarController?.popupBar.isHidden == false && obj_Player.str_Lib_Id == objSub.str_Lib_Id{
                }else{
                    obj_Main.arr_InProgress.add(objSub)
                }
            }
            
            for count in 0..<arr_NotAdded.count {
                let dict_Temp = arr_NotAdded[count] as! NSDictionary
                
                let objSub = GlobalObject()
                objSub.str_Lib_Id =  dict_Temp.getStringForID(key: "id")
                objSub.str_Lib_User_Id =  dict_Temp.getStringForID(key: "user_id")
                objSub.str_Lib_Title =  dict_Temp.getStringForID(key: "title")
                objSub.str_Lib_Text =  dict_Temp.getStringForID(key: "text")
                objSub.str_Lib_Type =  dict_Temp.getStringForID(key: "type")
                objSub.str_Lib_Image =  dict_Temp.getStringForID(key: "image")
                objSub.str_Lib_Progress =  dict_Temp.getStringForID(key: "progress")
                objSub.str_Lib_Status =  dict_Temp.getStringForID(key: "status")
                objSub.str_Lib_Created_At =  dict_Temp.getStringForID(key: "created_at")
                objSub.str_Lib_Updated_At =  dict_Temp.getStringForID(key: "updated_at")
                objSub.str_Lib_Deleted_At =  dict_Temp.getStringForID(key: "deleted_at")
                objSub.str_Lib_Note_Count =  dict_Temp.getStringForID(key: "note_count")
                objSub.str_Lib_Total_Time =  dict_Temp.getStringForID(key: "total_time")
                
                if vw_TabBarController?.popupBar.isHidden == false && obj_Player.str_Lib_Id == objSub.str_Lib_Id{
                }else{
                    obj_Main.arr_Completed.add(objSub)
                }
            }
            
            tbl_Main.reloadData()
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        arr_Main = []
        bool_Load = false
        tbl_Main.reloadData()
    }
}

extension IAPHandler : WebServiceHelperDelegate{
    //MARK: - IAPHandler -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "add_subscription"{
            
            let arr_responseLanguage = response["languages"] as! NSArray
            let arr_responseVoices = response["voices"] as! NSArray
            let arr_responseSubscription = response["subscriptions"] as! NSArray
            
            arr_Languages = []
            for i in 0..<arr_responseLanguage.count{
                let dict_Temp : NSDictionary = arr_responseLanguage[i] as! NSDictionary
                
                let objSub = GlobalObject()
                objSub.str_Lan_Id =  dict_Temp.getStringForID(key: "id")
                objSub.str_Lan_Name =  dict_Temp.getStringForID(key: "name")
                objSub.str_Lan_Code =  dict_Temp.getStringForID(key: "iso_code")
                objSub.str_Lan_Active =  dict_Temp.getStringForID(key: "active")
                
                arr_Languages.add(objSub)
            }
            
            arr_Voice = []
            for i in 0..<arr_responseVoices.count{
                let dict_Temp : NSDictionary = arr_responseVoices[i] as! NSDictionary
                
                let objSub = GlobalObject()
                objSub.str_Voice_Id =  dict_Temp.getStringForID(key: "id")
                objSub.str_Voice_Name =  dict_Temp.getStringForID(key: "name")
                objSub.str_Voice_Code =  dict_Temp.getStringForID(key: "code")
                objSub.str_Voice_Active =  dict_Temp.getStringForID(key: "active")
                
                arr_Voice.add(objSub)
            }
            
            arr_Subscription = []
            for i in 0..<arr_responseSubscription.count{
                let dict_Temp : NSDictionary = arr_responseSubscription[i] as! NSDictionary
                
                let objSub = GlobalObject()
                objSub.str_Sub_Id =  dict_Temp.getStringForID(key: "id")
                objSub.str_Sub_Code =  dict_Temp.getStringForID(key: "code")
                objSub.str_Sub_Expiry_date =  dict_Temp.getStringForID(key: "expiry_date")
                objSub.str_Sub_Type =  dict_Temp.getStringForID(key: "type")
                objSub.str_Sub_Active =  dict_Temp.getStringForID(key: "active")
                
                arr_Subscription.add(objSub)
            }
            
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadSubscription"), object: nil)
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadSubscription2"), object: nil)
             NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadAds1"), object: nil)
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadAds2"), object: nil)
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadAds3"), object: nil)
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}


extension ProfileViewViewController : WebServiceHelperDelegate{
    //MARK: - ProfileViewViewController -
    func appDataDidSuccess(_ data: Any, request strRequest: String) {
        
        let response = data as! NSDictionary
        if strRequest == "update_profile_image" {
            
            vw_Bottom.isHidden = true
            userObjectUpdate(dict_Get : response)
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadsidemenu"), object: nil)
        }
    }
    
    func appDataDidFail(_ error: Error, request strRequest: String) {
        
    }
}



